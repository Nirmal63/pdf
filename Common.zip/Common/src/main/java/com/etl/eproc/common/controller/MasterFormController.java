/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.model.TblCellMaster;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblClientBusinessType;
import com.etl.eproc.common.model.TblColumnMaster;
import com.etl.eproc.common.model.TblColumnType;
import com.etl.eproc.common.model.TblComboDetail;
import com.etl.eproc.common.model.TblDepartment;
import com.etl.eproc.common.model.TblFormBusinessType;
import com.etl.eproc.common.model.TblFormCategory;
import com.etl.eproc.common.model.TblFormMaster;
import com.etl.eproc.common.model.TblFormProduct;
import com.etl.eproc.common.model.TblFormRule;
import com.etl.eproc.common.model.TblFormRuleDetail;
import com.etl.eproc.common.model.TblMasterBid;
import com.etl.eproc.common.model.TblProduct;
import com.etl.eproc.common.model.TblProductCategory;
import com.etl.eproc.common.model.TblSubModule;
import com.etl.eproc.common.model.TblTableMaster;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.vendor.services.VendorPQAuditTrailService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.ManageItemService;
import com.etl.eproc.common.services.MasterFormService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.vendor.model.TblCompanyCell;
import com.etl.eproc.vendor.model.TblCompanyForm;
import com.etl.eproc.vendor.model.TblCompanyTable;
import com.etl.eproc.vendor.services.VendorEnlistmentService;

/**
 *
 * @author taher.tinwala
 */
@Controller
@RequestMapping("/common")
public class MasterFormController {

    private static final String TABLE_ID = "tableId";
    private static final String FORM_ID = "formId";
    private static final String HIDDEN_FORM_ID = "hdFormId";
    private static final String HIDDEN_TABLE_ID = "hdTableId";
    private static final String HDDATATYPE = "hdDataType_";
    private static final String HDDFILLEDBY = "hdFilledBy_";
    private static final String HDCOLUMNID = "hdColumnId_";
    private static final int PENDING_STATUS = 0;
    private static final int ZERO_VALUE = 0;
    private static final int IS_ACTIVE_STATUS = 1;
    private static final String REDIRECT_SESSION_EXPIRED = "redirect:/sessionexpired";
    private static final String SESSIONOBJECT = "sessionObject";
    @Autowired
    private FileUploadService fileUploadService;    
    @Autowired
    private VendorEnlistmentService vendorEnlistmentService;
    @Autowired
    private MasterFormService masterFormService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private VendorPQAuditTrailService vendorPQAuditTrailService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private ModelToSelectItem modelToSelectItem;    
    @Autowired
    private CommonService commonService;
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Value("#{vendorlinkProperties['bidder_manage_form_upload_document']?:565}")
    private int uploadBidderDocLinkId;
    @Value("#{linkProperties['master_form_library_form_dashboard_add_matrix']?:503}")
    private int masterFormMatrix;
    @Value("#{linkProperties['master_form_library_form_dashboard_edit_matrix']?:504}")
    private int masterFormMatrixEdit;
    @Value("#{vendorlinkProperties['enlistment_form_add_matrix']?:541}")
    private int vendorFormMatrix;
    @Value("#{vendorlinkProperties['enlistment_form_edit_matrix']?:542}")
    private int vendorFormMatrixEdit;
    @Value("#{vendorAuditTrailProperties['createFormMatrix']}")
    private String createVendorFormMatrixAudit;
    @Value("#{adminAuditTrailProperties['createFormMatrix']}")
    private String createMasterFormMatrixAudit;
    @Value("#{vendorAuditTrailProperties['editFormMatrix']}")
    private String editVendorFormMatrixAudit;
    @Value("#{adminAuditTrailProperties['editFormMatrix']}")
    private String editMasterFormMatrixAudit;
    @Value("#{vendorAuditTrailProperties['addFormMatrixEdit']}")
    private String addVendorFormMatrixEditAudit;
    @Value("#{adminAuditTrailProperties['addFormMatrixEdit']}")
    private String addMasterFormMatrixEditAudit;
    @Value("#{vendorAuditTrailProperties['addFormMatrixCreate']}")
    private String addVendorFormMatrixCreateAudit;
    @Value("#{adminAuditTrailProperties['addFormMatrixCreate']}")
    private String addMasterFormMatrixCreateAudit;
    @Value("#{vendorAuditTrailProperties['addBidForm']}")
    private String addVendorBidAudit;    
    @Value("#{vendorAuditTrailProperties['addBidFormEdit']}")
    private String addVendorBidEditAudit;    
    @Value("#{vendorAuditTrailProperties['viewBidForm']}")
    private String viewVendorBidAudit;    
    @Value("#{adminAuditTrailProperties['viewBidForm']}")
    private String viewMasterBidAudit;    
    @Value("#{linkProperties['master_form_library_view_bid']?:467}")
    private int masterBidView;
    @Value("#{linkProperties['master_form_library_bidding_form_view']?:494}")
    private int masterFormView;
    @Value("#{vendorlinkProperties['bidder_manage_form_fill']?:561}")
    private int vendorFormFill;
    @Value("#{vendorlinkProperties['bidder_manage_form_edit']?:562}")
    private int vendorFormEditFill;
    @Value("#{vendorlinkProperties['bidder_manage_form_view']?:563}")
    private int vendorFormViewFill;
    @Value("#{vendorlinkProperties['enlistment_form_view_form']?:530}")
    private int vendorFormView;
    @Value("#{vendorAuditTrailProperties['viewForm']}")
    private String viewVendorFormAudit;
    @Value("#{adminAuditTrailProperties['viewForm']}")
    private String viewMasterFormAudit;
    @Value("#{linkProperties['master_form_library_bidding_form_test']?:495}")
    private int masterFormTest;
    @Value("#{linkProperties['master_form_library_create_bid']?:465}")
    private int masterFormBid;
    @Value("#{linkProperties['master_form_library_edit_bid']?:466}")
    private int masterEditFormBid;
    @Value("#{linkProperties['master_form_library_bidding_form_approve']?:496}")
    private int masterFormApprove;
    @Value("#{linkProperties['master_form_library_bidding_form_cancel']?:497}")
    private int masterFormCancel;
    @Value("#{vendorlinkProperties['enlistment_form_test_form']?:531}")
    private int vendorFormTest;
    @Value("#{vendorlinkProperties['enlistment_form_approve_form']?:534}")
    private int vendorFormApprove;
    @Value("#{vendorlinkProperties['enlistment_form_delete_form']?:532}")
    private int vendorFormDelete;
    @Value("#{vendorlinkProperties['enlistment_form_cancel_form']?:535}")
    private int vendorFormCancel;
    @Value("#{vendorAuditTrailProperties['testForm']}")
    private String testVendorFormAudit;
    @Value("#{adminAuditTrailProperties['testForm']}")
    private String testMasterFormAudit;
    @Value("#{adminAuditTrailProperties['bidForm']}")
    private String bidMasterFormAudit;
    @Value("#{vendorAuditTrailProperties['bidForm']}")
    private String bidVendorFormAudit;
    @Value("#{vendorAuditTrailProperties['bidEditForm']}")
    private String bidVendorEditForm;
    @Value("#{adminAuditTrailProperties['bidEditForm']}")
    private String bidMasterEditForm;
    @Value("#{adminAuditTrailProperties['viewTable']}")
    private String viewMasterTable;
    @Value("#{vendorAuditTrailProperties['viewTable']}")
    private String viewVendorTable;
    @Value("#{adminAuditTrailProperties['approveForm']}")
    private String approveMasterForm;
    @Value("#{adminAuditTrailProperties['cancelForm']}")
    private String cancelMasterForm;
    @Value("#{vendorAuditTrailProperties['approveForm']}")
    private String approveVendorForm;
    @Value("#{vendorAuditTrailProperties['cancelForm']}")
    private String cancelVendorForm;
    @Value("#{adminAuditTrailProperties['approveFormPage']}")
    private String approveMasterFormPage;
    @Value("#{adminAuditTrailProperties['cancelFormPage']}")
    private String cancelMasterFormPage;
    @Value("#{vendorAuditTrailProperties['approveFormPage']}")
    private String approveVendorFormPage;
    @Value("#{vendorAuditTrailProperties['cancelFormPage']}")
    private String cancelVendorFormPage;
    @Value("#{vendorAuditTrailProperties['deleteForm']}")
    private String deleteVendorForm;
    
    @Value("#{linkProperties['master_form_library_form_dashboard_view_table']?:502}")
    private int masterViewTableLinkId;
    @Value("#{vendorlinkProperties['enlistment_form_view_table']?:540}")
    private int vendorViewTableLinkId;    
//    @Value("#{vendorProperties['datatype_smalltext']?:1}")
//    private int smalltext;
    @Value("#{vendorProperties['datatype_longtext']?:2}")
    private int longtext;
//    @Value("#{vendorProperties['datatype_numeric']?:3}")
//    private int numeric;
//    @Value("#{vendorProperties['datatype_money']?:4}")
//    private int money;
//    @Value("#{vendorProperties['datatype_money_all']?:5}")
//    private int moneyall;
    @Value("#{vendorProperties['datatype_combo']?:6}")
    private int combobox;
    @Value("#{vendorProperties['datatype_listbox']?:9}")
    private int listBox;
    
    @Value("#{adminAuditTrailProperties['getcreatemsterformremark']}")
    private String getCreateMsterFormRemark;
    @Value("#{adminAuditTrailProperties['postcreatemsterformremark']}")
    private String postCreateMsterFormRemark;
    @Value("#{adminAuditTrailProperties['geteditmsterformremark']}")
    private String getEditMsterFormRemark;
    @Value("#{adminAuditTrailProperties['posteditmsterformremark']}")
    private String postEditMsterFormRemark;
    
    @Value("#{vendorAuditTrailProperties['getcreatevendorformremark']}")
    private String getCreateVendorFormRemark;
    @Value("#{vendorAuditTrailProperties['postcreatevendorformremark']}")
    private String postCreateVendorFormRemark;
    @Value("#{vendorAuditTrailProperties['geteditvendorformremark']}")
    private String getEditVendorFormRemark;
    @Value("#{vendorAuditTrailProperties['posteditvendorformremark']}")
    private String postEditVendorFormRemark;
    
    @Value("#{adminAuditTrailProperties['managemasterform']}")
    private String manageMasterFormAudit;
    @Value("#{adminAuditTrailProperties['biddermasterform']}")
    private String bidderMasterFormAudit;
    @Value("#{vendorAuditTrailProperties['managevendorenlistmentform']}")
    private String manageVendorEnlistmentFormAudit;
    

    @Value("#{adminAuditTrailProperties['getformtables']}")
    private String getFormTablesRemark;
    @Value("#{adminAuditTrailProperties['postformtables']}")
    private String postFormTablesRemark;
    @Value("#{adminAuditTrailProperties['getaddformtable']}")
    private String getAddFormTableRemark;
    @Value("#{adminAuditTrailProperties['postaddformtable']}")
    private String postAddFormTableRemark;
    @Value("#{adminAuditTrailProperties['geteditformtable']}")
    private String getEditFormTableRemark;
    @Value("#{adminAuditTrailProperties['postupdateformtable']}")
    private String postUpdateFormTableRemark;
    
    @Value("#{vendorAuditTrailProperties['getRuleconfigured']}")
    private String getRuleconfigured;
    @Value("#{vendorAuditTrailProperties['postRuleconfigured']}")
    private String postRuleconfigured;
    @Value("#{vendorAuditTrailProperties['getRulecreated']}")
    private String getRulecreated;
    @Value("#{vendorAuditTrailProperties['postRulecreated']}")
    private String postRulecreated;
    
    @Value("#{projectProperties['master_form_module_id']?:40}")
    private int masterFormModuleId;
    @Value("#{projectProperties['vendor_enlistment_module_id']?:41}")
    private int vendorEnlistmentModuleId;
    @Value("#{vendorlinkProperties['enlistment_configuration_document_upload']?:743}")
    private int enlistmentOfficerDocLinkId;
    
    @Value("#{linkProperties['report_vendor_manage_master_form']?:52}")//todo
    private int reportVendorManageMasterForm;
    @Value("#{vendorlinkProperties['report_vendor_manage_vendor_form']?:60}")//todo
    private int reportVendorManageVendorForm;
    @Value("#{vendorlinkProperties['report_vendor_manage_bidder_vendor_form']?:55}")//todo
    private int reportVendorManageBidderVendorForm;
    
    @Value("#{linkProperties['master_form_library_bidding_form_create']?:492}")
    private int masterFormCreate;
    @Value("#{linkProperties['master_form_library_bidding_form_edit']?:493}")
    private int masterFormEdit;
    @Value("#{vendorlinkProperties['enlistment_form_create_form']?:528}")
    private int vendorEnlistFormCreate;
    @Value("#{vendorlinkProperties['enlistment_form_edit_form']?:529}")
    private int vendorEnlistFormEdit;
    
    @Value("#{linkProperties['master_form_library_form_dashboard_dashboard']?:499}")
    private int masterFormLibraryDashBoard;
    @Value("#{vendorlinkProperties['enlistment_form_dashboard']?:537}")
    private int enlistmentFormLibraryDashBoard;
    		
    @Value("#{linkProperties['master_form_library_form_dashboard_add_table']?:500}")
    private int masterFormTableCreate;
    @Value("#{linkProperties['master_form_library_form_dashboard_edit_table']?:501}")
    private int masterFormTableEdit;
    @Value("#{vendorlinkProperties['enlistment_form_add_table']?:538}")
    private int vendorFormTableCreate;
    @Value("#{vendorlinkProperties['enlistment_form_edit_table']?:539}")
    private int vendorFormTableEdit;
    
    @Value("#{linkProperties['master_form_library_bidding_form_manage']?:498}")
    private int manageMasterForm;
    @Value("#{linkProperties['bidding_form_master_form_library']?:491}")
    private int bidderMasterForm;
    @Value("#{vendorlinkProperties['enlistment_form_manage_form']?:536}")
    private int mangeVendorForm;
    @Value("#{vendorlinkProperties['enlistment_form_configure_rule']?:533}")
    private int enilstmentFormRuleConfiguration;
    @Value("#{vendorlinkProperties['enlistment_form_rule_detail']?:572}")
    private int enilstmentFormRuleDetail;
    
    


    /**
     * Create Form Matrix GET
     *
     * @param tenderId
     * @param formOperation
     * @param fromDash
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/createformmatrix/{formId}/{tableId}/{formOperation}/{enc}", method = RequestMethod.GET)
    public String createFormMatrix(@PathVariable("formId") Integer formId, @PathVariable("tableId") Integer tableId, @PathVariable("formOperation") String formOperation, ModelMap modelMap, HttpServletRequest request) {
        int subModuleId = 0;
        try {
            List<Object[]> list = masterFormService.getTableDetails(formId, tableId);
            int rowCount = 0;
            if (list != null && !list.isEmpty()) {
                rowCount = (Integer) list.get(0)[0];
                subModuleId = (Integer)list.get(0)[5];
                modelMap.addAttribute("subModuleId", subModuleId);
                modelMap.addAttribute("rowcount", rowCount);
                modelMap.addAttribute("colcount", list.get(0)[1]);
                modelMap.addAttribute("tableName", list.get(0)[2]);
                modelMap.addAttribute(TABLE_ID, tableId);
            }
            modelMap.addAttribute("filledBy", masterFormService.getFilledBy());
            modelMap.addAttribute("dataType", masterFormService.getDataType());
            modelMap.addAttribute("showHide", masterFormService.getShowHide());
            List<TblColumnMaster> columns = masterFormService.getColumnMasterByTableId(tableId);
            modelMap.addAttribute("columns", columns);
            if (!columns.isEmpty()) {
                List<TblCellMaster> cells = masterFormService.getCellMasterByTableId(tableId, 0);
                modelMap.addAttribute("cells", cells);
            }
            modelMap.addAttribute("decimalUpto", 5);//can be selected from client if required
            List<Object[]> combo = masterFormService.getClientCombo(abcUtility.getSessionClientId(request));
            List<SelectItem> clientCombo = new ArrayList<SelectItem>();
            List<SelectItem> clientListBox = new ArrayList<SelectItem>();
            for (Object[] cmb : combo) {
                if ((Integer) cmb[2] == 1) {
                    clientCombo.add(new SelectItem(cmb[1], cmb[0]));
                } else if ((Integer) cmb[2] == 2) {
                    clientListBox.add(new SelectItem(cmb[1], cmb[0]));
                }
            }
            modelMap.addAttribute("clientCombo", clientCombo);
            modelMap.addAttribute("clientListBox", clientListBox);
//            }

        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            int auditId = subModuleId == vendorEnlistmentModuleId ? (formOperation.equals("1") ? vendorFormMatrix : vendorFormMatrixEdit) : (formOperation.equals("1") ? masterFormMatrix : masterFormMatrixEdit);
            String auditMsg = subModuleId == vendorEnlistmentModuleId ? (formOperation.equals("1") ? createVendorFormMatrixAudit : editVendorFormMatrixAudit) : (formOperation.equals("1") ? createMasterFormMatrixAudit : editMasterFormMatrixAudit);
            if(subModuleId == vendorEnlistmentModuleId){
                vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),auditId , auditMsg, formId, tableId);
            }else{
                 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),auditId , auditMsg, formId, tableId);
            }
        }
        return "/common/admin/CreateFormMatrix";
    }

    @RequestMapping(value = "/admin/addformmatrix", method = RequestMethod.POST)
    public String addFormMatrix(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        boolean success = false;
        int formId = StringUtils.hasLength(request.getParameter(HIDDEN_FORM_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_FORM_ID)) : 0;
        int tableId = StringUtils.hasLength(request.getParameter(HIDDEN_TABLE_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TABLE_ID)) : 0;
        int subModuleId = StringUtils.hasLength(request.getParameter("hdSubModuleId")) ? Integer.parseInt(request.getParameter("hdSubModuleId")) : 0;        
        int formOperation = StringUtils.hasLength(request.getParameter("hdFormOperation")) ? Integer.parseInt(request.getParameter("hdFormOperation")) : 0;
        if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
            int col = StringUtils.hasLength(request.getParameter("txtCol")) ? Integer.parseInt(request.getParameter("txtCol")) : 0;
            int row = StringUtils.hasLength(request.getParameter("txtRow")) ? Integer.parseInt(request.getParameter("txtRow")) : 0;
            try {
                int userId = abcUtility.getSessionUserDetailId(request);
                Map<String, Object> params = new HashMap<String, Object>();
                Map<String, Boolean> operation = new HashMap<String, Boolean>();
                switch (formOperation) {
                    case 1:// Update with none of the below given operations/Fresh Insert 
                    case 3:// I want to update Data Type, Filled by option[updateall]
                    case 4:// I want to update form with Add Column operation[updateall]
                    case 5://I want to update form with Delete Column operation[DeleteInsert]
                    case 6://I want to update form with Add Row/Delete Row operation
                        List<TblColumnMaster> tenderColumns = new ArrayList<TblColumnMaster>();
                        List<TblCellMaster> tenderCells = new ArrayList<TblCellMaster>();
                        //Filled By - Auctioner:1, Bidder:2, Auto:3, Proxy Bid Column:4
                        //Data Type - SmallText:1, LongText:2, +No. with (.):3, +No. without (.):4, All Numbers:8
                        int cellNo = 0;
                        for (int i = 0; i < col; i++) {
                            TblColumnMaster tenderColumn = new TblColumnMaster();
                            tenderColumn.setColumnHeader(request.getParameter("txtacolHeader_" + i));
                            tenderColumn.setTblFormMaster(new TblFormMaster(formId));
                            tenderColumn.setDataType(Integer.parseInt(StringUtils.hasLength(request.getParameter("selDataType_" + i)) ? request.getParameter("selDataType_" + i) : StringUtils.hasLength(request.getParameter(HDDATATYPE + i)) ? request.getParameter(HDDATATYPE + i) : "0"));
                            tenderColumn.setFilledBy(Integer.parseInt(StringUtils.hasLength(request.getParameter("selFilledBy_" + i)) ? request.getParameter("selFilledBy_" + i) : StringUtils.hasLength(request.getParameter(HDDFILLEDBY + i)) ? request.getParameter(HDDFILLEDBY + i) : "0"));

                            tenderColumn.setIsShown(Integer.parseInt(StringUtils.hasLength(request.getParameter("selShowHide_" + i)) ? request.getParameter("selShowHide_" + i) : StringUtils.hasLength(request.getParameter("hdShowHide_" + i)) ? request.getParameter("hdShowHide_" + i) : "0"));
                            tenderColumn.setColumnNo(i + 1);
                            tenderColumn.setSortOrder(Integer.parseInt(StringUtils.hasLength(request.getParameter("txtColSortOrder_" + i)) ? request.getParameter("txtColSortOrder_" + i) : "0"));
                            tenderColumn.setTblTableMaster(new TblTableMaster(tableId));
                            tenderColumn.setTblColumnType(new TblColumnType(6));
                            if (formOperation == 3 || formOperation == 4 || formOperation == 6) {
                                tenderColumn.setColumnId(StringUtils.hasLength(request.getParameter(HDCOLUMNID + i)) ? Integer.parseInt(request.getParameter(HDCOLUMNID + i)) : 0);
                            }
                            for (int j = 0; j < row; j++) {
                                TblCellMaster tenderCell = new TblCellMaster();
                                tenderCell.setCellNo(cellNo);
                                tenderCell.setTblFormMaster(new TblFormMaster(formId));
                                tenderCell.setRowId(Integer.parseInt(StringUtils.hasLength(request.getParameter("txtRowSort_" + j)) ? request.getParameter("txtRowSort_" + j) : "0"));
                                tenderCell.setTblColumnMaster(tenderColumn);
                                tenderCell.setTblTableMaster(new TblTableMaster(tableId));
                                if (tenderColumn.getFilledBy() == 1) {
                                    if (tenderColumn.getDataType() == longtext) {
                                        tenderCell.setCellValue(request.getParameter("txtacell_" + j + "_" + i));
                                    } else {
                                        tenderCell.setCellValue(request.getParameter("txtcell_" + j + "_" + i));
                                    }
                                }
                                if (tenderColumn.getFilledBy() == 2) {
                                    tenderCell.setDataType(Integer.parseInt(StringUtils.hasLength(request.getParameter("selCellType_" + j + "_" + i)) ? request.getParameter("selCellType_" + j + "_" + i) : "0"));
                                    if (tenderCell.getDataType() == combobox) {
                                        tenderCell.setObjectId(Integer.parseInt(StringUtils.hasLength(request.getParameter("selClientCombo_" + j + "_" + i)) ? request.getParameter("selClientCombo_" + j + "_" + i) : "0"));
                                    }
                                    if (tenderCell.getDataType() == listBox) {
                                        tenderCell.setObjectId(Integer.parseInt(StringUtils.hasLength(request.getParameter("selClientCombo_" + j + "_" + i)) ? request.getParameter("selClientCombo_" + j + "_" + i) : "0"));
                                    }
                                } else {
                                    tenderCell.setDataType(tenderColumn.getDataType());
                                }
                                if (tenderCell.getCellValue() == null) {
                                    tenderCell.setCellValue("");
                                }
                                if (formOperation == 3) {
                                    tenderCell.setCellId(StringUtils.hasLength(request.getParameter("hdCellId_" + j + "_" + i)) ? Integer.parseInt(request.getParameter("hdCellId_" + j + "_" + i)) : 0);
                                }
                                tenderCells.add(tenderCell);
                                cellNo++;
                            }
                            tenderColumns.add(tenderColumn);
                        }
                        if (formOperation == 6 || formOperation == 4) {
                            //tm
                            operation.put("deleteFormCell", true);
                            params.put(TABLE_ID, tableId);
                            params.put(FORM_ID, formId);
//                            formService.deleteFormCell(tableId);
                        }

                        if (formOperation != 3) {
                            //tm
                            operation.put("addFormMatrix", true);
                            params.put("TblColumnMasters", tenderColumns);
                            params.put("TblCellMasters", tenderCells);
                            params.put("noOfRows", row);
                            params.put("noOfCols", col);
                            params.put("createdBy", userId);
                            params.put("isEdit", formOperation == 5);
//                            success = formService.addFormMatrix(auctionColumns, auctionCells, row, col, userId, formOperation == 5);
                        } else {
                            //tm
                            operation.put("addFormMatrix", true);
                            params.put("TblColumnMasters", tenderColumns);
                            params.put("TblCellMasters", tenderCells);
                            params.put("noOfRows", 0);
                            params.put("noOfCols", 0);
                            params.put("createdBy", userId);
                            params.put("isEdit", false);
//                            success = formService.addFormMatrix(auctionColumns, auctionCells, 0, 0, userId, false);
                        }
                        success = masterFormService.addFormMatrix(params, operation);
                        break;
                    case 2://I want to update Column/Row Description
                        List<Map<Integer, String>> colHead = new ArrayList<Map<Integer, String>>();
                        List<Map<Integer, String>> cellVal = new ArrayList<Map<Integer, String>>();
                        List<Map<Integer, Integer[]>> bidderCell = new ArrayList<Map<Integer, Integer[]>>();
                        for (int i = 0; i < col; i++) {
                            if (StringUtils.hasLength(request.getParameter(HDCOLUMNID + i)) && StringUtils.hasLength(request.getParameter("txtacolHeader_" + i))
                                    && StringUtils.hasLength(request.getParameter("hdColumnHeader_" + i))
                                    && !request.getParameter("hdColumnHeader_" + i).equals(request.getParameter("txtacolHeader_" + i))) {
                                //tm
                                Map<Integer, String> column = new HashMap<Integer, String>();
                                column.put(Integer.parseInt(request.getParameter(HDCOLUMNID + i)), request.getParameter("txtacolHeader_" + i));
                                colHead.add(column);
//                                formService.updateColumnHeader(Integer.parseInt(request.getParameter(HDCOLUMNID + i)), request.getParameter("txtacolHeader_" + i));
                            }
                            for (int j = 0; j < row; j++) {
                                String cellValue = null;
                                int cellId = 0;
                                if (StringUtils.hasLength(request.getParameter(HDDATATYPE + i)) && StringUtils.hasLength(request.getParameter(HDDFILLEDBY + i)) && Integer.parseInt(request.getParameter(HDDFILLEDBY + i)) == 1) {
                                    if (Integer.parseInt(request.getParameter(HDDATATYPE + i)) != longtext) {
                                        cellValue = request.getParameter("txtcell_" + j + "_" + i);
                                    } else {
                                        cellValue = request.getParameter("txtacell_" + j + "_" + i);
                                    }
                                    if (StringUtils.hasLength(cellValue) && !cellValue.equals(request.getParameter("hdCellValue_" + j + "_" + i))) {
                                        cellId = StringUtils.hasLength(request.getParameter("hdCellId_" + j + "_" + i)) ? Integer.parseInt(request.getParameter("hdCellId_" + j + "_" + i)) : 0;
                                        //tm
                                        Map<Integer, String> cell = new HashMap<Integer, String>();
                                        cell.put(cellId, cellValue);
                                        cellVal.add(cell);
//                                        formService.updateCellValue(cellId, cellValue);
                                    }
                                }
                                int dataType = 0;
                                int objectId = 0;
                                if (StringUtils.hasLength(request.getParameter(HDDFILLEDBY + i)) && Integer.parseInt(request.getParameter(HDDFILLEDBY + i)) == 2) {
                                    if (StringUtils.hasLength(request.getParameter("hdCellType_" + j + "_" + i))) {
                                        boolean toBeUpdate = false;
                                        cellId = StringUtils.hasLength(request.getParameter("hdCellId_" + j + "_" + i)) ? Integer.parseInt(request.getParameter("hdCellId_" + j + "_" + i)) : 0;
                                        if (!request.getParameter("hdCellType_" + j + "_" + i).equals(request.getParameter("selCellType_" + j + "_" + i))) {
                                            dataType = Integer.parseInt(request.getParameter("selCellType_" + j + "_" + i));
                                            toBeUpdate = true;
                                        }
                                        if (StringUtils.hasLength(request.getParameter("selClientCombo_" + j + "_" + i))) {
                                            dataType = Integer.parseInt(request.getParameter("selCellType_" + j + "_" + i));
                                            if ((dataType == combobox || dataType == listBox) && !request.getParameter("selClientCombo_" + j + "_" + i).equals(request.getParameter("hdObjectId_" + j + "_" + i))) {
                                                objectId = Integer.parseInt(request.getParameter("selClientCombo_" + j + "_" + i));
                                                toBeUpdate = true;
                                            }
                                        }
                                        if (toBeUpdate) {
                                            Map<Integer, Integer[]> cell = new HashMap<Integer, Integer[]>();
                                            cell.put(cellId, new Integer[]{dataType, objectId});
                                            bidderCell.add(cell);

                                        }
                                    }
                                }
                            }
                        }
                        success = masterFormService.updateFormHeadNCell(colHead, cellVal, bidderCell, tableId);
                        break;
                }
                if (success) {
                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), formOperation == 1 ? "redirect_success_addformmatrix" : "redirect_success_updateformmatrix");
                } else {
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                }
            } catch (Exception ex) {
                return exceptionHandlerService.writeLog(ex);
            } finally {
                int linkId=subModuleId==masterFormModuleId ? (formOperation == 1 ? masterFormMatrix : masterFormMatrixEdit) : (formOperation == 1 ? vendorFormMatrix : vendorFormMatrixEdit);
                String auditMsg=subModuleId==masterFormModuleId? (formOperation == 1 ? addMasterFormMatrixCreateAudit : addMasterFormMatrixEditAudit) : (formOperation == 1 ? addVendorFormMatrixCreateAudit : addVendorFormMatrixEditAudit);
                if(subModuleId == masterFormModuleId){
                    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId , auditMsg, formId, tableId);
                }else{
                     vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId , auditMsg, formId, tableId);
                }
            }
        } else {
            return REDIRECT_SESSION_EXPIRED;
        }
        return "redirect:/common/admin/tabledashboard/" + formId + encryptDecryptUtils.generateRedirect("common/admin/tabledashboard/" + formId, request);
    }

    /**
     * View Form Matrix GET
     *
     * @param tenderId
     * @param tableId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = {"/admin/viewform/{formId}/{objectId}/{enc}","/buyer/viewform/{formId}/{objectId}/{enc}"}, method = RequestMethod.GET)
    public String viewForm(@PathVariable("formId") Integer formId,@PathVariable("objectId") Integer tenderId, ModelMap modelMap, HttpServletRequest request) {
        int subModuleId = 0;
        try {

        	modelMap.addAttribute("tenderId", tenderId);
                masterFormService.setViewForm(formId, modelMap);
                subModuleId = ((TblFormMaster)modelMap.get("tblTenderForm")).getTblSubModule().getSubModuleId();
                modelMap.addAttribute("tblFormMaster",masterFormService.viewFormMasterList(formId));
                modelMap.addAttribute("productList",masterFormService.viewProductList(formId));
                modelMap.addAttribute("categoryList",masterFormService.viewCategoryList(formId));
                modelMap.addAttribute("businessType",masterFormService.viewBusinessList(formId));
                if(subModuleId == vendorEnlistmentModuleId){//officer doc listing for vendor pq
                    modelMap.addAttribute("docList",fileUploadService.getOfficerDocs(formId, abcUtility.getSessionClientId(request), enlistmentOfficerDocLinkId, 1));
                }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), subModuleId==vendorEnlistmentModuleId ? vendorFormView : masterFormView, subModuleId==vendorEnlistmentModuleId ? viewVendorFormAudit : viewMasterFormAudit, formId, 0);
            if(subModuleId == vendorEnlistmentModuleId){
                vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),vendorFormView , viewVendorFormAudit, formId, 0);
            }else{
                 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),masterFormView , viewMasterFormAudit, formId, 0);
            }
        }
        return "/common/admin/ViewForm";
    }

    /**
     * Test Form Matrix GET
     *
     * @param tenderId
     * @param tableId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/testform/{formId}/{enc}", method = RequestMethod.GET)
    public String testForm(@PathVariable("formId") Integer formId, ModelMap modelMap, HttpServletRequest request) {
        int subModuleId = 0;
        try {
            masterFormService.setViewForm(formId, modelMap);
            subModuleId = ((TblFormMaster)modelMap.get("tblTenderForm")).getTblSubModule().getSubModuleId();
            modelMap.addAttribute("decimalUpto", 5);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),subModuleId==vendorEnlistmentModuleId ? vendorFormTest : masterFormTest, subModuleId==vendorEnlistmentModuleId ? testVendorFormAudit : testMasterFormAudit, formId, 0);
            if(subModuleId == vendorEnlistmentModuleId){
                vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),vendorFormTest , testVendorFormAudit, formId, 0);
            }else{
                 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),masterFormTest , testMasterFormAudit, formId, 0);
            }
        }
        return "/common/admin/TestForm";
    }

    @RequestMapping(value = {"/admin/cancelform/{formId}/{enc}", "/admin/approveform/{formId}/{enc}", "/admin/deleteform/{formId}/{enc}"}, method = RequestMethod.GET)
    public String approveForm(@PathVariable("formId") Integer formId, ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes) {
    	boolean success = false;
    	boolean isDeleteForm = false;    	
    	int methodStatus = 0;//1:approve,2:cancel,3:delete
        int subModuleId=0;
        try {
        	if(request.getRequestURI().contains("deleteform")){
        		 success = masterFormService.deleteFormMaster(formId);
        		 redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_delete_form" : CommonKeywords.ERROR_MSG_KEY.toString());
        		 isDeleteForm = true;
                         methodStatus=3;
        	}else{
        		masterFormService.setViewForm(formId, modelMap);
                        subModuleId = ((TblFormMaster)modelMap.get("tblTenderForm")).getTblSubModule().getSubModuleId();
                if(request.getRequestURI().contains("cancelform")){
                    modelMap.addAttribute("iscancel", 1);
                    methodStatus=2;
                }else{
                    modelMap.addAttribute("isapprove", 1);
                    methodStatus=1;
                }
        	}
            
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {            
            int auditId = subModuleId==vendorEnlistmentModuleId ? (methodStatus==1 ? vendorFormApprove : methodStatus==2 ? vendorFormCancel : vendorFormDelete) : (methodStatus==1 ? masterFormApprove : masterFormCancel);
            String auditMsg = subModuleId==vendorEnlistmentModuleId ? (methodStatus==1 ? approveVendorFormPage : methodStatus==2 ? cancelVendorFormPage : deleteVendorForm) : (methodStatus==1 ? approveMasterFormPage : cancelMasterFormPage);
            if(subModuleId == vendorEnlistmentModuleId){
                vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),auditId , auditMsg, formId, 0);
            }else{
                 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),auditId , auditMsg, formId, 0);
            }
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), auditId, auditMsg, formId, 0);
        }
        
        return isDeleteForm ? "redirect:/common/admin/managevendorform"+ encryptDecryptUtils.generateRedirect("common/admin/managevendorform", request): "common/admin/ViewForm";
    }

    @RequestMapping(value = "/admin/submitapproveform", method = RequestMethod.POST)
    public String approveApproveForm(ModelMap modelMap, HttpServletRequest request, RedirectAttributes redirectAttributes) {
        String remarks = request.getParameter("txtaRemarks");
        int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
        int cstatus = StringUtils.hasLength(request.getParameter("hdCstatus")) ? Integer.parseInt(request.getParameter("hdCstatus")) : 0;        
        int subModuleId = StringUtils.hasLength(request.getParameter("hdSubModuleId")) ? Integer.parseInt(request.getParameter("hdSubModuleId")) : 0;        
        try {
            boolean updateSuccess = masterFormService.updateFormStatus(cstatus, abcUtility.getSessionUserId(request), formId);
            if (updateSuccess) {
                redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), cstatus==1 ? "redirect_success_formapproved" : "redirect_success_formcanceled");
            } else {
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {    
            int auditId = subModuleId==vendorEnlistmentModuleId ? (cstatus==1 ? vendorFormApprove : vendorFormCancel) : (cstatus==1 ? masterFormApprove : masterFormCancel);
            String auditMsg = subModuleId==vendorEnlistmentModuleId ? (cstatus==1 ? approveVendorForm : cancelVendorForm) : (cstatus==1 ? approveMasterForm : cancelMasterForm);
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), auditId,auditMsg, formId, 0, remarks);
            if(subModuleId == vendorEnlistmentModuleId){
                vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),auditId , auditMsg, formId, 0, remarks);
            }else{
                 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),auditId , auditMsg, formId, 0, remarks);
            }
        }
        return (subModuleId==masterFormModuleId) ? "redirect:/common/admin/managemasterform"+ encryptDecryptUtils.generateRedirect("common/admin/managemasterform", request) : "redirect:/common/admin/managevendorform"+ encryptDecryptUtils.generateRedirect("common/admin/managevendorform", request);
    }
    @RequestMapping(value = "/admin/viewtable/{formId}/{tableId}/{enc}", method = RequestMethod.GET)
    public String viewTable(@PathVariable("formId") int formId, @PathVariable("tableId") int tableId,
            HttpServletRequest request, ModelMap modelMap) {
        int subModuleId=0;
        try {
            List<Integer> formulaColId = new ArrayList<Integer>();
            List<Object[]> lstTblDetails = masterFormService.getTableDetails(formId, tableId);
            int rowCount = 0;
            if (!lstTblDetails.isEmpty()) {                
                rowCount = (Integer) lstTblDetails.get(0)[0];
                subModuleId = (Integer) lstTblDetails.get(0)[5];
                modelMap.put("rowcount", rowCount);
                modelMap.put("tableDtls", lstTblDetails);
            }
            modelMap.put("formulaColId", formulaColId);
            modelMap.put("cellDtls", masterFormService.getCellMasterByTableId(tableId, 0));
            modelMap.put("columnDtls", masterFormService.getColumnMasterByTableId(tableId));

        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
        	//auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), subModuleId==vendorEnlistmentModuleId ?  vendorViewTableLinkId : masterViewTableLinkId,subModuleId==vendorEnlistmentModuleId ? viewVendorTable : viewMasterTable, formId, tableId);
                if(subModuleId == vendorEnlistmentModuleId){
                   vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),vendorViewTableLinkId , viewVendorTable, formId, tableId);
                }else{
                     auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),masterViewTableLinkId , viewMasterTable, formId, tableId);
                }
        }
        return "common/admin/ViewTable";
    }
    
    /**
     * Bid Form Matrix GET
     *
     * @param tableId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/bidder/bidform/{formId}/{enc}", method = RequestMethod.GET)
    public String bidForm(@PathVariable("formId") Integer formId, ModelMap modelMap, HttpServletRequest request) {
        try {
            SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            modelMap.addAttribute("fromBidForm", true);
            modelMap.addAttribute("companyId", sessionBean.getCompanyId());            
            masterFormService.setViewForm(formId, modelMap);
            modelMap.addAttribute("decimalUpto", 5);            
            modelMap.addAttribute("formbid", true);
//            modelMap.addAttribute("viewformbid", "1");
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            boolean isBidAvail = modelMap.get("isbidavail")!=null && (Boolean)modelMap.get("isbidavail");
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), isBidAvail ?  masterEditFormBid : masterFormBid, isBidAvail? bidMasterEditForm : bidMasterFormAudit, formId, 0);
        }
        return "/common/admin/TestForm";
    }
    /**
     * Bid Form Matrix POST
     *
     * @param tableId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/bidder/addbid", method = RequestMethod.POST)
    public String addBid(ModelMap modelMap, HttpServletRequest request, RedirectAttributes redirectAttributes) {
        int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
        boolean isEdit = StringUtils.hasLength(request.getParameter("hdEdit")) ? Boolean.parseBoolean(request.getParameter("hdEdit")) : false;
        boolean success = false;
        String retVal = "redirect:/sessionexpired";
        try {            
           SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            if (sessionBean != null) {
                    List<TblMasterBid> masterBids = new ArrayList<TblMasterBid>();
                    String[] hdTableIds = request.getParameterValues("hdTableId");
                    for (String tableId : hdTableIds) {
                        String[] bids = request.getParameterValues("rtfSorBid_" + tableId);
                        for (String bidString : bids) {
                            masterBids.add(new TblMasterBid(bidString, sessionBean.getUserId(), 1,sessionBean.getCompanyId(), formId, Integer.parseInt(tableId)));                        
                        }
                    }
                    success = masterFormService.addTblMasterBid(masterBids);
                redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_bid_submission" : CommonKeywords.ERROR_MSG_KEY.toString());
//                retVal = success ? TENDER_DASHBOARD_URL + tenderId + "/2" : "common/bidder/bidform/" + formId + "/" + formId;
//                retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
                retVal = "redirect:/common/bidder/managemasterform"+ encryptDecryptUtils.generateRedirect("common/bidder/managemasterform", request);
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), isEdit ? masterEditFormBid : masterFormBid, isEdit ? bidMasterEditForm : bidMasterFormAudit, formId, 0);
        }
        return retVal;
    }
    /**
     * Bid Form Matrix GET
     *
     * @param tableId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/bidder/viewbid/{formId}/{enc}", method = RequestMethod.GET)
    public String viewBid(@PathVariable("formId") Integer formId, ModelMap modelMap, HttpServletRequest request) {
        try {
            SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            modelMap.addAttribute("fromBidForm", true);
            modelMap.addAttribute("companyId", sessionBean.getCompanyId());
            masterFormService.setViewForm(formId, modelMap);
            modelMap.addAttribute("decimalUpto", 5);            
            modelMap.addAttribute("formbid", true);
            modelMap.addAttribute("viewformbid", "1");
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), masterBidView, viewMasterBidAudit, formId, 0);
        }
        return "/common/admin/TestForm";
    }
    
    /**
     * Use to Open Master From
     * @author krunal.patel
     * @param formId
     * @param modelMap
     * @param request
     * @param response
     * @throws Exception
     * @return
     */
     @RequestMapping(value = "/admin/createmasterform/{formFlag}/{enc}", method = RequestMethod.GET)                      
     public String createMasterForm(@PathVariable("formFlag") Integer formflag,ModelMap modelMap, HttpServletResponse  response, HttpServletRequest request){
    	 String retVal = null;
    	 int enlistmentId = 0;
    	 int formId = 0;
         try{
        	 if(formflag==2){
        		 int clientId = abcUtility.getSessionClientId(request);
        		 modelMap.addAttribute("clientTypeList", commonService.getClientType());
        		 modelMap.addAttribute("genericSpecificList", commonService.getGenericSpecific());
        		 modelMap.addAttribute("ruleconfigList", commonService.getYesNo());
        		 enlistmentId = masterFormService.chkCentralizeDecentralize(clientId);
        		 
        		 Integer evaluationMode = (Integer) vendorEnlistmentService.getEnlistmentFields(clientId, "enlistmentId,evaluationMode", false).get(0)[1];
    			 modelMap.addAttribute("evaluationMode",  evaluationMode);
        		 if(enlistmentId != 0){
        			 modelMap.addAttribute("departmentComboList", abcUtility.convert(masterFormService.getDepartmentComboList(enlistmentId)));
        		 }
        		 modelMap.addAttribute("selBusinessType", abcUtility.convert(masterFormService.getbusinessTypeList(clientId,formId)));
        	 }
        	 modelMap.addAttribute("enlistmentId", enlistmentId);
        	 modelMap.addAttribute("opType","create");
        	 modelMap.addAttribute("formFlag",formflag);
        	 modelMap.addAttribute("formId",0);
        	 retVal = "common/admin/MasterForm";
         }
         catch(Exception e){
         	return exceptionHandlerService.writeLog(e);
         } finally {
             //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),formflag==1?masterFormCreate:vendorEnlistFormCreate,formflag==1?getCreateMsterFormRemark:getCreateVendorFormRemark, 0, 0);
             if(formflag == 1){
                    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),masterFormCreate , getCreateMsterFormRemark, 0, 0);
             }else{
                  vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),vendorEnlistFormCreate , getCreateVendorFormRemark, 0, 0);
             }
         }
         return retVal;
     }
     /**
      * Use to Edit Master From
      * @author krunal.patel
      * @param formId
      * @param modelMap
      * @param request
      * @param response
      * @throws Exception
      * @return
      */
      @RequestMapping(value = "/admin/editmasterform/{formId}/{formFlag}/{enc}", method = RequestMethod.GET)                      
      public String editMasterForm(@PathVariable("formId")int formId,@PathVariable("formFlag")int formFlag,ModelMap modelMap, HttpServletResponse  response, HttpServletRequest request){
     	 String retVal = null;
     	int enlistmentId = 0;
          try{
        	  if(formFlag==2){
        		  int clientId = abcUtility.getSessionClientId(request);
        		  modelMap.addAttribute("clientTypeList", commonService.getClientType());
        		  modelMap.addAttribute("genericSpecificList", commonService.getGenericSpecific());
        		  modelMap.addAttribute("ruleconfigList", commonService.getYesNo());
        		  modelMap.addAttribute("selBusinessType", abcUtility.convertSelected(masterFormService.getbusinessTypeList(clientId,formId)));
        		  Integer evaluationMode = (Integer) vendorEnlistmentService.getEnlistmentFields(clientId, "enlistmentId,evaluationMode", false).get(0)[1];
     			  modelMap.addAttribute("evaluationMode",  evaluationMode);
        		  List<Object[]> categoryArray = masterFormService.getCategoryByFormId(formId);
        		  
        		  String categoryIds="";
        		  String categoryNames="";
        		  for (Object[] objects : categoryArray) {
					
        			   categoryIds = objects[0].toString()+","+categoryIds; 
        			   categoryNames = objects[1].toString()+","+categoryNames;
        		  }
        		  if(categoryIds!=null && !"".equalsIgnoreCase(categoryIds) && categoryIds.length() > 1 && categoryIds.charAt(categoryIds.length()-1) == ','){
        			  modelMap.addAttribute("categoryIds", categoryIds.substring(0, categoryIds.length()-1));
        		  }else{
        			  modelMap.addAttribute("categoryIds", categoryIds);
        		  }
        		  modelMap.addAttribute("categoryNames", categoryNames);
        		  
        		  enlistmentId = masterFormService.chkCentralizeDecentralize(clientId);
        		  if(enlistmentId != 0){
         			 modelMap.addAttribute("departmentComboList", abcUtility.convert(masterFormService.getDepartmentComboList(enlistmentId)));
         		 }
        	  }
     		 
     		 modelMap.addAttribute("tblFormMaster",masterFormService.getMasterForm(formId));
     		 
     		  modelMap.addAttribute("enlistmentId", enlistmentId);
        	  modelMap.addAttribute("opType","update");
        	  modelMap.addAttribute("formFlag",formFlag);
        	  modelMap.addAttribute("formId",formId);
        	  retVal = "common/admin/MasterForm";
          }
          catch(Exception e){
          	return exceptionHandlerService.writeLog(e);
          } finally {
              //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),formFlag==1?masterFormEdit:vendorEnlistFormEdit,formFlag==1?getEditMsterFormRemark:getEditVendorFormRemark,formId,0);
              if(formFlag == 1){
                    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),masterFormEdit , getEditMsterFormRemark, formId, 0);
             }else{
                  vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),vendorEnlistFormEdit , getEditVendorFormRemark, formId, 0);
             }
          }
          return retVal;
      }
     /**
     * Use to save Master From
     * @author krunal.patel
     * @param modelMap
     * @param request
     * @param response
     * @throws Exception
     * @return
     */
    @RequestMapping(value = "/admin/savemasterform", method = RequestMethod.POST)                       
    public String saveMasterForm(ModelMap modelMap, HttpServletResponse response, HttpServletRequest  request,RedirectAttributes redirectAttributes)throws Exception{
    	
    	String retVal = REDIRECT_SESSION_EXPIRED;
    	StringBuilder retUrl = new StringBuilder();
    	boolean bSuccess = false;
    	String successMsg=null;
    	int formId=0;
    	int noOfTbl=0;
    	int selDepartment = 0;
    	int hdFormFlag = 0;
    	try{
      	int sessionUserId = abcUtility.getSessionUserId(request);
    		if(sessionUserId!=0){
    				String formName = StringUtils.hasLength(request.getParameter("txtaFormName"))? request.getParameter("txtaFormName"):"";
    				String formHeader = StringUtils.hasLength(request.getParameter("rtfFormHeader"))? request.getParameter("rtfFormHeader"):"";
    				String formFooter = StringUtils.hasLength(request.getParameter("rtfFormFooter"))? request.getParameter("rtfFormFooter"):"";
    				noOfTbl = StringUtils.hasLength(request.getParameter("txtNoOfTables"))? Integer.parseInt(request.getParameter("txtNoOfTables")):0;
    				
    				hdFormFlag = StringUtils.hasLength(request.getParameter("hdFormFlag"))? Integer.parseInt(request.getParameter("hdFormFlag")):0;
    				
    	         	/*** Start Code to set main Table Value **/
    				
    				if(!"".equals(formName) && !"".equals(formHeader) && noOfTbl != 0){
    					
    					TblFormMaster tblFormMaster = new TblFormMaster();
    					tblFormMaster.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
    					tblFormMaster.setFormName(AbcUtility.reverseReplaceSpecialChars(formName));
    					tblFormMaster.setFormHeader(formHeader);
    					tblFormMaster.setFormFooter(formFooter);
    					tblFormMaster.setNoOfTables(noOfTbl);
    					int userId = abcUtility.getSessionUserDetailId(request);
    					tblFormMaster.setCreatedBy(userId);
    					tblFormMaster.setCstatus(PENDING_STATUS);
    					
    					tblFormMaster.setUpdatedBy(userId);
    					tblFormMaster.setUpdatedOn(commonService.getServerDateTime());
    					
    					
    					if(hdFormFlag==1){
    						tblFormMaster.setTblSubModule(new TblSubModule(masterFormModuleId));
    						tblFormMaster.setTblDepartment(new TblDepartment(masterFormService.getDepartmentId(abcUtility.getSessionClientId(request))));
    						
    						/*** Set Fields 0 as master form save **/
        					tblFormMaster.setClientType(ZERO_VALUE);
        					tblFormMaster.setFormType(ZERO_VALUE);
        					tblFormMaster.setIsRuleConfigurationReq(ZERO_VALUE);
        					
        					bSuccess = masterFormService.addFormMaster(tblFormMaster);
        					
    					}else if(hdFormFlag==2){
    						
    						int selFormType = StringUtils.hasLength(request.getParameter("selFormType"))? Integer.parseInt(request.getParameter("selFormType")):0;
    						int selRuleconfig = StringUtils.hasLength(request.getParameter("selRuleconfig"))? Integer.parseInt(request.getParameter("selRuleconfig")):0;
    						
    						tblFormMaster.setTblSubModule(new TblSubModule(vendorEnlistmentModuleId));
    						tblFormMaster.setIsRuleConfigurationReq(selRuleconfig);
    						tblFormMaster.setFormType(selFormType);
    						
    						if(selFormType == 2){
    							
    							int hdEnlistmentId = StringUtils.hasLength(request.getParameter("hdEnlistmentId"))? Integer.parseInt(request.getParameter("hdEnlistmentId")):0;
    							int selClientType = StringUtils.hasLength(request.getParameter("selClientType"))? Integer.parseInt(request.getParameter("selClientType")):0;
    							
    							tblFormMaster.setClientType(selClientType);
        						
    							
    							String[] businessTypeArray =request.getParameterValues("chkBusinessType");
        						List<TblFormBusinessType> tblFormBusinessTypeList = new ArrayList<TblFormBusinessType>();
        						for (String businessType : businessTypeArray) {
        							TblFormBusinessType tblFormBusinessType = new TblFormBusinessType();
        							
        							tblFormBusinessType.setTblClientBusinessType(new TblClientBusinessType(Integer.parseInt(businessType)));
        							tblFormBusinessType.setIsActive(IS_ACTIVE_STATUS);
        							tblFormBusinessType.setTblFormMaster(tblFormMaster);
        							tblFormBusinessTypeList.add(tblFormBusinessType);
        		                }
        						
        						String[] productTypeArray =request.getParameterValues("chkProduct");
        						List<TblFormProduct> tblFormProductList = new ArrayList<TblFormProduct>();
        						for (String productType : productTypeArray) {
        							if(productType.contains(",") || productType.contains("_")){
        								String productCat =  productType.contains(",") ? productType.split(",")[productType.split(",").length-1] : productType; 
	        							TblFormProduct tblFormProduct = new TblFormProduct();
	        							tblFormProduct.setTblProduct(new TblProduct(Integer.parseInt(productCat.split("_")[1])));
	        							tblFormProduct.setTblProductCategory(new TblProductCategory(Integer.parseInt(productCat.split("_")[0])));
	        							tblFormProduct.setIsActive(IS_ACTIVE_STATUS);
	        							tblFormProduct.setTblFormMaster(tblFormMaster);
	        							tblFormProductList.add(tblFormProduct);
        							}
        		                }
    							
        						if(hdEnlistmentId!=0){
        							selDepartment = StringUtils.hasLength(request.getParameter("selDepartment"))? Integer.parseInt(request.getParameter("selDepartment")):0;	
        						}else{
        							selDepartment = masterFormService.getDepartmentId(abcUtility.getSessionClientId(request));	
        						}
        						tblFormMaster.setTblDepartment(new TblDepartment(selDepartment));
        						
        						String[] categoryArray =request.getParameterValues("txtCategory");
        						List<TblFormCategory> tblFormCategoryList = new ArrayList<TblFormCategory>();
        						for (String catType : categoryArray) {
        							if(!"".equalsIgnoreCase(catType)){
	        							TblFormCategory tblFormCategory = new TblFormCategory();
	        							tblFormCategory.setTblFormMaster(tblFormMaster);
	        							tblFormCategory.setTblProductCategory(new TblProductCategory(Integer.parseInt(catType)));
	        							tblFormCategoryList.add(tblFormCategory);
        							}
        		                }
        						
            					bSuccess = masterFormService.addFormMaster(tblFormMaster,tblFormBusinessTypeList,tblFormProductList, tblFormCategoryList);
    							
    						}else{
    							tblFormMaster.setTblDepartment(new TblDepartment(masterFormService.getDepartmentId(abcUtility.getSessionClientId(request))));
    							tblFormMaster.setClientType(ZERO_VALUE);	
            					
            					bSuccess = masterFormService.addFormMaster(tblFormMaster);
    						}
    					}
    					
    					formId = tblFormMaster.getFormId();
    					successMsg = "redirect_success_create_form";
    				}
    		}
       }
       catch(Exception e){
       	return exceptionHandlerService.writeLog(e);
       }finally {
           //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),hdFormFlag==1?masterFormCreate:vendorEnlistFormCreate,hdFormFlag==1?postCreateMsterFormRemark:postCreateVendorFormRemark,formId,0);
           if(hdFormFlag == 1){
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),masterFormCreate , postCreateMsterFormRemark, formId, 0);
           }else{
                  vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),vendorEnlistFormCreate , postCreateVendorFormRemark, formId, 0);
           }
       }
    		retVal=bSuccess?retUrl.append("common/admin/createformtables/").append(formId).toString():retUrl.append("common/admin/createmasterform/").append(formId).toString();
    		retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
    		redirectAttributes.addFlashAttribute(bSuccess ? CommonKeywords.SUCCESS_MSG.toString() :CommonKeywords.ERROR_MSG.toString(), bSuccess ? successMsg : CommonKeywords.ERROR_MSG_KEY.toString());

       return retVal.toString();
    	}
    /**
     * Use to update Master From
     * @author krunal.patel
     * @param modelMap
     * @param request
     * @param response
     * @throws Exception
     * @return
     */
    @RequestMapping(value = "/admin/updatemasterform", method = RequestMethod.POST)                       
    public String updateMasterForm(ModelMap modelMap, HttpServletResponse response, HttpServletRequest  request,RedirectAttributes redirectAttributes)throws Exception{
    	
    	String retVal = REDIRECT_SESSION_EXPIRED;
    	StringBuilder retUrl = new StringBuilder();
    	boolean bSuccess = false;
    	int formId=0;
    	int selDepartment = 0;
    	int hdFormFlag = 0;
    	try{
      	int sessionUserId = abcUtility.getSessionUserId(request);
    		if(sessionUserId!=0){
    				hdFormFlag = StringUtils.hasLength(request.getParameter("hdFormFlag"))? Integer.parseInt(request.getParameter("hdFormFlag")):0;
    				
    				formId = StringUtils.hasLength(request.getParameter("hdFormId"))? Integer.parseInt(request.getParameter("hdFormId")):0;
    				String formName = StringUtils.hasLength(request.getParameter("txtaFormName"))? request.getParameter("txtaFormName"):"";
    				String formHeader = StringUtils.hasLength(request.getParameter("rtfFormHeader"))? request.getParameter("rtfFormHeader"):"";
    				String formFooter = StringUtils.hasLength(request.getParameter("rtfFormFooter"))? request.getParameter("rtfFormFooter"):"";
    				

    				
    				/*** Update for Master Form**/
    				if(hdFormFlag==1){
        				if(formId!=0 && !"".equals(formName) && !"".equals(formHeader)){
        					bSuccess = masterFormService.updateFormMaster(formId, formName, formHeader, formFooter,abcUtility.getSessionUserDetailId(request));
        				}	
    				}else if(hdFormFlag==2){
    					/*** Update for Vendor form**/
    					int selFormType = StringUtils.hasLength(request.getParameter("selFormType"))? Integer.parseInt(request.getParameter("selFormType")):0;
						int selRuleconfig = StringUtils.hasLength(request.getParameter("selRuleconfig"))? Integer.parseInt(request.getParameter("selRuleconfig")):0;
    					
    					TblFormMaster tblFormMaster = null;
    					tblFormMaster = masterFormService.getMasterForm(formId);
    					
    					tblFormMaster.setFormName(AbcUtility.reverseReplaceSpecialChars(formName));
    					tblFormMaster.setFormHeader(formHeader);
    					tblFormMaster.setFormFooter(formFooter);
    					tblFormMaster.setIsRuleConfigurationReq(selRuleconfig);
						tblFormMaster.setFormType(selFormType);
						tblFormMaster.setUpdatedBy(abcUtility.getSessionUserDetailId(request));
    					tblFormMaster.setUpdatedOn(commonService.getServerDateTime());
						
    					
    					/*** Update for vendor form and form type specific**/
						if(selFormType == 2){
							
							int hdEnlistmentId = StringUtils.hasLength(request.getParameter("hdEnlistmentId"))? Integer.parseInt(request.getParameter("hdEnlistmentId")):0;
							int selClientType = StringUtils.hasLength(request.getParameter("selClientType"))? Integer.parseInt(request.getParameter("selClientType")):0;
							
							tblFormMaster.setClientType(selClientType);
    						
							
							String[] businessTypeArray =request.getParameterValues("chkBusinessType");
    						List<TblFormBusinessType> tblFormBusinessTypeList = new ArrayList<TblFormBusinessType>();
    						for (String businessType : businessTypeArray) {
    							TblFormBusinessType tblFormBusinessType = new TblFormBusinessType();
    							tblFormBusinessType.setTblClientBusinessType(new TblClientBusinessType(Integer.parseInt(businessType)));
    							tblFormBusinessType.setIsActive(IS_ACTIVE_STATUS);
    							tblFormBusinessType.setTblFormMaster(tblFormMaster);
    							tblFormBusinessTypeList.add(tblFormBusinessType);
    		                }
    						
    						String[] productTypeArray =request.getParameterValues("chkProduct");
    						List<TblFormProduct> tblFormProductList = new ArrayList<TblFormProduct>();
    						for (String productType : productTypeArray) {
    							if(productType.contains(",") || productType.contains("_")){
    								String productCat =  productType.contains(",") ? productType.split(",")[productType.split(",").length-1] : productType; 
        							TblFormProduct tblFormProduct = new TblFormProduct();
        							tblFormProduct.setTblProduct(new TblProduct(Integer.parseInt(productCat.split("_")[1])));
        							tblFormProduct.setTblProductCategory(new TblProductCategory(Integer.parseInt(productCat.split("_")[0])));
        							tblFormProduct.setIsActive(IS_ACTIVE_STATUS);
        							tblFormProduct.setTblFormMaster(tblFormMaster);
        							tblFormProductList.add(tblFormProduct);
    							}
    		                }
							
    						if(hdEnlistmentId!=0){
    							selDepartment = StringUtils.hasLength(request.getParameter("selDepartment"))? Integer.parseInt(request.getParameter("selDepartment")):0;	
    						}else{
    							selDepartment = masterFormService.getDepartmentId(abcUtility.getSessionClientId(request));	
    						}
    						tblFormMaster.setTblDepartment(new TblDepartment(selDepartment));
    						String[] categoryArray =request.getParameterValues("txtCategory");
    						List<TblFormCategory> tblFormCategoryList = new ArrayList<TblFormCategory>();
    						for (String catType : categoryArray) {
    							if(!"".equalsIgnoreCase(catType)){
        							TblFormCategory tblFormCategory = new TblFormCategory();
        							tblFormCategory.setTblFormMaster(tblFormMaster);
        							tblFormCategory.setTblProductCategory(new TblProductCategory(Integer.parseInt(catType)));
        							tblFormCategoryList.add(tblFormCategory);
    							}
    		                }
        					bSuccess = masterFormService.updateVendorForm(tblFormMaster,tblFormBusinessTypeList,tblFormProductList,tblFormCategoryList);
							
						}else{
							/*** Update for vendor form and form type generic**/
							tblFormMaster.setTblDepartment(new TblDepartment(masterFormService.getDepartmentId(abcUtility.getSessionClientId(request))));
							tblFormMaster.setClientType(ZERO_VALUE);	
        					bSuccess = masterFormService.updateVendorForm(tblFormMaster);
						}
    				}
    		}
       }
       catch(Exception e){
       	return exceptionHandlerService.writeLog(e);
       }finally {
           //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),hdFormFlag==1?masterFormEdit:vendorEnlistFormEdit,hdFormFlag==1?postEditMsterFormRemark:postEditVendorFormRemark,formId,0);
           if(hdFormFlag == 1){
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),masterFormEdit , postEditMsterFormRemark, formId, 0);
           }else{
                  vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),vendorEnlistFormEdit , postEditVendorFormRemark, formId, 0);
           }
       }
    		retVal=bSuccess?retUrl.append(hdFormFlag==1?"common/admin/managemasterform":"common/admin/managevendorform").toString():retUrl.append("common/admin/editmasterform/").append(formId).toString();
    		retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
    		redirectAttributes.addFlashAttribute(bSuccess ? CommonKeywords.SUCCESS_MSG.toString() :CommonKeywords.ERROR_MSG.toString(), bSuccess ? "redirect_success_update_form" : CommonKeywords.ERROR_MSG_KEY.toString());
       return retVal.toString();
    	}
    /**
     * Use to Open Table From
     * @author krunal.patel
     * @param formId
     * @param modelMap
     * @param request
     * @param response
     * @throws Exception
     * @return
     */
    @RequestMapping(value = "/admin/createformtables/{formId}/{enc}", method = RequestMethod.GET)
    public String createFormTables(@PathVariable("formId") int formId,ModelMap modelMap, HttpServletRequest request) {
    	String retVal = null;
    	int noOfTables=1;
    	TblFormMaster tblFormMaster = null;
    	int formFlag = 0;
        try {
        	
        	noOfTables = masterFormService.getNoOfTables(formId);
            modelMap.addAttribute("tableCount",noOfTables);
            modelMap.addAttribute("yesNoList", commonService.getYesNo());
            tblFormMaster = masterFormService.getMasterForm(formId);
            formFlag = tblFormMaster.getTblSubModule().getSubModuleId();
            modelMap.addAttribute("formFlag",formFlag);
            retVal = "common/admin/FormTable";
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),formFlag==masterFormModuleId?masterFormTableCreate:vendorFormTableCreate, getFormTablesRemark,0,formId);
            if(formFlag == masterFormModuleId){
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),masterFormTableCreate , getFormTablesRemark, 0, formId);
            }else{
                 vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),vendorFormTableCreate , getFormTablesRemark, 0, formId);
            }
        }
        return retVal;
    }
    /**
     * Use to save From Tables
     * @author krunal.patel
     * @param modelMap
     * @param request
     * @param response
     * @throws Exception
     * @return
     */
    @RequestMapping(value = "/admin/saveformtables", method = RequestMethod.POST)
    public String saveFormTables(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = REDIRECT_SESSION_EXPIRED;
        TblFormMaster tblFormMaster = null;
    	int formFlag = 0;
        int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
        try {
            int tableCount = StringUtils.hasLength(request.getParameter("txtRowCnt")) ? Integer.parseInt(request.getParameter("txtRowCnt")) : 0;
            int userId = abcUtility.getSessionUserDetailId(request);
            String[] tableName = new String[tableCount];
            String[] tableHeader = new String[tableCount];
            String[] tableFooter = new String[tableCount];
            int[] noOfRows = new int[tableCount];
            int[] noOfCols = new int[tableCount];
            int[] isMultFilling = new int[tableCount];
            boolean bool = false;
            boolean success = false;
            List<TblTableMaster> tblTableMasterList = new ArrayList<TblTableMaster>();
            TblTableMaster tblTableMaster = null;
            if (formId != 0 && userId != 0) {
                for (int i = 0; i < tableCount; i++) {
                    tableName[i] = StringUtils.hasLength(request.getParameter("txtaTableName_" + i)) ? request.getParameter("txtaTableName_" + i) : "";
                    tableHeader[i] = StringUtils.hasLength(request.getParameter("rtfTableHeader_" + i)) ? request.getParameter("rtfTableHeader_" + i) : tableName[i];
                    tableFooter[i] = StringUtils.hasLength(request.getParameter("rtfTableFooter_" + i)) ? request.getParameter("rtfTableFooter_" + i) : "";
                    noOfRows[i] = StringUtils.hasLength(request.getParameter("txtNoOfRows_" + i)) ? Integer.parseInt(request.getParameter("txtNoOfRows_" + i)) : 0;
                    noOfCols[i] = StringUtils.hasLength(request.getParameter("txtNoOfCols_" + i)) ? Integer.parseInt(request.getParameter("txtNoOfCols_" + i)) : 0;
                    isMultFilling[i] = StringUtils.hasLength(request.getParameter("selIsMultipleFilling_" + i)) ? Integer.parseInt(request.getParameter("selIsMultipleFilling_" + i)) : 0;
                }
                for (int i = 0; i < tableCount; i++) {
                    if ("".equals(tableName[i]) || noOfRows[i] == 0 || noOfCols[i] == 0 || isMultFilling[i] == -1) {
                        bool = true;
                    } else {
                    	tblTableMaster = new TblTableMaster();
                        tblTableMaster.setSortOrder((i + 1));
                        tblTableMaster.setIsMultipleFilling(isMultFilling[i]);
                        tblTableMaster.setNoOfCols(noOfCols[i]);
                        tblTableMaster.setNoOfRows(noOfRows[i]);
                        tblTableMaster.setCreatedBy(userId);
                        tblTableMaster.setTableFooter(tableFooter[i]);
                        tblTableMaster.setTableHeader(tableHeader[i]);
                        tblTableMaster.setTableName(tableName[i]);
                        tblTableMaster.setTblFormMaster(new TblFormMaster(formId));
                        tblTableMaster.setUpdatedBy(userId);
                        tblTableMaster.setUpdatedOn(commonService.getServerDateTime());
                        tblTableMasterList.add(tblTableMaster);
                    }
                }
                if (bool) {
                    retVal = "redirect:/common/admin/createformtable/"+formId+encryptDecryptUtils.generateRedirect("common/admin/createformtable/"+formId,request);
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                } else {
                    success = masterFormService.addTableMaster(tblTableMasterList);
                    tblFormMaster = masterFormService.getMasterForm(formId);
                    formFlag = tblFormMaster.getTblSubModule().getSubModuleId();
                    redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_add_table" : CommonKeywords.ERROR_MSG_KEY.toString());
                    retVal = "redirect:/common/admin/tabledashboard/" + formId + encryptDecryptUtils.generateRedirect("common/admin/tabledashboard/"+ formId, request);
                }
            }
        } catch (Exception ex) {
        	retVal= exceptionHandlerService.writeLog(ex);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),formFlag==masterFormModuleId?masterFormTableCreate:vendorFormTableCreate, postFormTablesRemark, formId,0);
            if(formFlag == masterFormModuleId){
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),masterFormTableCreate , postFormTablesRemark, formId, 0);
            }else{
                 vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),vendorFormTableCreate , postFormTablesRemark, formId, 0);
            }
        }
        return retVal;
    }
    /**
     * Use to Create Table
     * @author krunal.patel
     * @param formId
     * @param modelMap
     * @param request
     * @param response
     * @throws Exception
     * @return
     */
    @RequestMapping(value = "/admin/createtable/{formId}/{enc}", method = RequestMethod.GET)
    public String createTable(@PathVariable("formId") int formId,ModelMap modelMap, HttpServletRequest request) {
    	String retVal = null;
    	TblFormMaster tblFormMaster = null;
    	int formFlag = 0;
        try {
        	
            modelMap.addAttribute("formId",formId);
            modelMap.addAttribute("yesNoList", commonService.getYesNo());
            modelMap.addAttribute("sortOrderCount",masterFormService.getFormTablesList(formId).size()+1);
            tblFormMaster = masterFormService.getMasterForm(formId);
            formFlag = tblFormMaster.getTblSubModule().getSubModuleId();
            modelMap.addAttribute("formFlag",formFlag);
        	retVal = "common/admin/AddFormTable";
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),formFlag==masterFormModuleId?masterFormTableCreate:vendorFormTableCreate, getAddFormTableRemark, 0,formId);
            if(formFlag == masterFormModuleId){
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),masterFormTableCreate , getAddFormTableRemark, 0, formId);
            }else{
                 vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),vendorFormTableCreate , getAddFormTableRemark, 0, formId);
            }
        }
        return retVal;
    }
    /**
     * Use to Edit Table From
     * @author krunal.patel
     * @param formId
     * @param modelMap
     * @param request
     * @param response
     * @throws Exception
     * @return
     */
    @RequestMapping(value = "/admin/edittable/{formId}/{tableId}/{enc}", method = RequestMethod.GET)
    public String editTable(@PathVariable("formId") int formId,@PathVariable("tableId") int tableId,ModelMap modelMap, HttpServletRequest request) {
    	TblFormMaster tblFormMaster = null;
    	int formFlag = 0;
    	String retVal = null;
        try {
        	
            modelMap.addAttribute("formId",formId);
            modelMap.addAttribute("yesNoList", commonService.getYesNo());
            modelMap.addAttribute("tblTableMaster",masterFormService.getTableMaster(tableId));
            tblFormMaster = masterFormService.getMasterForm(formId);
            formFlag = tblFormMaster.getTblSubModule().getSubModuleId();
            modelMap.addAttribute("formFlag",formFlag);
        	retVal = "common/admin/AddFormTable";
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),formFlag==masterFormModuleId?masterFormTableEdit:vendorFormTableEdit, getEditFormTableRemark, formId,tableId);
            if(formFlag == masterFormModuleId){
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),masterFormTableEdit , getEditFormTableRemark, formId, tableId);
            }else{
                 vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),vendorFormTableEdit , getEditFormTableRemark, formId, tableId);
            }
        }
        return retVal;
    }
    /**
     * Use to Add From Table
     * @author krunal.patel
     * @param modelMap
     * @param request
     * @param response
     * @throws Exception
     * @return
     */
    @RequestMapping(value = "/admin/addtable", method = RequestMethod.POST)
    public String addTable(RedirectAttributes redirectAttributes, HttpServletRequest request) {
    	TblFormMaster tblFormMaster = null;
    	int formFlag = 0;
    	String retVal = REDIRECT_SESSION_EXPIRED;
    	boolean bool = false;
    	boolean success = false;
    	
    	int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
        try {
            int sortOrder = StringUtils.hasLength(request.getParameter("hdSortOrder")) ? Integer.parseInt(request.getParameter("hdSortOrder")) : 0;
            TblTableMaster tblTableMaster = null;
            int userId = abcUtility.getSessionUserDetailId(request);
            if (userId != 0) {
                String tableName = StringUtils.hasLength(request.getParameter("txtaTableName")) ? request.getParameter("txtaTableName") : "";
                String tableHeader = StringUtils.hasLength(request.getParameter("rtfTableHeader")) ? request.getParameter("rtfTableHeader") : tableName;
                String tableFooter = StringUtils.hasLength(request.getParameter("rtfTableFooter")) ? request.getParameter("rtfTableFooter") : "";
                int noOfRows = StringUtils.hasLength(request.getParameter("txtNoOfRows")) ? Integer.parseInt(request.getParameter("txtNoOfRows")) : 0;
                int noOfCols = StringUtils.hasLength(request.getParameter("txtNoOfCols")) ? Integer.parseInt(request.getParameter("txtNoOfCols")) : 0;
                int isMultFilling = StringUtils.hasLength(request.getParameter("selIsMultipleFilling")) ? Integer.parseInt(request.getParameter("selIsMultipleFilling")) : 0;
                if (isMultFilling == -1) {
                    bool = true;
                } else {
                    tblTableMaster = new TblTableMaster();
                    tblTableMaster.setSortOrder(sortOrder);
                    tblTableMaster.setIsMultipleFilling(isMultFilling);
                    tblTableMaster.setNoOfCols(noOfCols);
                    tblTableMaster.setNoOfRows(noOfRows);
                    tblTableMaster.setCreatedBy(userId);
                    tblTableMaster.setTableFooter(tableFooter);
                    tblTableMaster.setTableHeader(tableHeader);
                    tblTableMaster.setTableName(tableName);
                    tblTableMaster.setTblFormMaster(new TblFormMaster(formId));
                    tblTableMaster.setUpdatedBy(userId);
                    tblTableMaster.setUpdatedOn(commonService.getServerDateTime());
                }
                if (bool) {
                    retVal = "redirect:/common/admin/createtable/" + formId +encryptDecryptUtils.generateRedirect("common/admin/createtable/"+ formId,request);
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                } else {
                    success = masterFormService.saveUpdateTableMaster(tblTableMaster);
                    tblFormMaster = masterFormService.getMasterForm(formId);
                    formFlag = tblFormMaster.getTblSubModule().getSubModuleId();
                    redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_add_table" : CommonKeywords.ERROR_MSG_KEY.toString());
                    retVal = "redirect:/common/admin/tabledashboard/" + formId + encryptDecryptUtils.generateRedirect("common/admin/tabledashboard/"+formId, request);
                }
            }
        } catch (Exception ex) {
        	retVal= exceptionHandlerService.writeLog(ex);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),formFlag==masterFormModuleId?masterFormTableCreate:vendorFormTableCreate, postAddFormTableRemark, formId,0);
            if(formFlag == masterFormModuleId){
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),masterFormTableCreate , postAddFormTableRemark, formId, 0);
            }else{
                 vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),vendorFormTableCreate , postAddFormTableRemark, formId, 0);
            }
        }
        return retVal;
    }
    /**
     * Use to update From Table
     * @author krunal.patel
     * @param modelMap
     * @param request
     * @param response
     * @throws Exception
     * @return
     */
    @RequestMapping(value = "/admin/updatetable", method = RequestMethod.POST)
    public String updateTable(RedirectAttributes redirectAttributes, HttpServletRequest request) {
    	TblFormMaster tblFormMaster = null;
    	int formFlag = 0;
    	String retVal = REDIRECT_SESSION_EXPIRED;
    	boolean bool = false;
    	boolean success = false;
    	
    	int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
        int tableId = StringUtils.hasLength(request.getParameter("hdTableId")) ? Integer.parseInt(request.getParameter("hdTableId")) : 0;
        try {
            int userId = abcUtility.getSessionUserDetailId(request);
            if (tableId != 0 && userId != 0) {
                String tableName = StringUtils.hasLength(request.getParameter("txtaTableName")) ? request.getParameter("txtaTableName") : "";
                String tableHeader = StringUtils.hasLength(request.getParameter("rtfTableHeader")) ? request.getParameter("rtfTableHeader") : tableName;
                String tableFooter = StringUtils.hasLength(request.getParameter("rtfTableFooter")) ? request.getParameter("rtfTableFooter") : "";
                int isMultFilling = StringUtils.hasLength(request.getParameter("selIsMultipleFilling")) ? Integer.parseInt(request.getParameter("selIsMultipleFilling")) : 0;
                int radioId = StringUtils.hasLength(request.getParameter("rdFormOpr")) ? Integer.parseInt(request.getParameter("rdFormOpr")) : 0;
                if (isMultFilling == -1 || "".endsWith(tableName) || "".equals(tableHeader)){
                    bool = true;
                }
                if (bool) {
                    retVal = "redirect:/common/admin/editformtable/" + formId + "/"+tableId +encryptDecryptUtils.generateRedirect("common/admin/tabledashboard/"+ formId+"/"+tableId ,request);
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                } else {
                	success = masterFormService.updateTable(tableId, tableName, tableHeader, tableFooter, isMultFilling);
                	tblFormMaster = masterFormService.getMasterForm(formId);
                    formFlag = tblFormMaster.getTblSubModule().getSubModuleId();
                    redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_update_table" : CommonKeywords.ERROR_MSG_KEY.toString());
                    
                    if (radioId == 1) {
                        retVal = "redirect:/common/admin/tabledashboard/" +formId + encryptDecryptUtils.generateRedirect("common/admin/tabledashboard/" +formId, request);
                    } else {
                        retVal = "redirect:/common/admin/createformmatrix/"+formId+"/"+tableId+"/"+radioId + encryptDecryptUtils.generateRedirect("common/admin/createformmatrix/"+formId+"/"+tableId+"/"+radioId,request);
                    }
                }
            }
        } catch (Exception ex) {
        	retVal= exceptionHandlerService.writeLog(ex);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),formFlag==masterFormModuleId?masterFormTableEdit:vendorFormTableEdit, postUpdateFormTableRemark, formId,tableId);
            if(formFlag == masterFormModuleId){
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),masterFormTableEdit , postUpdateFormTableRemark, formId, tableId);
            }else{
                 vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),vendorFormTableEdit , postUpdateFormTableRemark, formId, tableId);
            }
        }
        return retVal;
    }
    /**
     * Use to get Table Listing
     * @author Krunal.Patel	
     * @param formId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/managemasterform/{enc}", method = RequestMethod.GET)
    public String manageMasterForm(ModelMap modelMap, HttpServletRequest request) {
        try {
            modelMap.addAttribute("reportId", reportVendorManageMasterForm);
            reportGeneratorService.getReportConfigDetails(reportVendorManageMasterForm, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageMasterForm,manageMasterFormAudit, 0, reportVendorManageMasterForm);
        }
        return "common/admin/ManageMasterForm";
    }
    /**
     * Use to get Table Listing
     * @author Krunal.Patel	
     * @param formId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/tabledashboard/{formId}/{enc}", method = RequestMethod.GET)                       
    public String tablesDashborard(@PathVariable("formId") int formId,ModelMap modelMap, HttpServletRequest request){
    	String retVal="common/admin/FormTablesDashboard";
    	TblFormMaster tblFormMaster = null;
    	int formFlag = 0;
    	try{
    		List<Object[]> tableList = masterFormService.getFormTablesList(formId);
    		if(tableList != null && !tableList.isEmpty()){
    			modelMap.addAttribute("tableList", tableList);
    		}
    		tblFormMaster = masterFormService.getMasterForm(formId);
    		modelMap.addAttribute("formName", tblFormMaster.getFormName());
            formFlag = tblFormMaster.getTblSubModule().getSubModuleId();
            modelMap.addAttribute("subModuleId", formFlag);
    	}
    	catch(Exception ex){
    		return exceptionHandlerService.writeLog(ex);
    	}
    	finally {
    		//auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),formFlag==masterFormModuleId?masterFormLibraryDashBoard:enlistmentFormLibraryDashBoard,"Accessed event Table dashboard page",0,formId);
                if(formFlag == masterFormModuleId){
                    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),masterFormLibraryDashBoard , "Accessed event Table dashboard page", 0, formId);
                }else{
                     vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),enlistmentFormLibraryDashBoard , "Accessed event Table dashboard page", 0, formId);
                }
    	}
    	return retVal;
    }
    /**
     * Use to get Master Form library
     * @author Krunal.Patel	
     * @param formId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/bidder/managemasterform/{enc}", method = RequestMethod.GET)
    public String masterFormLibrary(ModelMap modelMap, HttpServletRequest request) {
        try {
            modelMap.addAttribute("reportId", reportVendorManageBidderVendorForm);
            reportGeneratorService.getReportConfigDetails(reportVendorManageBidderVendorForm, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidderMasterForm,bidderMasterFormAudit, 0,reportVendorManageBidderVendorForm);
        }
        return "common/BidderMasterFormLibrary";
    }
    /**
     * ajax call for get Product from Product master table
     *
     * @param deptId
     * @return String
     */
    @RequestMapping(value = "/admin/ajax/getproductname", method = RequestMethod.POST)
    @ResponseBody
    public String getDepartmentOfficer(@RequestParam("categoryId") String categoryId,@RequestParam("hdFormId") String FormId,@RequestParam("selProduct") String selProduct,
    			  @RequestParam("disabledflag") boolean disabledflag, HttpServletRequest request) {
    	StringBuilder retVal = new StringBuilder("");
        try {
            if (request.getSession().getAttribute(SESSIONOBJECT) != null) {
            	
            	String[] strArray = categoryId.split(",");
            	Integer[] intArray = new Integer[strArray.length];
            	for(int i = 0; i < strArray.length; i++) {
            	    intArray[i] = Integer.parseInt(strArray[i]);
            	}
            	
            	List<Object[]> productList = masterFormService.getProductsList(intArray,Integer.parseInt(!"0".equalsIgnoreCase(FormId)?FormId:"0"));
            	
            	if(productList!=null && !productList.isEmpty()){
            		//retVal.append("<tr id='selectProductRow'>");
            		//retVal.append("<td><label class='m-top2'>Select product<span class='mandatory'> *</span></label></td>");
            		retVal.append("<div class='multiselect prefix1_1'><div class='check-box'>");
	            	for(Object[] object: productList){
                                
	                	//data.append("<script type='text/javascript'>var comp=$('#echkEventTypeList").append(moduleId).append("'); createMandatoryCheckBoxArray(comp);</script>");
	            		retVal.append("<label id=\""+object[1].toString()+"\"><input name='chkProduct' onclick='removeItemValidation()' id='chkProduct' isrequired='true' value='"+encryptDecryptUtils.encrypt(object[1].toString()+"_"+ object[0].toString())+"' type='checkbox' title='product'");
                                if(selProduct!=null && !"".equalsIgnoreCase(selProduct) && !"0".equalsIgnoreCase(selProduct)){
                                        if(selProduct.contains(object[0].toString())){
                                            if(disabledflag){
                                                retVal.append("checked='' disabled='disabled'");
                                            }else{
                                                retVal.append("checked=''");
                                            }
                                        }
                                }else{
                                    if(object[3]!=null){
                                            retVal.append("checked=''");	
                                    }
                                }
                                
	            		retVal.append(">"+object[2].toString()+"</label>");
	                	//retVal.append("</div>");
	                	//retVal.append(object[1]);
	                	//retVal.append("  </label>");
	            }
	            	//retVal.append("</div><div id='errDivchkProduct'></div>");
	            	//retVal.append("<input id='jhchkProduct' name='jhchkProduct' value='BuyapFBF7$$8=' type='hidden'>");
	            	retVal.append("</div>");
	            	//retVal.append("</td>");
	            	//retVal.append("</tr>");
            	//data.append("</div><div id=\"errDiv").append("echkEventTypeList").append(moduleId).append("\"></div>");
            	//data.append("</td>");
            	}
            	//int retVal1 = masterFormService.getProductsList(Integer.parseInt(categoryId),abcUtility.getSessionClientId(request));
                //retVal = encryptDecryptUtils.getOptions("selDeptOfficial", abcUtility.convert(eventCreationService.getDepartmentOfficer(Integer.parseInt(deptId), abcUtility.getSessionClientId(request))), true, "", messageSource.getMessage("auc_please_selectmsg", null, LocaleContextHolder.getLocale()));
            }else{
            	retVal.append("sessionexpired");
            }
            
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
        return retVal.toString();
    }
    
    /**
     * Bid Form Matrix POST
     *
     * @param tableId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/bidder/addvendorform", method = RequestMethod.POST)
    public String addVendorForm(ModelMap modelMap, HttpServletRequest request, RedirectAttributes redirectAttributes) {
        int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
        int reviseFormId = StringUtils.hasLength(request.getParameter("hdRevisedFormId")) ? Integer.parseInt(request.getParameter("hdRevisedFormId")) : 0;
        int companyEnlistmentId = StringUtils.hasLength(request.getParameter("hdCompanyEnlistmentId")) ? Integer.parseInt(request.getParameter("hdCompanyEnlistmentId")) : 0;
        boolean isEdit = StringUtils.hasLength(request.getParameter("hdEdit")) ? Boolean.parseBoolean(request.getParameter("hdEdit")) : false;
        boolean isRevised = reviseFormId!=0;
        boolean success = false;
        String retVal = "redirect:/sessionexpired";
        try {            
           SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            if (sessionBean != null) {
                
                    TblCompanyForm companyForm = new TblCompanyForm(sessionBean.getUserDetailId(), 0, sessionBean.getCompanyId(), formId,reviseFormId,companyEnlistmentId);
                    List<TblCompanyTable> companyTables = new ArrayList<TblCompanyTable>();
                    List<TblCompanyCell> companyCells = new ArrayList<TblCompanyCell>();
                    String[] hdTableIds = request.getParameterValues("hdTableId");
                    for (String tableId : hdTableIds) {
                        String[] bids = request.getParameterValues("rtfSorBid_" + tableId);
                        for (String bidString : bids) {
                            TblCompanyTable companyTable = new TblCompanyTable(companyForm, Integer.parseInt(tableId));
                            companyTables.add(companyTable);
//                            System.out.println("-----------------> "+bidString);
                            JSONArray jsonArray = new JSONArray(bidString);
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jSONObject = jsonArray.getJSONObject(i);
                                for (Iterator it = jSONObject.keys(); it.hasNext();) {
                                    String key = it.next().toString();
                                    String[] values = key.split("_");
                                    companyCells.add(new TblCompanyCell(Integer.parseInt(values[1]), jSONObject.getString(key), Integer.parseInt(values[0]), companyTable));
                                }
                            }      
                        }
                    }
                    success = vendorEnlistmentService.addVendorForm(companyForm, companyTables, companyCells,isRevised);
                    redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_form_submission" : CommonKeywords.ERROR_MSG_KEY.toString());
//                retVal = success ? TENDER_DASHBOARD_URL + tenderId + "/2" : "common/bidder/bidform/" + formId + "/" + formId;
//                retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
                retVal = "redirect:/enlistment/bidder/getvendorenlistformdetails/"+companyEnlistmentId+"/"+reviseFormId+ encryptDecryptUtils.generateRedirect("enlistment/bidder/getvendorenlistformdetails/"+companyEnlistmentId+"/"+reviseFormId, request);
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), isEdit ? vendorFormEditFill : vendorFormFill, isEdit ? addVendorBidEditAudit : addVendorBidAudit, formId, companyEnlistmentId);
        }
        return retVal;
    }
    /**
     * Use to Open Rule configuration
     * @author krunal.patel
     * @param formId
     * @param modelMap
     * @param request
     * @param response
     * @throws Exception
     * @return
     */
     @RequestMapping(value = "/admin/ruleconfiguration/{formId}/{enc}", method = RequestMethod.GET)                      
     public String createRuleConfiguration(@PathVariable("formId") Integer formId,ModelMap modelMap, HttpServletResponse  response, HttpServletRequest request){
    	 String retVal = null;
         try{
        	         	  
        	 List<Object[]>  itemDescriptionList = masterFormService.getItemDescription(formId);
        	 List<Object[]>  getFormRuleList = masterFormService.getFormRuleByFormId(formId);
        	 Map<String,String> uniqeMap = new HashMap<String, String>();
        	 for (Object[] rules : getFormRuleList) {
        		 uniqeMap.put(rules[0]+"_"+rules[1], "");
        	 }
        	 
        	modelMap.addAttribute("itemDescriptionList",itemDescriptionList);
        	modelMap.addAttribute("getFormRuleList",uniqeMap);
        	modelMap.addAttribute("formId",formId);
        	 
        	 retVal= "common/admin/RuleConfiguration";
         }
         catch(Exception e){
         	return exceptionHandlerService.writeLog(e);
         } finally {
             vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),enilstmentFormRuleConfiguration,getRuleconfigured,0,formId);
         }
         return retVal;
     }
     /**
      * Use to save Rule configuration
      * @author krunal.patel
      * @param modelMap
      * @param request
      * @param response
      * @throws Exception
      * @return
      */
     @RequestMapping(value = "/admin/saveruleconfiguration", method = RequestMethod.POST)                       
     public String saveRuleConfiguration(ModelMap modelMap, HttpServletResponse response, HttpServletRequest  request,RedirectAttributes redirectAttributes)throws Exception{
     	
     	String retVal = REDIRECT_SESSION_EXPIRED;
     	StringBuilder retUrl = new StringBuilder();
     	boolean bSuccess = false;
     	int formId=0;
     	try{
       	int sessionUserId = abcUtility.getSessionUserId(request);
     		if(sessionUserId!=0){
     			String[] hdoldValue =request.getParameterValues("hdoldValue");
     			String[] itemDescriptionArray =request.getParameterValues("chkItemDescription");
     			formId = StringUtils.hasLength(request.getParameter("hdFormId"))?Integer.parseInt(request.getParameter("hdFormId")):0;
     			
     			if(itemDescriptionArray != null){
     				for(int i=0;i<itemDescriptionArray.length;i++){
     					if(hdoldValue!=null){
     						for(int j=0;j<hdoldValue.length;j++){
     							if((itemDescriptionArray[i].equals(hdoldValue[j]))){
     								itemDescriptionArray[i] = null; 
     								hdoldValue[j] = null;
     								break;
     							}
     						}
     					}
         			}
	     			List<TblFormRule> tblFormRuleList = new ArrayList<TblFormRule>();
	     			for (String itemDescription : itemDescriptionArray) {
	     				if(itemDescription != null){
	     					
	     					String[] itemDescriptionData = itemDescription.split("@");
	     					TblFormRule tblFormRule = new TblFormRule();
	         				
	         				tblFormRule.setTblFormMaster(new TblFormMaster(Integer.parseInt(itemDescriptionData[0])));
	         				tblFormRule.setTblTableMaster(new TblTableMaster(Integer.parseInt(itemDescriptionData[1])));
	         				tblFormRule.setRowId(Integer.parseInt(itemDescriptionData[2]));
	         				tblFormRule.setIsActive(IS_ACTIVE_STATUS);
	         				
	         				tblFormRule.setCreatedBy(abcUtility.getSessionUserDetailId(request));
	         				tblFormRule.setUpdatedBy(abcUtility.getSessionUserDetailId(request));
	         				tblFormRule.setUpdatedOn(commonService.getServerDateTime());
	         				
	         				tblFormRuleList.add(tblFormRule);	
	     				}
					}
     			
	     			List<Integer[]> tableIdAndRowId = new ArrayList<Integer[]>();
	     			
	     			if(hdoldValue!=null){
		     			for(int i=0;i<hdoldValue.length;i++){
		     				if(hdoldValue[i] != null){
		     					String[] oldSingleValArray = hdoldValue[i].split("@");
		         				Integer[] intArray = new Integer[2];
		         				intArray[0]= Integer.parseInt(oldSingleValArray[1]);
		         				intArray[1]= Integer.parseInt(oldSingleValArray[2]);
		         				tableIdAndRowId.add(intArray);
		     				}
		     			}
	     			}
	     			bSuccess = masterFormService.addTblFormRule(tblFormRuleList,tableIdAndRowId);
     			}
     		}
        }
        catch(Exception e){
        	return exceptionHandlerService.writeLog(e);
        }finally {
            vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),enilstmentFormRuleConfiguration, postRuleconfigured,0,formId);
        }
     		retVal=bSuccess?retUrl.append("common/admin/createruledetails/").append(formId).toString():retUrl.append("common/admin/ruleconfiguration/").append(formId).toString();
     		retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
     		redirectAttributes.addFlashAttribute(bSuccess ? CommonKeywords.SUCCESS_MSG.toString() :CommonKeywords.ERROR_MSG.toString(), bSuccess ? "msg_rule_configuration" : CommonKeywords.ERROR_MSG_KEY.toString());

        return retVal.toString();
     	}
     /**
      * Use to Create Rule Details
      * @author krunal.patel
      * @param formId
      * @param modelMap
      * @param request
      * @param response
      * @throws Exception
      * @return
      */
      @RequestMapping(value = "/admin/createruledetails/{formId}/{enc}", method = RequestMethod.GET)                      
      public String createRuleDetalis(@PathVariable("formId") Integer formId,ModelMap modelMap, HttpServletResponse  response, HttpServletRequest request){
     	 String retVal = null;
          try{
         	
        	 /*** Code to get combo label and display to jsp**/
         	 List<Object[]>  getHideCellList = masterFormService.getHideCellDtls(formId);
         	 modelMap.addAttribute("getHideCellList",getHideCellList);
         	 
         	/*** Code to get first combo details and set jsp combobox**/
         	List<Object[]>  comboDtlsHideCell = masterFormService.getComboListForHideCell(formId);
         	List<SelectItem> comboDtlsSelectList = new ArrayList<SelectItem>();
         	List<Object[]>  editComboDtlsHideCell = masterFormService.getEditComboListForHideCell(formId);
         	for (Object[] objects : comboDtlsHideCell) {         		
				comboDtlsSelectList.add(new SelectItem(objects[2],objects[0]+"@"+objects[1]+"@"+objects[3]+"@"+objects[4]));
			}
         	modelMap.addAttribute("comboDtlsHideCell",comboDtlsHideCell);
         	modelMap.addAttribute("comboDtlsSelectList",comboDtlsSelectList);
         	
         	/*** Code to get saved first combo record and set jsp combobox**/
         	
         	List<String> editListUniqStr = new ArrayList<String>();
         	for (Object[] objects : editComboDtlsHideCell) {
         		editListUniqStr.add(objects[0].toString()+"@"+objects[1].toString()+"@"+objects[2].toString()+"@"+objects[3].toString());
			}
         	modelMap.addAttribute("editListUniqStr",editListUniqStr);
         	
         	 retVal= "common/admin/RuleDetails";
          }
          catch(Exception e){
          	return exceptionHandlerService.writeLog(e);
          } finally {
              vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),enilstmentFormRuleDetail,getRulecreated,0,formId);
          }
          return retVal;
      }
      /**
       * ajax call for get Product from Product master table
       *
       * @param deptId
       * @return String
       */
      @RequestMapping(value = "/admin/ajax/ajaxgetcombodata", method = RequestMethod.POST)
      @ResponseBody
      public String ajaxgetComboData(@RequestParam("selFirstComboId") String selFirstComboId,@RequestParam("ruleId") String selRuleId, HttpServletRequest request) {
      	StringBuilder retVal = new StringBuilder("");
          try {
              if (request.getSession().getAttribute(SESSIONOBJECT) != null) {
            	  String[] selFirstComboData = selFirstComboId.split("@");
            	  if(selFirstComboData != null){
            		  Object[] array = new Object[1];  
                	  array[0] = Integer.parseInt(selFirstComboData[2]);
                	  List<TblComboDetail> details = masterFormService.getComboDetailByComboId(array);
                	  List<Object[]> ruleDetail = masterFormService.getRuleDetail(Integer.parseInt(selRuleId));                	  
                	  List<TblComboDetail> valdetails = new ArrayList<TblComboDetail>();
                	  List<String> toBeSelected=new ArrayList<String>();
                	  for(TblComboDetail comboDetail : details){
                		  //ruleId,tableId,rowId,cellId,cellValue
                		  String optionValue = comboDetail.getOptionValue();                		  
                		  comboDetail.setOptionValue(selRuleId+"@@"+selFirstComboData[0]+"@@"+selFirstComboData[1]+"@@"+selFirstComboData[3] +"@@"+ comboDetail.getOptionValue());
                		  for (Object[] ruleD : ruleDetail) {
    						    if(ruleD[0].equals(Integer.parseInt(selFirstComboData[3])) && ruleD[1].equals(optionValue)){
    						    	toBeSelected.add(encryptDecryptUtils.encrypt(comboDetail.getOptionValue()));
    						    }
    					  }
                		  valdetails.add(comboDetail);
                	  }
                	  if(details != null && !details.isEmpty()){                		  
                		  retVal.append(encryptDecryptUtils.getOptions("selSecondComboId", modelToSelectItem.convertListIntoSelectItemList(valdetails,"optionValue","optionName"), false, "", "")+"~~"+toBeSelected.toString().replace("[", "").replace("]", "").replace(", ", "~~"));	  
                	  }
            	  }
              }else{
              	retVal.append("sessionexpired");
              }
          } catch (Exception e) {
              exceptionHandlerService.writeLog(e);
          }
          return retVal.toString();
      }
      /**
       * Use to save Rule configuration for combo Details
       * @author krunal.patel
       * @param modelMap
       * @param request
       * @param response
       * @throws Exception
       * @return
       */
      @RequestMapping(value = "/admin/saveruleconfigcombodtls", method = RequestMethod.POST)                       
      public String saveRuleConfigComboDtls(ModelMap modelMap, HttpServletResponse response, HttpServletRequest  request,RedirectAttributes redirectAttributes)throws Exception{
      	
      	String retVal = REDIRECT_SESSION_EXPIRED;
      	StringBuilder retUrl = new StringBuilder();
      	boolean bSuccess = false;
      	int formId=0;
      	try{
        	int sessionUserId = abcUtility.getSessionUserId(request);
      		if(sessionUserId!=0){
      			String[] secondComboBoxArray =request.getParameterValues("selSecondComboBox");
      			if(secondComboBoxArray != null){
      				List<TblFormRuleDetail> tblFormRuleDetailList = new ArrayList<TblFormRuleDetail>();
          			
      				Integer[] ruleIds = new Integer[secondComboBoxArray.length];
      				for (int i = 0; i < secondComboBoxArray.length; i++) {
      					String secondComboBoxData = secondComboBoxArray[i];
      							
      					String[] secondComboBoxSplit = secondComboBoxData.split("@@");
      					TblFormRuleDetail tblFormRuleDetail = new TblFormRuleDetail();
          				
      					ruleIds[i] = Integer.parseInt(secondComboBoxSplit[0]);
      							
          				tblFormRuleDetail.setTblFormRule(new TblFormRule(Integer.parseInt(secondComboBoxSplit[0])));
          				tblFormRuleDetail.setTblTableMaster(new TblTableMaster(Integer.parseInt(secondComboBoxSplit[1])));
          				tblFormRuleDetail.setParentRowId(Integer.parseInt(secondComboBoxSplit[2]));
          				tblFormRuleDetail.setTblCellMaster(new TblCellMaster(Integer.parseInt(secondComboBoxSplit[3])));
          				tblFormRuleDetail.setCellValue(secondComboBoxSplit[4]);	
          				tblFormRuleDetailList.add(tblFormRuleDetail);
					}
      				bSuccess = masterFormService.addTblFormRuleDetails(tblFormRuleDetailList,ruleIds);
      			}
      		}
         }
         catch(Exception e){
         	return exceptionHandlerService.writeLog(e);
         }finally {
             vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),enilstmentFormRuleDetail, postRulecreated,0,formId);
         }
      		retVal=bSuccess?retUrl.append("common/admin/managevendorform").toString():retUrl.append("common/admin/createruledetails/").append(formId).toString();
      		retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
      		redirectAttributes.addFlashAttribute(bSuccess ? CommonKeywords.SUCCESS_MSG.toString() :CommonKeywords.ERROR_MSG.toString(), bSuccess ? "msg_rule_detail" : CommonKeywords.ERROR_MSG_KEY.toString());
         return retVal.toString();
      	}
      /**
       * Use to get Vendor Form library
       * @author Krunal.Patel	
       * @param formId
       * @param modelMap
       * @param request
       * @return
       */
      @RequestMapping(value = "/admin/managevendorform/{enc}", method = RequestMethod.GET)
      public String vendorFormLibrary(ModelMap modelMap, HttpServletRequest request) {
          try {
              modelMap.addAttribute("reportId", reportVendorManageVendorForm);
              reportGeneratorService.getReportConfigDetails(reportVendorManageVendorForm, modelMap);
          } catch (Exception ex) {
              return exceptionHandlerService.writeLog(ex);
          } finally {
              vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),mangeVendorForm,manageVendorEnlistmentFormAudit, 0,reportVendorManageVendorForm);
          }
          return "common/admin/ManageVendorForm";
      }
      
      /**
     * Bid Form Matrix GET
     *
     * @param tableId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/bidder/fillform/{formId}/{bidId}/{companyEnlistmentId}/{reviseFormId}/{enc}", method = RequestMethod.GET)
    public String fillForm(@PathVariable("formId") Integer formId,@PathVariable("bidId") Integer bidId,@PathVariable("reviseFormId") Integer reviseFormId,@PathVariable("companyEnlistmentId") Integer companyEnlistmentId, ModelMap modelMap, HttpServletRequest request) {
        try {
//            modelMap.addAttribute("fromBidForm", true);
            modelMap.addAttribute("bidId", bidId);            
            modelMap.addAttribute("vendorForm", true);
            modelMap.addAttribute("reviseFormId", reviseFormId);
            masterFormService.setViewForm(formId, modelMap);
            modelMap.addAttribute("decimalUpto", 5);            
            modelMap.addAttribute("formbid", true);
//            modelMap.addAttribute("viewformbid", "1");
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), modelMap.get("cellValues")==null ? vendorFormFill : vendorFormEditFill, modelMap.get("cellValues")==null ? bidVendorFormAudit : bidVendorEditForm, formId, companyEnlistmentId);
        }
        return "/common/admin/TestForm";
    }
    
    /**
     * Bid Form Matrix GET
     *
     * @param tableId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/bidder/enlistmentform/{formId}/{bidId}/{companyEnlistmentId}/{reviseFormId}/{enc}", method = RequestMethod.GET)
    public String enlistmentForm(@PathVariable("formId") Integer formId,@PathVariable("bidId") Integer bidId,@PathVariable("reviseFormId") Integer reviseFormId,@PathVariable("companyEnlistmentId") Integer companyEnlistmentId, ModelMap modelMap, HttpServletRequest request) {
        try {
                modelMap.addAttribute("bidId", bidId);
                modelMap.addAttribute("vendorForm", true);
                masterFormService.setViewForm(formId, modelMap);
                modelMap.addAttribute("decimalUpto", 5);            
                modelMap.addAttribute("formbid", true);                
                modelMap.addAttribute("docList",fileUploadService.getBidderDocs(bidId, abcUtility.getSessionClientId(request), uploadBidderDocLinkId, 1, 0));
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            vendorPQAuditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), vendorFormViewFill, viewVendorBidAudit, formId, 0);
        }
        return "/common/admin/EnlistmentForm";
    }
    
    /**
     * 
     * @param response
     * @param httpSession
     * @param request
     * @throws IOException
     */
    @RequestMapping(value = "/admin/ajaxgeteditcatlist", method = RequestMethod.POST)
    public void getEditCategoryList(HttpServletResponse response, HttpSession httpSession, HttpServletRequest request) throws IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        try {
            //int clientId = 0;
            String catTree = null;
            /*if (httpSession.getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null) {
                ClientBean clientBean = (ClientBean) httpSession.getAttribute(CommonKeywords.CLIENT_OBJ.toString());
                clientId = clientBean.getClientId();
            }*/
            
            String txtCategoryIds = StringUtils.hasLength(request.getParameter("txtCategoryIds")) ? request.getParameter("txtCategoryIds") : null; 
            String[] catIds = txtCategoryIds!=null ?  txtCategoryIds.split(",") : null;
            int editCatIds = 0;
            int treeType = StringUtils.hasLength(request.getParameter("txtTreeType")) ?  Integer.parseInt(request.getParameter("txtTreeType")) : 0;
            List<Map<String, Object>> lst = commonService.getCatTree(abcUtility.getSessionClientId(request));
            StringBuilder jsonString = new StringBuilder();
            if (lst != null && !lst.isEmpty()) {
                Iterator<Map<String, Object>> itr = lst.iterator();
                jsonString.append("[{");
                int prevLevel = 1;
                int currLevel = 1;
                boolean isFirstLevel = true;
                boolean isChecked = false;
                int index = 0;
                while (itr.hasNext()) {
                    int catLevel = 1;
                    int categoryId = 0;
                    String categoryName = null;

                    Map<String, Object> map = (Map<String, Object>) itr.next();
                    categoryId = Integer.parseInt(map.get("categoryId").toString());
                    catLevel = Integer.parseInt(map.get("catLevel") != null ? (String) map.get("catLevel").toString() : "1");
                    categoryName = abcUtility.reverseReplaceSpecialChars(map.get("categoryName").toString());
                    currLevel = catLevel;
                    editCatIds =  catIds!=null ?  catIds.length ==1 ? Integer.parseInt(catIds[index]) : index < catIds.length ? Integer.parseInt(catIds[index]) : 0 : 0;
                    isChecked = (categoryId!=editCatIds) ? false : true;
                    
                    if (currLevel == prevLevel) {
                        if (!isFirstLevel) {
                            jsonString.append("}, {");
                        } else {
                            isFirstLevel = false;
                        }
                        jsonString.append("\"id\":").append(categoryId).append(",")
                                .append("\"text\":").append("\"").append(categoryName).append("\"").append(",");
		                        if(isChecked){
		                        	if(treeType!=1){
		                        		jsonString.append("\"checked\":").append(true).append(",");
		                        	}
		                        	else{
		                        		jsonString.append("\"selected\":").append(true).append(",");
		                        	}
		                        }
		                        jsonString.append("\"state\":").append("\"").append("closed").append("\"").append(",")
		                                  .append("\"children\":[{");
                    } else if (currLevel > prevLevel) {
                        jsonString.append("\"id\":").append(categoryId).append(",")
                                .append("\"text\":").append("\"").append(categoryName).append("\"").append(",");
                        if(isChecked){
                        	if(treeType!=1){
                        		jsonString.append("\"checked\":").append(true).append(",");
                        	}
                        	else{
                        		jsonString.append("\"selected\":").append(true).append(",");
                        	}
                        }
		                        jsonString.append("\"state\":").append("\"").append("closed").append("\"").append(",")
				                          .append("\"children\":[{");
                    } else if (currLevel < prevLevel) {
                        int diff = prevLevel - currLevel;
                        for (int i = 0; i < diff; i++) {
                            jsonString.append("}]");
                        }
                        jsonString.append("}, {\"id\":").append(categoryId).append(",")
                                .append("\"text\":").append("\"").append(categoryName).append("\"").append(",");
                        if(isChecked){
                        	if(treeType!=1){
                        		jsonString.append("\"checked\":").append(true).append(",");
                        	}
                        	else{
                        		jsonString.append("\"selected\":").append(true).append(",");
                        	}
                        }
		                jsonString.append("\"state\":").append("\"").append("closed").append("\"").append(",")
		                        		  .append("\"children\":[{");
                    }

                    prevLevel = currLevel;
                    index = catIds!=null ? catIds.length==1 ? 0 : index+1 : 0;
                }
                for (int i = 0; i < currLevel; i++) {
                    jsonString.append("}]");
                }
                //System.out.println(jsonString.toString().replace(",\"state\":\"closed\",\"children\":[{}", "}"));
            }
            catTree = jsonString.toString().replace(",\"state\":\"closed\",\"children\":[{}", "}");
//            System.out.println("EDIT __ TREE :: "+catTree);
            out.print(catTree);
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            out.close();
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), categoryTreeLinkId, ajaxGetCategoryTreeAuditMsg, 0, 0);
        }
    }


    /**
     * 
     * delete master form table
     * 
     * @author nirav.prajapati
     * 
     * @param redirectAttributes
     * @param request
     * @param formId
     * @param tableId
     * @return
     */
    
    @RequestMapping(value = "/admin/deletemasterformtable/{formId}/{tableId}/{enc}", method = RequestMethod.GET)
    public String deleteMasterFormTable(RedirectAttributes redirectAttributes, HttpServletRequest request,@PathVariable("formId") int formId,@PathVariable("tableId") int tableId) {
        String	retVal = "redirect:/common/admin/tabledashboard/" + formId + encryptDecryptUtils.generateRedirect("common/admin/tabledashboard/" + formId, request);
        boolean success = false;
        
        try {
            success = masterFormService.deleteMasterFormTable(tableId,formId);
            redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_tabledeleted" : CommonKeywords.ERROR_MSG_KEY.toString());
        } catch (Exception ex) {
        	retVal= exceptionHandlerService.writeLog(ex);
        } finally {
        }
        return retVal;
    }
    
    
    
    
    
}

