package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblUserOtp;
import com.etl.eproc.common.daointerface.TblUserOtpDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author Dhruvil Panchal
 */
@Repository @Transactional    /*StackUpdate*/
public class TblUserOtpImpl extends AbcAbstractClass<TblUserOtp> implements TblUserOtpDao {

    @Override
    public void addTblUserOtp(TblUserOtp tblUserOtp){
        super.addEntity(tblUserOtp);
    }

    @Override
    public void deleteTblUserOtp(TblUserOtp tblUserOtp) {
        super.deleteEntity(tblUserOtp);
    }

    @Override
    public void updateTblUserOtp(TblUserOtp tblUserOtp) {
        super.updateEntity(tblUserOtp);
    }

    @Override
    public List<TblUserOtp> getAllTblUserOtp() {
        return super.getAllEntity();
    }

    @Override
    public List<TblUserOtp> findTblUserOtp(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblUserOtpCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblUserOtp> findByCountTblUserOtp(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblUserOtp(List<TblUserOtp> tblUserOtps){
        super.updateAll(tblUserOtps);
    }
}
