package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientCPPPConfig;
import java.util.List;

public interface TblClientCPPPConfigDao  {

    public void addTblClientCPPPConfig(TblClientCPPPConfig tblClientCPPPConfig);

    public void deleteTblClientCPPPConfig(TblClientCPPPConfig tblClientCPPPConfig);

    public void updateTblClientCPPPConfig(TblClientCPPPConfig tblClientCPPPConfig);

    public List<TblClientCPPPConfig> getAllTblClientCPPPConfig();

    public List<TblClientCPPPConfig> findTblClientCPPPConfig(Object... values) throws Exception;

    public List<TblClientCPPPConfig> findByCountTblClientCPPPConfig(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientCPPPConfigCount();

    public void saveUpdateAllTblClientCPPPConfig(List<TblClientCPPPConfig> tblClientCPPPConfigs);

	public void saveOrUpdateTblClientCPPPConfig(TblClientCPPPConfig tblClientCPPPConfig);
}