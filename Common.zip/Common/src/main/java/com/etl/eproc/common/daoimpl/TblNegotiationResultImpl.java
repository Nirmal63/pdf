package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblNegotiationResult;
import com.etl.eproc.common.daointerface.TblNegotiationResultDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblNegotiationResultImpl extends AbcAbstractClass<TblNegotiationResult> implements TblNegotiationResultDao {

    @Override
    public void addTblNegotiationResult(TblNegotiationResult tblNegotiationResult){
        super.addEntity(tblNegotiationResult);
    }

    @Override
    public void deleteTblNegotiationResult(TblNegotiationResult tblNegotiationResult) {
        super.deleteEntity(tblNegotiationResult);
    }

    @Override
    public void updateTblNegotiationResult(TblNegotiationResult tblNegotiationResult) {
        super.updateEntity(tblNegotiationResult);
    }

    @Override
    public List<TblNegotiationResult> getAllTblNegotiationResult() {
        return super.getAllEntity();
    }

    @Override
    public List<TblNegotiationResult> findTblNegotiationResult(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblNegotiationResultCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblNegotiationResult> findByCountTblNegotiationResult(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblNegotiationResult(List<TblNegotiationResult> tblNegotiationResults){
        super.updateAll(tblNegotiationResults);
    }
}
