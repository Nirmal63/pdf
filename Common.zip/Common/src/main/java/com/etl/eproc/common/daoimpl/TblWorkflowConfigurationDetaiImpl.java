/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daoimpl;


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblWorkflowConfigurationDetail;
import com.etl.eproc.common.daointerface.TblWorkflowConfigurationDetaiDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblWorkflowConfigurationDetaiImpl extends AbcAbstractClass<TblWorkflowConfigurationDetail> implements TblWorkflowConfigurationDetaiDao {

    @Override
    public void addTblWorkflowConfigurationDetai(TblWorkflowConfigurationDetail tblWorkflowConfigurationDetai){
        super.addEntity(tblWorkflowConfigurationDetai);
    }

    @Override
    public void deleteTblWorkflowConfigurationDetai(TblWorkflowConfigurationDetail tblWorkflowConfigurationDetai) {
        super.deleteEntity(tblWorkflowConfigurationDetai);
    }

    @Override
    public void updateTblWorkflowConfigurationDetai(TblWorkflowConfigurationDetail tblWorkflowConfigurationDetai) {
        super.updateEntity(tblWorkflowConfigurationDetai);
    }

    @Override
    public List<TblWorkflowConfigurationDetail> getAllTblWorkflowConfigurationDetai() {
        return super.getAllEntity();
    }

    @Override
    public List<TblWorkflowConfigurationDetail> findTblWorkflowConfigurationDetai(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblWorkflowConfigurationDetaiCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblWorkflowConfigurationDetail> findByCountTblWorkflowConfigurationDetai(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblWorkflowConfigurationDetai(List<TblWorkflowConfigurationDetail> tblWorkflowConfigurationDetais){
        super.updateAll(tblWorkflowConfigurationDetais);
    }
}
