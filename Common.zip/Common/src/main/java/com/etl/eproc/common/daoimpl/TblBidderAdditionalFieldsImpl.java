package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblBidderAdditionalFields;
import com.etl.eproc.common.daointerface.TblBidderAdditionalFieldsDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblBidderAdditionalFieldsImpl extends AbcAbstractClass<TblBidderAdditionalFields> implements TblBidderAdditionalFieldsDao {

    @Override
    public void addTblBidderAdditionalFields(TblBidderAdditionalFields tblBidderAdditionalFields){
        super.addEntity(tblBidderAdditionalFields);
    }

    @Override
    public void deleteTblBidderAdditionalFields(TblBidderAdditionalFields tblBidderAdditionalFields) {
        super.deleteEntity(tblBidderAdditionalFields);
    }

    @Override
    public void updateTblBidderAdditionalFields(TblBidderAdditionalFields tblBidderAdditionalFields) {
        super.updateEntity(tblBidderAdditionalFields);
    }

    @Override
    public List<TblBidderAdditionalFields> getAllTblBidderAdditionalFields() {
        return super.getAllEntity();
    }

    @Override
    public List<TblBidderAdditionalFields> findTblBidderAdditionalFields(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblBidderAdditionalFieldsCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblBidderAdditionalFields> findByCountTblBidderAdditionalFields(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblBidderAdditionalFields(List<TblBidderAdditionalFields> tblBidderAdditionalFieldss){
        super.updateAll(tblBidderAdditionalFieldss);
    }

	@Override
	public void saveOrUpdateTblBidderAdditionalFields(TblBidderAdditionalFields tblBidderAdditionalFields) {
		super.saveOrUpdateEntity(tblBidderAdditionalFields);
	}
}
