package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblDynFieldDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblDynField;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDynFieldImpl extends AbcAbstractClass<TblDynField> implements TblDynFieldDao {

    @Override
    public void addTblDynField(TblDynField tblDynField){
        super.addEntity(tblDynField);
    }

    @Override
    public void deleteTblDynField(TblDynField tblDynField) {
        super.deleteEntity(tblDynField);
    }

    @Override
    public void updateTblDynField(TblDynField tblDynField) {
        super.updateEntity(tblDynField);
    }

    @Override
    public List<TblDynField> getAllTblDynField() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDynField> findTblDynField(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDynFieldCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDynField> findByCountTblDynField(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDynField(List<TblDynField> tblDynFields){
        super.updateAll(tblDynFields);
    }

	@Override
	public void saveOrUpdateTblDynField(TblDynField tblDynField) {
		super.saveOrUpdateEntity(tblDynField);
	}
}
