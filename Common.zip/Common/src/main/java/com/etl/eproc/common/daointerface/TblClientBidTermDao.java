package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.common.model.TblClientBidTerm;

public interface TblClientBidTermDao  {

    public void addTblClientBidTerm(TblClientBidTerm tblClientBidTerm);

    public void deleteTblClientBidTerm(TblClientBidTerm tblClientBidTerm);

    public void updateTblClientBidTerm(TblClientBidTerm tblClientBidTerm);

    public List<TblClientBidTerm> getAllTblClientBidTerm();

    public List<TblClientBidTerm> findTblClientBidTerm(Object... values) throws Exception;

    public List<TblClientBidTerm> findByCountTblClientBidTerm(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientBidTermCount();

    public void saveUpdateAllTblClientBidTerm(List<TblClientBidTerm> tblClientBidTerms);
}