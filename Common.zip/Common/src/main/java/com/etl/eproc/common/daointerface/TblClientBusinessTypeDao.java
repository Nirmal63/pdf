package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientBusinessType;
import java.util.List;

public interface TblClientBusinessTypeDao  {

    public void addTblClientBusinessType(TblClientBusinessType tblClientBusinessType);

    public void deleteTblClientBusinessType(TblClientBusinessType tblClientBusinessType);

    public void updateTblClientBusinessType(TblClientBusinessType tblClientBusinessType);

    public List<TblClientBusinessType> getAllTblClientBusinessType();

    public List<TblClientBusinessType> findTblClientBusinessType(Object... values) throws Exception;

    public List<TblClientBusinessType> findByCountTblClientBusinessType(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientBusinessTypeCount();

    public void saveUpdateAllTblClientBusinessType(List<TblClientBusinessType> tblClientBusinessTypes);
}