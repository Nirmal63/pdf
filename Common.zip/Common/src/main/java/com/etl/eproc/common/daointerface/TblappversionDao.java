package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.Tblappversion;

public interface TblappversionDao {

    public void addTblappversion(Tblappversion tblappversion);

    public void deleteTblappversion(Tblappversion tblappversion);

    public void updateTblappversion(Tblappversion tblappversion);

    public List<Tblappversion> getAllTblappversion();

    public List<Tblappversion> findTblappversion(Object... values) throws Exception;

    public List<Tblappversion> findByCountTblappversion(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblappversionCount();

    public void saveUpdateAllTblappversion(List<Tblappversion> tblappversions);

	public void saveOrUpdateTblappversion(Tblappversion tblappversion);
}