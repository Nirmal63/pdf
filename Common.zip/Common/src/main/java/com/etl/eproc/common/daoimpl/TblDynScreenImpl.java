package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblDynScreenDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblDynScreen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDynScreenImpl extends AbcAbstractClass<TblDynScreen> implements TblDynScreenDao {

    @Override
    public void addTblDynScreen(TblDynScreen tblDynScreen){
        super.addEntity(tblDynScreen);
    }

    @Override
    public void deleteTblDynScreen(TblDynScreen tblDynScreen) {
        super.deleteEntity(tblDynScreen);
    }

    @Override
    public void updateTblDynScreen(TblDynScreen tblDynScreen) {
        super.updateEntity(tblDynScreen);
    }

    @Override
    public List<TblDynScreen> getAllTblDynScreen() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDynScreen> findTblDynScreen(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDynScreenCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDynScreen> findByCountTblDynScreen(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDynScreen(List<TblDynScreen> tblDynScreens){
        super.updateAll(tblDynScreens);
    }
}
