/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daointerface;


import com.etl.eproc.common.model.TblDynamicMailContent;
import java.util.List;

public interface TblDynamicMailDao  {

    void addTblDynamicMailContent(TblDynamicMailContent tblusermaster);

    void deleteTblDynamicMailContent(TblDynamicMailContent tblusermaster);

    void updateTblDynamicMailContent(TblDynamicMailContent tblusermaster);

    List<TblDynamicMailContent> getAllTblDynamicMailContent();

    List<TblDynamicMailContent> findTblDynamicMailContent(Object... values) throws Exception;

    List<TblDynamicMailContent> findByCountTblDynamicMailContent(int firstResult, int maxResult, Object... values) throws Exception;

    long getTblDynamicMailContentCount();
}