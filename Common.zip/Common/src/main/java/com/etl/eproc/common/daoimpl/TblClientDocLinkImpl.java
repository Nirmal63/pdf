package com.etl.eproc.common.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblClientDocLinkDao;
import com.etl.eproc.common.model.TblClientDocLink;

/**
*
* @author dipika
*/
@Repository @Transactional    /*StackUpdate*/
public class TblClientDocLinkImpl extends AbcAbstractClass<TblClientDocLink> implements TblClientDocLinkDao {


	@Override
	public void addTblClientDocLink(TblClientDocLink tblClientDocLink) {
		super.addEntity(tblClientDocLink);
	}

	@Override
	public void deleteTblClientDocLink(TblClientDocLink tblClientDocLink) {
		super.deleteEntity(tblClientDocLink);
	}

	@Override
	public void updateTblClientDocLink(TblClientDocLink tblClientDocLink) {
		super.updateEntity(tblClientDocLink);
	}

	@Override
	public List<TblClientDocLink> getAllTblClientDocLink() {
		
		return super.getAllEntity();
	}

	@Override
	public List<TblClientDocLink> findTblClientDocLink(Object... values)
			throws Exception {
		
		return super.findEntity(values);
	}

	@Override
	public List<TblClientDocLink> findByCountTblClientDocLink(int firstResult,
			int maxResult, Object... values) throws Exception {
		
		return super.findByCountEntity(firstResult, maxResult, values);
	}

	@Override
	public long getTblClientDocLinkCount() {
		
		return super.getEntityCount();
	}

	@Override
	public void saveUpdateAllTblClientDocLink(
			List<TblClientDocLink> tblClientDocLinks) {
		super.updateAll(tblClientDocLinks);
		
	}

	@Override
	public void saveOrUpdateTblClientDocLink(TblClientDocLink tblClientDocLink) {
		super.saveOrUpdateEntity(tblClientDocLink);
	}

	

}
