package com.etl.eproc.common.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblMobileUserLoginDao;
import com.etl.eproc.common.model.TblMobileUserLogin;

/**
 * 
 * @author urja.r
 *
 */
@Repository @Transactional    /*StackUpdate*/
public class TblMobileUserLoginImpl extends AbcAbstractClass<TblMobileUserLogin> implements TblMobileUserLoginDao {

    @Override
    public void addTblMobileUserLogin(TblMobileUserLogin tblMobileUserLogin){
        super.addEntity(tblMobileUserLogin);
    }

    @Override
    public void deleteTblMobileUserLogin(TblMobileUserLogin tblMobileUserLogin) {
        super.deleteEntity(tblMobileUserLogin);
    }

    @Override
    public void updateTblMobileUserLogin(TblMobileUserLogin tblMobileUserLogin) {
        super.updateEntity(tblMobileUserLogin);
    }

    @Override
    public List<TblMobileUserLogin> getAllTblMobileUserLogin() {
        return super.getAllEntity();
    }

    @Override
    public List<TblMobileUserLogin> findTblMobileUserLogin(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblMobileUserLoginCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblMobileUserLogin> findByCountTblMobileUserLogin(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblMobileUserLogin(List<TblMobileUserLogin> tblMobileUserLogins){
        super.updateAll(tblMobileUserLogins);
    }
}
