package com.etl.eproc.common.daointerface;

import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.springframework.dao.DataAccessResourceFailureException;

/*
 * @author TaherT
 */
public interface HibernateQueryDao  {
	//GenericDao methods
		List<Object[]> createQuery(String query,Map<String,Object> var);
	    
	    List<Object[]> createSQLQuery(String query,Map<String,Object> var);
	    
	    public List<Object[]> createSQLQuery(String query, Map<String, Object> var,int[] ncharsIndex,int colcount);

	   // List<Object[]> createByCountQuery(String query, Map<String,Object> var,int firstResult, int maxResult);

	    long countForQuery(String from,String countOn, String where,Map<String,Object> var) throws Exception;

	    List<Object> singleColQuery(String query,Map<String,Object> var);

	    int updateDeleteQuery(String query,Map<String,Object> var);

	    int updateDeleteSQLQuery(String query,Map<String,Object> var);
	    
	    public List nativeQueryToBean(String query, Class classAlias, Map<String, Object> var) throws DataAccessResourceFailureException, HibernateException, IllegalStateException, ClassNotFoundException;
	    
	    List<Object[]> createQueryForGmr(String query,Map<String,Object> var);
	    
	    //Existing methods
		List<Object[]> createNewQuery(String query,Map<String,Object> var);
	     
	   // List<Object[]> createByCountNewQuery(String query,Map<String,Object> var,int firstResult,int maxResult);

	    public long countForNewQuery(String from,String countOn, String where,Map<String,Object> var) throws Exception;

	    List<Object> getSingleColQuery(String query,Map<String,Object> var);

	    int updateDeleteNewQuery(String query,Map<String,Object> var);

	    int updateDeleteSQLNewQuery(String query,Map<String,Object> var);

	    List<Object[]> nativeSQLQuery(String query, Map<String, Object> var);
	     
	    public List nativeNewQueryToBean(String query, Class classAlias, Map<String, Object> var) throws DataAccessResourceFailureException, HibernateException, IllegalStateException, ClassNotFoundException;

	}
