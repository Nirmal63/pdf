package com.etl.eproc.advertise.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.springframework.core.style.ToStringCreator;

@Entity
@Table(name="Tbl_AdvertiseDigitalSignHistory",schema="appreport")
public class TblAdvertiseDigitalSignHistory  implements java.io.Serializable {

        private   int advertiseDigitalSignId;
        private   String remark;
        private   String signText;
        private   TblAdvertiseAuditTrail tblAdvertiseAuditTrail;


        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name="advertiseDigitalSignId",unique=true,nullable=false)
        public int getAdvertiseDigitalSignId() {
            return this.advertiseDigitalSignId;
        }

        public void setAdvertiseDigitalSignId(int advertiseDigitalSignId) {
            this.advertiseDigitalSignId = advertiseDigitalSignId;
        }
        public TblAdvertiseDigitalSignHistory(int advertiseDigitalSignId){
            this.advertiseDigitalSignId = advertiseDigitalSignId;
        }
        @Column(name="remark",nullable=false, length=1000)
        public String getRemark() {
            return this.remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }
        @Column(name="signText",nullable=true, length= -1)
        public String getSignText() {
            return this.signText;
        }

        public void setSignText(String signText) {
            this.signText = signText;
        }
        @ManyToOne(fetch=FetchType.LAZY)
        @JoinColumn(name="advertiseaudittrailid")
        public TblAdvertiseAuditTrail getTblAdvertiseAuditTrail() {
            return this.tblAdvertiseAuditTrail;
        }

        public void setTblAdvertiseAuditTrail(TblAdvertiseAuditTrail tblAdvertiseAuditTrail) {
            this.tblAdvertiseAuditTrail = tblAdvertiseAuditTrail;
        }
        public TblAdvertiseDigitalSignHistory(){
        }
        @Override
	public String toString() {
		return new ToStringCreator(this)
.append("advertiseDigitalSignId", this.getAdvertiseDigitalSignId())
.append("remark", this.getRemark())
.append("signText", this.getSignText())

		.toString();

	}
}
