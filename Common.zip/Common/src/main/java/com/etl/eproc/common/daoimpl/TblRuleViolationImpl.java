package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblRuleViolation;
import com.etl.eproc.common.daointerface.TblRuleViolationDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblRuleViolationImpl extends AbcAbstractClass<TblRuleViolation> implements TblRuleViolationDao {

    @Override
    public void addTblRuleViolation(TblRuleViolation tblRuleViolation){
        super.addEntity(tblRuleViolation);
    }

    @Override
    public void deleteTblRuleViolation(TblRuleViolation tblRuleViolation) {
        super.deleteEntity(tblRuleViolation);
    }

    @Override
    public void updateTblRuleViolation(TblRuleViolation tblRuleViolation) {
        super.updateEntity(tblRuleViolation);
    }

    @Override
    public List<TblRuleViolation> getAllTblRuleViolation() {
        return super.getAllEntity();
    }

    @Override
    public List<TblRuleViolation> findTblRuleViolation(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblRuleViolationCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblRuleViolation> findByCountTblRuleViolation(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblRuleViolation(List<TblRuleViolation> tblRuleViolations){
        super.updateAll(tblRuleViolations);
    }
}