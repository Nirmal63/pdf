package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblRetiredOfficerRegDao;
import com.etl.eproc.common.model.TblRetiredOfficerReg;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Nirav Raval
 */
@Repository @Transactional    /*StackUpdate*/
public class TblRetiredOfficerRegImpl extends AbcAbstractClass<TblRetiredOfficerReg> implements TblRetiredOfficerRegDao {

    @Override
    public void addTblRetiredOfficerReg(TblRetiredOfficerReg tblRetiredOfficerReg) {
        super.addEntity(tblRetiredOfficerReg);
    }

    @Override
    public void deleteTblRetiredOfficerReg(TblRetiredOfficerReg tblRetiredOfficerReg) {
        super.deleteEntity(tblRetiredOfficerReg);
    }

    @Override
    public void updateTblRetiredOfficerReg(TblRetiredOfficerReg tblRetiredOfficerReg) {
        super.updateEntity(tblRetiredOfficerReg);
    }

    @Override
    public List<TblRetiredOfficerReg> getAllTblRetiredOfficerReg() {
        return super.getAllEntity();
    }

    @Override
    public List<TblRetiredOfficerReg> findTblRetiredOfficerReg(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblRetiredOfficerRegCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblRetiredOfficerReg> findByCountTblRetiredOfficerReg(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblRetiredOfficerReg(List<TblRetiredOfficerReg> tblRetiredOfficerRegs) {
        super.updateAll(tblRetiredOfficerRegs);
    }
}
