package com.etl.eproc.common.daointerface;

import java.util.List;


import com.etl.eproc.common.model.TblClientDocLink;

/**
*
* @author dipika
*/
public interface TblClientDocLinkDao  {

    public void addTblClientDocLink(TblClientDocLink tblClientDocLink);

    public void deleteTblClientDocLink(TblClientDocLink tblClientDocLink);

    public void updateTblClientDocLink(TblClientDocLink tblClientDocLink);

    public List<TblClientDocLink> getAllTblClientDocLink();

    public List<TblClientDocLink> findTblClientDocLink(Object... values) throws Exception;

    public List<TblClientDocLink> findByCountTblClientDocLink(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientDocLinkCount();

    public void saveUpdateAllTblClientDocLink(List<TblClientDocLink> tblClientDocLinks);

	public void saveOrUpdateTblClientDocLink(TblClientDocLink tblClientDocLink);
}
