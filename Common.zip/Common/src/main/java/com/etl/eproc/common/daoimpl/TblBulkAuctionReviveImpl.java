package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblBulkAuctionRevive;
import com.etl.eproc.common.daointerface.TblBulkAuctionReviveDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblBulkAuctionReviveImpl extends AbcAbstractClass<TblBulkAuctionRevive> implements TblBulkAuctionReviveDao {

    @Override
    public void addTblBulkAuctionRevive(TblBulkAuctionRevive tblBulkAuctionRevive){
        super.addEntity(tblBulkAuctionRevive);
    }

    @Override
    public void deleteTblBulkAuctionRevive(TblBulkAuctionRevive tblBulkAuctionRevive) {
        super.deleteEntity(tblBulkAuctionRevive);
    }

    @Override
    public void updateTblBulkAuctionRevive(TblBulkAuctionRevive tblBulkAuctionRevive) {
        super.updateEntity(tblBulkAuctionRevive);
    }

    @Override
    public List<TblBulkAuctionRevive> getAllTblBulkAuctionRevive() {
        return super.getAllEntity();
    }

    @Override
    public List<TblBulkAuctionRevive> findTblBulkAuctionRevive(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblBulkAuctionReviveCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblBulkAuctionRevive> findByCountTblBulkAuctionRevive(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblBulkAuctionRevive(List<TblBulkAuctionRevive> tblBulkAuctionRevives){
        super.updateAll(tblBulkAuctionRevives);
    }

	@Override
	public void saveOrUpdateTblBulkAuctionRevive(TblBulkAuctionRevive tblBulkAuctionRevive) {
		super.saveOrUpdateEntity(tblBulkAuctionRevive);
		
	}
}
