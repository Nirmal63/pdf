package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblUserClientAccessDao;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblUserClientAccess;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblUserClientAccessImpl extends AbcAbstractClass<TblUserClientAccess> implements TblUserClientAccessDao {

    @Override
    public void addTblUserClientAccess(TblUserClientAccess tblUserClientAccess){
        super.addEntity(tblUserClientAccess);
    }

    @Override
    public void deleteTblUserClientAccess(TblUserClientAccess tblUserClientAccess) {
        super.deleteEntity(tblUserClientAccess);
    }

    @Override
    public void updateTblUserClientAccess(TblUserClientAccess tblUserClientAccess) {
        super.updateEntity(tblUserClientAccess);
    }

    @Override
    public List<TblUserClientAccess> getAllTblUserClientAccess() {
        return super.getAllEntity();
    }

    @Override
    public List<TblUserClientAccess> findTblUserClientAccess(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblUserClientAccessCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblUserClientAccess> findByCountTblUserClientAccess(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblUserClientAccess(List<TblUserClientAccess> tblUserClientAccesss){
        super.updateAll(tblUserClientAccesss);
    }
}
