package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblCommitteeUserRole;
import java.util.List;

public interface TblCommitteeUserRoleDao  {

    public void addTblCommitteeUserRole(TblCommitteeUserRole tblCommitteeUserRole);

    public void deleteTblCommitteeUserRole(TblCommitteeUserRole tblCommitteeUserRole);

    public void updateTblCommitteeUserRole(TblCommitteeUserRole tblCommitteeUserRole);

    public List<TblCommitteeUserRole> getAllTblCommitteeUserRole();

    public List<TblCommitteeUserRole> findTblCommitteeUserRole(Object... values) throws Exception;

    public List<TblCommitteeUserRole> findByCountTblCommitteeUserRole(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCommitteeUserRoleCount();

    public void saveUpdateAllTblCommitteeUserRole(List<TblCommitteeUserRole> tblCommitteeUserRoles);
}