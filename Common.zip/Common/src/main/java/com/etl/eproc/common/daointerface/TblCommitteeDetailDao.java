package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblCommitteeDetail;
import java.util.List;

public interface TblCommitteeDetailDao  {

    public void addTblCommitteeDetail(TblCommitteeDetail tblCommitteeDetail);

    public void deleteTblCommitteeDetail(TblCommitteeDetail tblCommitteeDetail);

    public void updateTblCommitteeDetail(TblCommitteeDetail tblCommitteeDetail);

    public List<TblCommitteeDetail> getAllTblCommitteeDetail();

    public List<TblCommitteeDetail> findTblCommitteeDetail(Object... values) throws Exception;

    public List<TblCommitteeDetail> findByCountTblCommitteeDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCommitteeDetailCount();

    public void saveUpdateAllTblCommitteeDetail(List<TblCommitteeDetail> tblCommitteeDetails);
}