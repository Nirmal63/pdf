package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblMessage;
import java.util.List;

public interface TblMessageDao  {

    public void addTblMessage(TblMessage tblMessage);

    public void deleteTblMessage(TblMessage tblMessage);

    public void updateTblMessage(TblMessage tblMessage);

    public List<TblMessage> getAllTblMessage();

    public List<TblMessage> findTblMessage(Object... values) throws Exception;

    public List<TblMessage> findByCountTblMessage(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblMessageCount();

    public void saveUpdateAllTblMessage(List<TblMessage> tblMessages);

	public void saveOrUpdateTblMessage(TblMessage tblMessage);
}