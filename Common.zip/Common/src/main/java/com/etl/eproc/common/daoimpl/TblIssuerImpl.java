package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblIssuerDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblIssuer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblIssuerImpl extends AbcAbstractClass<TblIssuer> implements TblIssuerDao {

    @Override
    public void addTblIssuer(TblIssuer tblIssuer){
        super.addEntity(tblIssuer);
    }

    @Override
    public void deleteTblIssuer(TblIssuer tblIssuer) {
        super.deleteEntity(tblIssuer);
    }

    @Override
    public void updateTblIssuer(TblIssuer tblIssuer) {
        super.updateEntity(tblIssuer);
    }

    @Override
    public List<TblIssuer> getAllTblIssuer() {
        return super.getAllEntity();
    }

    @Override
    public List<TblIssuer> findTblIssuer(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblIssuerCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblIssuer> findByCountTblIssuer(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblIssuer(List<TblIssuer> tblIssuers){
        super.updateAll(tblIssuers);
    }
}
