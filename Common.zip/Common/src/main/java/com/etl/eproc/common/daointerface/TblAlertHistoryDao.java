package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblAlertHistory;

public interface TblAlertHistoryDao  {

    public void addTblAlertHistory(TblAlertHistory tblAlertHistory);

    public void deleteTblAlertHistory(TblAlertHistory tblAlertHistory);

    public void updateTblAlertHistory(TblAlertHistory tblAlertHistory);

    public List<TblAlertHistory> getAllTblAlertHistory();

    public List<TblAlertHistory> findTblAlertHistory(Object... values) throws Exception;

    public List<TblAlertHistory> findByCountTblAlertHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblAlertHistoryCount();

    public void saveUpdateAllTblAlertHistory(List<TblAlertHistory> tblAlertHistorys);
}