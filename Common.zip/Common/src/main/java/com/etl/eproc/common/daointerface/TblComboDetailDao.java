package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblComboDetail;
import java.util.List;

public interface TblComboDetailDao  {

    public void addTblComboDetail(TblComboDetail tblComboDetail);

    public void deleteTblComboDetail(TblComboDetail tblComboDetail);

    public void updateTblComboDetail(TblComboDetail tblComboDetail);

    public List<TblComboDetail> getAllTblComboDetail();

    public List<TblComboDetail> findTblComboDetail(Object... values) throws Exception;

    public List<TblComboDetail> findByCountTblComboDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblComboDetailCount();

    public void saveUpdateAllTblComboDetail(List<TblComboDetail> tblComboDetails);
}