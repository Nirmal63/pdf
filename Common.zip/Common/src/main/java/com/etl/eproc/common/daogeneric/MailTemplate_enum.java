package com.etl.eproc.common.daogeneric;

/**
 * @author pradip.jinjala
 *
 */
public enum MailTemplate_enum {

	tempBlacklist("9"),
	renewalOfRegistration("130"),
	digitalCertAttachedbyCompany("235"),
	bidderRegistration("236"),
	successfulRegistration("239"),
	registeredEmailId("240"),
	youHaveBeenRegistered("241"),
	bidderApproval("242"),
	digitalCertHasUnmapped("250"),
	restOfEventItemWiseAuthorizeSendmailTemplateId("255"),
	restOfEventGrandTotalAuthorizeSendmailTemplateId("256"),
	notificationFortheEventAttachmentPath("258"),
	notificationFortheEvent("259"),
	notifyBidderMailTemplateId("269"),
	oneTimePasswordForabcprocureMobile("270"),
	submitOfflineEMDTemplateId("329"),
	unintentionlMailIdUsed("360"),
	vendorCodeHasUpdated("366"),
	invitedForPriceReviseimpact("367"),
	digitalCertAttached("372"),
	tenderHasPublished("373"),
	regrettedBySystem("384"),
	discussioForEnquiry("385"),
	registerUserVfByMailAndMobile("6"),
	registerUserVfByMail("12"),
	profileRegistered("13"),
	enableOfficer("14"),
	disableOfficer("15"),
	PermanentlyBlacklisted("16"),
	registrationByOfficer("18"),
	profileUpdated("19"),
	profileRegisteredVfByBidder("20"),
	removeTempBlacklist("21"),
	approveBidderbyOfficer("22"),
	rejectBidderProfileOfficer("23"),
	renewalregistration("24"),
	registeredDepartmentUser("25"),
	bidderRegistrationBySelf("26"),
	approveOfficerProfile("30"),
	invitationConsortium("41"),
	accptRejConsortium("42"),
	resetConsortium("43"),
	tenNegotiationInvite("84"),
	tenFinalSubmission("86"),
	tenCloseNegotiation("87"),
	tenNegotiationPublishCommittee("90"),
	tenNegotiationBidderAcceptance("94"),
	tenNegotiationBuyerAcceptance("95"),
	finalEvaluation("386"),
	discussionReplyForEnquiry("390"),
	discussionCloseForEnquiry("391"),
	bidEvaluationReportPublish("392"),
	resultSharingToEligibleBidders("389"),
	reviseimpactFinalSubmission("388"),
	aucBrdInvitation("61"),
	aucRevisedBrd("65"),
	aucLoiPublish("73"),
	aucNegotiationInvite("83"),
	aucCloseNegotiation("88"),
	aucNegotiationPublishCommittee("89"),
	aucNegotiationBidderAcceptance("91"),
	aucNegotiationBuyerAcceptance("94"),
	aucUnmapBidder("165"),
	aucStop("166"),
	aucRejectBid("167"),
	aucResume("168"),
	aucProxyAutoBid("169"),
	aucProxyBid("170"),
	aucRestOfAuctionMoney("238"),
	aucEmdPayment("257"),
	aucPublished("171"),
	aucCancel("173"),
	aucSendStcTempleteId("177"),
	aucSendSoldTempleteId("178"),
	aucBidEvaluation("181"),
	aucQuickAuctionMailToRegisteredbidder("183"),
	aucQuickAuctionMailToUnRegisteredbidder("184"),
	aucBidstatusOts("208"),
	aucBidstatusSta("209"),
	aucRestOfSecurityAuthorize("356"),
	aucPaymentRestOfSecurityFees("357"),
	aucReleaseRestOfSecurityFees("358"),
	aucSendReminderMail("393");
	
	
	private final String mailTemplateId;
	private MailTemplate_enum(String mailTemplateId){
		this.mailTemplateId=mailTemplateId;
	}
	
	@Override
	public String toString(){
		return mailTemplateId;
	}
}
