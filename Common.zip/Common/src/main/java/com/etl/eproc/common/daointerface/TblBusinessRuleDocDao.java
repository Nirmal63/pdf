/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblBusinessRuleDoc;

/**
 *
 * @author Nirav M. Raval
 */
public interface TblBusinessRuleDocDao  {

    public void addTblBusinessRuleDoc(TblBusinessRuleDoc tblBusinessRuleDoc);

    public void deleteTblBusinessRuleDoc(TblBusinessRuleDoc tblBusinessRuleDoc);

    public void updateTblBusinessRuleDoc(TblBusinessRuleDoc tblBusinessRuleDoc);

    public List<TblBusinessRuleDoc> getAllTblBusinessRuleDoc();

    public List<TblBusinessRuleDoc> findTblBusinessRuleDoc(Object... values) throws Exception;

    public List<TblBusinessRuleDoc> findByCountTblBusinessRuleDoc(int firstResult, int maxResult, Object... values) throws Exception;

    public long getTblBusinessRuleDocCount();

    public void saveUpdateAllTblBusinessRuleDoc(List<TblBusinessRuleDoc> tblBusinessRuleDocs);
}
