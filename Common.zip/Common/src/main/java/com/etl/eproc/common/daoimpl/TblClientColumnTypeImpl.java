package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblClientColumnType;
import com.etl.eproc.common.daointerface.TblClientColumnTypeDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientColumnTypeImpl extends AbcAbstractClass<TblClientColumnType> implements TblClientColumnTypeDao {

    @Override
    public void addTblClientColumnType(TblClientColumnType tblClientColumnType){
        super.addEntity(tblClientColumnType);
    }

    @Override
    public void deleteTblClientColumnType(TblClientColumnType tblClientColumnType) {
        super.deleteEntity(tblClientColumnType);
    }

    @Override
    public void updateTblClientColumnType(TblClientColumnType tblClientColumnType) {
        super.updateEntity(tblClientColumnType);
    }

    @Override
    public List<TblClientColumnType> getAllTblClientColumnType() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientColumnType> findTblClientColumnType(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientColumnTypeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientColumnType> findByCountTblClientColumnType(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientColumnType(List<TblClientColumnType> tblClientColumnTypes){
        super.updateAll(tblClientColumnTypes);
    }
}
