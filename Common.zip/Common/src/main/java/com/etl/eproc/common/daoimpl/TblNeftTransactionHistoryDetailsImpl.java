package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.etl.eproc.common.model.TblNeftTransactionHistoryDetails;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblNeftTransactionHistoryDetailsDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.hibernate.SessionFactory;

import java.util.List;

/**
 *
 * @author taher
 */
@Repository
public class TblNeftTransactionHistoryDetailsImpl extends AbcAbstractClass<TblNeftTransactionHistoryDetails> implements TblNeftTransactionHistoryDetailsDao {

	@Override
	public void addTblNeftTransactionHistoryDetails(TblNeftTransactionHistoryDetails tblNeftTransactionHistoryDetails) {
		// TODO Auto-generated method stub
		super.addEntity(tblNeftTransactionHistoryDetails);
	}

	@Override
	public void deleteTblNeftTransactionHistoryDetails(TblNeftTransactionHistoryDetails tblNeftTransactionHistoryDetails) {
		// TODO Auto-generated method stub
        super.updateEntity(tblNeftTransactionHistoryDetails);
	}

	@Override
	public void updateTblNeftTransactionHistoryDetails(TblNeftTransactionHistoryDetails tblNeftTransactionHistoryDetails) {
		// TODO Auto-generated method stub
		super.updateEntity(tblNeftTransactionHistoryDetails);
	}

	@Override
	public List<TblNeftTransactionHistoryDetails> getAllTblNeftTransactionHistoryDetails() {
		// TODO Auto-generated method stub
        return super.getAllEntity();
	}

	@Override
	public List<TblNeftTransactionHistoryDetails> findTblNeftTransactionHistoryDetails(Object... values) throws Exception {
		// TODO Auto-generated method stub
        return super.findEntity(values);
	}

	@Override
	public List<TblNeftTransactionHistoryDetails> findByCountTblNeftTransactionHistoryDetails(int firstResult, int maxResult, Object... values) throws Exception {
		// TODO Auto-generated method stub
        return super.findByCountEntity(firstResult, maxResult, values);
	}

	@Override
	public long getTblNeftTransactionHistoryDetailsCount() {
		// TODO Auto-generated method stub
		return super.getEntityCount();
	}

	@Override
	public void saveUpdateAllTblNeftTransactionHistoryDetails(List<TblNeftTransactionHistoryDetails> tblNeftTransactionHistoryDetails) {
		// TODO Auto-generated method stub
        super.updateAll(tblNeftTransactionHistoryDetails);
	}

	@Override
	public void saveOrUpdateTblNeftTransactionHistoryDetails(
			TblNeftTransactionHistoryDetails tblNeftTransactionHistoryDetails) {
		super.saveOrUpdateEntity(tblNeftTransactionHistoryDetails);
		
	}


    
}
