package com.etl.eproc.common.daointerface;

import java.util.List;


import com.etl.eproc.common.model.TblCouponHistory;

/*
 * @author TaherT
 */
public interface TblCouponHistoryDao  {
	
	public List<TblCouponHistory> findTblCouponHistory(Object... values) throws Exception;

	public void saveOrUpdateTblCouponHistory(TblCouponHistory tblCouponHistory);

	
}
