/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daointerface;

/**
 *
 * @author mitesh
 */
import com.etl.eproc.common.model.TblCommitteeRemarks;

import java.util.List;

public interface TblCommitteeRemarksDao  {

    public void addTblCommitteeRemarks(TblCommitteeRemarks tblCommitteeRemarks);

    public void deleteTblCommitteeRemarks(TblCommitteeRemarks tblCommitteeRemarks);

    public void updateTblCommitteeRemarks(TblCommitteeRemarks tblCommitteeRemarks);

    public List<TblCommitteeRemarks> getAllTblCommitteeRemarks();

    public List<TblCommitteeRemarks> findTblCommitteeRemarks(Object... values) throws Exception;

    public List<TblCommitteeRemarks> findByCountTblCommitteeRemarks(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCommitteeRemarksCount();

    public void saveUpdateAllTblCommitteeRemarks(List<TblCommitteeRemarks> tblCommitteeRemarkss);

	public void saveOrUpdateTblCommitteeRemarks(TblCommitteeRemarks committeeremarks);
}