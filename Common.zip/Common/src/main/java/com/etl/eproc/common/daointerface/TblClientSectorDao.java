package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientSector;
import java.util.List;

public interface TblClientSectorDao  {

    public void addTblClientSector(TblClientSector TblClientSector);

    public void deleteTblClientSector(TblClientSector TblClientSector);

    public void updateTblClientSector(TblClientSector TblClientSector);

    public List<TblClientSector> getAllTblClientSector();

    public List<TblClientSector> findTblClientSector(Object... values) throws Exception;

    public List<TblClientSector> findByCountTblClientSector(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientSectorCount();

    public void saveOrUpdateTblClientSector(TblClientSector list);
}