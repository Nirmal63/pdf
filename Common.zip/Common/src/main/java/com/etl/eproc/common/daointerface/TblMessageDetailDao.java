package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.common.model.TblMessageDetail;

public interface TblMessageDetailDao  {

    public void addTblMessageDetail(TblMessageDetail tblMessageDetail);

    public void deleteTblMessageDetail(TblMessageDetail tblMessageDetail);

    public void updateTblMessageDetail(TblMessageDetail tblMessageDetail);

    public List<TblMessageDetail> getAllTblMessageDetail();

    public List<TblMessageDetail> findTblMessageDetail(Object... values) throws Exception;

    public List<TblMessageDetail> findByCountTblMessageDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblMessageDetailCount();

    public void saveUpdateAllTblMessageDetail(List<TblMessageDetail> tblMessageDetails);
}