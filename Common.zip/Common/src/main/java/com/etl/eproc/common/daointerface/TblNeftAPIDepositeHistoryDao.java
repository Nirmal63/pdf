package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



import com.etl.eproc.common.model.TblNeftAPIDepositeHistory;
import java.util.List;


public interface TblNeftAPIDepositeHistoryDao  {

    public void addTblNeftAPIDepositeHistory(TblNeftAPIDepositeHistory tblNeftAPIDepositeHistory);

    public void deleteTblNeftAPIDepositeHistory(TblNeftAPIDepositeHistory tblNeftAPIDepositeHistory);

    public void updateTblNeftAPIDepositeHistory(TblNeftAPIDepositeHistory tblNeftAPIDepositeHistory);

    public List<TblNeftAPIDepositeHistory> getAllTblNeftAPIDepositeHistory();

    public List<TblNeftAPIDepositeHistory> findTblNeftAPIDepositeHistory(Object... values) throws Exception;

    public List<TblNeftAPIDepositeHistory> findByCountTblNeftAPIDepositeHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblNeftAPIDepositeHistoryCount();

    public void saveUpdateAllTblNeftAPIDepositeHistory(List<TblNeftAPIDepositeHistory> tblNeftAPIDepositeHistorys);

	public void saveOrUpdateTblNeftAPIDepositeHistory(TblNeftAPIDepositeHistory tblNeftAPIDepositeHistory);
}