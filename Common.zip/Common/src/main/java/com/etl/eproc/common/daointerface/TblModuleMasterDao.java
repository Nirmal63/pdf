package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.common.model.TblModuleMaster;

public interface TblModuleMasterDao  {

    public void addTblModuleMaster(TblModuleMaster tblModuleMaster);

    public void deleteTblModuleMaster(TblModuleMaster tblModuleMaster);

    public void updateTblModuleMaster(TblModuleMaster tblModuleMaster);

    public List<TblModuleMaster> getAllTblModuleMaster();

    public List<TblModuleMaster> findTblModuleMaster(Object... values) throws Exception;

    public List<TblModuleMaster> findByCountTblModuleMaster(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblModuleMasterCount();
}