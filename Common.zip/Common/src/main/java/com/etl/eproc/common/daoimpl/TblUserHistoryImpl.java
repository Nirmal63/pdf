package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblUserHistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblUserHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblUserHistoryImpl extends AbcAbstractClass<TblUserHistory> implements TblUserHistoryDao {

    @Override
    public void addTblUserHistory(TblUserHistory tblUserHistory){
        super.addEntity(tblUserHistory);
    }

    @Override
    public void deleteTblUserHistory(TblUserHistory tblUserHistory) {
        super.deleteEntity(tblUserHistory);
    }

    @Override
    public void updateTblUserHistory(TblUserHistory tblUserHistory) {
        super.updateEntity(tblUserHistory);
    }

    @Override
    public List<TblUserHistory> getAllTblUserHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblUserHistory> findTblUserHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblUserHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblUserHistory> findByCountTblUserHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblUserHistory(List<TblUserHistory> tblUserHistorys){
        super.updateAll(tblUserHistorys);
    }

	@Override
	public void saveOrUpdateTblUserHistory(TblUserHistory userHistory) {
		super.saveOrUpdateEntity(userHistory);
		
	}
}
