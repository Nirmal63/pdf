package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblOfflineAdvancePurchaseOrderDao;
import com.etl.eproc.common.model.TblOfflineAdvancePurchaseOrder;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblOfflineAdvancePurchaseOrderImpl extends AbcAbstractClass<TblOfflineAdvancePurchaseOrder> implements TblOfflineAdvancePurchaseOrderDao {

    @Override
    public void addTblOfflineAdvancePurchaseOrde(TblOfflineAdvancePurchaseOrder tblOfflineAdvancePurchaseOrde){
        super.addEntity(tblOfflineAdvancePurchaseOrde);
    }

    @Override
    public void deleteTblOfflineAdvancePurchaseOrde(TblOfflineAdvancePurchaseOrder tblOfflineAdvancePurchaseOrde) {
        super.deleteEntity(tblOfflineAdvancePurchaseOrde);
    }

    @Override
    public void updateTblOfflineAdvancePurchaseOrde(TblOfflineAdvancePurchaseOrder tblOfflineAdvancePurchaseOrde) {
        super.updateEntity(tblOfflineAdvancePurchaseOrde);
    }

    @Override
    public List<TblOfflineAdvancePurchaseOrder> getAllTblOfflineAdvancePurchaseOrde() {
        return super.getAllEntity();
    }

    @Override
    public List<TblOfflineAdvancePurchaseOrder> findTblOfflineAdvancePurchaseOrde(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblOfflineAdvancePurchaseOrdeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblOfflineAdvancePurchaseOrder> findByCountTblOfflineAdvancePurchaseOrde(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblOfflineAdvancePurchaseOrde(List<TblOfflineAdvancePurchaseOrder> tblOfflineAdvancePurchaseOrdes){
        super.updateAll(tblOfflineAdvancePurchaseOrdes);
    }

	@Override
	public void saveOrUpdateTblOfflineAdvancePurchaseOrder(TblOfflineAdvancePurchaseOrder offlineAPO) {
		super.saveOrUpdateEntity(offlineAPO);
	}
}
