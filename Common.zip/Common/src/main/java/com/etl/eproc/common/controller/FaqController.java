/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblFaq;
import com.etl.eproc.common.model.TblFaqDetail;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FaqService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.EncryptDecryptUtils;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 *
 * @author Vivek.Purohit
 */
@Controller
@RequestMapping(value = "/common")
public class FaqController {

    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private CommonService commonService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private FaqService faqService;
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Autowired
    private AbcUtility abcUtility;
    private static final String ROWCNT = "txtRowCnt";
    private static final String CLIENTID = "hdClientId";
    private static final String FAQID = "faqId";
  
//    private static final String Header = "txtHeader";
    @Value("#{linkProperties['edit_faq_link']?:1633}")
    private int editFaqLinkId;
    @Value("#{linkProperties['create_faq_link']?:1631}")
    private int createFaqLinkId;
    @Value("#{linkProperties['manage_faq_link']?:1632}")
    private int manageFaqLinkId;
    @Value("#{linkProperties['report_admin_manage_faq']?:122}")
    private int manageFaqReportId;
    @Value("#{adminAuditTrailProperties['getEditFaq']}")
    private String getEditFaq;
    @Value("#{adminAuditTrailProperties['getManageFaq']}")
    private String getManageFaq;
    @Value("#{adminAuditTrailProperties['getCreateFaq']}")
    private String getCreateFaq;
    @Value("#{adminAuditTrailProperties['updatedFaqMessage']}")
    private String updatedFaqMessage;
    @Value("#{adminAuditTrailProperties['addFaqMessage']}")
    private String addFaqMessage;
    @Value("#{adminAuditTrailProperties['editFaq']}")
    private String editFaqMessage;
    @Value("#{adminAuditTrailProperties['enableFaqHeader']}")
    private String enableFaqHeader;
    @Value("#{adminAuditTrailProperties['disabledFaqHeader']}")
    private String disabledFaqHeader;
    @Value("#{adminAuditTrailProperties['deleteFaqMessage']}")
    private String deleteFaqMessage;
    
    @RequestMapping(value = "/admin/createfaq/{enc}", method = RequestMethod.GET)
    public String createFaqs(ModelMap modelMap, HttpServletRequest request) {
        try {
        	request.setAttribute("clientId", abcUtility.getSessionClientId(request));
        	modelMap.addAttribute("oprationType", "create");
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createFaqLinkId, getCreateFaq, 0, 0);
        }
        return "common/admin/CreateFaq";
    }

    @RequestMapping(value = "/admin/managefaq/{enc}", method = RequestMethod.GET)
    public String manageFaqs(ModelMap modelMap, HttpServletRequest request) {
        String retVal = null;
        try {
        	retVal = "common/admin/ManageFaq";
        	int clientId = abcUtility.getSessionClientId(request);
        	List<Object[]>faqList=faqService.getManageContent(clientId);
        	if(faqList.size()!=0){
				Object[] frqFirst=faqList.get(0);
				modelMap.addAttribute("frqFirst", frqFirst);
			}
        	modelMap.addAttribute("faqList", faqList);

        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageFaqLinkId, getManageFaq, 0, 0);
        }
        return retVal;
    }

    @RequestMapping(value = "/admin/editfaq/{faqId}/{operation}/{active}/{enc}", method = RequestMethod.GET)
    public String getEditFaq(@PathVariable(FAQID)Integer faqId,@PathVariable("operation")Integer op,@PathVariable("active")Integer active,ModelMap modelMap, HttpServletRequest request) {
    	Object[] frqFirst = null;
    	String retVal = null;
    	boolean success=false;
    	String oprationType=null;
    	int isActive=0;
    	try {
    		request.setAttribute("clientId", abcUtility.getSessionClientId(request));
        	int clientId = abcUtility.getSessionClientId(request);
        	if(op==1)
    		{
    			oprationType="add";
    		}
    		else if(op==0)
    		{
    			oprationType="edit";
    		}
        	if(op!=3)
        	{
		    	List<Object[]> getFAQ = faqService.getEditFaq(faqId, clientId);
				if(getFAQ!=null)
				{
					frqFirst=getFAQ.get(0);
				}
				modelMap.addAttribute("frqFirst", frqFirst);
				modelMap.addAttribute("faqId", faqId);
				modelMap.addAttribute("getFAQ", getFAQ);
				modelMap.addAttribute("oprationType",oprationType);
				retVal= "common/admin/CreateFaq";
        	}
        	else
        	{        		
        		if(active==0)
        		{
        			isActive=1;
        		}
        		success=faqService.disableEnableFAQ(faqId,isActive);
        		if(success)
        		{
        			retVal= "redirect:/common/admin/managefaq" + encryptDecryptUtils.generateRedirect("common/admin/managefaq", request);
        		}
        		
        	}
    		
    		
    		

        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
        	String faqMessage=null;
        	if(op==0)
        	{
        		faqMessage=editFaqMessage;
        	}
        	else if(op==1)
        	{
        		faqMessage=addFaqMessage;
        	}
        	else
        	{
        		if(isActive==1)
        		{
        			faqMessage=enableFaqHeader;
        		}
        		else
        		{
        			faqMessage=disabledFaqHeader;
        		}
        		
        	}
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editFaqLinkId, faqMessage, 0, 0);
        }
    	return retVal;
        
    }

     @RequestMapping(value = "/admin/submitFaq", method = RequestMethod.POST)
    public String submitFaq(RedirectAttributes redirectAttributes, HttpServletRequest request) {
         boolean success=false;
    	 TblFaq tblFAQ=null;
         TblClient tblClient=null;
         TblFaqDetail tblFaqDetail=null;
         List<TblFaqDetail>listTblFaqDetail=new ArrayList<TblFaqDetail>();
         String retVal = null;
         int clientId=0;
         int cnt = 0;
         int faqId=0;
         int totalRow=0;
         String[] faqDetailID = null;
         String[] question;
         String[] answer;
         try {
             	String op=request.getParameter("hdOpt");
             	if(!op.equals("create"))
             	{
             		totalRow=Integer.parseInt(request.getParameter("TotalEditRow"));
             		question=new String[totalRow];
             		answer=new String[totalRow];
             		for(int i=1;i<=totalRow;i++)
             		{
             			question[i-1]=request.getParameter("txtaAddQuestion_"+i);
             			answer[i-1]=request.getParameter("txtaAddAnswer_"+i);
             		}
             		faqDetailID= request.getParameterValues("hdFaqDetailId") ;
             		faqId = StringUtils.hasLength(request.getParameter("hdFaqId")) ? Integer.parseInt(request.getParameter("hdFaqId")) : 0;
             	}
             	else
             	{
             		question = request.getParameterValues("txtaAddQuestion");
             		answer = request.getParameterValues("txtaAddAnswer");
             		cnt = StringUtils.hasLength(request.getParameter(ROWCNT)) ? Integer.parseInt(request.getParameter(ROWCNT)) : 0;
             	}
        	 	
         		clientId = StringUtils.hasLength(request.getParameter(CLIENTID)) ? Integer.parseInt(request.getParameter(CLIENTID)) : 0;
         		
         		String[] sortOrder = request.getParameterValues("txtsortOrder");
         		
         		tblFAQ=new TblFaq();
         		tblClient=new TblClient();
         		tblClient.setClientId(clientId);
         		if(!op.equals("create"))
         		{
         			tblFAQ.setFaqId(faqId);
         		}
         		if(op.equals("create"))
         		{
         			totalRow=cnt;
         		}
         		tblFAQ.setTblClient(tblClient);
         		tblFAQ.setCreatedBy(abcUtility.getSessionUserId(request));
         		tblFAQ.setUpdatedBy(abcUtility.getSessionUserId(request));
         		tblFAQ.setSortOrder(1);
         		tblFAQ.setIsActive(1);
         		tblFAQ.setFaqHeader(request.getParameter("txtHeader"));         		
         		         			
     			for(int i=0;i<totalRow;i++)
     			{
     				tblFaqDetail=new TblFaqDetail();
     				if(op.equals("add")&& (i!=totalRow-1))
     				{
     					tblFaqDetail.setFaqDetailId(Integer.parseInt(faqDetailID[i]));
     				}
     				else if(op.equals("edit"))
     				{
     					tblFaqDetail.setFaqDetailId(Integer.parseInt(faqDetailID[i]));
     				}
     				tblFaqDetail.setQuestion(question[i]);
     				tblFaqDetail.setAnswer(answer[i]);
     				tblFaqDetail.setTblFaq(tblFAQ);
     				tblFaqDetail.setSortOrder(Integer.parseInt(sortOrder[i]));
     				tblFaqDetail.setCreatedBy(abcUtility.getSessionUserId(request));
     				tblFaqDetail.setUpdatedBy(abcUtility.getSessionUserId(request));
     				tblFaqDetail.setIsActive(1);
     				listTblFaqDetail.add(tblFaqDetail);
     			}
     			if(listTblFaqDetail!=null)
     			{
     				success=faqService.addFAQ(tblFAQ,listTblFaqDetail);
     					if (success) {
     		                retVal = "redirect:/common/admin/managefaq" + encryptDecryptUtils.generateRedirect("common/admin/managefaq", request);
     		            }
     				
     			}
         		
         } catch (Exception e) {
             return exceptionHandlerService.writeLog(e);
         } finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editFaqLinkId, addFaqMessage, 0, 0);
         }
         return retVal;
    }
          

    @RequestMapping(value = "/admin/managefaq/deleteFaqDetail", method = RequestMethod.POST)
    @ResponseBody
    public String deleteFaqDetails(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String chckValue=request.getParameter("arr_check");
        String id=request.getParameter("id");
        String[] chkValueList=chckValue.split(",");
        try {
        	List<Integer> faqdetailId = new ArrayList<Integer>();
        	for(int singleChk=0;singleChk<chkValueList.length;singleChk++)
            {
        		if(singleChk==(chkValueList.length)-1)
            	{
        			faqdetailId.add(Integer.parseInt(chkValueList[singleChk].substring(chkValueList[singleChk].indexOf(id)+id.length()+1, chkValueList[singleChk].length()-2)));
            	}
            	else
            	{
            		faqdetailId.add(Integer.parseInt(chkValueList[singleChk].substring(chkValueList[singleChk].indexOf(id)+id.length()+1, chkValueList[singleChk].length()-1)));
            	}
            }
        	faqService.DeleteFAQ(faqdetailId);
        	

        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editFaqLinkId, deleteFaqMessage, 0, 0);
        }
        return "success";
    }
}
