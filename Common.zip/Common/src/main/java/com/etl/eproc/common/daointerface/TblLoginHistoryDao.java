package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblLoginHistory;
import java.util.List;

public interface TblLoginHistoryDao  {

    public void addTblLoginHistory(TblLoginHistory tblLoginHistory);

    public void deleteTblLoginHistory(TblLoginHistory tblLoginHistory);

    public void updateTblLoginHistory(TblLoginHistory tblLoginHistory);

    public List<TblLoginHistory> getAllTblLoginHistory();

    public List<TblLoginHistory> findTblLoginHistory(Object... values) throws Exception;

    public List<TblLoginHistory> findByCountTblLoginHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblLoginHistoryCount();

    public void saveUpdateAllTblLoginHistory(List<TblLoginHistory> tblLoginHistorys);
}