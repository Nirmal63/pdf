/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daointerface;

/**
 *
 * @author mahesh.patel
 */

import com.etl.eproc.common.model.TblFaqDetail;
import java.util.List;

public interface TblFaqDetailDao  {

    public void addTblFaqDetail(TblFaqDetail tblFaqDetail);

    public void deleteTblFaqDetail(TblFaqDetail tblFaqDetail);

    public void updateTblFaqDetail(TblFaqDetail tblFaqDetail);

    public List<TblFaqDetail> getAllTblFaqDetail();

    public List<TblFaqDetail> findTblFaqDetail(Object... values) throws Exception;

    public List<TblFaqDetail> findByCountTblFaqDetail(int firstResult, int maxResult, Object... values) throws Exception;

    public long getTblFaqDetailCount();

    public void saveUpdateAllTblFaqDetail(List<TblFaqDetail> tblFaqDetails);
}