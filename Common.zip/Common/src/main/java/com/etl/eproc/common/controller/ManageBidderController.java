package com.etl.eproc.common.controller;

import java.math.BigDecimal;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.TblBidderStatusDao;
import com.etl.eproc.common.daointerface.TblCompanyDao;
import com.etl.eproc.common.databean.BidderRegistrationDataBean;
import com.etl.eproc.common.databean.CertiDataBean;
import com.etl.eproc.common.model.TblBidderAdditionalFields;
import com.etl.eproc.common.model.TblBidderDocMapping;
import com.etl.eproc.common.model.TblBidderStatus;
import com.etl.eproc.common.model.TblCertUnMapHistory;
import com.etl.eproc.common.model.TblCertificate;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblCountry;
import com.etl.eproc.common.model.TblDCDetachHistory;
import com.etl.eproc.common.model.TblDepartment;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblHintQuestion;
import com.etl.eproc.common.model.TblIndustryClassification;
import com.etl.eproc.common.model.TblIndustryType;
import com.etl.eproc.common.model.TblLink;
import com.etl.eproc.common.model.TblMobileBidderStatus;
import com.etl.eproc.common.model.TblModule;
import com.etl.eproc.common.model.TblOfflinePayment;
import com.etl.eproc.common.model.TblOnlinePayment;
import com.etl.eproc.common.model.TblPasswordHistory;
import com.etl.eproc.common.model.TblPayment;
import com.etl.eproc.common.model.TblPaymentType;
import com.etl.eproc.common.model.TblRegisteredIn;
import com.etl.eproc.common.model.TblRegistrationWorkflow;
import com.etl.eproc.common.model.TblState;
import com.etl.eproc.common.model.TblTimeZone;
import com.etl.eproc.common.model.TblUserBlackList;
import com.etl.eproc.common.model.TblUserCertificate;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserHistory;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.model.TblVendorCodeMapping;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DepartmentUserService;
import com.etl.eproc.common.services.DynamicFieldService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.services.ManageBidderService;
import com.etl.eproc.common.services.ManageContentService;
import com.etl.eproc.common.services.MobileBidderStatusService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.services.WSCheckAvailService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.CommonValidators;
import com.etl.eproc.common.utility.DateUtils;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.SHA1HashEncryption;
import com.etl.eproc.common.utility.SHA256HashEncryption;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.common.utility.WSCheckAvail;
import com.etl.eproc.common.webservice.DataObject;
import com.etl.eproc.vendor.model.TblBidderIndustry;
import com.etl.eproc.vendor.model.TblBidderRegisteredIn;
import com.etl.eproc.vendor.model.TblCompanyEnlistment;
import com.etl.eproc.vendor.services.VendorEnlistmentService;
@Controller
@RequestMapping(value = "/common")
public class ManageBidderController {

	@Autowired
	private ManageBidderService manageBidderService;
	/*@Autowired
	private DateUtils dateUtils;*/
	@Autowired
	private ClientService clientService;
	@Autowired
	private CommonService commonService;
	@Autowired
	private ModelToSelectItem modelToSelectItem;
	@Autowired
	private ExceptionHandlerService exceptionHandlerService;
	@Autowired
	private AuditTrailService auditTrailService;
	@Autowired
	private EncryptDecryptUtils encryptDecryptUtils;
	@Autowired
	private CommonValidators commonValidators;
	@Autowired
	private AbcUtility abcUtility;
	@Autowired
    private SHA256HashEncryption sha256HashEncryption;
    @Autowired
    private SHA1HashEncryption sha1HashEncryption;
	@Autowired
	private LoginService loginService;
	@Autowired
    private ReportGeneratorService reportGeneratorService;
	@Autowired
	private ConversionService conversionService; 
    @Autowired
    private WSCheckAvailService wSCheckAvailService;
    @Autowired
	private ManageContentService manageContentService;
    @Autowired
    private VendorEnlistmentService vendorEnlistmentService;
    @Autowired
    private ReloadableResourceBundleMessageSource messageSource;
    @Autowired
    private FileUploadService fileUploadService;
	@Value("#{projectProperties['userhistory.actiontype.edit']?:2}")
	private int userHistoryEdit;
	@Value("#{projectProperties['userhistory.actiontype.blacklisted']}")
	private String userHistBlacklistStatus;
	@Value("#{projectProperties['bidder.status.incomplete']?:5}")
	private int cstatusIncomplete;
	@Value("#{projectProperties['userhistory.actiontype.create']?:1}")
	private int userHistoryCreate;
	@Value("#{projectProperties['bidder.status.approved']?:1}")
	private String bidderStatusApprove;
	@Value("#{projectProperties['bidder.status.removedfromblacklist']?:13}")
	private String bidderStatusRemovedFromBlacklist;
	@Value("#{projectProperties['bidder.status.rejected']?:7}")
	private String bidderStatusRejected;
	/*@Value("#{projectProperties['bidder.status.renew']?:8}")
	private String bidderStatusRenew;*/
	@Value("#{linkProperties['report_admin_manage_bidder']?:5}")
    private int manageBidderReportId;
	@Value("#{linkProperties['report_view_supplier']?:89}")
    private int viewSupplierReportId;
	@Value("#{linkProperties['report_manage_dc']?:120}")
    private int report_manage_dc;
	@Value("#{linkProperties['report_manage_twostage_reg']?:122}")
    private int report_manage_twostage_reg;
	
	
	@Value("#{projectProperties['userhistory.actiontype.approve']?:3}")
	private String userHistApprove;
	@Value("#{projectProperties['userhistory.actiontype.rejected']?:9}")
	private String userHistReject;
	@Value("#{projectProperties['userhistory.actiontype.renew']?:10}")
	private String userHistRenew;
	@Value("#{projectProperties['bidder.status.approveincomplete']?:6}")
	private int cstatusApproveIncomplete;
	@Value("#{projectProperties['bidder.status.pending']?:0}")
	private int cstatusPending;
	@Autowired
    private MailContentUtillity mailContentUtillity;
	@Value("#{projectProperties['reset.passwordupdatedfrom']}")
    private int passwordUpdatedFrom;
	@Autowired
    private DepartmentUserService departmentUserService;
	@Autowired
    DynamicFieldService dynamicFieldService;
	@Autowired
    private DateUtils dateUtils;
	
	@Value("#{linkProperties['manage_bidder_approve']?:30}")
	private int bidderAproveLinkId;
	@Value("#{linkProperties['manage_bidder_renew_registration']?:35}")
	private int renewRegistrationLinkId;
	@Value("#{linkProperties['manage_bidder_blacklist']?:32}")
	private int bidderBlacklistLinkId;
	@Value("#{linkProperties['manage_bidder_blacklist_edit']?:33}")
	private int bidderBlacklistEditLinkId;
	@Value("#{linkProperties['manage_bidder_remove_from_blacklist']?:34}")
	private int bidderRemoveFromBlacklistLinkId;
	@Value("#{linkProperties['manage_bidder_register_bidder']?:24}")
	private int registrationLinkId;
	@Value("#{linkProperties['manage_bidder_edit_bidder']?:25}")
	private int editBidderLinkId;
	@Value("#{linkProperties['manage_bidder_view_bidder']?:29}")
	private int viewBidderLinkId;
	@Value("#{linkProperties['manage_bidder_unmap_dc']?:37}")
	private int unMapDCLinkId;
	@Value("#{linkProperties['other_map_certificate_on_login']?:151}")
    private int certiMapLink;
	@Value("#{linkProperties['manage_bidder_blacklist_view']?:445}")
    private int viewBlacklistBidderLink;
	@Value("#{linkProperties['manage_bidder_field_value']?:161}")
	private int manageBidderFieldValueId;
	@Value("#{linkProperties['report_admin_manage_registration_charges']?:87}")
    private int manageRegistrationCharges;
	@Value("#{linkProperties['manage_bidders_manage_supplier_registration_charges']?:802}")
    private int manageSupplierRegCharges;
	
	@Value("#{adminAuditTrailProperties['getBidderRegistrationByUser']}")
	private String auditBidderRegistration;
	@Value("#{adminAuditTrailProperties['postBidderRegistedByUser']}")
	private String auditBidderRegistered;
	@Value("#{adminAuditTrailProperties['postBidderRegisterByUserFailed']}")
	private String auditBidderRegistrationFailed;
	@Value("#{adminAuditTrailProperties['getViewBidderProfile']}")
	private String auditViewBidderProfile;
	@Value("#{adminAuditTrailProperties['getEditBidderByAuthUser']}")
	private String auditEditBidderProfile;
	@Value("#{adminAuditTrailProperties['postBidderUpdatedByAuthUser']}")
	private String auditBidderProfileEdited;
	@Value("#{adminAuditTrailProperties['postBidderUpdateByAuthUserFailed']}")
	private String auditBidderProfileEditFailed;
	@Value("#{adminAuditTrailProperties['getRenewBidderRegistration']}")
	private String auditRenewBidderRegistration;
	@Value("#{adminAuditTrailProperties['getApproveBidder']}")
	private String auditApproveBidder;
	@Value("#{adminAuditTrailProperties['getManageBidder']}")
	private String auditManageBidder;
	@Value("#{adminAuditTrailProperties['getBlackListBidder']}")
	private String auditBlackListBidder;
	@Value("#{adminAuditTrailProperties['getEditBlackListBidder']}")
	private String auditEditBlackListBidder;
	@Value("#{adminAuditTrailProperties['getViewBlackListBidder']}")
	private String auditGetViewBlackListBidder;
	@Value("#{adminAuditTrailProperties['getUnMapDC']}")
	private String auditUnMapDc;
	@Value("#{adminAuditTrailProperties['postUnMapDcWithSign']}")
	private String auditUnMapDcWithSign;
	@Value("#{adminAuditTrailProperties['enableSuppalierRegCharges']}")
	private String enableSuppalierRegCharges;
//	@Value("#{adminAuditTrailProperties['postUnMapDcWithSignFailed']}")
//	private String auditUnMapDcWithSignFailed;
//	@Value("#{adminAuditTrailProperties['postUnMapDcNoSign']}")
//	private String auditUnMapDcNoSign;
//	@Value("#{adminAuditTrailProperties['postUnMapDcNoSignFailed']}")
//	private String auditUnMapDcNoSignFailed;
	@Value("#{adminAuditTrailProperties['postBlackListBidder']}")
	private String auditBlackListed;
	@Value("#{adminAuditTrailProperties['postBlackListBidderFailed']}")
	private String auditBlackListFailed;
	@Value("#{adminAuditTrailProperties['postBlackListBidderEdited']}")
	private String auditBlackListEdited;
	@Value("#{adminAuditTrailProperties['postBlackListBidderEditFailed']}")
	private String auditBlackListEditFailed;
	@Value("#{adminAuditTrailProperties['getRemoveBlackList']}")
	private String auditRemoveBlackList;
	@Value("#{adminAuditTrailProperties['postRenewBidderRegistration']}")
	private String auditRenewRegistration;
	@Value("#{adminAuditTrailProperties['postBidderApproved']}")
	private String auditApprovedBidder;
	@Value("#{adminAuditTrailProperties['postRejectBidder']}")
	private String auditRejectedBidder;
	@Value("#{adminAuditTrailProperties['postBidderApprovedSecondStage']}")
	private String auditApprovedBidderSecondStage;	
	@Value("#{adminAuditTrailProperties['postRejectBidderSecondStage']}")
	private String auditRejectedBidderSecondStage;
	@Value("#{adminAuditTrailProperties['postCheckRegCharges']}")
	private String auditCheckRegCharges;
	@Value("#{adminAuditTrailProperties['getResendRegMail']}")
	private String auditResendRegEmail;
	@Value("#{adminAuditTrailProperties['showCertiBidder']}")
    private String showCertiAudit;
	@Value("#{projectProperties['userhistory.actiontype.sendregresetpassword']?:12}")
    private int actionTypeSendRegResetPassword;
	@Value("#{projectProperties['rci_client_ids']}")
    private String rciClientIds;
	@Value("#{projectProperties['bullwarkClientIds']}")
    private String bullwarkClientIds;
	@Value("#{projectProperties['gsl_client']}")
    private String gslClientIds;
	@Value("#{adminAuditTrailProperties['getManageDC']}")
	private String getManageDC;
	@Value("#{adminAuditTrailProperties['getTwoStageReg']}")
	private String getTwoStageReg;
	@Value("#{adminAuditTrailProperties['verifyDC']}")
	private String verifyDC;
	@Value("#{projectProperties['india_iso_code']}")
    private String indiaISOCode;
	@Value("#{projectProperties['investorType_Owner']}")
    private String investorTypeOwner;
	@Value("#{projectProperties['investorType_Agent']}")
    private String investorTypeAgent;
	@Value("#{projectProperties['investorType_NA']}")
    private String investorTypeNA;
	@Value("#{projectProperties['propertyLookingFor_OwnUse']}")
    private String propertyLookingForOwnUse;
	@Value("#{projectProperties['propertyLookingFor_Investment']}")
    private String propertyLookingForInvestment;
	@Value("#{projectProperties['propertyLookingFor_Rent']}")
    private String propertyLookingForRent;
	@Value("#{projectProperties['loanRequired_Yes']}")
    private String loanRequiredYes;
	@Value("#{projectProperties['loanRequired_No']}")
    private String loanRequiredNo;
	@Value("#{projectProperties['spacematrix_clientId']}")
    private int smClientId;
	
	
	
	@Value("#{linkProperties['add_new_field_details']?:3338}")
    private int addNewFieldDetails;
	@Value("#{adminAuditTrailProperties['getAddNewFieldDetails']}")
	private String getAddNewFieldDetails;
	@Value("#{adminAuditTrailProperties['getAddNewFieldDetailsCreation']}")
	private String getAddNewFieldDetailsCreation;
	@Value("#{linkProperties['report_admin_registered_bidders']?:126}")
    private int manageRegisteredBidderReportId;
	@Value("#{projectProperties['mobileapp.defaultAPClientId']?:1}")
    private String defaultAPClientId;
	@Autowired
    private MobileBidderStatusService mobilebidderstatusservice;
	@Value("#{projectProperties['mobileApp_sector']?:9}")
    private int mobileApp_sector;
	@Value("#{linkProperties['upload_bidder_charges_offline']?:684}")
    private int uploadBidderChargesOfflineLink;
	@Value("#{projectProperties['default_contry_id']}")
    private int countryId;
	@Value("#{linkProperties['hide_registration_link']?:3355}")
    private int hideRegistrationLinkId;
	
    @Value("#{linkProperties['manage_bidder_detach_dc']?:5538}")
	private int detachDCLinkId;
    @Value("#{adminAuditTrailProperties['getDetachDC']}")
	private String auditDetachDc;
    @Value("#{adminAuditTrailProperties['postDetachDcWithSign']}")
	private String auditDetachDcWithSign;
    @Value("#{adminAuditTrailProperties['postDetachDcWithEnc']}")
	private String auditDetachDcWithEnc;
    @Value("#{adminAuditTrailProperties['postDetachDcWithSignEnc']}")
	private String auditDetachDcWithSignEnc;
    @Autowired
    private TblBidderStatusDao tblBidderStatusDao;
    @Autowired
    private TblCompanyDao tblCompanyDao;
    @Value("#{projectProperties['block_user_mail_to']}")
	private String block_user_mail_Id;
    @Value("#{projectProperties['phone_no']}")
	private String contact_phoneno;
    @Value("#{projectProperties['email']}")
	private String contact_emailId;
    
    private final static String XFORWARDEDFOR = "X-FORWARDED-FOR";
    
	@RequestMapping(value = "/admin/registerbidderbyuser/{enc}", method = RequestMethod.GET)                       
    public String registerBidderByUser(@ModelAttribute BidderRegistrationDataBean bidderRegistrationDataBean, HttpServletRequest request, ModelMap map){
        String retVal=null;
        try{
        	String publicKey=null;
            if(abcUtility.getSessionIsPkiEnabled(request)==1){
        		String certIds[] = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getCertId().split(",");
        		if(certIds!=null && certIds.length!=0){
        			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
        		}
    		}
            map.put("lstClientMarquee", clientService.getClientMarqueeBylocation((int) abcUtility.getSessionClientId(request),3));/* For After Loging Marque */
            List<Object[]> clientDetails = commonService.getClientCountryStateTimezone(abcUtility.getSessionClientId(request));
            if(clientDetails != null && !clientDetails.isEmpty()) {
            	bidderRegistrationDataBean.setSelTimezone(Integer.parseInt(clientDetails.get(0)[0].toString()));
            	bidderRegistrationDataBean.setSelCountry(Integer.parseInt(clientDetails.get(0)[1].toString()));
            	bidderRegistrationDataBean.setSelState(clientDetails.get(0)[2].toString());
            }
            String langId=WebUtils.getCookie(request, "locale").getValue();
            map.put("timezoneList", modelToSelectItem.convertListIntoSelectItemList(commonService.getTimeZoneList(), "timeZoneId", "lang"+langId));
            map.put("countryList", modelToSelectItem.convertListIntoSelectItemList(commonService.getCountryList(langId), "countryId", "lang"+langId));
            map.put("stateList", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(bidderRegistrationDataBean.getSelCountry()), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
            map.put("publicKey", publicKey);
            map.put("isRegisterByAuthorizedUser", true);
            int clientId = abcUtility.getSessionClientId(request);
            int objectId = abcUtility.getSessionUserId(request);
            map.addAttribute("clientId",clientId);
			map.addAttribute("objectId", objectId);
			map.addAttribute("linkId", manageBidderFieldValueId);
			map.addAttribute("dynFieldMap", dynamicFieldService.setDynamicField(manageBidderFieldValueId, clientId, objectId));
			if(abcUtility.isModuleAssignToClient(request,9)){  //spend analysis module. PT: 20745
				map.put("isCategoryAllow",commonService.isCategoryAllow(abcUtility.getSessionClientId(request)));
			}else{
				map.put("isCategoryAllow",0);
			}
			map.addAttribute("isClientSectorApplicable",  manageBidderService.isClientSectorApplicable(clientId));
			List<SelectItem> isCompanyName = new ArrayList<SelectItem>();
			isCompanyName.add(new SelectItem("Company Name", 1));
			isCompanyName.add(new SelectItem("Individual Name", 0));
			map.addAttribute("isCompanyName", isCompanyName);
			map.addAttribute("isSelCompanyName", 1);
			
			map.addAttribute("registerbidderbyuser","Yes");
			List<SelectItem> entityList = new ArrayList<SelectItem>();
			entityList.add(new SelectItem("GAIL","GAIL"));
			entityList.add(new SelectItem("GGSPL","GGSPL"));
			
			List<SelectItem> typeOfAgreementList= new ArrayList<SelectItem>();
			List<Object[]> activeAgreementTypes=manageBidderService.getActiveAgreementTypes();
			for(Object agreementType:activeAgreementTypes) {
				typeOfAgreementList.add(new SelectItem(String.valueOf(agreementType),String.valueOf(agreementType)));
			}
//			typeOfAgreementList.add(new SelectItem("MSPA","MSPA"));
//			typeOfAgreementList.add(new SelectItem("MSCA","MSCA"));
//			typeOfAgreementList.add(new SelectItem("SPA","SPA"));
//			typeOfAgreementList.add(new SelectItem("GSA","GSA"));
//			typeOfAgreementList.add(new SelectItem("Others","Others"));
			
			List<SelectItem> businessCategoryList = new ArrayList<SelectItem>();
			businessCategoryList.add(new SelectItem("MSPA Buy/Sell","MSPA Buy/Sell"));
			businessCategoryList.add(new SelectItem("MSPA Buy","MSPA Buy"));
			businessCategoryList.add(new SelectItem("MSPA Sell","MSPA Sell"));
			businessCategoryList.add(new SelectItem("Ship Broker","Ship Broker"));
			businessCategoryList.add(new SelectItem("Ship Owner","Ship Owner"));
			businessCategoryList.add(new SelectItem("RLNG Buy","RLNG Buy"));
			businessCategoryList.add(new SelectItem("RLNG Sell","RLNG Sell"));
			businessCategoryList.add(new SelectItem("Others","Others"));
			
			map.addAttribute("entityList",entityList);
			map.addAttribute("typeOfAgreementList",typeOfAgreementList);
			map.addAttribute("businessCategoryList",businessCategoryList);
			
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
	        Date date = new Date();
	        String sdate= formatter.format(date);
	        map.addAttribute("sdate",sdate);
            retVal="BidderRegistration";
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        } finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), registrationLinkId, auditBidderRegistration, 0, 0);
		}
        return retVal;
    }
	
	@RequestMapping(value="/admin/addbidderbyuser", method=RequestMethod.POST)
	public String addBidderByUser(@ModelAttribute BidderRegistrationDataBean bidderRegistrationDataBean, BindingResult result, HttpServletRequest request, RedirectAttributes redirectAttributes, ModelMap modelMap) {
//		String email = request.getParameter("txtEmailId");
		String typeOfAgreement[] = request.getParameterValues("chkAgreements");
		String companyName = request.getParameter("txtCompanyName");
		String dateOfExecutionOfAgreement = request.getParameter("txtDateOfExecutionOfAgreement");
//		String registeredAddress = request.getParameter("txtaAddress");
		String entity = request.getParameter("selEntity");
		String checkDate = request.getParameter("txtCheckDate");
		String pointOfContact = request.getParameter("txtPointOfContact");
		String remarks = request.getParameter("txtRemarks");
		String businessCategory[] = request.getParameterValues("chkbusinessCategories");
		
		bidderRegistrationDataBean.setTxtCompanyName(companyName);
		String hdSubmitType = request.getParameter("hdSubmitType");	
		SimpleDateFormat formatter1=new SimpleDateFormat("dd/MM/yyyy");
		Date DateobjExecutionOfAgreement = null;
		try {
			DateobjExecutionOfAgreement = formatter1.parse(dateOfExecutionOfAgreement);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
//		String txtTypeOfAgreement = request.getParameter("txtAgreements");
		String txtBusinessCategory = request.getParameter("txtbusinessCategories");
		
		String joinedTypeOfAgreement=null;
//		String agreementWith = String.join(",",entity);
		if(typeOfAgreement!=null) {
			joinedTypeOfAgreement = String.join(",", typeOfAgreement);
//			if(txtTypeOfAgreement!="") {			
//				joinedTypeOfAgreement = joinedTypeOfAgreement+","+txtTypeOfAgreement;
//			}			
		}else {
			joinedTypeOfAgreement="";
		}
		
		String joinedBusinessCategory = String.join(",", businessCategory);
		if(txtBusinessCategory!="") {			
			joinedBusinessCategory = joinedBusinessCategory+","+txtBusinessCategory;
		}
		
		boolean success = false;
		String successMsgCode = null;
		String retVal = null;
		int userId=0;
		int clientId = abcUtility.getSessionClientId(request);
		int contentManagementId = 0;
		String selectedCategory[] = null; // PT: 20745
		String isCategoryAllow = "0";
		try{
			bidderRegistrationDataBean.setCommonValidators(commonValidators);
			selectedCategory = request.getParameterValues("txtCategory");
			isCategoryAllow = request.getParameter("hdIsCategoryAllow");
			List<Object> busCatKeywords = null;
			List<LinkedHashMap<String, Object>> list = commonService.checkValidUserInClient(clientId, bidderRegistrationDataBean.getTxtEmailId(), 2);
			int actionType = 0;
			int bidderId = 0;
			int officerId = 0;
			if(list != null && !list.isEmpty()) {
				Map<String, Object> map  = list.get(0);
				if(map.get("actionType") != null) {				
					actionType = Integer.parseInt(map.get("actionType").toString());
					bidderId = Integer.parseInt(map.get("bidderId").toString());
					officerId = Integer.parseInt(map.get("officerId").toString());
				}
			}
			
			// Bug #33494 By Jitendra. If category is allow then getting keyword names from keyword ids and set in bidderRegistrationDataBean model. 
			if(isCategoryAllow != null && isCategoryAllow.equals("1") && selectedCategory != null){
				busCatKeywords = commonService.getKeywordNamesByIds(selectedCategory);
				bidderRegistrationDataBean.setTxtaBusCatKeywords(abcUtility.converObjectArrayToCommas(busCatKeywords));
			}
			
			String pass = null;
			boolean isCheckPassword = false;
			if(actionType == 1) {
				pass = UUID.randomUUID().toString().substring(0, 4)+"@"+UUID.randomUUID().toString().substring(0, 4);
				String encryptedPassword = sha256HashEncryption.encodeStringSHA256(pass);
				bidderRegistrationDataBean.setTxtUserPassword(encryptedPassword);
				bidderRegistrationDataBean.setTxtConfirmPassword(encryptedPassword);
				bidderRegistrationDataBean.setTxtsha1pass(sha1HashEncryption.encodeStringSHA1(pass));
				isCheckPassword = true;
			}
//			bidderRegistrationDataBean.validate(result, true, isCheckPassword, false, actionType);

			if(actionType==2 && bidderId>0) {
				result.rejectValue("txtEmailId", "msg_js_registration_bidderexists", "Email id already registered as bidder on this domain");
			} else if(actionType==2 && officerId>0) {
				result.rejectValue("txtEmailId", "msg_js_registration_officerexists", "Email id already registered as department user on this domain");
			}
			
			if(actionType == 3) {
				success = manageBidderService.addBidderWithProfileInOtherDomain(clientId ,bidderId,false,0,0);
				successMsgCode = "redirect_success_bidder_registration";
				retVal = "redirect:/common/admin/managebidder"+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
			} 
			else if(result.hasErrors()) {
				String langId=WebUtils.getCookie(request, "locale").getValue();
				modelMap.put("countryList", modelToSelectItem.convertListIntoSelectItemList(commonService.getCountryList(langId), "countryId", "lang"+langId));
				if(bidderRegistrationDataBean.getSelCountry() != 0) {
					modelMap.put("stateList", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(bidderRegistrationDataBean.getSelCountry()), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
				}
				modelMap.put("timezoneList", modelToSelectItem.convertListIntoSelectItemList(commonService.getTimeZoneList(), "timeZoneId", "lang"+langId));
				
				String publicKey=null;
	            if(abcUtility.getSessionIsPkiEnabled(request)==1){
	        		String certIds[] = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getCertId().split(",");
	        		if(certIds!=null && certIds.length!=0){
	        			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
	        		}
	    		}
	            modelMap.put("publicKey", publicKey);
				//modelMap.put("isRegisterByAuthorizedUser", true);
				modelMap.addAttribute("registerbidderbyuser","Yes");
				
				success=false;
				
				retVal = "BidderRegistration";
			} else if(actionType!=3 && actionType!=2) {
				int bidderVerificationBy =  clientService.getBidderRegistrationVerifiedBy(clientId);
				String verificationCode = null;
				if(bidderVerificationBy != 0 && bidderVerificationBy != 3) {
					verificationCode=UUID.randomUUID().toString().replaceAll("-", "").substring(0, 10);
				} else {
					verificationCode="0";
				}
				
				TblUserLogin tblUserLogin = null;
				int registrationWorkflowId = 0;
				if(actionType == 4) {
					List<TblUserLogin> tblUserLogins = commonService.getUserLoginById(officerId);
					if(tblUserLogins!=null && !tblUserLogins.isEmpty()) {
						tblUserLogin = tblUserLogins.get(0);
					}
					registrationWorkflowId = manageBidderService.getClientRegWorkflowId(abcUtility.getSessionClientId(request), tblUserLogin.getIsEmailVerified()==1? 3 : 0);
				} else {
					tblUserLogin = bidderRegistrationDataBean._toTblUserLogin(bidderVerificationBy, verificationCode, abcUtility.getSessionUserId(request), 1);
					tblUserLogin.setTblClient(new TblClient(clientId));
					registrationWorkflowId = manageBidderService.getClientRegWorkflowId(abcUtility.getSessionClientId(request), 0);
					if(bidderVerificationBy == 3){
						tblUserLogin.setIsEmailVerified(1);
						tblUserLogin.setIsMobileNoVerified(1);
						registrationWorkflowId=manageBidderService.getClientRegWorkflowId(abcUtility.getSessionClientId(request), 3);
					}
				}
				tblUserLogin.setTblHintQuestion(new TblHintQuestion(1));
				tblUserLogin.setHintAnswer(sha256HashEncryption.encodeStringSHA256("abc"));
				
				if(tblUserLogin.getPasswordUpdatedOn()==null){
					tblUserLogin.setPasswordUpdatedOn(commonService.getServerDateTime());
				}

				int cstatus = cstatusIncomplete;
				if(registrationWorkflowId == 9) {
					cstatus=cstatusPending;
				}
				int isAutoApprove= Integer.parseInt(commonService.getField("TblClient", "isTwoStepBidderApproval", "clientId", clientId));
				if(isAutoApprove==2){
					registrationWorkflowId=9;
					cstatus=1;
				}
				//For CR #25825 - Keval Soni
				if(rciClientIds != null && !"".equals(rciClientIds)){
					String[] rciIds = rciClientIds.split(",");
					if(rciIds.length != 0){
						for(int i = 0;i<rciIds.length;i++){
							if(!"".equals(rciIds[i])){
								if(clientId == Integer.parseInt(rciIds[i])){
									if(actionType == 1){
										int clientCountryId=clientService.getCountryIdByClientId(clientId);
										int bidderCountryId=Integer.parseInt(request.getParameter("selCountry"));
										if(clientCountryId != bidderCountryId && registrationWorkflowId == 5){
											registrationWorkflowId=8;
											break;
										}
									}
								}
							}
						}
					}
				}
				contentManagementId = StringUtils.hasLength(request.getParameter("hdContentManagementId"))?Integer.parseInt(request.getParameter("hdContentManagementId").toString()):0;
				TblBidderStatus tblBidderStatus = bidderRegistrationDataBean._toTblBidderStatus(clientId, cstatus, abcUtility.getSessionUserId(request),contentManagementId);
				tblBidderStatus.setTblRegistrationWorkflow(new TblRegistrationWorkflow(4));
				TblPasswordHistory tblPasswordHistory = new TblPasswordHistory(); //Bug:18917
		        tblPasswordHistory.setCreatedOn(commonService.getServerDateTime());
		        tblPasswordHistory.setOldPassword(tblUserLogin.getPassword());
		        tblPasswordHistory.setPasswordUpdatedFrom(4);
		        
		        List<Object[]> clientCountryStateTimezone = commonService.getClientCountryStateTimezone(clientId);
		        
		        bidderRegistrationDataBean.setSelCountry((int)clientCountryStateTimezone.get(0)[1]);
		        bidderRegistrationDataBean.setSelState(clientCountryStateTimezone.get(0)[2].toString());
		        
		        TblCompany tblCompany = bidderRegistrationDataBean._toTblCompany(clientId);
		        tblCompany.setTblCountry(new TblCountry(Integer.valueOf(clientCountryStateTimezone.get(0)[1].toString())));
		        tblCompany.setTblState(new TblState(Integer.valueOf(clientCountryStateTimezone.get(0)[2].toString())));
		        tblCompany.setAgreementType(joinedTypeOfAgreement);
		        tblCompany.setExecutionDateOfAgreement(DateobjExecutionOfAgreement);
//		        tblCompany.setAgreementWith(agreementWith);
		        tblCompany.setAgreementWith(entity);
		        tblCompany.setCredentialsCheckDate(checkDate);
		        tblCompany.setPointOfContact(pointOfContact);
		        tblCompany.setRemarks(remarks);
		        tblCompany.setBusinessCategory(joinedBusinessCategory);
		        
		        tblUserLogin.setMobileNo("");
		        tblUserLogin.setUserName("");
		        tblUserLogin.setTblTimeZone(new TblTimeZone((Integer.valueOf(clientCountryStateTimezone.get(0)[0].toString()))));
		        tblUserLogin.setIpAddress("");
		        tblUserLogin.setIsFirstLogin(0);
		        
		        TblUserDetail tblUserDetail = bidderRegistrationDataBean._toTblUserDetail(abcUtility.getSessionUserId(request));
		        tblUserDetail.setUserName("");
		        
		        tblCompany.setCity("");
		        tblCompany.setPhoneNo("");
		        tblCompany.setWebsite("");
		        tblCompany.setCompanyName(companyName);
		        
		        tblBidderStatus.setIsAdminBidder(1);
		        tblBidderStatus.setIsParentBidderId(0);
		        tblBidderStatus.setTblCompany(tblCompany);
				success = manageBidderService.addBidderRegistration(tblUserLogin, tblUserDetail, tblCompany, tblBidderStatus, bidderRegistrationDataBean._toTblUserHistory(userHistoryCreate, clientId),tblPasswordHistory, actionType);
				userId=tblUserLogin.getUserId();					    	
	    		success = dynamicFieldService.addDynamicFieldValueProcess(dynamicFieldService.dynFieldSetUp(request.getParameterMap(), request),clientId,manageBidderFieldValueId,userId,userId);
				if(success) {
					boolean isRegister = wSCheckAvailService.registerSSA(bidderRegistrationDataBean,null,tblUserLogin.getUserId(),2,clientId,true);
					if(isRegister){
						loginService.updateLoginSSOStatus(userId);//Is bidder register in SSO,change SSO-status 0 to 1 in TblUserLogin
					}
					URL url = new URL(request.getRequestURL().toString());
					Map<String, Object> emailDataMap = new HashMap<String, Object>();
					emailDataMap.put("to", tblUserLogin.getLoginId());
					emailDataMap.put("subdomainname", url.getHost());
					emailDataMap.put("emailid", tblUserLogin.getLoginId());
					emailDataMap.put("password", pass);
					emailDataMap.put("SubDomainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
					emailDataMap.put("RegByAdminLink","<a href=\"/bidderregistrationByAdmin/"+tblUserLogin.getUserId() + "/"+ tblCompany.getCompanyId() +encryptDecryptUtils.generateRedirect("bidderregistrationByAdmin/" + tblUserLogin.getUserId() + "/"+ tblCompany.getCompanyId(),request)+"\">Registration Link</a>");
					
					Map<String, Object> mailParams = new HashMap<String, Object>();
					mailParams.put("to", tblUserLogin.getLoginId());
					mailParams.put("ClientName",clientService.getClientNameByClientId(abcUtility.getSessionClientId(request)));
					mailParams.put("RegisteredEmailID", tblUserLogin.getLoginId());
					mailParams.put("Password", pass);
					mailParams.put("SubDomainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
					
					boolean isGslClient = CommonUtility.isClientConditionExistInProperty(gslClientIds, clientId) && registrationWorkflowId==9; //for GSL client, sent mail to bidder for complete registration process as step-1
					switch (bidderVerificationBy) {
					case 3:
						if(actionType == 1) {
							if(isGslClient){
								mailContentUtillity.dynamicMailGeneration("241", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
							}else{
								mailContentUtillity.dynamicMailGeneration("18", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
							}
						} else {
							if(isGslClient){
								mailContentUtillity.dynamicMailGeneration("240", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
							}else{
								mailContentUtillity.dynamicMailGeneration("26", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");
							}
						}
					case 2:
						if(actionType == 1) {
							if(tblUserLogin.getIsEmailVerified() == 0) {
								emailDataMap.put("link1", "<a href=\"/authbiddermail/"+encryptDecryptUtils.encrypt(bidderRegistrationDataBean.getTxtEmailId()+"@@"+2+"_"+0)+"\">Email Verification Link</a>");
								mailContentUtillity.dynamicMailGeneration("19", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");
								// TODO :: Mobile verification code by SMS.
							} else {
								mailContentUtillity.dynamicMailGeneration("18", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
							}
						} else {
							mailContentUtillity.dynamicMailGeneration("26", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");
						}
						break;

					case 1:
						if(actionType == 1) {
							emailDataMap.put("link1", "<a href=\"/authbiddermail/"+encryptDecryptUtils.encrypt(bidderRegistrationDataBean.getTxtEmailId()+"@@"+2+"_"+0)+"/"+encryptDecryptUtils.encrypt(tblUserLogin.getVerificationCode())+"\">Email Verification Link</a>");
							mailContentUtillity.dynamicMailGeneration("20", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");  //This template is getting called
						} else {
							mailContentUtillity.dynamicMailGeneration("26", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");
						}
						break;

					case 0:
						if(actionType == 1) {
							if(isGslClient){
								mailContentUtillity.dynamicMailGeneration("241", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
							}else{
								mailContentUtillity.dynamicMailGeneration("18", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
							}
						} else {
							if(isGslClient){
								mailContentUtillity.dynamicMailGeneration("240", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
							}else{
								mailContentUtillity.dynamicMailGeneration("26", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");
							}
						}
						break;

					default:
						break;
					}
					// PT: 20745
					if(abcUtility.isModuleAssignToClient(request,9) && isCategoryAllow != null && isCategoryAllow.equals("1")){ // Module assign Spend Analysis and Statistic 
                    	commonService.insertUpdateCategory("edit",userId,selectedCategory,registrationLinkId);
                    }
					successMsgCode = "redirect_success_bidder_registration";
				}
				
				
				retVal="redirect:/common/admin/managebidder"+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
				if(hdSubmitType.equals("1")) {
					retVal="redirect:/eauction/bidder/uploadDocument/" + userId + encryptDecryptUtils.generateRedirect("eauction/bidder/uploadDocument/"+ userId, request);
				}
			}
			redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? successMsgCode : CommonKeywords.ERROR_MSG_KEY.toString());
		}
		catch(Exception ex){
			return exceptionHandlerService.writeLog(ex);
		} finally {
			if(clientId==1){
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), registrationLinkId, success ? auditBidderRegistered : auditBidderRegistrationFailed, 0, userId, "",request.getParameter("skpSignText"));
			} else {
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), registrationLinkId, success ? auditBidderRegistered : auditBidderRegistrationFailed, 0, userId);
			}
		}
		return retVal;
	}
	
	/**
	 * Use for Bidder details in view page of RegistrationDetails.jsp
	 * @author nirav.modi
	 * @param bidderId
	 * @return HashMap of <code><String, Object></code>
	 * @throws Exception
	 */
	private Map<String, Object> getViewBidderDetails(int bidderId, int clientId,String langId) throws Exception{
		Map<String, Object> bidderDetailMap = new HashMap<String, Object>();
		List<Object[]> bidderDetails = manageBidderService.viewBidderProfile(bidderId, clientId,true);
    	if(!bidderDetails.isEmpty()){
    		Object[] obj = bidderDetails.get(0);
                DataObject dataObject = WSCheckAvail.getSSOLoginMastreDetailasObject(obj[9].toString());
    		bidderDetailMap.put("name",(dataObject!=null && dataObject.getData7()!=null && !"".equalsIgnoreCase(dataObject.getData7().toString()))?dataObject.getData7().toString():obj[0]);
        	bidderDetailMap.put("companyName",(dataObject!=null && dataObject.getData6()!=null && !"".equalsIgnoreCase(dataObject.getData6().toString()))?dataObject.getData6().toString():obj[1]);
        	bidderDetailMap.put("address",(dataObject!=null && dataObject.getData9()!=null && !"".equalsIgnoreCase(dataObject.getData9().toString()))?dataObject.getData9().toString():obj[2]);
        	bidderDetailMap.put("city",(dataObject!=null && dataObject.getData15()!=null && !"".equalsIgnoreCase(dataObject.getData15().toString()))?dataObject.getData15().toString():obj[5]);
        	bidderDetailMap.put("phoneNo",(dataObject!=null && dataObject.getData10()!=null && !"".equalsIgnoreCase(dataObject.getData10().toString()))?dataObject.getData10().toString():obj[6]);
        	bidderDetailMap.put("mobileNo",(dataObject!=null && dataObject.getData12()!=null && !"".equalsIgnoreCase(dataObject.getData12().toString()))?dataObject.getData12().toString():obj[7]);
        	bidderDetailMap.put("website",(dataObject!=null && dataObject.getData22()!=null && !"".equalsIgnoreCase(dataObject.getData22().toString()))?dataObject.getData22().toString():obj[8]);
        	bidderDetailMap.put("emailId",(dataObject!=null && dataObject.getData2()!=null && !"".equalsIgnoreCase(dataObject.getData2().toString()))?dataObject.getData2().toString():obj[9]);
        	bidderDetailMap.put("countryName",(dataObject!=null && dataObject.getData13()!=null && !"".equalsIgnoreCase(dataObject.getData13().toString()))?dataObject.getData13().toString():obj[13]);
        	bidderDetailMap.put("stateName",(dataObject!=null && dataObject.getData14()!=null && !"".equalsIgnoreCase(dataObject.getData14().toString()))?dataObject.getData14().toString():obj[14]);
        	bidderDetailMap.put("timeZone",(dataObject!=null && dataObject.getData26()!=null && !"".equalsIgnoreCase(dataObject.getData26().toString()))?commonService.getTimeZone(dataObject.getData26().toString(), langId):obj[15]);
        	
        	String agreementType="";
    		String businessCategory ="";        	
        	if(obj[21]!=null) {
        		agreementType = obj[21].toString().replace(",Others", "");        		
        	}else if(obj[21]==null) {
        		agreementType="";
        	}
        	
        	if(obj[27]!=null) {
        		businessCategory = obj[27].toString().replace(",Others", "");        		
        	}else if(obj[27]==null) {
        		businessCategory ="";
        	}
        	
        	bidderDetailMap.put("agreementType",agreementType);
        	bidderDetailMap.put("executionDateOfAgreement",obj[22]);
        	bidderDetailMap.put("agreementWith",obj[23]);
        	bidderDetailMap.put("credentialsCheckDate",obj[24]);
        	bidderDetailMap.put("pointOfContact",obj[25]);
        	bidderDetailMap.put("remarks",obj[26]);
        	bidderDetailMap.put("businessCategory",businessCategory);
//        	bidderDetailMap.put("isAdminBidder",obj[27].equals("1")?"True":"False");
        	
        	int isCategoryAllow = commonService.isCategoryAllow(clientId);
        	if(isCategoryAllow == 1){
	        	StringBuilder bidderKeywords = new StringBuilder();
	    			bidderKeywords.append(commonService.getCategoryNameList(bidderId,registrationLinkId));
	    		bidderDetailMap.put("keywords", bidderKeywords.toString().substring(0, bidderKeywords.length()));
        	}else{
        		List<Object[]> keywords = manageBidderService.getBidderKeywords(bidderId);
	        	if(!keywords.isEmpty()) {
	        		StringBuilder bidderKeywords = new StringBuilder();
	        		for (int i=0; i<keywords.size(); i++) {
	        			bidderKeywords.append(keywords.get(i)).append(",");
	        		}
	        		bidderDetailMap.put("keywords", (dataObject!=null && dataObject.getData21()!=null && !"".equalsIgnoreCase(dataObject.getData21().toString()))?dataObject.getData21().toString():bidderKeywords.toString().substring(0, bidderKeywords.length()-1));
	        	}
        	}
        	bidderDetailMap.put("isEmailVerified",obj[10]!=null?obj[10]:0);
        	bidderDetailMap.put("cstatus",obj[18]);
        	bidderDetailMap.put("alternateLoginId", obj[20]);
    	}
    	return bidderDetailMap;
	}
	
	/**
	 * @author nirav.modi
	 * @param bidderId
	 * @param modelMap
	 * @param response
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/admin/viewbidderprofile/{bidderId}/{enc}","/bidder/viewbidderprofile/{bidderId}/{enc}"}, method = RequestMethod.GET)                       
    public String viewBidderProfile(@PathVariable("bidderId") int bidderId,ModelMap modelMap, HttpServletResponse response, HttpServletRequest request){
        String retVal=null;
        int clientId=0;
        try{
        	clientId=abcUtility.getSessionClientId(request);
        	modelMap.addAttribute("bidderDetailMap", getViewBidderDetails(bidderId, clientId,WebUtils.getCookie(request, "locale").getValue()));//for registrationdetails.jsp page
        	modelMap.addAttribute("documentList", manageBidderService.getBidderDocs(bidderId, clientId));//For document list
        	modelMap.addAttribute("isWorkFlow", 0);
        	// TODO : To get Certificate Details of Bidder 
        	List<Object[]> certDetails= manageBidderService.getBidderCertiDetails(bidderId,abcUtility.getSessionIsDualCerti(request)==true?2:1);
        	List<Map<String,Object>> certiDetailsList = new ArrayList<Map<String,Object>>();
        	if(!certDetails.isEmpty()){
        		for (int i = 0; i < certDetails.size(); i++) {
        			Map<String,Object> certDetail= new HashMap<String, Object>();
            		Object[] object = certDetails.get(i);
            		certDetail.put("subject", object[0]);
            		certDetail.put("issuer", object[1]);
            		certDetail.put("serialNumber", object[2]);
            		certDetail.put("publicKey", object[3]);
            		certDetail.put("keyUsage", object[4]);
            		certDetail.put("endDate", object[5]);
            		certiDetailsList.add(certDetail);
    			}
        	}
            int sessionUserId = abcUtility.getSessionUserId(request);
            int i = commonService.checkAbcUser(Integer.toString(sessionUserId));
            if(i>0)
            {
            	modelMap.addAttribute("isAbcUser", i);
            }            
        	modelMap.addAttribute("certiDetailsList", certiDetailsList);
        	request.setAttribute("certDetail", manageBidderService.getBidderCertiDetailsNew(bidderId,abcUtility.getSessionIsDualCerti(request)==true?2:1));
        	
        	boolean isRegApplicable=clientService.checkIsRegChargesApplicable(clientId);
        	request.setAttribute("isRegApplicable", isRegApplicable);
        	if(isRegApplicable){
        		
				TblPayment tblPayment = manageBidderService.getPaymentDetailByBidderId(bidderId, clientId,3,1);
				request.setAttribute("tblPayment",tblPayment);

				if (tblPayment != null) {

					int paymentId = 0;
					paymentId = tblPayment.getPaymentId();
				
					
					request.setAttribute("payType",commonService.getPaymentTypeDetail(tblPayment.getTblPaymentType().getPaymentTypeId()).getLang1());
					request.setAttribute("paymentTypeId",tblPayment.getTblPaymentType().getPaymentTypeId());
					request.setAttribute("registrationCharges",tblPayment.getAmount().intValue());
					request.setAttribute("transactionDate",tblPayment.getCreatedOn());
					
					TblOfflinePayment tblOfflinePayment = manageBidderService.getOfflinePaymentDetail(paymentId);
							
					if (tblOfflinePayment != null) {
						
						request.setAttribute("payDate",tblOfflinePayment.getReferenceDate());
						request.setAttribute("payMode", "Offline");		
						request.setAttribute("referenceNo",tblOfflinePayment.getReferenceNo());
						request.setAttribute("bankName1", tblOfflinePayment.getBankName());	
						TblBidderDocMapping tblBidderDocMapping=manageBidderService.getBidderDocDetails(paymentId,uploadBidderChargesOfflineLink);
						request.setAttribute("tblBidderDocMapping",	tblBidderDocMapping);
						
					} else {
					
						TblOnlinePayment tblOnlinePayment = manageBidderService.getOnlinePaymentDetail(paymentId);
						if(tblOnlinePayment != null){
							request.setAttribute("payDate",	tblOnlinePayment.getUpdatedOn());							
							request.setAttribute("payMode", "Online");
							request.setAttribute("referenceNo",tblPayment.getPaymentId());
						}
					}
					
					//request.setAttribute("paymentType",tblPayment.getTblPaymentType().getLang1());
			
				}
        	}
        	int objectId = bidderId;
        	if(abcUtility.getSessionUserTypeId(request) == 1 || abcUtility.getSessionUserTypeId(request) == 3 || abcUtility.getSessionUserTypeId(request) == 2 && clientId == smClientId){
        		TblVendorCodeMapping tblVendorCodeMapping = manageBidderService.getVendorCode(bidderId, clientId);
        		if(tblVendorCodeMapping != null){
        			modelMap.addAttribute("vendorCode",tblVendorCodeMapping.getVendorCode());
        		}else{
        			modelMap.addAttribute("vendorCode","");
        		}
            	
        	}
        	modelMap.addAttribute("clientId",clientId);
        	modelMap.addAttribute("objectId", objectId);
        	modelMap.addAttribute("linkId", manageBidderFieldValueId);
        	modelMap.addAttribute("dynFieldMap", dynamicFieldService.setDynamicField(manageBidderFieldValueId, clientId, objectId));
			if(CommonUtility.isClientConditionExistInProperty(gslClientIds, clientId)){
				modelMap.addAttribute("bidderRegisteredInDocList", manageBidderService.getBidderRegisteredInDocs(bidderId, abcUtility.getSessionClientId(request)));//For GSL bidder Registered In Document list
				modelMap.addAttribute("bidderIndustryAndClass", manageBidderService.getBidderIndustryAndClassificationWithDoc(bidderId, abcUtility.getSessionClientId(request)));//For GSL bidder Registered In Document list
			}
			if(CommonUtility.isClientConditionExistInProperty(rciClientIds, clientId)){
				boolean isOfficerOrAdmin = abcUtility.getSessionUserTypeId(request) != 2 ? true : false;
				ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
				if(isOfficerOrAdmin && clientBean.getClientModules().contains("8")){ // if vendor enlistment module configure
					int companyId = commonService.getCompanyId(bidderId, clientId);
					List<TblCompanyEnlistment> appovedVendorEnlistedFileList=  vendorEnlistmentService.getApprovedCompanyEnlistedFile(clientId,companyId);
					if (appovedVendorEnlistedFileList != null && !appovedVendorEnlistedFileList.isEmpty() && appovedVendorEnlistedFileList.get(0) !=null) {
						modelMap.addAttribute("appovedVendorEnlistedFileList",appovedVendorEnlistedFileList);
			        }
				}
			}
			
			// PT : #35308 By Jitendra. Adding new fields in the bidder profile
            boolean isClientSectorApplicable = manageBidderService.isClientSectorApplicable(clientId);
            boolean isBidderApproved = manageBidderService.isBidderApproved(bidderId, clientId); // Bug #35556 By Jitendra
            modelMap.addAttribute("isClientSectorApplicable", isClientSectorApplicable);
            modelMap.addAttribute("isBidderApproved", isBidderApproved);
            
            if(isClientSectorApplicable && isBidderApproved){
                List<Object[]> bidderAdditionalFields = manageBidderService.getBidderAdditionalFields(bidderId, clientId);
                if(bidderAdditionalFields != null && !bidderAdditionalFields.isEmpty()){
                	String[] typeOfPropertyArr = bidderAdditionalFields.get(0)[2].toString().split("\\|");
                	List<Object> propertyTypeList = new ArrayList<Object>();
                	for (String typeOfProperty : typeOfPropertyArr) {
                		propertyTypeList.add(manageBidderService.getPropertyTypeById(Integer.parseInt(typeOfProperty)));
					}
                	
                	// PT : 36402 By Jitendra. 
                	String[] stateIdArr = bidderAdditionalFields.get(0)[8].toString().split("\\|");
                	List<Object> stateIdList = new ArrayList<Object>();
                	for (String stateId : stateIdArr) {
                		stateIdList.add(manageBidderService.getStateById(Integer.parseInt(stateId)));
					}
                	modelMap.addAttribute("typeOfInvestor", bidderAdditionalFields.get(0)[0].toString());
                	modelMap.addAttribute("propertyLookingFor", bidderAdditionalFields.get(0)[1].toString());
                	modelMap.addAttribute("typeOfProperty", abcUtility.converObjectArrayToCommas(propertyTypeList));
                	modelMap.addAttribute("minBudget", bidderAdditionalFields.get(0)[3].toString());
                	modelMap.addAttribute("maxBudget", bidderAdditionalFields.get(0)[4].toString());
                	modelMap.addAttribute("isLoanRequired", bidderAdditionalFields.get(0)[5].toString());
                	modelMap.addAttribute("areaOrLocation", bidderAdditionalFields.get(0)[6].toString());
                	modelMap.addAttribute("additionalCity", bidderAdditionalFields.get(0)[7].toString());
                	modelMap.addAttribute("additionalState", abcUtility.converObjectArrayToCommas(stateIdList));
                }
            }
            int isGSTRequired = (Integer)clientService.getClientField(clientId, "isGSTRequired");
            if(clientService.getBidderCountryIdByUserId(bidderId)!=countryId){
        		isGSTRequired = 0;
        	}
			modelMap.addAttribute("isGSTRequired", isGSTRequired);
        	if(isGSTRequired==1){
	        	Object[] obj = manageBidderService.getGstFields("TblBidderGstDetails", bidderId,clientId, "gstTaxClassification,gstNo,gstDeclarationId,panNo,reason");
	        	if(obj!=null){
	        		modelMap.addAttribute("gstTaxClassification", (Integer)obj[0]);
	        		modelMap.addAttribute("BidderGstNo", obj[1]);
	        		modelMap.addAttribute("gstDeclarationId", obj[2]);
	        		modelMap.addAttribute("panNo", obj[3]);
	        		modelMap.addAttribute("reason", obj[4]);
	        	}
        	}
        	if(isGSTRequired==1){
	        	List<Object[]> lstGstReceipt = manageBidderService.getBidderGstReceipt(bidderId, clientId);
		    	if(!lstGstReceipt.isEmpty()){
		    		modelMap.addAttribute("gstDocumentList", lstGstReceipt);
		    	}
        	}

            //Nitin Start
            List<Object[]> detachCertHistoryDetails = commonService.getBidderDetachCertiDetails(bidderId,abcUtility.getSessionIsDualCerti(request)==true?2:1);
            List<Map<String,Object>> detachCertiDetailsList = new ArrayList<Map<String,Object>>();
            if(!detachCertHistoryDetails.isEmpty()){
            	for (int k = 0; k < detachCertHistoryDetails.size(); k++) {
            		Map<String,Object> detachCertDetail= new HashMap<String, Object>();
            		Object[] object = detachCertHistoryDetails.get(k);
            		
            		detachCertDetail.put("companyId", commonService.getCompanyNameByCompanyId(Integer.parseInt(object[0].toString())));
            		detachCertDetail.put("dateandtime", CommonUtility.convertTimezone(object[3]));
            		detachCertDetail.put("detachedby", commonService.getUserName(Integer.parseInt(object[5].toString())));
            		detachCertDetail.put("clientname", clientService.getClientNameByClientId(Integer.parseInt(object[6].toString())));
            		detachCertDetail.put("certName", object[7]);
            		detachCertDetail.put("keyUsage", object[2]);
            		detachCertDetail.put("ipAddress", object[9]);
            		
            		/*TblVendorCodeMapping tblVendorCodeMapping = manageBidderService.getVendorCode(Integer.parseInt(object[1].toString()), Integer.parseInt(object[6].toString()));
            		detachCertDetail.put("vendorcode", tblVendorCodeMapping.getVendorCode());*/
            		detachCertiDetailsList.add(detachCertDetail);
            	}
            }
            
            modelMap.addAttribute("detachCertiDetailsList", detachCertiDetailsList);
            
            //Nitin End
            
            modelMap.put("domainName", manageBidderService.getDomainByUserId(bidderId));
            retVal="common/admin/ViewBidderProfile";
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }
        finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewBidderLinkId, auditViewBidderProfile, 0, bidderId);
        }
        return retVal;
    }
	
	
	@RequestMapping(value = {"/admin/viewbidderprofileclient/{bidderId}/{clientId}/{enc}"}, method = RequestMethod.GET)                       
    public String viewBidderProfileclient(@PathVariable("bidderId") int bidderId,@PathVariable("clientId") int clientId,ModelMap modelMap, HttpServletResponse response, HttpServletRequest request){
        String retVal=null;
        try{
        	
        	modelMap.addAttribute("bidderId", bidderId);
        	modelMap.addAttribute("clientId", clientId);
        	
        	
        	TblClient tblClient = clientService.getClientById(clientId);
        	modelMap.addAttribute("showDomainName", 1);
        	modelMap.addAttribute("isDocReq", tblClient.getIsManDocsReq());
        	modelMap.addAttribute("domainName", tblClient.getDomainName());
        	modelMap.addAttribute("bidderDetailMap", getViewBidderDetails(bidderId, clientId,WebUtils.getCookie(request, "locale").getValue()));//for registrationdetails.jsp page
        	modelMap.addAttribute("documentList", manageBidderService.getBidderDocs(bidderId, clientId));//For document list
        	modelMap.addAttribute("isWorkFlow", 0);
        	// TODO : To get Certificate Details of Bidder 
        	List<Object[]> certDetails= manageBidderService.getBidderCertiDetails(bidderId,tblClient.getIsDualCerti());
        	//List<Object[]> certDetails= manageBidderService.getBidderCertiDetailsByBidderId(bidderId);
        	List<Map<String,Object>> certiDetailsList = new ArrayList<Map<String,Object>>();
        	if(!certDetails.isEmpty()){
        		for (int i = 0; i < certDetails.size(); i++) {
        			Map<String,Object> certDetail= new HashMap<String, Object>();
            		Object[] object = certDetails.get(i);
            		certDetail.put("subject", object[0]);
            		certDetail.put("issuer", object[1]);
            		certDetail.put("serialNumber", object[2]);
            		certDetail.put("publicKey", object[3]);
            		certDetail.put("keyUsage", object[4]);
            		certDetail.put("endDate", object[5]);
            		certiDetailsList.add(certDetail);
    			}
        	}
        	modelMap.addAttribute("certiDetailsList", certiDetailsList);
        	request.setAttribute("certDetail", manageBidderService.getBidderCertiDetailsNew(bidderId,abcUtility.getSessionIsDualCerti(request)==true?2:1));
        	
        	boolean isRegApplicable=clientService.checkIsRegChargesApplicable(clientId);
        	request.setAttribute("isRegApplicable", isRegApplicable);
        	if(isRegApplicable){
        		
				TblPayment tblPayment = manageBidderService.getPaymentDetailByBidderId(bidderId, clientId,3,1);
				request.setAttribute("tblPayment",tblPayment);

				if (tblPayment != null) {

					int paymentId = 0;
					paymentId = tblPayment.getPaymentId();
				
					
					request.setAttribute("payType",commonService.getPaymentTypeDetail(tblPayment.getTblPaymentType().getPaymentTypeId()).getLang1());
					request.setAttribute("paymentTypeId",tblPayment.getTblPaymentType().getPaymentTypeId());
					request.setAttribute("registrationCharges",tblPayment.getAmount().intValue());
					
					TblOfflinePayment tblOfflinePayment = manageBidderService.getOfflinePaymentDetail(paymentId);
							
					if (tblOfflinePayment != null) {
						
						request.setAttribute("payDate",tblOfflinePayment.getReferenceDate());
						request.setAttribute("payMode", "Offline");		
						request.setAttribute("referenceNo",tblOfflinePayment.getReferenceNo());
						request.setAttribute("bankName1", tblOfflinePayment.getBankName());	
						TblBidderDocMapping tblBidderDocMapping=manageBidderService.getBidderDocDetails(paymentId,uploadBidderChargesOfflineLink);
						request.setAttribute("tblBidderDocMapping",	tblBidderDocMapping);
						
					} else {
					
						TblOnlinePayment tblOnlinePayment = manageBidderService.getOnlinePaymentDetail(paymentId);
						if(tblOnlinePayment != null){
							request.setAttribute("payDate",	tblOnlinePayment.getUpdatedOn());							
							request.setAttribute("payMode", "Online");
							request.setAttribute("referenceNo",tblPayment.getPaymentId());
						}
					}
					
					//request.setAttribute("paymentType",tblPayment.getTblPaymentType().getLang1());
			
				}
        	}
        	int objectId = bidderId;
        	if(abcUtility.getSessionUserTypeId(request) == 1 || abcUtility.getSessionUserTypeId(request) == 3){
        		TblVendorCodeMapping tblVendorCodeMapping = manageBidderService.getVendorCode(bidderId, clientId);
        		if(tblVendorCodeMapping != null){
        			modelMap.addAttribute("vendorCode",tblVendorCodeMapping.getVendorCode());
        		}else{
        			modelMap.addAttribute("vendorCode","");
        		}
            	
        	}
        	modelMap.addAttribute("clientId",clientId);
        	modelMap.addAttribute("objectId", objectId);
        	modelMap.addAttribute("linkId", manageBidderFieldValueId);
        	modelMap.addAttribute("dynFieldMap", dynamicFieldService.setDynamicField(manageBidderFieldValueId, clientId, objectId));
			if(CommonUtility.isClientConditionExistInProperty(gslClientIds, clientId)){
				modelMap.addAttribute("bidderRegisteredInDocList", manageBidderService.getBidderRegisteredInDocs(bidderId, clientId));//For GSL bidder Registered In Document list
				modelMap.addAttribute("bidderIndustryAndClass", manageBidderService.getBidderIndustryAndClassificationWithDoc(bidderId, clientId));//For GSL bidder Registered In Document list
			}
			if(CommonUtility.isClientConditionExistInProperty(rciClientIds, clientId)){
				boolean isOfficerOrAdmin = abcUtility.getSessionUserTypeId(request) != 2 ? true : false;
				ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
				if(isOfficerOrAdmin && clientBean.getClientModules().contains("8")){ // if vendor enlistment module configure
					int companyId = commonService.getCompanyId(bidderId, clientId);
					List<TblCompanyEnlistment> appovedVendorEnlistedFileList=  vendorEnlistmentService.getApprovedCompanyEnlistedFile(clientId,companyId);
					if (appovedVendorEnlistedFileList != null && !appovedVendorEnlistedFileList.isEmpty() && appovedVendorEnlistedFileList.get(0) !=null) {
						modelMap.addAttribute("appovedVendorEnlistedFileList",appovedVendorEnlistedFileList);
			        }
				}
			}
            retVal="common/admin/ViewBidderProfile";
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }
        finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, verifyDC, 0, bidderId);
        }
        return retVal;
    }
	
	
	/**
	 * @author dixit
	 * @param bidderId
	 * @param modelMap
	 * @param response
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/admin/viewbidderInfo/{bidderId}/{isWorkFlow}/{enc}"}, method = RequestMethod.GET)                       
        public String viewbidderInfo(@PathVariable("bidderId") int bidderId,@PathVariable("isWorkFlow") int isWorkFlow,ModelMap modelMap, HttpServletResponse response, HttpServletRequest request){
        String retVal=null;
        int clientId=0;
        try{
        	clientId=abcUtility.getSessionClientId(request);
        	modelMap.addAttribute("bidderDetailMap", getViewBidderDetails(bidderId, clientId,WebUtils.getCookie(request, "locale").getValue()));//for registrationdetails.jsp page
        	modelMap.addAttribute("documentList", manageBidderService.getBidderDocs(bidderId, clientId));//For document list
        	modelMap.addAttribute("isWorkFlow", isWorkFlow);
        	
        	// TODO : To get Certificate Details of Bidder 
        	if(abcUtility.getSessionIsPkiEnabled(request)==1){
	        	List<Object[]> certDetails= manageBidderService.getBidderCertiDetails(bidderId,abcUtility.getSessionIsDualCerti(request)==true?2:1);
	        	List<Map<String,Object>> certiDetailsList = new ArrayList<Map<String,Object>>();
	        	if(!certDetails.isEmpty()){
	        		for (int i = 0; i < certDetails.size(); i++) {
	        			Map<String,Object> certDetail= new HashMap<String, Object>();
	            		Object[] object = certDetails.get(i);
	            		certDetail.put("subject", object[0]);
	            		certDetail.put("issuer", object[1]);
	            		certDetail.put("serialNumber", object[2]);
	            		certDetail.put("publicKey", object[3]);
	            		certDetail.put("keyUsage", object[4]);
	            		certiDetailsList.add(certDetail);
	    			}
	        	}
	        	modelMap.addAttribute("certiDetailsList", certiDetailsList);
        	}
            retVal="common/admin/ViewBidderProfile";
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }
        finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewBidderLinkId, auditViewBidderProfile, 0, bidderId);
        }
        return retVal;
    }
	
	@RequestMapping(value = "/admin/disablebidder/{bidderId}/{parentBidderId}/{enc}", method = RequestMethod.GET)
	public String disableBidder(@PathVariable("bidderId") int bidderId,@PathVariable("parentBidderId") int parentBidderId, HttpServletRequest request, RedirectAttributes redirectAttributes) {
		String retVal=null;
		try {
			boolean result=manageBidderService.updateDisableBidder(bidderId);
			if(result) {
				redirectAttributes.addFlashAttribute("successMsg", "msg_bidder_disable_success");
			}
			retVal="redirect:/common/admin/editbidderprofile/" + parentBidderId + encryptDecryptUtils.generateRedirect("common/admin/editbidderprofile/"+ parentBidderId, request);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return retVal;
	}

	
	@RequestMapping(value = "/admin/enablebidder/{bidderId}/{parentBidderId}/{enc}", method = RequestMethod.GET)
	public String enableBidder(@PathVariable("bidderId") int bidderId, @PathVariable("parentBidderId") int parentBidderId, HttpServletRequest request, RedirectAttributes redirectAttributes) {
		String retVal=null;
		try {
			boolean result=manageBidderService.updateEnableBidder(bidderId);
			if(result) {
				redirectAttributes.addFlashAttribute("successMsg", "msg_bidder_enable_success");
			}
			retVal="redirect:/common/admin/editbidderprofile/" + parentBidderId + encryptDecryptUtils.generateRedirect("common/admin/editbidderprofile/"+ parentBidderId, request);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return retVal;
	}
	
	@RequestMapping(value = "/admin/editbidderprofile/{bidderId}/{enc}", method = RequestMethod.GET)                       
    public String editBidderProfile(@PathVariable("bidderId") int bidderId, @ModelAttribute BidderRegistrationDataBean bidderRegistrationDataBean, HttpSession session, HttpServletRequest request, ModelMap map){
        String retVal=null;
        try{
        	map.put("isAdminBidder", commonService.getBidderStatus(bidderId));
        	List<Object[]> bidderDetails = manageBidderService.viewBidderProfile(bidderId, abcUtility.getSessionClientId(request), false);
                DataObject dataObject = WSCheckAvail.getSSOLoginMastreDetailasObject(bidderDetails.get(0)[9].toString());
        	bidderRegistrationDataBean.setTxtFullName((dataObject!=null && dataObject.getData7()!=null && !"".equalsIgnoreCase(dataObject.getData7().toString()))?dataObject.getData7().toString():bidderDetails.get(0)[0].toString());
        	bidderRegistrationDataBean.setTxtCompanyName((dataObject!=null && dataObject.getData6()!=null && !"".equalsIgnoreCase(dataObject.getData6().toString()))?dataObject.getData6().toString():bidderDetails.get(0)[1].toString());
        	bidderRegistrationDataBean.setTxtaAddress((dataObject!=null && dataObject.getData9()!=null && !"".equalsIgnoreCase(dataObject.getData9().toString()))?dataObject.getData9().toString():bidderDetails.get(0)[2].toString());
        	bidderRegistrationDataBean.setIsAdminBidder(bidderDetails.get(0)[28].toString());
        	TblCountry tblCountry = dataObject != null && dataObject.getData13() != null && !"".equalsIgnoreCase(dataObject.getData13().toString()) ? commonService.getCountryIdByName(dataObject.getData13().toString()) : null;
        	bidderRegistrationDataBean.setSelCountry(tblCountry != null ? tblCountry.getCountryId():(Integer)bidderDetails.get(0)[3]);
        	
        	TblState tblState = dataObject != null && dataObject.getData14()!=null && !"".equalsIgnoreCase(dataObject.getData14().toString()) ? commonService.getStateIdByName(dataObject.getData14().toString()) : null;
        	bidderRegistrationDataBean.setSelState(tblState != null ? tblState.getStateId().toString() : bidderDetails.get(0)[4].toString());
        	
        	bidderRegistrationDataBean.setTxtCity((dataObject!=null && dataObject.getData15()!=null && !"".equalsIgnoreCase(dataObject.getData15().toString()))?dataObject.getData15().toString():bidderDetails.get(0)[5].toString());
        	bidderRegistrationDataBean.setTxtPhone((dataObject!=null && dataObject.getData10()!=null && !"".equalsIgnoreCase(dataObject.getData10().toString()))?dataObject.getData10().toString():bidderDetails.get(0)[6].toString());
        	bidderRegistrationDataBean.setTxtMobileNo((dataObject!=null && dataObject.getData12()!=null && !"".equalsIgnoreCase(dataObject.getData12().toString()))?dataObject.getData12().toString():bidderDetails.get(0)[7].toString());
        	bidderRegistrationDataBean.setTxtWebsite((dataObject!=null && dataObject.getData22()!=null && !"".equalsIgnoreCase(dataObject.getData22().toString()))?dataObject.getData22().toString():bidderDetails.get(0)[8].toString());
        	bidderRegistrationDataBean.setTxtEmailId(bidderDetails.get(0)[9].toString());
        	bidderRegistrationDataBean.setHdBidderId((Integer)bidderDetails.get(0)[11]);
        	bidderRegistrationDataBean.setHdCompanyId((Integer)bidderDetails.get(0)[12]);
        	bidderRegistrationDataBean.setTxtAlternateLoginId(bidderDetails.get(0)[20]!=null ? bidderDetails.get(0)[20].toString() : "");
        	Date agreementExecutionDate = (Date)bidderDetails.get(0)[22];
        	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        	String strAgreementExecutionDate= formatter.format(agreementExecutionDate);
        	bidderRegistrationDataBean.setTxtExecutionDateOfAgreement(strAgreementExecutionDate.equals("01/01/1900")? "":strAgreementExecutionDate);
        	bidderRegistrationDataBean.setTxtCredentialCheckDate(bidderDetails.get(0)[24]!=null ?bidderDetails.get(0)[24].toString():"");
        	bidderRegistrationDataBean.setTxtPointOfContact(bidderDetails.get(0)[25]!=null?bidderDetails.get(0)[25].toString():"");
        	bidderRegistrationDataBean.setTxtRemarks(bidderDetails.get(0)[26]!=null?bidderDetails.get(0)[26].toString():"");
        	bidderRegistrationDataBean.setSelEntity(bidderDetails.get(0)[23]!=null?bidderDetails.get(0)[23].toString():"");
        	String strTypeOfAgreement=bidderDetails.get(0)[21]!=null?bidderDetails.get(0)[21].toString():"";
        	String strBusinessCategory=bidderDetails.get(0)[27]!=null?bidderDetails.get(0)[27].toString():"";
        	bidderRegistrationDataBean.setSelState(bidderDetails.get(0)[4]!=null?bidderDetails.get(0)[4].toString():"");
        	bidderRegistrationDataBean.setSelCountry(bidderDetails.get(0)[3]!=null?(int) bidderDetails.get(0)[3]:1);
        	List<String> listTypeOfAgreement = new ArrayList<String>();
        	listTypeOfAgreement = Arrays.asList(strTypeOfAgreement.split(","));
        	List<String> listBusinessCategory = new ArrayList<String>();
        	listBusinessCategory = Arrays.asList(strBusinessCategory.split(","));
        	
        	if(listTypeOfAgreement.contains("Others")) {
        		map.put("txtOtherAgreement",listTypeOfAgreement.get(listTypeOfAgreement.size() - 1));
        	}
        	if(listBusinessCategory.contains("Others")) {
        		map.put("txtOtherBusinessCat",listBusinessCategory.get(listBusinessCategory.size() - 1));
        	}
        	map.put("listTypeOfAgreement",listTypeOfAgreement);
        	map.put("listBusinessCategory",listBusinessCategory);
        	
        	List<Object[]> childBidderList=manageBidderService.getChildBidderDetailsByAdmin(bidderId);
        	map.put("childBidderList",childBidderList);
        	TblTimeZone tblTimeZone = dataObject != null && dataObject.getData26()!=null && !"".equalsIgnoreCase(dataObject.getData26().toString()) ? commonService.getTimezoneIdByTimeZone(dataObject.getData26().toString()) : null;
        	bidderRegistrationDataBean.setSelTimezone(tblTimeZone != null?tblTimeZone.getTimeZoneId():Integer.parseInt(bidderDetails.get(0)[15].toString()));

        	int clientId = abcUtility.getSessionClientId(request);
        	int objectId = bidderId;
        	boolean isRegistrationByBidder = clientService.getBidderRegistrationBy(clientId) == 1;
        	boolean isEmailVerificationRequired = clientService.getBidderRegistrationVerifiedBy(clientId) != 0; 
        	boolean isEmailVerified = ((Integer)bidderDetails.get(0)[10]) == 1;
        	
        	List<Object[]> keywords = manageBidderService.getBidderKeywords(bidderId);
        	if(keywords != null && !keywords.isEmpty()) {
        		StringBuilder bidderKeywords = new StringBuilder();
        		for (int i=0; i<keywords.size(); i++) {
        			bidderKeywords.append(keywords.get(i)).append(",");
        		}
        		bidderRegistrationDataBean.setTxtaBusCatKeywords((dataObject!=null && dataObject.getData21()!=null && !"".equalsIgnoreCase(dataObject.getData21().toString()))?dataObject.getData21().toString():bidderKeywords.toString().substring(0, bidderKeywords.length()-1));
        	}
        	String langId=WebUtils.getCookie(request, "locale").getValue();
        	map.put("timezoneList", modelToSelectItem.convertListIntoSelectItemList(commonService.getTimeZoneList(), "timeZoneId", "lang"+langId));
        	map.put("countryList", modelToSelectItem.convertListIntoSelectItemList(commonService.getCountryList(langId), "countryId", "lang"+langId));
        	map.put("stateList", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(bidderRegistrationDataBean.getSelCountry()), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
        	/*map.put("bidderDocuments", value);*/
        	map.put("editProfileByBidder", false);
        	map.put("isRegistrationByBidder", isRegistrationByBidder);
        	map.put("isEmailVerified", isEmailVerified);
        	map.put("isEmailVerificationRequired", isEmailVerificationRequired);
        	map.addAttribute("homeUrl", "common/admin/managebidder");
        	map.addAttribute("clientId",clientId);
        	map.addAttribute("objectId", objectId);
        	map.addAttribute("linkId", manageBidderFieldValueId);
        	map.addAttribute("bidderCstatus", bidderDetails.get(0)[18]);
        	int isGSTRequired = (Integer)clientService.getClientField(clientId, "isGSTRequired");
        	if(clientService.getBidderCountryIdByUserId(bidderId)!=countryId){
        		isGSTRequired = 0;
        	}
        	map.put("isGSTRequired", isGSTRequired);
        	if(isGSTRequired==1){
	        	Object[] obj = manageBidderService.getGstFields("TblBidderGstDetails", bidderId,clientId, "gstTaxClassification,gstNo,gstDeclarationId");
	        	if(obj!=null){
	        		map.put("gstTaxClassification", (Integer)obj[0]);
	        		map.put("BidderGstNo", obj[1]);
	        		map.put("gstDeclarationId", obj[2]);
	        	}
        	}
        	TblVendorCodeMapping tblVendorCodeMapping = manageBidderService.getVendorCode(bidderId,clientId);
        	if(tblVendorCodeMapping!=null){
        		bidderRegistrationDataBean.setTxtVendorCode(tblVendorCodeMapping.getVendorCode());
        	}else{
        		bidderRegistrationDataBean.setTxtVendorCode("");
        	}
        	
        	
        	map.addAttribute("dynFieldMap", dynamicFieldService.setDynamicField(manageBidderFieldValueId, clientId, objectId));
        	
        	if(abcUtility.isModuleAssignToClient(request,9)){ //spend analysis and statistic module.  PT: 20745
        		map.put("isCategoryAllow",commonService.isCategoryAllow(abcUtility.getSessionClientId(request)));
            }else{
            	map.put("isCategoryAllow",0);
            }
            if(map.get("isCategoryAllow").equals(1))
            {
            	List<Object[]> selectedCategory = commonService.getCategoryIdList(bidderId,registrationLinkId);
            	map.put("selectedCategory",selectedCategory);
            }
            
            // PT : #35308 By Jitendra. Adding new fields in the bidder profile
            boolean isClientSectorApplicable = manageBidderService.isClientSectorApplicable(clientId);
            boolean isBidderApproved = manageBidderService.isBidderApproved(bidderId, clientId); // Bug #35556 By Jitendra
            int countryId = commonService.getCountryIdFromIsoCode(indiaISOCode);
            int bidderFieldId = 0;
            map.put("isClientSectorApplicable", isClientSectorApplicable);
            map.put("isBidderApproved", isBidderApproved);
            map.put("actualBidderId", bidderDetails.get(0)[19].toString());
            
            if(isClientSectorApplicable && isBidderApproved){
            	List<SelectItem> investorType = new ArrayList<SelectItem>();   
            	investorType.add(new SelectItem(investorTypeOwner, 1));
            	investorType.add(new SelectItem(investorTypeAgent, 2));
            	investorType.add(new SelectItem(investorTypeNA, 3)); 	// PT : #38862 By Jitendra.
            	
            	List<SelectItem> propertyLookingFor = new ArrayList<SelectItem>();
            	propertyLookingFor.add(new SelectItem(propertyLookingForOwnUse, 1));
            	propertyLookingFor.add(new SelectItem(propertyLookingForInvestment, 2));
            	propertyLookingFor.add(new SelectItem(propertyLookingForRent, 3));
            	
            	List<SelectItem> loanRequired = new ArrayList<SelectItem>();
            	loanRequired.add(new SelectItem(loanRequiredNo, 0));
            	loanRequired.add(new SelectItem(loanRequiredYes, 1));

                map.put("investorType", investorType);
                map.put("propertyLookingFor", propertyLookingFor);
            	map.put("loanRequired", loanRequired);
            	map.put("propertyTypeList", modelToSelectItem.convertListIntoSelectItemList(manageBidderService.getPropertyTypeList(), "propertyTypeId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
            	map.put("stateList", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(countryId), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
            	
                List<Object[]> bidderAdditionalFields = manageBidderService.getBidderAdditionalFields(bidderId, clientId);
                if(bidderAdditionalFields != null && !bidderAdditionalFields.isEmpty()){
                	bidderRegistrationDataBean.setSelTypesOfInvestor(bidderAdditionalFields.get(0)[0].toString());
                	bidderRegistrationDataBean.setSelPropertyLookingFor(bidderAdditionalFields.get(0)[1].toString());
                	bidderRegistrationDataBean.setChkTypesOfProperty(bidderAdditionalFields.get(0)[2].toString());
                	bidderRegistrationDataBean.setTxtMinBudget(bidderAdditionalFields.get(0)[3].toString());
                	bidderRegistrationDataBean.setTxtMaxBudget(bidderAdditionalFields.get(0)[4].toString());
                	bidderRegistrationDataBean.setSelLoanRequired(bidderAdditionalFields.get(0)[5].toString());
                	bidderRegistrationDataBean.setTxtAreaOrLocation(bidderAdditionalFields.get(0)[6].toString());
                	bidderRegistrationDataBean.setTxtAdditionalCity(bidderAdditionalFields.get(0)[7].toString());
                	bidderRegistrationDataBean.setChkAdditionalState(bidderAdditionalFields.get(0)[8].toString());
                	
                	String[] typeOfPropertyArr = bidderAdditionalFields.get(0)[2].toString().split("\\|");
                	List<Object> propertyTypeList = new ArrayList<Object>();
                	for (String typeOfProperty : typeOfPropertyArr) {
                		propertyTypeList.add(manageBidderService.getPropertyTypeById(Integer.parseInt(typeOfProperty)));
					}
                	
                	// PT : 36402 By Jitendra. 
                	String[] stateIdArr = bidderAdditionalFields.get(0)[8].toString().split("\\|");
                	List<Object> stateIdList = new ArrayList<Object>();
                	for (String stateId : stateIdArr) {
                		stateIdList.add(manageBidderService.getStateById(Integer.parseInt(stateId)));
					}
                	map.put("additionalState", abcUtility.converObjectArrayToCommas(stateIdList));
                	map.put("typesOfProperty", abcUtility.converObjectArrayToCommas(propertyTypeList));
                	bidderFieldId = Integer.parseInt(bidderAdditionalFields.get(0)[10].toString());
                }
                map.put("bidderFieldsId", bidderFieldId);
               
            }
            int clientsectorId = clientService.getClientSectorId(clientId, mobileApp_sector); //Check domain sector vertical mobileapp 
            int user_Id = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getUserId();
          
            int i = commonService.checkAbcUser(Integer.toString(user_Id)); // isAbcUser
            boolean isMobileApp = (clientsectorId != 0 && i !=0) ? true : false;
            map.addAttribute("isMobileApp", isMobileApp);
            if(isMobileApp){
            	List<Object[]> allDomainList = commonService.getMultipleClientsForMobileApp(bidderId,abcUtility.getSessionUserId(request)); // Bug Id: #38594
            	List<SelectItem> domainList = new ArrayList<SelectItem>();
            	String clientIds =mobilebidderstatusservice.selectedDomainOnMobile(bidderId);
            	if(allDomainList!=null && !allDomainList.isEmpty() && clientIds!=null && !clientIds.isEmpty()) {
            		for (Object[] objects : allDomainList) {
            				if(clientIds.contains(","+objects[0].toString().trim()+",")) {
            					domainList.add(new SelectItem(objects[1], objects[0]+"~~0~~0",1));
            				}
            				else{
            					domainList.add(new SelectItem(objects[1], objects[0]+"~~0~~0"));
            				}
            				
            			}
            		}
            	map.addAttribute("domainList", domainList);
            }
            
            map.addAttribute("registerbidderbyuser","Yes");
			List<SelectItem> entityList = new ArrayList<SelectItem>();
			entityList.add(new SelectItem("GAIL","GAIL"));
			entityList.add(new SelectItem("GGSPL","GGSPL"));
			
			List<SelectItem> typeOfAgreementList= new ArrayList<SelectItem>();
			List<Object[]> activeAgreementTypes=manageBidderService.getActiveAgreementTypes();
			for(Object agreementType:activeAgreementTypes) {
				typeOfAgreementList.add(new SelectItem(String.valueOf(agreementType),String.valueOf(agreementType)));
			}
			
//			typeOfAgreementList.add(new SelectItem("MSPA","MSPA"));
//			typeOfAgreementList.add(new SelectItem("MSCA","MSCA"));
//			typeOfAgreementList.add(new SelectItem("SPA","SPA"));
//			typeOfAgreementList.add(new SelectItem("GSA","GSA"));
//			typeOfAgreementList.add(new SelectItem("Others","Others"));
			
			List<SelectItem> businessCategoryList = new ArrayList<SelectItem>();
			businessCategoryList.add(new SelectItem("MSPA Buy/Sell","MSPA Buy/Sell"));
			businessCategoryList.add(new SelectItem("MSPA Buy","MSPA Buy"));
			businessCategoryList.add(new SelectItem("MSPA Sell","MSPA Sell"));
			businessCategoryList.add(new SelectItem("Ship Broker","Ship Broker"));
			businessCategoryList.add(new SelectItem("Ship Owner","Ship Owner"));
			businessCategoryList.add(new SelectItem("RLNG Buy","RLNG Buy"));
			businessCategoryList.add(new SelectItem("RLNG Sell","RLNG Sell"));
			businessCategoryList.add(new SelectItem("Others","Others"));
			
			map.addAttribute("entityList",entityList);
			map.addAttribute("typeOfAgreementList",typeOfAgreementList);
			map.addAttribute("businessCategoryList",businessCategoryList);
            
            map.put("domainName", manageBidderService.getDomainByUserId(bidderId));
        	retVal="common/admin/EditBidderProfile";
        }
        catch(Exception ex){
        	return exceptionHandlerService.writeLog(ex);
        } finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editBidderLinkId, auditEditBidderProfile, 0, 0);
        }
        return retVal;
    }
	
	@RequestMapping(value = "/admin/updateregisterbidderbyuser", method = RequestMethod.POST)
	public String updateBidderRegistration(@ModelAttribute BidderRegistrationDataBean bidderRegistrationDataBean, HttpServletRequest request, HttpSession session, BindingResult result, 
			ModelMap map, RedirectAttributes redirectAttributes) {
		boolean success = false;
		String retVal = null;
		int userId=0;
		int clientId = abcUtility.getSessionClientId(request);
		int hdBidderId=bidderRegistrationDataBean.getHdBidderId();
		String selectedCategory[] = null;
		String isCategoryAllow = "0";
		String email = request.getParameter("txtEmailId");
		String typeOfAgreement[] = request.getParameterValues("chkAgreements");
		String companyName = request.getParameter("txtCompanyName");
		String dateOfExecutionOfAgreement = request.getParameter("txtDateOfExecutionOfAgreement");
		String registeredAddress = request.getParameter("txtaAddress");
		String entity = request.getParameter("selEntity");
		String checkDate = request.getParameter("txtCheckDate");
		String pointOfContact = request.getParameter("txtPointOfContact");
		String remarks = request.getParameter("txtRemarks");
		String businessCategory[] = request.getParameterValues("chkbusinessCategories");
		
		String hdCity = request.getParameter("hdcity");
		String hdphoneno = request.getParameter("hdphoneno");
		String hdwebsite = request.getParameter("hdwebsite");
		String hdstate = request.getParameter("hdstate");
		String hdcountry = request.getParameter("hdcountry");
		String selMainBidder = request.getParameter("MainBidder");
		
		if(selMainBidder!=null && !selMainBidder.equals(String.valueOf(hdBidderId))) {
			if(selMainBidder!=null) {
				try {
					manageBidderService.updateChildBidderAsAdmin(Integer.valueOf(selMainBidder),hdBidderId);
					manageBidderService.updateAdminBidderAsChild(Integer.valueOf(selMainBidder),hdBidderId);
				} catch (Exception e1) {
					return exceptionHandlerService.writeLog(e1);
				}			
			}			
		}
		
		
		
		SimpleDateFormat formatter1=new SimpleDateFormat("dd/MM/yyyy");
		Date DateobjExecutionOfAgreement = null;
		try {
			if(dateOfExecutionOfAgreement!="") {
			DateobjExecutionOfAgreement = formatter1.parse(dateOfExecutionOfAgreement);
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
//		String txtTypeOfAgreement = request.getParameter("txtAgreements");
		String txtBusinessCategory = request.getParameter("txtbusinessCategories");
		
//		String agreementWith = String.join(",",entity);
		String joinedTypeOfAgreement=null;
		if(typeOfAgreement!=null) {
			joinedTypeOfAgreement = String.join(",", typeOfAgreement);
//			if(txtTypeOfAgreement!="") {			
//				joinedTypeOfAgreement = joinedTypeOfAgreement+","+txtTypeOfAgreement;
//			}			
		}else {
			joinedTypeOfAgreement="";
		}
		
		
		String joinedBusinessCategory = String.join(",", businessCategory);
		if(txtBusinessCategory!="") {			
			joinedBusinessCategory = joinedBusinessCategory+","+txtBusinessCategory;
		}
		

		
		
		try{
			String oldEmailId = request.getParameter("hdOldEmailId");
			boolean isEditProfileByBidder = Boolean.valueOf(request.getParameter("hdEditProfileByBidder"));
			boolean isEmailIdChanged = (!"".equals(bidderRegistrationDataBean.getTxtEmailId()) && !oldEmailId.equalsIgnoreCase(bidderRegistrationDataBean.getTxtEmailId()));
			bidderRegistrationDataBean.setCommonValidators(commonValidators);
//			bidderRegistrationDataBean.validate(result, isEmailIdChanged, false, isEditProfileByBidder, 1);
			selectedCategory = request.getParameterValues("txtCategory");
			isCategoryAllow = request.getParameter("hdIsCategoryAllow");
			int isFromRegisteredBidder = StringUtils.hasLength(request.getParameter("isFromRegisteredBidder")) ? Integer.parseInt(request.getParameter("isFromRegisteredBidder")) : 0;
			List<Object> busCatKeywords = null;
			 boolean isSSOEnabled = false;
			if(session.getAttribute("clientObject") != null) {
				 ClientBean clientBean = (ClientBean) session.getAttribute("clientObject");
                 isSSOEnabled = clientBean.isIsSsoEnabled();
			}
			int bidderId = 0;
//    		if(isEmailIdChanged){
//    			List<LinkedHashMap<String, Object>> list = commonService.checkValidUserInClient(clientId, bidderRegistrationDataBean.getTxtEmailId(), 2);
//    			if(list != null && !list.isEmpty()) {
//    				if(list.get(0).get("actionType") != null) {
//    					Map<String, Object> map1  = list.get(0);
//    					int actionType = Integer.parseInt(map1.get("actionType").toString());
//    					bidderId = Integer.parseInt(map1.get("bidderId").toString());
//    					int officerId = Integer.parseInt(map1.get("officerId").toString());
//    					if(actionType==2 && bidderId>0) {
//    						result.rejectValue("txtEmailId", null, "Email ID already registered as bidder on this domain.");
//    					} else if(actionType==2 && officerId>0) {
//    						result.rejectValue("txtEmailId", null, "Email ID already registered as department user on this domain.");
//    				}
//    			}
//    		}
//    		}
    		userId=bidderRegistrationDataBean.getHdBidderId();
    		
    		// Bug #33494 By Jitendra. If category is allow then getting keyword names from keyword ids and set in bidderRegistrationDataBean model. 
			if(isCategoryAllow != null && isCategoryAllow.equals("1") && selectedCategory != null){
				busCatKeywords = commonService.getKeywordNamesByIds(selectedCategory);
				bidderRegistrationDataBean.setTxtaBusCatKeywords(abcUtility.converObjectArrayToCommas(busCatKeywords));
			}
    		
			if(result.hasErrors()) {
				String langId=WebUtils.getCookie(request, "locale").getValue();
				map.put("countryList", modelToSelectItem.convertListIntoSelectItemList(commonService.getCountryList(langId), "countryId", "lang"+langId));
				map.put("timezoneList", modelToSelectItem.convertListIntoSelectItemList(commonService.getTimeZoneList(), "timeZoneId", "lang"+langId));
				if(bidderRegistrationDataBean.getSelCountry() != 0) {
					map.put("stateList", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(bidderRegistrationDataBean.getSelCountry()), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
				}
	        	boolean isRegistrationByBidder = clientService.getBidderRegistrationBy(clientId) == 1;
	        	boolean isEmailVerificationRequired = clientService.getBidderRegistrationVerifiedBy(clientId) != 0; 
	        	boolean isEmailVerified = manageBidderService.isEmailVerified(userId);
	        	map.put("editProfileByBidder", false);
	        	map.put("isRegistrationByBidder", isRegistrationByBidder);
	        	map.put("isEmailVerified", isEmailVerified);
	        	map.put("isEmailVerificationRequired", isEmailVerificationRequired);
	        	if(abcUtility.isModuleAssignToClient(request,9)){
	        		map.put("isCategoryAllow",commonService.isCategoryAllow(abcUtility.getSessionClientId(request)));
	             }else{
	            	 map.put("isCategoryAllow",0);
	             }
	        	map.addAttribute("clientId",clientId);
	        	map.addAttribute("objectId", userId);
	        	map.addAttribute("linkId", manageBidderFieldValueId);
				success=false;
				retVal = "common/admin/EditBidderProfile";
			} else {
				String clientIds= null;  //Added by Dhruvil Panchal PT #38353	
				boolean isMobileApp= Boolean.valueOf(request.getParameter("hdisMoblieApp"));
				if(isMobileApp){
					String clientArr[]=request.getParameterValues("chkMultipleDomain");
					int cStatus = 1; // mobilebidder status 
		    		if(clientArr == null){
		    			clientIds = defaultAPClientId;
		    		}else{
		    			clientIds = abcUtility.convertArrayToCommas(clientArr).replaceAll("~~0~~0", "").trim();
		    		}
		    		success = mobilebidderstatusservice.updateMobileBiddercStatus(userId,cStatus, clientIds, "update",abcUtility.getSessionUserId(request));
				}
				int bidderVerificationBy =  clientService.getBidderRegistrationVerifiedBy(clientId);
				String verificationCode = null;
				if(bidderVerificationBy != 0 && isEmailIdChanged) {
					verificationCode=UUID.randomUUID().toString().replaceAll("-", "").substring(0, 10);
				} else {
					verificationCode="";
				}
				
				boolean isNewCompanyDetails = (isEmailIdChanged 
						|| !request.getParameter("hdOldFullName").equalsIgnoreCase(bidderRegistrationDataBean.getTxtFullName()) 
						|| !request.getParameter("hdOldCompanyName").equalsIgnoreCase(bidderRegistrationDataBean.getTxtCompanyName()));
				
				TblUserLogin tblUserLogin = null;
				if(isSSOEnabled){
					success = wSCheckAvailService.updateSSOUser(bidderRegistrationDataBean,null, userId, oldEmailId, 2, clientId);
					if (WSCheckAvail.isSsoAvailable() && !success) {
	        			//First dump user in sso from Local
						success = wSCheckAvailService.dumpUserWithChngPwd(userId,clientId,2,false);
	        		}
				}
				
				bidderRegistrationDataBean.setSelCountry(Integer.parseInt(hdcountry));
				bidderRegistrationDataBean.setSelState(hdstate);
				bidderRegistrationDataBean.setTxtEmailId(oldEmailId);
				
				
				TblCompany tblCompany = bidderRegistrationDataBean._toTblCompany(clientId);
		        tblCompany.setAgreementType(joinedTypeOfAgreement);
		        tblCompany.setExecutionDateOfAgreement(DateobjExecutionOfAgreement);
		        tblCompany.setAgreementWith(entity);
		        tblCompany.setCredentialsCheckDate(checkDate);
		        tblCompany.setPointOfContact(pointOfContact);
		        tblCompany.setRemarks(remarks);
		        tblCompany.setCompanyName(companyName);
		        tblCompany.setBusinessCategory(joinedBusinessCategory);
		        tblCompany.setTblCountry(new TblCountry(1));
		        tblCompany.setCity(hdCity);
		        tblCompany.setPhoneNo(hdphoneno);
		        tblCompany.setWebsite(hdwebsite);
		        tblCompany.setTblState(new TblState(Integer.valueOf(hdstate)));		        
		        
				boolean servAvail = false;
				if((success && isSSOEnabled) || (!success && !isSSOEnabled)){
					success = manageBidderService.updateBidderRegistration(isEmailIdChanged,bidderVerificationBy, verificationCode, bidderRegistrationDataBean, tblUserLogin, bidderRegistrationDataBean._toTblUserDetail(abcUtility.getSessionUserId(request)), tblCompany, bidderRegistrationDataBean._toTblUserHistory(userHistoryEdit, clientId), bidderRegistrationDataBean.getTxtaBusCatKeywords(), isNewCompanyDetails, abcUtility.getSessionUserId(request), isEditProfileByBidder,clientId);
					success = dynamicFieldService.addDynamicFieldValueProcess(dynamicFieldService.dynFieldSetUp(request.getParameterMap(), request),clientId,manageBidderFieldValueId,userId,userId);
					servAvail = true;
				}else if (isSSOEnabled && WSCheckAvail.isSsoAvailable() && !success) {
					redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
				}else{
					redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_reg_serv_not_avail");
					servAvail = false;
					retVal="redirect:/common/admin/editbidderprofile/" + bidderRegistrationDataBean.getHdBidderId() + encryptDecryptUtils.generateRedirect("common/admin/editbidderprofile/"+ bidderRegistrationDataBean.getHdBidderId(), request);
					return retVal;
				}
				// If success and email ID is changed, send notification mail to old address. And send the mail verification link to the new mail address.
				if(success)
				{ // PT: 20745
					if(abcUtility.isModuleAssignToClient(request,9) && isCategoryAllow != null && isCategoryAllow.equals("1")){ //spend analysis.
                    	commonService.insertUpdateCategory("edit",userId,selectedCategory,registrationLinkId);
                    }
				}
				int bidderCstatus = Integer.parseInt(request.getParameter("bidderCstatus").toString());
				TblVendorCodeMapping tblVendorCode = manageBidderService.getVendorCode(bidderRegistrationDataBean.getHdBidderId(),clientId);
//				if(bidderCstatus == 1 && tblVendorCode == null){
//					String vendorCode = bidderRegistrationDataBean.getTxtVendorCode();
//					if(vendorCode != "" || !vendorCode.equalsIgnoreCase("") || vendorCode!=null){
//						TblVendorCodeMapping tblVendorCodeMapping = new TblVendorCodeMapping();
//						tblVendorCodeMapping.setVendorCode(vendorCode);
//						tblVendorCodeMapping.setClientId(clientId);
//						tblVendorCodeMapping.setCreatedBy(abcUtility.getSessionUserId(request));
//						tblVendorCodeMapping.setUpdatedBy(abcUtility.getSessionUserId(request));
//						tblVendorCodeMapping.setCreatedOn(commonService.getServerDateTime());
//						tblVendorCodeMapping.setUpdatedOn(commonService.getServerDateTime());
//						tblVendorCodeMapping.setIsActive(1);
//						manageBidderService.addTblVendorCodeMapping(tblVendorCodeMapping,bidderRegistrationDataBean);
//					}
//				}
				
				// PT : #35308 By Jitendra. Adding new fields in the bidder profile.
				boolean isClientSectorApplicable = manageBidderService.isClientSectorApplicable(clientId);
				boolean isBidderApproved = manageBidderService.isBidderApproved(userId, clientId); // Bug #35556 By Jitendra
				if(isFromRegisteredBidder==1 && isClientSectorApplicable){
					int bidderFieldsId = Integer.parseInt(request.getParameter("hdBidderFieldsId"));
					int actualBidderId = Integer.parseInt(request.getParameter("hdActualBidderId"));
					TblBidderAdditionalFields tblBidderAdditionalFields = new TblBidderAdditionalFields();
					
					// Bug #35609 By Jitendra
					if(manageBidderService.checkIfExistsBidderFieldDetails(userId)){ 
						bidderFieldsId = manageBidderService.getBidderFieldId(userId); 
						tblBidderAdditionalFields.setBidderFieldsId(bidderFieldsId); 
					}
					tblBidderAdditionalFields.setTypeOfInvestor(StringUtils.hasLength(bidderRegistrationDataBean.getSelTypesOfInvestor()) ? Integer.parseInt(bidderRegistrationDataBean.getSelTypesOfInvestor()) : 0);
					tblBidderAdditionalFields.setPropertyLookingFor(StringUtils.hasLength(bidderRegistrationDataBean.getSelPropertyLookingFor()) ? Integer.parseInt(bidderRegistrationDataBean.getSelPropertyLookingFor()) : 0);
					tblBidderAdditionalFields.setTypeOfProperty(bidderRegistrationDataBean.getChkTypesOfProperty().replaceAll("\\,", "|"));
					tblBidderAdditionalFields.setMinBudget(new BigDecimal(bidderRegistrationDataBean.getTxtMinBudget())); // Bug #36627 By Jitendra.
					tblBidderAdditionalFields.setMaxBudget(new BigDecimal(bidderRegistrationDataBean.getTxtMaxBudget()));
					tblBidderAdditionalFields.setIsLoanRequired(StringUtils.hasLength(bidderRegistrationDataBean.getSelLoanRequired()) ? Integer.parseInt(bidderRegistrationDataBean.getSelLoanRequired()) : 0);
					tblBidderAdditionalFields.setAreaOrLocation(bidderRegistrationDataBean.getTxtAreaOrLocation());
					tblBidderAdditionalFields.setCity(bidderRegistrationDataBean.getTxtAdditionalCity());
					tblBidderAdditionalFields.setStateId(bidderRegistrationDataBean.getChkAdditionalState().replaceAll("\\,", "|"));
					tblBidderAdditionalFields.setTblClient(new TblClient(clientId));
					tblBidderAdditionalFields.setTblUserLogin(new TblUserLogin(userId));
					tblBidderAdditionalFields.setTblBidderStatus(new TblBidderStatus(actualBidderId));
					tblBidderAdditionalFields.setCStatus(1);
					tblBidderAdditionalFields.setCreatedBy(abcUtility.getSessionUserId(request));
					tblBidderAdditionalFields.setUpdatedOn(commonService.getServerDateTime());
					tblBidderAdditionalFields.setIsUpdated(1);
					success = manageBidderService.addOrUpdateBidderAdditionalFields(tblBidderAdditionalFields);
				}
				else{
					if(isClientSectorApplicable && isBidderApproved){
						int bidderFieldsId = Integer.parseInt(request.getParameter("hdBidderFieldsId"));
						int actualBidderId = Integer.parseInt(request.getParameter("hdActualBidderId"));
						TblBidderAdditionalFields tblBidderAdditionalFields = new TblBidderAdditionalFields();

						// Bug #35609 By Jitendra
						if(manageBidderService.checkIfExistsBidderFieldDetails(userId)){ 
							bidderFieldsId = manageBidderService.getBidderFieldId(userId); 
							tblBidderAdditionalFields.setBidderFieldsId(bidderFieldsId); 
						}
						tblBidderAdditionalFields.setTypeOfInvestor(StringUtils.hasLength(bidderRegistrationDataBean.getSelTypesOfInvestor()) ? Integer.parseInt(bidderRegistrationDataBean.getSelTypesOfInvestor()) : 0);
						tblBidderAdditionalFields.setPropertyLookingFor(StringUtils.hasLength(bidderRegistrationDataBean.getSelPropertyLookingFor()) ? Integer.parseInt(bidderRegistrationDataBean.getSelPropertyLookingFor()) : 0);
						tblBidderAdditionalFields.setTypeOfProperty(bidderRegistrationDataBean.getChkTypesOfProperty().replaceAll("\\,", "|"));
						tblBidderAdditionalFields.setMinBudget(new BigDecimal(bidderRegistrationDataBean.getTxtMinBudget())); // Bug #36627 By Jitendra.
						tblBidderAdditionalFields.setMaxBudget(new BigDecimal(bidderRegistrationDataBean.getTxtMaxBudget()));
						tblBidderAdditionalFields.setIsLoanRequired(StringUtils.hasLength(bidderRegistrationDataBean.getSelLoanRequired()) ? Integer.parseInt(bidderRegistrationDataBean.getSelLoanRequired()) : 0);
						tblBidderAdditionalFields.setAreaOrLocation(bidderRegistrationDataBean.getTxtAreaOrLocation());
						tblBidderAdditionalFields.setCity(bidderRegistrationDataBean.getTxtAdditionalCity());
						tblBidderAdditionalFields.setStateId(bidderRegistrationDataBean.getChkAdditionalState().replaceAll("\\,", "|"));
						tblBidderAdditionalFields.setTblClient(new TblClient(clientId));
						tblBidderAdditionalFields.setTblUserLogin(new TblUserLogin(userId));
						tblBidderAdditionalFields.setTblBidderStatus(new TblBidderStatus(actualBidderId));
						tblBidderAdditionalFields.setCStatus(1);
						tblBidderAdditionalFields.setCreatedBy(abcUtility.getSessionUserId(request));
						tblBidderAdditionalFields.setUpdatedOn(commonService.getServerDateTime());
						success = manageBidderService.addOrUpdateBidderAdditionalFields(tblBidderAdditionalFields);
					}
				}
				if(success && isEmailIdChanged) {
					URL url = new URL(request.getRequestURL().toString());
					StringBuilder verifyUrlPrefix = new StringBuilder();
					verifyUrlPrefix.append(((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) ? "http" : "https").append("://").append(url.getHost());
					if ((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) {
						verifyUrlPrefix.append(":").append(url.getPort());
					}
					verifyUrlPrefix.append(url.getPath().substring(url.getPath().indexOf("/"), url.getPath().lastIndexOf("/")));

					Map<String, Object> mailParams = new HashMap<String, Object>();
					mailParams.put("to", oldEmailId+","+bidderRegistrationDataBean.getTxtEmailId());
					mailParams.put("SubDomainName", clientService.getClientNameById(clientId));
					mailParams.put("ServerDateTime", CommonUtility.convertTimezone(commonService.getServerDateTime()));
					mailContentUtillity.dynamicMailGeneration("8", String.valueOf(userId), String.valueOf(clientId), mailParams, "");
					Map<String, Object> paramMap = new HashMap<String, Object>();
					paramMap.put("UsersRegisteredEmailId", bidderRegistrationDataBean.getTxtEmailId());
					paramMap.put("Url", clientService.getClientNameById(clientId));
					switch (bidderVerificationBy) {
					case 2:
						mailContentUtillity.dynamicMailGeneration("4", String.valueOf(userId), String.valueOf(clientId),null ,"");

						//ToDo :: Mobile verification code by SMS.
						break;
					case 1:
//						mailContentUtillity.dynamicMailGeneration("1", String.valueOf(userId), String.valueOf(clientId), null,"");
						break;

					case 0:
						mailContentUtillity.dynamicMailGeneration("5", String.valueOf(userId), String.valueOf(clientId), paramMap,"");
						break;
					}
					if(isFromRegisteredBidder!=1){
					retVal="redirect:/common/admin/managebidder"+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
					}else{
						retVal="redirect:/common/admin/manageregisteredbidders"+ encryptDecryptUtils.generateRedirect("common/admin/manageregisteredbidders", request);
					}
				}else {
					retVal="redirect:/common/admin/editbidderprofile/" + bidderRegistrationDataBean.getHdBidderId() + encryptDecryptUtils.generateRedirect("common/admin/editbidderprofile/"+ bidderRegistrationDataBean.getHdBidderId(), request);
					if(servAvail){
						redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_edit_bidderprofile" : CommonKeywords.ERROR_MSG_KEY.toString());
					}
				}
				if((success && isSSOEnabled) || (success && !isSSOEnabled)) {
					if(isFromRegisteredBidder!=1){
						retVal="redirect:/common/admin/managebidder"+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
						}else{
							retVal="redirect:/common/admin/manageregisteredbidders"+ encryptDecryptUtils.generateRedirect("common/admin/manageregisteredbidders", request);
						}
                     redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_edit_bidderprofile" : CommonKeywords.ERROR_MSG_KEY.toString());
				} 
			}
		}
		catch(Exception ex){
			return exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editBidderLinkId, auditBidderProfileEdited, 0, userId);
		}
		return retVal;
	}
	
	/**
	 * 
	 * @param userId
	 * @param oprType 1 for approve and 2 for renew registration operation 
	 * @param response
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/admin/approvebidder/{userId}/{oprType}/{enc}","/admin/renewbidderregistration/{userId}/{oprType}/{enc}","/admin/approvetwostagebidder/{userId}/{oprType}/{enc}"}, method = RequestMethod.GET)                       
    public String approveBidder(@PathVariable("userId") int userId,@PathVariable("oprType") int oprType,HttpServletRequest request,ModelMap map){
        String retVal=null;
        try{
        	String publicKey=null;
        	map.put("isAdminBidder", commonService.getBidderStatus(userId));
        	if(abcUtility.getSessionIsPkiEnabled(request)==1){
        		String certIds[] = ((SessionBean) request.getSession().getAttribute("sessionObject")).getCertId().split(",");
        		if(certIds!=null && certIds.length!=0){
        			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
        		}
        		List<Object[]> certDetails= manageBidderService.getBidderCertiDetails(userId,abcUtility.getSessionIsDualCerti(request)==true?2:1);
            	List<Map<String,Object>> certiDetailsList = new ArrayList<Map<String,Object>>();
            	if(!certDetails.isEmpty()){
            		for (int i = 0; i < certDetails.size(); i++) {
            			Map<String,Object> certDetail= new HashMap<String, Object>();
                		Object[] object = certDetails.get(i);
                		certDetail.put("subject", object[0]);
                		certDetail.put("issuer", object[1]);
                		certDetail.put("serialNumber", object[2]);
                		certDetail.put("publicKey", object[3]);
                		certDetail.put("keyUsage", object[4]);
                		certDetail.put("endDate", object[5]);
                		certDetail.put("isVerified", object[6]);
                		if(object[7] != null && Integer.parseInt(object[7].toString()) != 0){
                			certDetail.put("verifiedBy", loginService.getUserLoginById(Integer.parseInt(object[7].toString())).getUserName());
                		}else{
                			certDetail.put("verifiedBy", null);
                		}
                		
                		certDetail.put("verifiedOn", object[8]);
                		certiDetailsList.add(certDetail);
        			}
            	}
            	request.setAttribute("certiDetailsList", certiDetailsList);
            	request.setAttribute("certDetail", manageBidderService.getBidderCertiDetailsNew(userId,abcUtility.getSessionIsDualCerti(request)==true?2:1));
    		}
        	int clientId=abcUtility.getSessionClientId(request);
        	Object mapDcReqObj = clientService.getClientField(clientId,"mapDcRequired");
        	Integer mapDcRequired = 0;
        	if(mapDcReqObj!=null)
        	{
        		mapDcRequired = (Integer) mapDcReqObj;
        	}
        	
        	request.setAttribute("clientName", clientService.getClientNameById(clientId));
        	request.setAttribute("mapDcRequired",mapDcRequired);
        	List<Object[]> allPaymentModeList = commonService.getPaymentTypeByStatust(2);//2 offline
        	/*List<SelectItem> paymentModeList = new ArrayList<SelectItem>();
        	if(allPaymentModeList!=null && !allPaymentModeList.isEmpty()){
        		for (Object[] objects : allPaymentModeList) {
        			paymentModeList.add(new SelectItem(objects[1], objects[0]));
    			}
        	}*/
        	request.setAttribute("paymentModeList", abcUtility.convert(allPaymentModeList));
        	List<SelectItem> statusList = new ArrayList<SelectItem>();
        	statusList.add(new SelectItem("Approve", bidderStatusApprove));
        	statusList.add(new SelectItem("Reject", bidderStatusRejected));
        	request.setAttribute("statusList", statusList);
        	request.setAttribute("yesNoList", commonService.getYesNo());
        	List<SelectItem> domainList = new ArrayList<SelectItem>();
        	Map<String,Object> paymentAppClient=null;
        	List<Map<String,Object>> paymentAppClientList=new ArrayList<Map<String,Object>>();
        	int clientsectorId = clientService.getClientSectorId(clientId, mobileApp_sector); //Check domain sector vertical mobileapp 
            boolean isMobileApp =clientsectorId != 0 ? true : false; //check isMobile sector
        	request.setAttribute("isMobileApp",isMobileApp);
        	List<Object[]> allDomainList = null;
        	String clientIds = null;
        	if(isMobileApp){
        		 allDomainList = commonService.getMultipleClientsForMobileApp(userId,abcUtility.getSessionUserId(request));
        		 clientIds=mobilebidderstatusservice.selectedDomainOnMobile(userId);
        	}else{
        		 allDomainList=  commonService.getMultipleClientsForAprove(userId,abcUtility.getSessionUserId(request));
        	}
        	if(allDomainList!=null && !allDomainList.isEmpty()){
        		for (Object[] objects : allDomainList) {
        			if(clientsectorId != 0){
        				if(clientIds != null){
        					if(clientIds.contains(","+objects[0].toString().trim()+",")) {
        						domainList.add(new SelectItem(objects[1], objects[0]+"~~0~~0",1));
        					}else{
        						domainList.add(new SelectItem(objects[1], objects[0]+"~~0~~0"));
        					}
        				}else{
        					domainList.add(new SelectItem(objects[1], objects[0]+"~~0~~0"));
        				}
        			}else{
        				domainList.add(new SelectItem(objects[1], objects[0]+"~~"+objects[2]+"~~"+objects[3]));
        			}
            		paymentAppClient=new HashMap<String, Object>();
            		paymentAppClient.put("clientId", objects[0]);
            		paymentAppClient.put("isRegistrationCharges", objects[2]);
            		paymentAppClientList.add(paymentAppClient);
    			}
        	}
        	if(abcUtility.isModuleAssignToClient(request,9)){ //spend analysis and statistic module.  PT: 20745
        		request.setAttribute("isCategoryAllow",commonService.isCategoryAllow(clientId));
            }else{
            	request.setAttribute("isCategoryAllow",0);
            }
        	request.setAttribute("getTime", commonService.getServerDateTime());
        	request.setAttribute("domainList", domainList);
        	request.setAttribute("vendorCode", "");
        	request.setAttribute("paymentAppClientList", paymentAppClientList);
        	request.setAttribute("bidderDetailMap", getViewBidderDetails(userId, abcUtility.getSessionClientId(request),WebUtils.getCookie(request, "locale").getValue()));
        	request.setAttribute("documentList", manageBidderService.getBidderDocs(userId, abcUtility.getSessionClientId(request)));//For document list
        	String gslClientIdsArr[]= gslClientIds.split(",");
			boolean isGslClient = false;
			for (String strGslClientId : gslClientIdsArr) {
				if(!"".equals(strGslClientId) && Integer.parseInt(strGslClientId) == clientId){
	            	isGslClient = true;
	            	break;
	            }
			}
			if(isGslClient){
				request.setAttribute("bidderRegisteredInDocList", manageBidderService.getBidderRegisteredInDocs(userId, abcUtility.getSessionClientId(request)));//For GSL bidder Registered In Document list
				request.setAttribute("bidderIndustryAndClass", manageBidderService.getBidderIndustryAndClassificationWithDoc(userId, abcUtility.getSessionClientId(request)));//For GSL bidder Registered In Document list
			}
        	request.setAttribute("publicKey", publicKey);
        	request.setAttribute("approveStatus",manageBidderService.getBidderCstatus(clientId, userId));
          	boolean isRegApplicable=clientService.checkIsRegChargesApplicable(clientId);
        	request.setAttribute("isRegApplicable", isRegApplicable);
        	int user_Id = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getUserId();     	 
            int i = commonService.checkAbcUser(Integer.toString(user_Id));
            if(i>0)
            {
            	request.setAttribute("isAbcUser", i);
            }
        	if(isRegApplicable){
        		List<Object[]> regChargesMode=clientService.getRegChargesMode(clientId);
        		if(!regChargesMode.isEmpty()){
        			request.setAttribute("regChargesMode", regChargesMode.get(0)[1]);
        			request.setAttribute("userTypeId", abcUtility.getSessionUserTypeId(request));
        		}
				TblPayment tblPayment = manageBidderService
						.getPaymentDetailByBidderId(userId, clientId,3,1);

				request.setAttribute("tblPayment",tblPayment);
				

				if (tblPayment != null) {

					int paymentId = 0;
					paymentId = tblPayment.getPaymentId();
				
					
					request.setAttribute("payType",commonService.getPaymentTypeDetail(tblPayment.getTblPaymentType().getPaymentTypeId()).getLang1());
					
					request.setAttribute("registrationCharges",tblPayment.getAmount().intValue());
					request.setAttribute("transactionDate",tblPayment.getCreatedOn());
					TblOfflinePayment tblOfflinePayment = manageBidderService.getOfflinePaymentDetail(paymentId);
							
					if (tblOfflinePayment != null) {
						
						request.setAttribute("payDate",tblOfflinePayment.getReferenceDate());
						request.setAttribute("payMode", "Offline");		
						request.setAttribute("referenceNo",tblOfflinePayment.getReferenceNo());
						request.setAttribute("bankName1", tblOfflinePayment.getBankName());
						TblBidderDocMapping tblBidderDocMapping=manageBidderService.getBidderDocDetails(paymentId,uploadBidderChargesOfflineLink);
						request.setAttribute("tblBidderDocMapping",	tblBidderDocMapping);
						
					} else {
					
						TblOnlinePayment tblOnlinePayment = manageBidderService.getOnlinePaymentDetail(paymentId);
						
						request.setAttribute("payDate",	tblOnlinePayment.getUpdatedOn());							
						request.setAttribute("payMode", "Online");
						request.setAttribute("referenceNo",tblPayment.getPaymentId());
					}
					
					//request.setAttribute("paymentType",tblPayment.getTblPaymentType().getLang1());
				}
        	}
        	else{
        		request.setAttribute("tblPayment",null);
        	}
        	int isGSTRequired = (Integer)clientService.getClientField(clientId, "isGSTRequired");
        	if(clientService.getBidderCountryIdByUserId(userId)!=countryId){
        		isGSTRequired = 0;
        	}
        	request.setAttribute("isGSTRequired", isGSTRequired);
        	if(isGSTRequired==1){
	        	Object[] obj = manageBidderService.getGstFields("TblBidderGstDetails", userId,clientId ,"gstTaxClassification,gstNo,gstDeclarationId,panNo,reason");
	        	if(obj!=null){
	        		request.setAttribute("gstTaxClassification", (Integer)obj[0]);
	        		request.setAttribute("BidderGstNo", obj[1]);
	        		request.setAttribute("gstDeclarationId", obj[2]);
	        		request.setAttribute("panNo", obj[3]);
	        		request.setAttribute("reason", obj[4]);
	        	}
        	}
        	if(isGSTRequired==1){
	        	List<Object[]> lstGstReceipt = manageBidderService.getBidderGstReceipt(userId, clientId);
		    	if(!lstGstReceipt.isEmpty()){
		    		request.setAttribute("gstDocumentList", lstGstReceipt);
		    	}
        	}
        	request.setAttribute("dynFieldMap", dynamicFieldService.setDynamicField(manageBidderFieldValueId, clientId, userId));
        //	int clientsectorId = clientService.getClientSectorId(clientId, mobileApp_sector); //Check domain sector vertical mobileapp 
        //  request.setAttribute("isMobileApp", clientsectorId != 0 ? true : false );
        	retVal="common/admin/ApproveBidder";
			if(oprType == 3 || oprType == 4)
			{
				retVal="common/admin/ApproveTwoStageBidder";
			}
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), oprType == 2 ? renewRegistrationLinkId  : bidderAproveLinkId, oprType == 2 ? auditRenewBidderRegistration : auditApproveBidder, 0, userId);
        }
        
        return retVal;
    }
	@RequestMapping(value = {"/admin/verifydc/{userId}/{enc}"}, method = RequestMethod.GET)                       
    public String verifyDC(@PathVariable("userId") int userId,ModelMap modelMap,HttpServletRequest request){
        String retVal=null;
        try{
        	List<Object[]> list = clientService.getClientByBidderId(userId);
        	int size = 0;
        	int pkiDomainCount = 0;
        	for (Object[] objects : list) {
				if((Integer)objects[5] == 0){
					size++;
				}
				if((Integer)objects[4] > 0){
					pkiDomainCount++;
				}
				
			}
        	int verificationNotRequired = 0;
        	//if(list.size() > 0 && size == list.size()){
        	if(list.size() > 0 && size == pkiDomainCount){
        		verificationNotRequired = 1;
        	}
        	modelMap.addAttribute("verificationNotRequired", verificationNotRequired);
        	modelMap.addAttribute("domainList", list);
        	modelMap.addAttribute("bidderDetail", loginService.getUserDetailId(userId));
        	modelMap.addAttribute("certDetail", manageBidderService.getBidderCertiDetailsByBidderId(userId));
        	modelMap.addAttribute("userId", userId);
            retVal="common/admin/VerifyDC";
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, verifyDC, 0, userId);
        }      
        return retVal;
    }
	
	@RequestMapping(value = "/admin/submitverifydc", method = RequestMethod.POST)
	public String submitverifydc( RedirectAttributes redirectAttributes, HttpServletResponse response, HttpServletRequest request) {
		String retVal = "";
		int userId = 0;
		int operationType = 0;
		int SubmitWithoutVerify = 0;
		int sessionUserId = abcUtility.getSessionUserId(request); 
		try{
			userId=StringUtils.hasLength(request.getParameter("hdUserId")) ? Integer.parseInt(request.getParameter("hdUserId")) : 0;
			operationType = StringUtils.hasLength(request.getParameter("submitVerify")) ? Integer.parseInt(request.getParameter("submitVerify")) : 0;
			SubmitWithoutVerify = StringUtils.hasLength(request.getParameter("hdSubmitWithoutVerify")) ? Integer.parseInt(request.getParameter("hdSubmitWithoutVerify")) : 0;
			if(SubmitWithoutVerify == 0){
				if(operationType == 1){
	    			loginService.verifyDC(userId, 1, sessionUserId);
	    		}else if(operationType == 2){
	    			loginService.verifyDC(userId, 2, sessionUserId);
	    		}
			}else if(SubmitWithoutVerify == 1){
    			loginService.verifyDC(userId, 1, sessionUserId);
    			loginService.verifyDC(userId, 2, sessionUserId);
			}
			
			retVal="common/admin/verifydc/"+userId;
		}
		catch(Exception ex){
			return exceptionHandlerService.writeLog(ex);
		} finally {
			String message = "";
			if(SubmitWithoutVerify == 0){
				message = "On Verification of Digital certificate: ";
				if(operationType == 1){
					message += "Signing certificate is verified";
				}else if(operationType == 2){
					message += "Encryption certificate is verified";
				}
			}else{
				message = "On submit where DC verification is not required : Signing/Encryption certificate is verified";
			}
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, message, 0, userId);
		}
		return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
	}
	
	@RequestMapping(value = "/admin/managedc/{enc}", method = RequestMethod.GET)                       
    public String manageDC(ModelMap modelMap, HttpServletRequest request){
        String retVal=null;
        try{
            modelMap.addAttribute("reportId", report_manage_dc);
            reportGeneratorService.getReportConfigDetails(report_manage_dc, modelMap);
            String langId=WebUtils.getCookie(request, "locale").getValue();
            SelectItem pleseSelect = new SelectItem("Select", 0); 
            List<SelectItem> countryList =modelToSelectItem.convertListIntoSelectItemList(commonService.getCountryList(langId), "countryId", "lang"+langId);
            countryList.add(0, pleseSelect);
            modelMap.put("countryList",countryList);
            retVal="common/admin/ManageDC";
           // System.out.println(modelMap);
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }
        finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, getManageDC, 0,0);
        }
        
        return retVal;
    }
	
	@RequestMapping(value = "/admin/managetwostagereg/{enc}", method = RequestMethod.GET)                       
    public String manageTwoStageReg(ModelMap modelMap, HttpServletRequest request){
        String retVal=null;
        try{
            modelMap.addAttribute("reportId", report_manage_twostage_reg);
            reportGeneratorService.getReportConfigDetails(report_manage_twostage_reg, modelMap);
            String langId=WebUtils.getCookie(request, "locale").getValue();
            retVal="common/admin/TwoStageReg";
           // System.out.println(modelMap);
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }
        finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, getTwoStageReg, 0,0);
        }
        
        return retVal;
    }
	@RequestMapping(value = "/admin/managebidder/{enc}", method = RequestMethod.GET)                       
    public String mangeBidder(ModelMap modelMap, HttpServletRequest request){
        String retVal=null;
        try{
            modelMap.addAttribute("reportId", manageBidderReportId);
            reportGeneratorService.getReportConfigDetails(manageBidderReportId, modelMap);
            String langId=WebUtils.getCookie(request, "locale").getValue();
            SelectItem pleseSelect = new SelectItem("Select", 0); 
            List<SelectItem> countryList =modelToSelectItem.convertListIntoSelectItemList(commonService.getCountryList(langId), "countryId", "lang"+langId);
            countryList.add(0, pleseSelect);
            modelMap.put("countryList",countryList);
            int clientId = abcUtility.getSessionClientId(request);
            Object[] isTwoStepBidderApprovalObj = clientService.getClientFields(clientId,"isTwoStepBidderApproval,domainName");
            Integer twoStepBidderApproval = 0;
            if(isTwoStepBidderApprovalObj!=null)
            {
            	twoStepBidderApproval = (Integer) isTwoStepBidderApprovalObj[0];	
            }
            
            modelMap.put("twoStepBidderApproval",twoStepBidderApproval);
            retVal="common/admin/ManageBidder";
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }
        finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, auditManageBidder, 0,0);
        }
        
        return retVal;
    }
	
	/**
	 * to display blacklist bidder page
	 * @param userId
	 * @param response
	 * @param request
	 * @return String
	 */
	@RequestMapping(value = {"/admin/blacklistbidder/{userId}/{bidderId}/{oprType}/{enc}","/admin/viewblacklistbidder/{userId}/{bidderId}/{oprType}/{enc}"}, method = RequestMethod.GET)                       
    public String blacklistBidder(@PathVariable("userId") int userId,@PathVariable("bidderId") int bidderId,@PathVariable("oprType") String oprType,HttpServletRequest request){
        String retVal=null;
        Map<String,Object> bidderDetalis=null;
        try{
        	//ClientBean clientBean = (ClientBean) request.getSession().getAttribute("clientObject");
        	String publicKey=null;
        	if(abcUtility.getSessionIsPkiEnabled(request)==1){
        		String certIds[] = ((SessionBean) request.getSession().getAttribute("sessionObject")).getCertId().split(",");
        		if(certIds!=null && certIds.length!=0){
        			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
        		}
    		}
        	List<SelectItem> blackListType = new ArrayList<SelectItem>();
        	blackListType.add(new SelectItem("Temporary", "1"));
        	blackListType.add(new SelectItem("Permanent", "2"));
        	List<Object[]> bidderList=manageBidderService.getBidderDetailsForBlacklist(userId,abcUtility.getSessionClientId(request));
        	if(bidderList != null && bidderList.size() > 0){
        		bidderDetalis=new HashMap<String, Object>();
        		bidderDetalis.put("userName", bidderList.get(0)[0]);
        		bidderDetalis.put("companyName", bidderList.get(0)[1]);
        		bidderDetalis.put("loginId", bidderList.get(0)[2]);
        	}
        	List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(15, abcUtility.getSessionClientId(request));
            int allowedSize = 0;
            StringBuilder allowedExt = new StringBuilder();
            if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
                allowedSize = lstDocUploadConf.get(0).getMaxSize();
                allowedExt.append(lstDocUploadConf.get(0).getType());
                request.setAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
            }
            int index = allowedExt.toString().indexOf(",");
    	    allowedExt.insert(index + 1, "*.");
    	    while (index >= 0) {
    			index = allowedExt.toString().indexOf(",", index + ",".length());
    			allowedExt.insert(index + 1, "*.");
    	    }

    	    request.setAttribute("allowedExt", allowedExt);
    	    request.setAttribute("allowedSize", allowedSize/1024);
        	request.setAttribute("blackListType", blackListType);
        	request.setAttribute("bidderDetalis", bidderDetalis);
        	request.setAttribute("publicKey", publicKey);
        	request.setAttribute("linkId",bidderBlacklistLinkId );
        	request.setAttribute("opType", oprType);
        	TblUserBlackList tblUserBlackList=null;
        	if("E".equalsIgnoreCase(oprType) || "V".equalsIgnoreCase(oprType)){
        		tblUserBlackList=manageBidderService.getUserBlackListByBidderId(bidderId);
        		request.setAttribute("blacklistDetails", tblUserBlackList);
        		if("V".equalsIgnoreCase(oprType)){
        			request.setAttribute("cStatusDoc", 1);
        			request.setAttribute("cStatusDocView",1);
        		}else{
        			request.setAttribute("cStatusDoc", 0);
        		}
        	}
        	if("C".equalsIgnoreCase(oprType)){
        		request.setAttribute("cStatusDoc", 0);
        	}
        	if("V".equalsIgnoreCase(oprType)){
        		retVal="common/admin/ViewBlacklistBidder";
        		request.setAttribute("blacklistHistoryDetails", manageBidderService.getUserBlackListByBidderId(bidderId,0));
        		request.setAttribute("userDetail", loginService.getUserLoginById(tblUserBlackList.getCreatedBy()));
        	}else{
        		retVal="common/admin/BlacklistBidder";
        	}
        }
        catch(Exception ex){
        	return exceptionHandlerService.writeLog(ex);
        }finally {
        	int linkId=0;
        	String msg=null;
        	if("C".equalsIgnoreCase(oprType)){
        		linkId=bidderBlacklistLinkId;
        		msg=auditBlackListBidder;
        	}else if("V".equalsIgnoreCase(oprType)){
        		linkId=viewBlacklistBidderLink;
        		msg=auditGetViewBlackListBidder;
        	}else{
        		linkId=bidderBlacklistEditLinkId;
        		msg=auditEditBlackListBidder;
        	}
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, 0,userId);
        }
        return retVal;
    }
	
	@RequestMapping(value = "/admin/mapdc/{enc}", method = RequestMethod.GET)                       
    public String mapDC(HttpServletRequest request){
        String retVal=null;
        try{
        	List<SelectItem> certList = new ArrayList<SelectItem>();
        	certList.add(new SelectItem("tmcsuperadmin - 07-2012", "1"));
        	certList.add(new SelectItem("Test 1 Enc", "2"));
        	certList.add(new SelectItem("test 4 Enc", "3"));
        	certList.add(new SelectItem("stqc SA Enc", "3"));
        	certList.add(new SelectItem("stqcsa1Enc", "3"));
        	request.setAttribute("certList", certList);
            retVal="common/admin/MapDC";
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }
        return retVal;
    }
    
	
	/**
	 * To get details of un-map DC on UnMapDC.jsp page
	 * @author nirav.modi
	 * @param bidderId
	 * @param modelMap
	 * @param request
	 * @return
	 */
    @RequestMapping(value = "/admin/unmapdc/{bidderId}/{enc}", method = RequestMethod.GET)                       
    public String unMapDC(@PathVariable("bidderId") int bidderId,ModelMap modelMap,HttpServletRequest request){
        String retVal=null;
        try{
        	int clientId=abcUtility.getSessionClientId(request);
        	modelMap.addAttribute("bidderDetailMap", getViewBidderDetails(bidderId, clientId,WebUtils.getCookie(request, "locale").getValue()));//for registrationdetails.jsp page

        	//ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        	String publicKey=null;
        	//TODO:For sign generation code
        	if(abcUtility.getSessionIsPkiEnabled(request)==1){
        		String certIds[] = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getCertId().split(",");
        		if(certIds!=null && certIds.length!=0){
        			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
        		}
        		modelMap.addAttribute("publicKeyForSign", publicKey);
    		}
        	
        	List<Object[]> unmapCertDetails= manageBidderService.getUnMapCertDetails(bidderId, clientId);
        	if(!unmapCertDetails.isEmpty() && unmapCertDetails.size() != 3){
        		for (int i = 0; i < unmapCertDetails.size(); i++) {
        			Map<String,Object> certDetail= new HashMap<String, Object>();
            		Object[] object = unmapCertDetails.get(i);
            		certDetail.put("loginId", object[0]);
            		certDetail.put("keyUsage", object[11]);
            		certDetail.put("subject", object[2]);
            		certDetail.put("issuer", object[3]);
            		certDetail.put("publicKey", object[4]);
            		certDetail.put("serialNumber", object[5]);
            		certDetail.put("validFrom", object[6]);
            		certDetail.put("validTo", object[7]);
            		certDetail.put("certId",object[8]);
            		certDetail.put("userCertId",object[9]);
            		certDetail.put("isDual",object[10]);
            		if((Integer)object[11] == 1){
            			modelMap.addAttribute("SigningCerti", certDetail);
            		}else if((Integer)object[11] == 2){
            			modelMap.addAttribute("EncryptionCerti", certDetail);
            		}
    			}
        	}else if(!unmapCertDetails.isEmpty() && unmapCertDetails.size() == 3){
        		List<HashMap<String,Object>> data=new ArrayList<HashMap<String,Object>>();
        		for (int i = 0; i < unmapCertDetails.size(); i++) {
        			Map<String,Object> certDetail= new HashMap<String, Object>();
        			Object[] object = unmapCertDetails.get(i);
            		certDetail.put("loginId", object[0]);
            		certDetail.put("keyUsage", object[11]);
            		certDetail.put("subject", object[2]);
            		certDetail.put("issuer", object[3]);
            		certDetail.put("publicKey", object[4]);
            		certDetail.put("serialNumber", object[5]);
            		certDetail.put("validFrom", object[6]);
            		certDetail.put("validTo", object[7]);
            		certDetail.put("certId",object[8]);
            		certDetail.put("userCertId",object[9]);
            		certDetail.put("isDual",object[10]);
            		data.add((HashMap<String, Object>) certDetail);
        		}
        		modelMap.addAttribute("data", data);
        	}
        	modelMap.addAttribute("rowSize", unmapCertDetails.size());// for count how many rows return. It means is dual certi or single certi
            retVal="common/admin/UnMapDC";
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }
        finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),unMapDCLinkId, auditUnMapDc, 0,bidderId);
        }
        return retVal;
    }
    /**
     * @author nirav.modi
     * @param redirectAttributes
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/addunmapdc", method = RequestMethod.POST)                       
    public String addUnMapDC(RedirectAttributes redirectAttributes, HttpServletResponse response, HttpServletRequest request){
        boolean success = false;
        String retVal = null;
        String bidderId = null;
        ClientBean clientBean=null;
        String remark = null;
        try{
        	clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        	String encryCertId = request.getParameter("hdEncryCertId");;
        	String encryUserCertId = request.getParameter("hdEncryUserCertId");
        	String encryKeyUsage = request.getParameter("hdEncryKeyUsage");
        	String encryIsDual = request.getParameter("hdEncryIsDual");
        	//String encryCertIdDual = null;
        	String userCertIds[] = null;
        	String signingCertId = request.getParameter("hdSigningCertId");
        	String signingUserCertId = request.getParameter("hdSigningUserCertId");
        	String signingKeyUsage = request.getParameter("hdSigningKeyUsage");
        	String signingIsDual = request.getParameter("hdSigningIsDual");
        	bidderId = request.getParameter("hdBidderId");//it's a bidder id
        	remark = request.getParameter("txtaRemarks");
        	String rowSize = request.getParameter("hdRowSize");
        	String loginId = request.getParameter("hdLoginId");
        	String encCertiId = request.getParameter("certIsSelect_enc");
        	String signCertiId = request.getParameter("certIsSelect_sign");
                
        	int createdBy = abcUtility.getSessionUserId(request);
        	//TODO : If dual certi exist. rowSize is used for dual certi
        	
        		
//                 if(rowSize.equals("3")){
//        		userCertIds = request.getParameterValues("certIsSelect");// in condition if Encry certi exist
//        		//encryUserCertIdDual = request.getParameter("hdEncryUserCertId");// in condition if Encry certi exist
//        	}
           
                List<TblUserCertificate> tblUserCertificates = null;
        	if(StringUtils.hasLength(loginId) /*&& StringUtils.hasLength(signingUserCertId)*/  && StringUtils.hasLength(remark) && StringUtils.hasLength(bidderId) /*&& StringUtils.hasLength(signingCertId)*/){
        		List<TblCertUnMapHistory> tblCertUnMapHistorys = new ArrayList<TblCertUnMapHistory>();
        		tblUserCertificates = new ArrayList<TblUserCertificate>();
        		if ( signCertiId != null  &&  !signCertiId.isEmpty()) {
                        TblCertUnMapHistory tblCertUnMapHistory = new TblCertUnMapHistory();
                        tblCertUnMapHistory.setRemark(remark);
                        tblCertUnMapHistory.setCreatedBy(createdBy);
                        tblCertUnMapHistory.setTblUserLogin(new TblUserLogin(Integer.parseInt(bidderId)));
                        tblCertUnMapHistory.setTblClient(new TblClient(clientBean.getClientId()));
                        tblCertUnMapHistory.setIsMapped(0);
                        TblUserCertificate tblUserCertificate = new TblUserCertificate();

                        tblCertUnMapHistory.setTblCertificate(new TblCertificate(Integer.parseInt(signingCertId)));
                        tblCertUnMapHistory.setKeyUsage(Integer.parseInt(signingKeyUsage));
                        tblCertUnMapHistory.setIsDualCert(Integer.parseInt(signingIsDual));
                        tblUserCertificate.setUserCertId(Integer.parseInt(signingUserCertId));


                        tblUserCertificates.add(tblUserCertificate);
                        tblCertUnMapHistorys.add(tblCertUnMapHistory);
                      }
	                if (encCertiId != null && !encCertiId.isEmpty()) {
                        TblCertUnMapHistory tblCertUnMapHistory = new TblCertUnMapHistory();
                        tblCertUnMapHistory.setRemark(remark);
                        tblCertUnMapHistory.setCreatedBy(createdBy);
                        tblCertUnMapHistory.setTblUserLogin(new TblUserLogin(Integer.parseInt(bidderId)));
                        tblCertUnMapHistory.setTblClient(new TblClient(clientBean.getClientId()));
                        tblCertUnMapHistory.setIsMapped(0);
                        TblUserCertificate tblUserCertificate = new TblUserCertificate();

                        tblCertUnMapHistory.setTblCertificate(new TblCertificate(Integer.parseInt(encryCertId)));
                        tblCertUnMapHistory.setKeyUsage(Integer.parseInt(encryKeyUsage));
                        tblCertUnMapHistory.setIsDualCert(Integer.parseInt(encryIsDual));
                        tblUserCertificate.setUserCertId(Integer.parseInt(encryUserCertId));

                        tblUserCertificates.add(tblUserCertificate);
                        tblCertUnMapHistorys.add(tblCertUnMapHistory);
                    }
//        		}else if(rowSize.equals("3")){
//            		for(int i=0;i<userCertIds.length;i++){
//            			TblCertUnMapHistory tblCertUnMapHistory = new TblCertUnMapHistory();
//	                	tblCertUnMapHistory.setRemark(remark);
//	                	tblCertUnMapHistory.setCreatedBy(createdBy);
//	                	tblCertUnMapHistory.setTblUserLogin(new TblUserLogin(Integer.parseInt(bidderId)));
//                        tblCertUnMapHistory.setTblClient(new TblClient(clientBean.getClientId()));
//                        tblCertUnMapHistory.setIsMapped(0);
//            			TblUserCertificate tblUserCertificate = new TblUserCertificate();
//            			if(userCertIds[i] !=null && !userCertIds[i].contains(",")){
//            				tblCertUnMapHistory.setTblCertificate(new TblCertificate(Integer.parseInt(request.getParameter("hdCertId_"+i))));
//            				//System.out.println("User Cert Id ::::"+Integer.parseInt(userCertIds[i]));
//            				tblUserCertificate.setUserCertId(Integer.parseInt(userCertIds[i]));
//            				tblCertUnMapHistory.setKeyUsage(Integer.parseInt(request.getParameter("hdKeyUsage_"+i)));
//            				tblCertUnMapHistory.setIsDualCert(Integer.parseInt(request.getParameter("hdIsDual_"+i)));
//            				tblUserCertificates.add(tblUserCertificate);
//            				tblCertUnMapHistorys.add(tblCertUnMapHistory);
//            			}else if(userCertIds[i] !=null && userCertIds[i].contains(",")){
//            				tblUserCertificate.setUserCertId(Integer.parseInt(userCertIds[i].split(",")[0]));
//            				tblCertUnMapHistory.setTblCertificate(new TblCertificate(Integer.parseInt(request.getParameter("hdCertId_"+i))));
//            				tblCertUnMapHistory.setIsDualCert(Integer.parseInt(request.getParameter("hdIsDual_"+i)));
//            				tblCertUnMapHistory.setKeyUsage(Integer.parseInt(request.getParameter("hdKeyUsage_"+i)));
//            				tblCertUnMapHistorys.add(tblCertUnMapHistory);
//            				tblUserCertificates.add(tblUserCertificate);
//            				
//            				tblCertUnMapHistory = new TblCertUnMapHistory();
//    	                	tblCertUnMapHistory.setRemark(remark);
//    	                	tblCertUnMapHistory.setCreatedBy(createdBy);
//    	                	tblCertUnMapHistory.setTblUserLogin(new TblUserLogin(Integer.parseInt(bidderId)));
//                            tblCertUnMapHistory.setTblClient(new TblClient(clientBean.getClientId()));
//                            tblCertUnMapHistory.setIsMapped(0);
//                            tblCertUnMapHistory.setTblCertificate(new TblCertificate(Integer.parseInt(request.getParameter("hdCertId_"+(i+1)))));
//                            tblCertUnMapHistory.setKeyUsage(Integer.parseInt(request.getParameter("hdKeyUsage_"+(i+1))));
//            				tblCertUnMapHistory.setIsDualCert(Integer.parseInt(request.getParameter("hdIsDual_"+(i+1))));
//            				tblCertUnMapHistorys.add(tblCertUnMapHistory);
//            				//System.out.println("User Cert Id ::::"+Integer.parseInt(userCertIds[i].split(",")[0]));
//            				
//            				tblUserCertificate = new TblUserCertificate();
//            				tblUserCertificate.setUserCertId(Integer.parseInt(userCertIds[i].split(",")[1]));
//                                        certIds.append(tblUserCertificate.getUserCertId()).append(",");
//            				//System.out.println("User Cert Id ::::"+Integer.parseInt(userCertIds[i].split(",")[1]));
//            				tblUserCertificates.add(tblUserCertificate);
//            			}
//            		}
            	success = manageBidderService.addCertUnMapHistory(tblCertUnMapHistorys,tblUserCertificates);
        	}
        	if(success){
                        //wSCheckAvailService.updateCertificateStatus(commonService.getSerialNo(certIds.substring(0, certIds.length()-1).toString())); 
        		Map<String,Object> mailParams=new HashMap<String, Object>();
        		mailParams.put("SubDomainName", clientService.getClientNameById(clientBean.getClientId()));
        		List<Object> data=loginService.getLoginIdByUserId(Integer.parseInt(bidderId));
        		mailParams.put("EmailID", !data.isEmpty() ? data.get(0) : "");
        		mailParams.put("ClientName", clientService.getClientNameByClientId(clientBean.getClientId()));
        		List<Object[]> maildata=commonService.getCompanyDetailsByUserId(Integer.parseInt(bidderId),clientBean.getClientId());
        		data=commonService.getAllClientByUserId(Integer.parseInt(bidderId));
        		mailParams.put("portalname", abcUtility.converObjectArrayToCommas(data));
        		mailParams.put("bcc", "info@abcprocure.com");
        		mailParams.put("companyName", maildata.get(0)[0]);
        		mailParams.put("mobileno", maildata.get(0)[2]);
        		mailParams.put("landlineno", maildata.get(0)[1]);
        		maildata.clear();
        		if ( signCertiId != null  &&  !signCertiId.isEmpty()) {
        			maildata.clear();maildata=commonService.getCertiDetailsByCertId(Integer.parseInt(signingCertId));
        			mailParams.put("signCertLbl", "Signing Certificate Validity Detail :");
        			mailParams.put("certSignStartDateLbl","Start Date   :   "+dateUtils.convertStringtoDate(dateUtils.convertStringtoDate(maildata.get(0)[0].toString(),"yyyy-MM-dd HH:mm:ss.SS"),"MMM dd yyyy h:mm a"));
            		mailParams.put("certSignEndDateLbl",  "End Date     :   "+dateUtils.convertStringtoDate(dateUtils.convertStringtoDate(maildata.get(0)[1].toString(),"yyyy-MM-dd HH:mm:ss.SS"),"MMM dd yyyy h:mm a"));
        		}else{
        			mailParams.put("signCertLbl","");
        			mailParams.put("certSignStartDateLbl", "");
            		mailParams.put("certSignEndDateLbl", "");
        		}
        		if(encCertiId != null && !encCertiId.isEmpty()){
        			maildata.clear();maildata=commonService.getCertiDetailsByCertId(Integer.parseInt(encryCertId));
        			mailParams.put("encCertLbl", "Encryption Certificate Validity Detail :");
        			mailParams.put("certEncStartDateLbl","Start Date   :   "+dateUtils.convertStringtoDate(dateUtils.convertStringtoDate(maildata.get(0)[0].toString(),"yyyy-MM-dd HH:mm:ss.SS"),"MMM dd yyyy h:mm a"));
            		mailParams.put("certEncEndDateLbl",  "End Date     :   "+dateUtils.convertStringtoDate(dateUtils.convertStringtoDate(maildata.get(0)[1].toString(),"yyyy-MM-dd HH:mm:ss.SS"),"MMM dd yyyy h:mm a"));
        		}else{
        			mailParams.put("encCertLbl", "");
        			mailParams.put("certEncStartDateLbl", "");
            		mailParams.put("certEncEndDateLbl", "");
        		}
        		mailContentUtillity.dynamicMailGeneration("10", bidderId, String.valueOf(clientBean.getClientId()), mailParams, "");
        		retVal = "common/admin/managebidder";
        	}else{
        		retVal = "common/admin/unmapdc/"+bidderId;
        	}
        }
        catch(Exception ex){
        	retVal = "common/admin/unmapdc/"+bidderId;
        	exceptionHandlerService.writeLog(ex);
        }
        finally{
        	if(clientBean.getIsPkiEnabled()==1){
        		String signText=request.getParameter("skpSignText");
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), unMapDCLinkId, auditUnMapDcWithSign , 0,bidderId!=null && !bidderId.equals("")? Integer.parseInt(bidderId):0,remark,signText);
        	}else{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), unMapDCLinkId, auditUnMapDcWithSign , 0,bidderId!=null && !bidderId.equals("")? Integer.parseInt(bidderId):0,remark);
        	}
        }
        redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "reiderct_success_unmap_certificate" : CommonKeywords.ERROR_MSG_KEY.toString());
        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }
    
    /**
     * to blacklist bidder
     * @param request
     * @param session
     * @param redirectAttributes
     * @return String
     */
    @RequestMapping(value = "/admin/submitblacklistbidder", method = RequestMethod.POST)                       
    public String blacklistBidder(HttpServletRequest request, HttpSession session,RedirectAttributes redirectAttributes){
        String retVal=null;
        int userId=0;
        int type=0;
        TblUserBlackList tblUserBlackList=null;
        TblUserHistory tblUserHistory=null;
        String startDate=null;
        String endDate=null;
        boolean success=false;
        String remarks=null;
        String emailId=null;
        String userName=null;
        int blackListId=0;
        int bidderId=0;
        try{
        	int clientId=abcUtility.getSessionClientId(request);
        	tblUserBlackList=new TblUserBlackList();
        	tblUserHistory=new TblUserHistory();
        	type=StringUtils.hasLength(request.getParameter("selBlacklistType")) ? Integer.parseInt(request.getParameter("selBlacklistType")) : 0;
        	userId=StringUtils.hasLength(request.getParameter("hdUserId")) ? Integer.parseInt(request.getParameter("hdUserId")) : 0;
        	startDate=StringUtils.hasLength(request.getParameter("txtBlackListStartDate")) ? request.getParameter("txtBlackListStartDate") : null;
        	endDate=StringUtils.hasLength(request.getParameter("txtBlackListEndDate")) ? request.getParameter("txtBlackListEndDate") : null;
        	remarks=StringUtils.hasLength(request.getParameter("txtaRemarks")) ? request.getParameter("txtaRemarks") : null;
        	emailId=StringUtils.hasLength(request.getParameter("hdLoginId")) ? request.getParameter("hdLoginId") : null;
        	userName=StringUtils.hasLength(request.getParameter("hdUserName")) ? request.getParameter("hdUserName") : null;
        	blackListId=StringUtils.hasLength(request.getParameter("hdBlacklistId")) ? Integer.parseInt(request.getParameter("hdBlacklistId")) : 0;
        	bidderId=StringUtils.hasLength(request.getParameter("hdBidderId")) ? Integer.parseInt(request.getParameter("hdBidderId")) : 0;
        	//System.out.println("blackListId Id :::"+request.getParameter("hdBlacklistId"));
        	if(type==1 && (startDate == null || endDate == null)){
        		retVal="redirect:/common/admin/blacklistbidder/"+userId + encryptDecryptUtils.generateRedirect("common/admin/blacklistbidder/"+userId, request);
        		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
        	}else{
        		tblUserHistory.setActionType(Integer.parseInt(userHistBlacklistStatus));
	        	tblUserHistory.setTblUserLogin(new TblUserLogin(userId));
	        	tblUserHistory.setTblClient(new TblClient(clientId));
	        	tblUserHistory.setCreatedBy(abcUtility.getSessionUserId(request));
	        	
	        	if(blackListId != 0){
	        		tblUserBlackList.setUserBlackListId(blackListId);
	        	}
	        	tblUserBlackList.setType(type);
	        	tblUserBlackList.setCstatus(1);
	        	tblUserBlackList.setRemarks(remarks);
	        	tblUserBlackList.setCreatedBy(abcUtility.getSessionUserId(request));
	        	tblUserBlackList.setTblBidderStatus(new TblBidderStatus(bidderId));
	        	if(type==1){
	        		//tblUserBlackList.setStartDate(dateUtils.convertStringtoDate(startDate.replaceAll("/", "-"),"dd-MM-yyyy"));
	        		//tblUserBlackList.setEndDate(dateUtils.convertStringtoDate(endDate.replaceAll("/", "-"),"dd-MM-yyyy"));
	        		tblUserBlackList.setStartDate(CommonUtility.getDateObj(startDate));
	        		tblUserBlackList.setEndDate(CommonUtility.getDateObj(endDate));
	        	}else{
	        		tblUserBlackList.setStartDate(commonService.getServerDateTime());
	        		tblUserBlackList.setEndDate(commonService.getServerDateTime());
	        	}
	        	success=manageBidderService.updateUserStatus(tblUserBlackList, tblUserHistory,clientId);
	        	
	        	
	        	if(success){
	        		String txtHidDocIds = CommonUtility.checkNull(request.getParameter("txtHidDocIds"));
	        		
	        		if (!"".equalsIgnoreCase(txtHidDocIds)) {
	        			success = fileUploadService.updateOfficerDocsObjectId(txtHidDocIds, userId);
	        			fileUploadService.approvePendingOfficerDoc(userId, bidderBlacklistLinkId);
                    }
	        		URL url = new URL(request.getRequestURL().toString());
	        		retVal="redirect:/common/admin/managebidder"+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
	        		redirectAttributes.addFlashAttribute("successMsgBdrBlk", "redirect_success_blacklistbidder");
	        		redirectAttributes.addFlashAttribute("argmnts", userName);
	        		Map<String,Object> dataMap=new HashMap<String, Object>();
	        		dataMap.put("subdomainname", url.getHost());
	        		dataMap.put("to", emailId);
	        		if(type == 1){
		        		dataMap.put("BlacklistingStartDate", startDate);
		        		dataMap.put("BlacklistingEndDate", endDate);
		        		dataMap.put("BlacklistingReason", remarks);
		        		dataMap.put("SubDomainName", clientService.getClientNameById(clientId));
		        		dataMap.put("ClientName", clientService.getClientNameByClientId(clientId));
	        			mailContentUtillity.dynamicMailGeneration("9", String.valueOf(userId), String.valueOf(clientId),dataMap ,"");
	        		}else if(type==2){
	        			mailContentUtillity.dynamicMailGeneration("16", String.valueOf(userId), String.valueOf(clientId),dataMap ,"");
	        		}
	        	}else{
	        		retVal="redirect:/common/admin/blacklistbidder/"+userId+"/"+bidderId + encryptDecryptUtils.generateRedirect("common/admin/blacklistbidder/"+userId+"/"+bidderId, request);
	        		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
	        	}
        	}
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }finally {
        	int linkId=0;
        	String msg=null;
        	if(blackListId == 0){
        		linkId=bidderBlacklistLinkId;
        		msg=success ? auditBlackListed : auditBlackListFailed ;
        	}else{
        		linkId=bidderBlacklistEditLinkId;
        		msg=success ? auditBlackListEdited : auditBlackListEditFailed;
        	}
        	if(remarks != null){
        		if(abcUtility.getSessionIsPkiEnabled(request)==1){
        			String signText=request.getParameter("skpSignText");
        			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, 0,tblUserBlackList.getUserBlackListId(),remarks,signText);
        		}else{
        			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, 0,tblUserBlackList.getUserBlackListId(),remarks);
        		}
        	}else{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, 0,tblUserBlackList.getUserBlackListId());
        	}
        }
        return retVal;
    }
    
    /**
     * to remove bidder from the blacklist
     * @param userId
     * @param request
     * @param session
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "/admin/removeblacklistbidderdetails/{userId}/{bidderId}/{enc}", method = RequestMethod.GET)                       
    public String removeBlacklistedBidderDetails(@PathVariable("userId") int userId,@PathVariable("bidderId") int bidderId,HttpServletRequest request, RedirectAttributes redirectAttributes){
        String retVal=null;
        TblUserHistory tblUserHistory=null;
        boolean success=false;
        String emailId=null;
        try{
        	int clientId=abcUtility.getSessionClientId(request);
        	int sessionUserId=abcUtility.getSessionUserId(request);
        	tblUserHistory=new TblUserHistory();
        	tblUserHistory.setActionType(Integer.parseInt(bidderStatusRemovedFromBlacklist));
        	tblUserHistory.setTblUserLogin(new TblUserLogin(userId));
        	tblUserHistory.setTblClient(new TblClient(clientId));
        	tblUserHistory.setCreatedBy(sessionUserId);
        	success=manageBidderService.unBlacklistBidder(Integer.parseInt(bidderStatusApprove), bidderId, sessionUserId, tblUserHistory,"UB",clientId);
        	if(success){
        		retVal="redirect:/common/admin/managebidder"+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
        		redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_unblacklist");
        		URL url = new URL(request.getRequestURL().toString());
        		List<Object> data=loginService.getLoginIdByUserId(userId);
        		if(data != null && !data.isEmpty()){
        			emailId= (String)data.get(0);
        		}
        		Map<String,Object> dataMap=new HashMap<String, Object>();
        		dataMap.put("ClientName", clientService.getClientNameByClientId(clientId));
        		dataMap.put("SubDomainName", clientService.getClientNameById(clientId));
        		//Added By Lipi - For MessageBox
        		dataMap.put("to", emailId);
        		String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/tenderlisting/0/");
            	String herfStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
            	dataMap.put("link", herfStr);
        		mailContentUtillity.dynamicMailGeneration("21", String.valueOf(userId), String.valueOf(clientId),dataMap ,"");
        	}else{
        		retVal="redirect:/common/admin/managebidder" + encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
        		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
        	}
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }finally {
        	/*if(remarks != null){
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, "UnBlacklist bidder", 0,tblUserBlackList.getUserBlackListId(),remarks);
        	}else{*/
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidderRemoveFromBlacklistLinkId, auditRemoveBlackList, 0,bidderId);
        	//}
        }
        return retVal;
    }
    
    /**
     * to approve and renew bidder registration 
     * @param request
     * @param session
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "/admin/submitapprovebidder", method = RequestMethod.POST)                       
    public String submitApproveBidder(HttpServletRequest request, HttpSession session,RedirectAttributes redirectAttributes){
        String retVal=null;
        int userId=0;
        int status=0;
        boolean isSecondStageApproval = false;
        TblUserHistory tblUserHistory=null;
        String endDate=null;
        boolean success=false;
        String emailId=null;
        String refdate=null;
        String remarks=null;
        int validUpto=0;
        int oprType=0;
        String clientIds=null;
        try{
        	int clientId=abcUtility.getSessionClientId(request);
        	int sessionUserId=abcUtility.getSessionUserId(request);
        	TblPayment tblPayment=null;
        	TblOfflinePayment tblOfflinePayment=null;
        	TblBidderStatus tblBidderStatus=null;
        	/*String isPaymentReq=request.getParameter("isPaymentReq");
        	String regChargesApplClient=request.getParameter("txtRegChargesApplClient");*/
        	userId=StringUtils.hasLength(request.getParameter("hdUserId")) ? Integer.parseInt(request.getParameter("hdUserId")) : 0;
        	status=StringUtils.hasLength(request.getParameter("selAction")) ? Integer.parseInt(request.getParameter("selAction")) : 0;
        	remarks=StringUtils.hasLength(request.getParameter("txtaRemarks")) ? request.getParameter("txtaRemarks") : null;
        	oprType=StringUtils.hasLength(request.getParameter("hdOprType")) ? Integer.parseInt(request.getParameter("hdOprType")) : 0;
        	String paymentAplicable=StringUtils.hasLength(request.getParameter("txtPaymentApp")) ? request.getParameter("txtPaymentApp") : "";
        	int companyId=Integer.parseInt(commonService.getCompanyIdByUserId(userId).toString());
        	
        	int chkSigningVerified = StringUtils.hasLength(request.getParameter("chksigningVerified")) ? Integer.parseInt(request.getParameter("chksigningVerified")) : 0;
        	int chkEncryptionVerified = StringUtils.hasLength(request.getParameter("chkencryptionVerified")) ? Integer.parseInt(request.getParameter("chkencryptionVerified")) : 0;
        	
        	if(oprType == 3 || oprType == 4)
        	{
        		isSecondStageApproval = true;
        		List<TblBidderStatus> listBidderStatus = new ArrayList();
        		tblBidderStatus = manageBidderService.getBidderObjectByUserIdAndClientId(userId, clientId);
        		if(tblBidderStatus !=null)
        		{
            		if(tblBidderStatus.getTwoStageStatus()!=0)
            		{
            			if(tblBidderStatus.getTwoStageStatus() == 1)
            			{
                 			redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_already_approve_secondstagebidder");
            			}
            			else
            			{
                 			redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_already_reject_secondstagebidder");
            			}
            			
            			retVal="redirect:/common/admin/managetwostagereg"+ encryptDecryptUtils.generateRedirect("common/admin/managetwostagereg", request);
            		}
            		else
            		{
                		if(status == 7)
                		{
                			tblBidderStatus.setTwoStageStatus(2);
                			tblBidderStatus.setCstatus(7);
                		}
                		else if(status == 1)
                		{
                			tblBidderStatus.setTwoStageStatus(1);
                		}
                		
                		tblBidderStatus.setApprovedOn(new Date());
                		tblBidderStatus.setApprovedBy(sessionUserId);
                		tblBidderStatus.setRemarks(remarks);
                		tblBidderStatus.setUpdatedBy(sessionUserId);
                		tblBidderStatus.setUpdatedOn(new Date());
                		
                		listBidderStatus.add(tblBidderStatus);
                		boolean result = manageBidderService.saveOrUpdateBidderList(listBidderStatus);
                		
                		if(status == 1)
                		{
                			redirectAttributes.addFlashAttribute(result ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), result ? "msg_approve_secondstagebidder" : CommonKeywords.ERROR_MSG_KEY.toString());	
                		}
                		else if(status == 7)
                		{
                			redirectAttributes.addFlashAttribute(result ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), result ? "msg_reject_secondstagebidder" : CommonKeywords.ERROR_MSG_KEY.toString());
                		}
                			retVal="redirect:/common/admin/managetwostagereg"+ encryptDecryptUtils.generateRedirect("common/admin/managetwostagereg", request);
            		}
        		}
        		else
        		{
        			redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
        			retVal="redirect:/common/admin/managetwostagereg"+ encryptDecryptUtils.generateRedirect("common/admin/managetwostagereg", request);
        		}
        	}
        	else
        	{
            	if(/*(status==Integer.parseInt(bidderStatusApprove)) && */("Y".equalsIgnoreCase(paymentAplicable) && oprType == 2) || (oprType==1 && status!=7)){
    	        	refdate=StringUtils.hasLength(request.getParameter("txtPaymentDate")) ? request.getParameter("txtPaymentDate") : null;
    	        	String startDate=StringUtils.hasLength(request.getParameter("txtStartDate")) ? request.getParameter("txtStartDate") : null;
    	        	startDate+=" "+CommonUtility.getTimeZone().substring(1)+":00";
    	        	endDate=StringUtils.hasLength(request.getParameter("txtEndDate")) ? startDate != null ?request.getParameter("txtEndDate"):null : null;
    	        	endDate+=" "+CommonUtility.getTimeZone().substring(1)+":00";
    	        	validUpto=StringUtils.hasLength(request.getParameter("txtRegistrationValidity")) ? Integer.parseInt(request.getParameter("txtRegistrationValidity")) : 0;
    	        	clientIds=StringUtils.hasLength(request.getParameter("txtRegChargesApplClient")) ? request.getParameter("txtRegChargesApplClient").substring(0, request.getParameter("txtRegChargesApplClient").length()-1): "";
    	        	String bankName=StringUtils.hasLength(request.getParameter("txtBankName")) ? request.getParameter("txtBankName") : "";
    	        	Double amount=StringUtils.hasLength(request.getParameter("txtAmount")) ? Double.parseDouble(request.getParameter("txtAmount")) : 0;
    	        	int offlinePaymentApplicable=StringUtils.hasLength(request.getParameter("hdOfflinePaymentMode")) ? Integer.parseInt(request.getParameter("hdOfflinePaymentMode")) : 0;
    	        	/*boolean isRegApplicable=clientService.checkIsRegChargesApplicable(clientId);
    	        	TblPayment tblPaymentTemp = manageBidderService.getPaymentDetailByBidderId(userId, clientId);*/
    	        	if(oprType == 2 || offlinePaymentApplicable == 1){
    	        		tblPayment=new TblPayment();
    	        		tblOfflinePayment=new TblOfflinePayment();
    	        		tblPayment.setTblClient(new TblClient(clientId));
    	        		tblPayment.setTblCompany(new TblCompany(companyId));
    	        		tblPayment.setTblPaymentType(new TblPaymentType(request.getParameter("selPaymentMode") != null && !"".equalsIgnoreCase(request.getParameter("selPaymentMode")) ? Integer.parseInt(request.getParameter("selPaymentMode")) : 0));
    	        		tblPayment.setTblUserLogin(new TblUserLogin(userId));
    	        		tblPayment.setTblLink(new TblLink(oprType == 2 ? renewRegistrationLinkId : bidderAproveLinkId));//need t ochange from static one
    	        		tblPayment.setAmount(new BigDecimal(amount));
    	        		tblPayment.setExemptionAmt(new BigDecimal(0));
    	        		tblPayment.setObjectId(0);
    	        		tblPayment.setClientIds(clientIds);
    	        		tblPayment.setCreatedBy(sessionUserId);
    	        		tblPayment.setRemark(remarks);
    	        		tblPayment.setPaymentFor(3);
    	        		tblPayment.setCstatus(1);
    	        		tblPayment.setTblDepartment(new TblDepartment(Integer.parseInt(clientService.getClientField(clientId, "deptId").toString())));				
    					tblPayment.setTblModule(new TblModule(commonService.getModuleIdbyLinkId(oprType == 2 ? renewRegistrationLinkId : bidderAproveLinkId)));
    	        		tblOfflinePayment.setReferenceNo(request.getParameter("txtPaymentReferenceNo") !=null && !"".equals(request.getParameter("txtPaymentReferenceNo")) ? request.getParameter("txtPaymentReferenceNo") : "");
    	        		tblOfflinePayment.setReferenceDate(conversionService.convert(refdate,Date.class));
    	        		tblOfflinePayment.setBankName(bankName);
    	        	}
    	        	List<Object[]> cList = (manageContentService.getClientRegTerms(clientId, 8, Integer.parseInt(WebUtils.getCookie(request, "locale").getValue())));
    	        	int contentManagementId  = Integer.parseInt(cList != null && !cList.isEmpty()?cList.get(0)[1].toString():"0");
    	        	String clientArr[]=request.getParameterValues("chkMultipleDomain");
    	        	if(clientArr == null ){
    	        		clientArr=new String[1];
    	        		clientArr[0]=String.valueOf(abcUtility.getSessionClientId(request))+"~~"+contentManagementId;
    	        		//clientArr=clientIds.split(",");
    	        	}else if(!Arrays.asList(clientArr).contains(String.valueOf(clientId))){
    	        		String[] result = Arrays.copyOf(clientArr, clientArr.length +1);
    	        	    result[clientArr.length] = String.valueOf(clientId)+"~~"+contentManagementId;
    	        	    clientArr=result;
    	        	}
    	        	StringBuilder tempClients= new StringBuilder();
    	        	Map<Integer, Integer> contentMap = new HashMap<Integer, Integer>();
    	        	int clientIdS [] = new int[clientArr.length];
    	        	for(int i=0;i<clientArr.length;i++){
    	        		clientIdS[i] = Integer.parseInt(clientArr[i].split("~~")[0]);
    	        		tempClients.append(clientArr[i].split("~~")[0]).append(",");
    	        		contentMap.put(Integer.parseInt(clientArr[i].split("~~")[0]), Integer.parseInt(clientArr[i].split("~~")[1]));
    	        	}
    	        	Arrays.sort(clientIdS);
    	        	List<TblBidderStatus> bidderStatusList=new ArrayList<TblBidderStatus>();
    	        	List<TblUserHistory> userHistoryList=new ArrayList<TblUserHistory>();
    	        	List<Object[]> bidderIdList=manageBidderService.getBidderdByUserIdAndClientId(userId,tempClients.substring(0,tempClients.length()-1));
    	        	List<Object> clientRegWorkFlow=manageBidderService.getClientRegWorkFlow(tempClients.substring(0,tempClients.length()-1));
    	        	for(int i=0;i<clientIdS.length;i++){
    	        		tblBidderStatus = tblBidderStatusDao.findTblBidderStatus("tblClient.clientId", Operation_enum.EQ, clientId,"tblUserLogin.userId", Operation_enum.EQ, userId).get(0);
    	        		//int bidderId=manageBidderService.getBidderdByUserIdAndClientId(userId,Integer.parseInt(clientArr[i]));
    	        		if(bidderIdList!= null && !bidderIdList.isEmpty() && clientIdS[i]==Integer.parseInt(bidderIdList.get(0)[1].toString())){
    	        			tblBidderStatus.setBidderId(Integer.parseInt(bidderIdList.get(0)[0].toString()));
    	        			tblBidderStatus.setCstatus(Integer.parseInt(bidderStatusApprove));
    	        			tblBidderStatus.setTblRegistrationWorkflow(new TblRegistrationWorkflow(9));
    	        			tblBidderStatus.setTblClient(new TblClient(Integer.parseInt(bidderIdList.get(0)[1].toString())));
    	        		    tblBidderStatus.setIsAdminBidder(Integer.parseInt(bidderIdList.get(0)[2].toString()));
    	        	        tblBidderStatus.setIsParentBidderId(Integer.parseInt(bidderIdList.get(0)[3].toString()));
    	        		}else{
    	        			tblBidderStatus.setCstatus(cstatusApproveIncomplete);
    	        			tblBidderStatus.setTblRegistrationWorkflow(new TblRegistrationWorkflow(Integer.parseInt(clientRegWorkFlow.get(i).toString())));
    	        			tblBidderStatus.setTblClient(new TblClient(clientIdS[i]));
    	        			
    	        		}
    	        		/*tblBidderStatus.setTblClient(new TblClient(clientIdS[i]));*/
    	            	tblBidderStatus.setTblUserLogin(new TblUserLogin(userId));
    	            	tblBidderStatus.setTblCompany(new TblCompany(companyId));
    	            	tblBidderStatus.setUpdatedOn(new Date());
    	            	tblBidderStatus.setUpdatedBy(sessionUserId);
    	            	//UI Change #12251 - Aditya
    	            	//Start
//    	            	tblBidderStatus.setStartDate(startDate != null && !"".equals(startDate) ?  conversionService.convert(startDate,Date.class) :null);
//    	            	tblBidderStatus.setEndDate(endDate != null && !"".equals(endDate) ?  conversionService.convert(endDate,Date.class) :null);
//    	            	tblBidderStatus.setValidityUpto(validUpto);
    	            	tblBidderStatus.setStartDate(null);
    	            	tblBidderStatus.setEndDate(null);
    	            	tblBidderStatus.setValidityUpto(0);
    	            	//End
    	            	tblBidderStatus.setContentManagemenId(contentMap.get(clientIdS[i]) != null && !contentMap.isEmpty() ?contentMap.get(clientIdS[i]):0);
    	            	tblBidderStatus.setApprovedBy(sessionUserId);
    	            	tblBidderStatus.setApprovedOn(new Date());
    	            	tblBidderStatus.setTwoStageStatus(0);
    	            	tblBidderStatus.setRemarks(remarks);
    	            	bidderStatusList.add(tblBidderStatus);
    	            	
    	            	tblUserHistory=new TblUserHistory();
    	            	if(oprType == 2){
    	            		tblUserHistory.setActionType(Integer.parseInt(userHistRenew));
    	            	}else{
    	            		tblUserHistory.setActionType(Integer.parseInt(userHistApprove));
    	            	}
    		        	tblUserHistory.setTblUserLogin(new TblUserLogin(userId));
    		        	tblUserHistory.setTblClient(new TblClient(clientIdS[i]));
    		        	tblUserHistory.setCreatedBy(sessionUserId);
    		        	userHistoryList.add(tblUserHistory);
    	        	}
    	        	success=manageBidderService.approveBidder(tblPayment, tblOfflinePayment, bidderStatusList, userHistoryList);
    	        	if(success){
    	        		if(chkSigningVerified == 1){
    	        			loginService.verifyDC(userId, 1, sessionUserId);
    	        		}if(chkEncryptionVerified == 1){
    	        			loginService.verifyDC(userId, 2, sessionUserId);
    	        		}
    	        	}
    	        	
    	        	List<TblBidderStatus> objbs = tblBidderStatusDao.findTblBidderStatus("tblRegistrationWorkflow.registrationWorkflowId", Operation_enum.EQ, 9,"cstatus", Operation_enum.EQ, 0,"isParentBidderId", Operation_enum.EQ, userId);
    	        	ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
    	        	if(objbs!= null && !objbs.isEmpty()) {
    	        		for(TblBidderStatus bs : objbs) {
    	        			
    	        			//Start: Code for approving Sub user 
    	        			bs.setCstatus(1);
    	        			tblBidderStatusDao.updateTblBidderStatus(bs);
    	        			Map<String,Object> dataMap=new HashMap<String, Object>();
//                          dataMap.put("subdomainname", url.getHost());
    	        			dataMap.put("to", bs.getTblUserLogin().getLoginId());
    	        			dataMap.put("emailId", bs.getTblUserLogin().getLoginId());
    	        			dataMap.put("ClientName", clientService.getClientNameByClientId(clientBean.getClientId()));
    	        			dataMap.put("SubDomainName", clientService.getClientNameById(clientBean.getClientId()));
    	        			dataMap.put(emailId, bs.getTblUserLogin().getLoginId());
//    	        			String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/tenderlisting/0/");
//    	        			String herfStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
//    	        			dataMap.put("link", herfStr);
    	        			mailContentUtillity.dynamicMailGeneration("22", String.valueOf(bs.getTblUserLogin().getUserId()) , String.valueOf(clientBean.getClientId()),dataMap ,"");
    	        			//End: Code for approving Sub user
    	        			
    	        			//Start: Code for approving Sub user's certificate
    	        			loginService.verifyDC(bs.getTblUserLogin().getUserId(), 1, sessionUserId);
    	        			loginService.verifyDC(bs.getTblUserLogin().getUserId(), 2, sessionUserId);
    	        			//End: Code for approving Sub user's certificate
    	        		}    	        		
    	        	}
    	        	
    	        	if(success){
    	        		success = dynamicFieldService.addDynamicFieldValueProcess(dynamicFieldService.dynFieldSetUp(request.getParameterMap(), request),clientId,manageBidderFieldValueId,userId,userId);
    	        	}
    	        	if(success){
    	        		retVal="redirect:/common/admin/managebidder"+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
    	        		redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), oprType == 2 ? "redirect_success_renew" : "redirect_success_aproved");
    		        	URL url = new URL(request.getRequestURL().toString());
    	        		List<Object> data=loginService.getLoginIdByUserId(userId);
    	        		if(data != null && !data.isEmpty()){
    	        			emailId= (String)data.get(0);
    	        		}
    	        		Map<String,Object> dataMap=new HashMap<String, Object>();
    	        		dataMap.put("ClientName", clientService.getClientNameByClientId(clientId));
    	        		dataMap.put("subdomainname", url.getHost());
    	        		dataMap.put("to", emailId);
    	        		dataMap.put("emailId", emailId);
    	        		if(oprType == 2){
    	        			dataMap.put("SubDomainName", url.getHost());
    	        			dataMap.put("enddate", endDate);
    	        			dataMap.put("EndDate", endDate);
    	        			dataMap.put("cc", "info@abcprocure.com"+","+ loginService.getLoginIdByUserId(sessionUserId).get(0).toString());
    	        			mailContentUtillity.dynamicMailGeneration("130", String.valueOf(userId), String.valueOf(clientId),dataMap ,"");
    	        		}else{
    	        			dataMap.put("ClientName", clientService.getClientNameByClientId(clientId));
    	        			dataMap.put("SubDomainName", clientService.getClientNameById(clientId));
    	        			dataMap.put(emailId, emailId);
    	        			//Added By Lipi - For MessageBox
    	        			String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/tenderlisting/0/");
    	                	String herfStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
    	                	dataMap.put("link", herfStr);
    	                	if(CommonUtility.isClientConditionExistInProperty(gslClientIds, clientId)){ //for GSL client, sent mail to bidder for complete registration process as step-1
    	                		mailContentUtillity.dynamicMailGeneration("242", String.valueOf(userId), String.valueOf(clientId),dataMap ,"");
    	                	}else{
    	                		mailContentUtillity.dynamicMailGeneration("22", String.valueOf(userId), String.valueOf(clientId),dataMap ,"");
    	                	}
    	        		}
    	        	}else{
    	        		retVal="redirect:/common/admin/approvebidder/"+userId+"/"+oprType+ encryptDecryptUtils.generateRedirect("common/admin/approvebidder/"+userId+"/"+oprType, request);
    	        		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
    	        	}
            	}else/* if(status==Integer.parseInt(bidderStatusRejected))*/{
            		
               		List<TblBidderStatus> listBidderStatus = new ArrayList();
            		tblBidderStatus = manageBidderService.getBidderObjectByUserIdAndClientId(userId, clientId);
            		if(tblBidderStatus !=null)
            		{
                		tblBidderStatus.setApprovedOn(new Date());
                		tblBidderStatus.setApprovedBy(sessionUserId);
                		tblBidderStatus.setRemarks(remarks);
                		tblBidderStatus.setUpdatedBy(sessionUserId);
                		tblBidderStatus.setUpdatedOn(new Date());
                		listBidderStatus.add(tblBidderStatus);
                		success = manageBidderService.saveOrUpdateBidderList(listBidderStatus);
            		}
        
            		tblUserHistory=new TblUserHistory();
    	        	tblUserHistory.setActionType(Integer.parseInt(status == 1 ? userHistApprove: userHistReject));
    	        	tblUserHistory.setTblUserLogin(new TblUserLogin(userId));
    	        	tblUserHistory.setTblClient(new TblClient(clientId));
    	        	tblUserHistory.setCreatedBy(sessionUserId);
            		success=manageBidderService.unBlacklistAllBidder(status, userId, sessionUserId, tblUserHistory,null,clientId,companyId);
            		if(success){
    	        		if(chkSigningVerified == 1){
    	        			loginService.verifyDC(userId, 1, sessionUserId);
    	        		}else if(chkEncryptionVerified == 1){
    	        			loginService.verifyDC(userId, 2, sessionUserId);
    	        		}
    	        	}
            		if(success){
    	        		retVal="redirect:/common/admin/managebidder"+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
    	        		redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), status == 1 ? "redirect_success_aproved" : "redirect_success_rejected");
    		        	URL url = new URL(request.getRequestURL().toString());
    	        		List<Object> data=loginService.getLoginIdByUserId(userId);
    	        		if(data != null && !data.isEmpty()){
    	        			emailId= (String)data.get(0);
    	        		}
    	        		Map<String,Object> dataMap=new HashMap<String, Object>();
    	        		dataMap.put("subdomainname", url.getHost());
    	        		dataMap.put("to", emailId);
    	        		if(status == 1){
    	        			dataMap.put("ClientName", clientService.getClientNameByClientId(clientId));
    	        			dataMap.put("SubDomainName", clientService.getClientNameById(clientId));
    	        			//Added By Lipi - For MessageBox
    	        			String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/tenderlisting/0/");
    	                	String herfStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
    	                	dataMap.put("link", herfStr);
    	        			mailContentUtillity.dynamicMailGeneration("22", String.valueOf(userId), String.valueOf(clientId),dataMap ,"");
    	        		}else{
    	        			dataMap.put("ReasonOfRejection", remarks);
    	        			dataMap.put("ClientName", clientService.getClientNameByClientId(clientId));
    	        			mailContentUtillity.dynamicMailGeneration("23", String.valueOf(userId), String.valueOf(clientId),dataMap ,"");
    	        		}
    	        	}else{
    	        		retVal="redirect:/common/admin/approvebidder/"+userId+ encryptDecryptUtils.generateRedirect("common/admin/approvebidder/"+userId, request);
    	        		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
    	        	}
            	}       		
        	}
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }finally {
        	int linkId=0;
        	String msg=null;
        	if(oprType == 2){
        		linkId=renewRegistrationLinkId;
        		msg=auditRenewRegistration;
        	}else if(status == 1){
        		if(isSecondStageApproval)
        		{
        			linkId = report_manage_twostage_reg;	
        			msg=auditApprovedBidderSecondStage;
        		}
        		else
        		{
            		linkId=bidderAproveLinkId;
            		msg=auditApprovedBidder;
        		}
        	}
        	else{
        		
        		if(isSecondStageApproval)
        		{
        			linkId = report_manage_twostage_reg;
        			msg = auditRejectedBidderSecondStage;
        		}
        		else
        		{
	        		linkId=bidderAproveLinkId;
	        		msg=auditRejectedBidder;
        		}
        	}
        	if(remarks != null){
        		if(abcUtility.getSessionIsPkiEnabled(request)==1){
        			String signText=request.getParameter("skpSignText");
        			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, 0,userId,remarks,signText);
        		}else{
        			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, 0,userId,remarks);
        		}
        	}else{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, 0,userId);
        	}
        }
        return retVal;
    }
    
    /**
     * Ajax function to check is registration charges are applicable or not 
     * @param productName
     * @param categoryId
     * @param productId
     * @param session
     * @param request
     * @return
     */
    @RequestMapping(value = "/ajax/checkisregchargeapplicable", method = RequestMethod.POST)
    @ResponseBody
    public String checkIsRegChargeApplicable(@RequestParam("clientId") int clientId,@RequestParam("clientIds") String clientIds,HttpSession session, HttpServletRequest request) {
        String resultString = null;
        try {
        	if(clientIds != null && "Y".equalsIgnoreCase(clientIds)){
        		resultString = clientService.checkIsRegChargesApplicableForMultClient(clientIds);
        	}else{
	            boolean result = clientService.checkIsRegChargesApplicable(clientId);
	            resultString = result ? String.valueOf(clientId) : null;
        	}
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        //finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, auditCheckRegCharges, 0, clientId);
        //}
        return resultString;
    }
    
    @RequestMapping(value = "/admin/resendRegistrationMail/{userId}/{userTypeId}/{enc}", method = RequestMethod.GET)
    public String resendRegistrationMail(@PathVariable("userId") int userId, @PathVariable("userTypeId") int userTypeId, HttpSession session,
            HttpServletRequest request, RedirectAttributes redirectAttributes) {
        int clientId = 0;
        String pageView = null;
        try {
                clientId = abcUtility.getSessionClientId(request);
                int verificationBy = 0;
                int bidderRegistrationBy = 0;
                int officerId = departmentUserService.getOfficerId(userId, clientId);
                URL url = new URL(request.getRequestURL().toString());
                Map<String, Object> paramMap =  new HashMap<String, Object>();
                TblUserLogin tblUserLogin = loginService.getUserLoginById(userId);;
                String pass = UUID.randomUUID().toString().substring(0, 4)+"@"+UUID.randomUUID().toString().substring(0, 4);
                
                if(userTypeId == 2){
                    verificationBy = clientService.getBidderRegistrationVerifiedBy(clientId);
                    bidderRegistrationBy = clientService.getBidderRegistrationBy(clientId);
                    
                    paramMap.put("to", tblUserLogin.getLoginId());
                    paramMap.put("subdomainname", url.getHost());
                    paramMap.put("emailid", tblUserLogin.getLoginId());
                    paramMap.put("password", pass); 
                    
                    pageView = "redirect:/common/admin/managebidder"+encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
                }else{
                    verificationBy = clientService.getOfficerRegistrationVerifiedBy(clientId);
                    paramMap.put("subdomainname", url.getHost());
                    paramMap.put("to", tblUserLogin.getLoginId());
                    paramMap.put("loginId", tblUserLogin.getLoginId());
                    paramMap.put("password", pass);
                    
                    String encryptedPassword = sha256HashEncryption.encodeStringSHA256(pass);
                    String sha1encryptedPassword = sha1HashEncryption.encodeStringSHA1(pass);
                    int createdBy = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getUserId();
                    TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();
                    tblPasswordHistory.setTblUserLogin(new TblUserLogin(userId));
                    tblPasswordHistory.setCreatedBy(createdBy);
                    tblPasswordHistory.setOldPassword(tblUserLogin.getPassword());
                    tblPasswordHistory.setPasswordUpdatedFrom(passwordUpdatedFrom);//3
                    
                    TblUserHistory tblUserHistory = new TblUserHistory();
            		tblUserHistory.setActionType(actionTypeSendRegResetPassword);
            		tblUserHistory.setCreatedBy(createdBy);
            		tblUserHistory.setTblUserLogin(tblUserLogin);
            		tblUserHistory.setTblClient(new TblClient(clientId));
            		boolean isSuccess = false;
            		isSuccess = wSCheckAvailService.changePassword(tblUserLogin.getLoginId(), encryptedPassword+"~~"+sha1encryptedPassword,tblUserLogin.getUserId(),clientId);
            		if (WSCheckAvail.isSsoAvailable() && !isSuccess) {
            			//First dump user in sso from Local and then reset the pass
            			isSuccess = wSCheckAvailService.dumpUserWithChngPwd(userId,clientId,userTypeId,true,encryptedPassword,sha1encryptedPassword);
            		}
            		if(isSuccess){
            			isSuccess = departmentUserService.resetPassword(userId,encryptedPassword,tblPasswordHistory,tblUserHistory);
            			redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_resendregistration_dtls" : CommonKeywords.ERROR_MSG_KEY.toString());
            		}else if (WSCheckAvail.isSsoAvailable() && !isSuccess) {
            			redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
            		}else{
            			redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_reg_serv_not_avail");
            		}
                    pageView = "redirect:/common/admin/managedeptuser"+encryptDecryptUtils.generateRedirect("common/admin/managedeptuser", request);
                }
                switch (verificationBy) {
                    case 2:
                        if(userTypeId == 2){
                            if(bidderRegistrationBy == 1){
                                mailContentUtillity.dynamicMailGeneration("4", String.valueOf(userId), String.valueOf(clientId), null, "");
                            }else{
                                paramMap.put("link1", "<a href=\"/authbiddermail/"+encryptDecryptUtils.encrypt(tblUserLogin.getLoginId()+"@@"+userTypeId+"_"+0)+"\">Email Verification Link</a>");
                                mailContentUtillity.dynamicMailGeneration("19", String.valueOf(userId), String.valueOf(clientId), paramMap,"");

                            }
                        }else{
                            paramMap.put("link1", "<a href=\"/authbiddermail/"+encryptDecryptUtils.encrypt(tblUserLogin.getLoginId()+"@@"+userTypeId+"_"+officerId)+"\">Email Verification Link</a>");
                            mailContentUtillity.dynamicMailGeneration("6", String.valueOf(userId), String.valueOf(clientId),paramMap);
                        }
                        break;

                    case 1:
                        if(userTypeId == 2){
                            if(bidderRegistrationBy == 1){
                                mailContentUtillity.dynamicMailGeneration("1", String.valueOf(userId), String.valueOf(clientId), null, "");
                            }else{
                                paramMap.put("link1", "<a href=\"/authbiddermail/"+encryptDecryptUtils.encrypt(tblUserLogin.getLoginId()+"@@"+userTypeId+"_"+0)+"/"+encryptDecryptUtils.encrypt(tblUserLogin.getVerificationCode())+"\">Email Verification Link</a>");
                                mailContentUtillity.dynamicMailGeneration("20", String.valueOf(userId), String.valueOf(clientId), paramMap,""); 
                            }
                        }else{
                            paramMap.put("link1", "<a href=\"/authbiddermail/"+encryptDecryptUtils.encrypt(tblUserLogin.getLoginId()+"@@"+userTypeId+"_"+officerId)+"/"+encryptDecryptUtils.encrypt(tblUserLogin.getVerificationCode())+"\">Email Verification Link</a>");
                            mailContentUtillity.dynamicMailGeneration("12", String.valueOf(userId), String.valueOf(clientId),paramMap);
                        }
                        break;

                    case 0:
                        if(userTypeId == 2){
                            if(bidderRegistrationBy == 1){
                                mailContentUtillity.dynamicMailGeneration("5", String.valueOf(userId), String.valueOf(clientId), null, "");
                            }else{
                                mailContentUtillity.dynamicMailGeneration("18", String.valueOf(userId), String.valueOf(clientId), paramMap,""); 
                            }
                        }else{
                            mailContentUtillity.dynamicMailGeneration("13", String.valueOf(userId), String.valueOf(clientId),paramMap);
                        }
                        break;

                    default:
                        break;
                }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, auditResendRegEmail, userId, clientId);
        }
        
        return pageView;
    }
    
    @RequestMapping(value = "/bidder/attacheventspeccerti/{redirectLink}/{enc}", method = RequestMethod.GET)
    public String showCerti(@PathVariable("redirectLink") String redirectLink,@ModelAttribute CertiDataBean certiDataBean, ModelMap model, HttpServletRequest req) {
        String pageName = "redirect:/loginfailed";
        if (req.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
            SessionBean sessionBean = (SessionBean) req.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            ClientBean clientBean = (ClientBean) req.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            boolean flag = false;
            try {				 
            	model.addAttribute("isDcVerificationRequired",clientBean.getIsDcVerificationRequired());
            	model.addAttribute("attachCerti", true);
            	model.addAttribute("redirectLink", redirectLink);
            	flag=loginService.setCertiDetails(sessionBean, clientBean, model);
           TblClient tempClient=clientService.getClientById(clientBean.getClientId());
            	model.addAttribute("certificateClass",tempClient.getCertificateClass());
            } catch (Exception e) {
                return exceptionHandlerService.writeLog(e);
            } finally {
                auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), certiMapLink, showCertiAudit, 0, sessionBean.getUserId());
            }
            if (flag) {
                pageName = "CertiMap";
            }
        }
        return pageName;
    }
    /**
	 * @author Lipi
	 * used to set dynamic field value at bidder side (Bidder left panel-Briefcase)
	 */
    /*@RequestMapping(value = "/bidder/managedynamicfield/{clientId}/{eventTypeId}/{enc}", method = RequestMethod.GET) 
    public String manageDynamicField(@PathVariable("clientId") int clientId,@PathVariable("eventTypeId")int eventTypeId, ModelMap modelMap,HttpServletRequest request) {
        int linkId = 161;
        //remarks
        try {
        	int objectId = clientId;
        	modelMap.addAttribute("objectId", objectId);
            modelMap.addAttribute("dynFieldMap", dynamicFieldService.setDynamicField(linkId, clientId, objectId));
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId,"0", 0,clientId);
        }
        return "/common/bidder/MasterData";
    }    
    @RequestMapping(value = "/bidder/adddynamicfieldvalue/{clientId}", method = RequestMethod.POST)
    public String addDynamicFieldValue(@PathVariable("clientId") int clientId,HttpServletRequest request,RedirectAttributes redirectAttributes) {
    	int linkId = 161;
    	//remarks
    	boolean flag = false;
    	int objectId = abcUtility.getSessionUserId(request);
    	try{
    		flag = dynamicFieldService.addDynamicFieldValueProcess(requestMapVal,clientId,linkId,objectId,objectId);//createdBy
    	}catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId,"0", 0,clientId);
        }
    	return "/common/bidder/MasterData";
    }*/
    
    /**
     * 
     * @author bharat
     * @param modelMap
     * @param request
     * @param bidderId
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/admin/manageregistrationcharges/{bidderId}/{companyId}/{enc}", method = RequestMethod.GET)                       
    public String manageregistrationcharges(ModelMap modelMap, HttpServletRequest request,@PathVariable("bidderId") int bidderId,@PathVariable("companyId") int companyId){
        String retVal=null;
        try{
            modelMap.addAttribute("reportId", manageRegistrationCharges);
            modelMap.addAttribute("bidderId", bidderId);
            modelMap.addAttribute("companyId", companyId);
            modelMap.addAttribute("languageId",WebUtils.getCookie(request, "locale").getValue());
            reportGeneratorService.getReportConfigDetails(manageRegistrationCharges, modelMap);
            retVal="common/admin/ManageRegistrationCharges";
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }
        finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageSupplierRegCharges, enableSuppalierRegCharges, 0,0);
        }
        
        return retVal;
    }
    
    /**
     * CR:20564
     * @author bharat
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/enableregistrationcharges", method = RequestMethod.POST)                       
    public String enableRegistrationcharges(ModelMap modelMap, HttpServletRequest request, RedirectAttributes redirectAttributes){
        String retVal=null;
        try{
        	String[] paymentId = request.getParameterValues("hdPaymentId");
        	String bidderId = request.getParameter("hdBidderId");
        	String companyId = request.getParameter("hdCompanyId");
        	boolean flag = false;
        	if(paymentId != null)
        	{
        		if(manageBidderService.updateSupplierRegCharges(paymentId))
        		{
        			flag = true;
        		}
        	}
        	if(flag){
        		redirectAttributes.addFlashAttribute("successMsg", "msg_registration_charges_enabled_success");
        	}else{
        		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());	
        	}
        	retVal="redirect:/common/admin/manageregistrationcharges/"+bidderId+"/"+companyId 
        			+ encryptDecryptUtils.generateRedirect("common/admin/manageregistrationcharges/"+bidderId+"/"+companyId, request);			
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }
        finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageSupplierRegCharges, enableSuppalierRegCharges, 0,0);
        }
        
        return retVal;
    }
    
    /**
     * 
     * @param modelMap
     * @param request
     * @param categoryId
     * @return
     */
    @RequestMapping(value = "/admin/viewsupplier/{categoryId}/{enc}", method = RequestMethod.GET)                      
    public String viewSupplier(ModelMap modelMap, HttpServletRequest request,@PathVariable("categoryId") int categoryId){
        String retVal=null;
        try{
            modelMap.addAttribute("reportId", 89);
            modelMap.addAttribute("categoryId", categoryId);
            reportGeneratorService.getReportConfigDetails(viewSupplierReportId, modelMap);
            retVal="common/admin/ViewSupplier";
        }
        catch(Exception ex){
             return exceptionHandlerService.writeLog(ex);
        }
        finally{
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, auditManageBidder, 0,0);
        }
       
        return retVal;
    }

    
    /***
     * @author dhruvil
     * @param vendorCode
     * @param clientId
     * @return
     */
    @RequestMapping(value="/ajax/checkeVendorCodeExis",method = RequestMethod.POST)
    @ResponseBody
    public String checkVendorCodeExis(@RequestParam("txtVendorCode") String vendorCode ,@RequestParam("clientId") int clientId){
    	
    	String retVal=null;
    	try{
    		TblVendorCodeMapping tblVendorCodeMapping = manageBidderService.checkVendorCodeExis(vendorCode,clientId);
    		if(tblVendorCodeMapping != null){
    			retVal=messageSource.getMessage("msg_vendor_code_exis", null, LocaleContextHolder.getLocale());
    		}else{
    			retVal=messageSource.getMessage("msg_valid", null, LocaleContextHolder.getLocale());
    		}
    	}catch(Exception e){
    		return exceptionHandlerService.writeLog(e);
    	}
    	return retVal;
    }
    
    /**
     * It is used to set data for bidder additional fields details. PT : #35308.
     * @author jitendra
     * @param modelMap
     * @param request
     * @param userId
     * @param bidderId
     * @return
     */
    @RequestMapping(value = "/admin/addNewFieldDetails/{userId}/{bidderId}/{enc}", method = RequestMethod.GET)                       
    public String addNewFieldDetails(ModelMap modelMap, HttpServletRequest request,@PathVariable("userId") int userId,@PathVariable("bidderId") int bidderId){
        String retVal = null;
        try{
        	int countryId = commonService.getCountryIdFromIsoCode(indiaISOCode);
        	List<SelectItem> investorType = new ArrayList<SelectItem>();   
        	investorType.add(new SelectItem(investorTypeOwner, 1));
        	investorType.add(new SelectItem(investorTypeAgent, 2));
        	investorType.add(new SelectItem(investorTypeNA, 3)); 	// PT : #38862 By Jitendra.
        	        	
        	List<SelectItem> propertyLookingFor = new ArrayList<SelectItem>();
        	propertyLookingFor.add(new SelectItem(propertyLookingForOwnUse, 1));
        	propertyLookingFor.add(new SelectItem(propertyLookingForInvestment, 2));
        	propertyLookingFor.add(new SelectItem(propertyLookingForRent, 3));
        	
        	List<SelectItem> loanRequired = new ArrayList<SelectItem>();
        	loanRequired.add(new SelectItem(loanRequiredNo, 0));
        	loanRequired.add(new SelectItem(loanRequiredYes, 1));
        	
        	modelMap.addAttribute("userId", userId);
            modelMap.addAttribute("bidderId", bidderId);
        	modelMap.addAttribute("investorType", investorType);
        	modelMap.addAttribute("propertyLookingFor", propertyLookingFor);
        	modelMap.addAttribute("loanRequired", loanRequired);
        	modelMap.addAttribute("propertyTypeList", modelToSelectItem.convertListIntoSelectItemList(manageBidderService.getPropertyTypeList(), "propertyTypeId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
            modelMap.addAttribute("stateList", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(countryId), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
            retVal="common/admin/AddingNewFieldDetails";
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }
        finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),addNewFieldDetails, getAddNewFieldDetails, 0,0);
        }
        return retVal;
    }
    
    /**
     * It is used to insert bidder additional fields. PT : #35308.
     * @author jitendra
     * @param session
     * @param request
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "/admin/submitBidderAdditionalFields", method = RequestMethod.POST) 
    public String submitBidderAdditionalFields(HttpSession session, HttpServletRequest request, RedirectAttributes redirectAttributes){
    	String retVal=null;
    	TblBidderAdditionalFields tblBidderAdditionalFields = null;
    	int clientId = 0;
    	int userId = 0;
    	int bidderId = 0;
    	int typesOfInvestor = 0;
    	int propertyLookingFor = 0; 
    	String typesOfProperty = null;
    	BigDecimal minBudget = null;
    	BigDecimal maxBudget = null;
    	int isLoanRequired = 0;
    	String areaOrLocation = null;
    	String city = null;
    	String stateIds = null;
    	boolean success=false;
    	try{
    		clientId = abcUtility.getSessionClientId(request);
    		tblBidderAdditionalFields = new TblBidderAdditionalFields();
    		userId=StringUtils.hasLength(request.getParameter("hdUserId")) ? Integer.parseInt(request.getParameter("hdUserId")) : 0;
    		bidderId=StringUtils.hasLength(request.getParameter("hdBidderId")) ? Integer.parseInt(request.getParameter("hdBidderId")) : 0;
    		typesOfInvestor = StringUtils.hasLength(request.getParameter("selTypesOfInvestor")) ? Integer.parseInt(request.getParameter("selTypesOfInvestor")) : 0;
    		propertyLookingFor = StringUtils.hasLength(request.getParameter("selPropertyLookingFor")) ? Integer.parseInt(request.getParameter("selPropertyLookingFor")) : 0;
    		typesOfProperty = abcUtility.convertArrayToCommas(StringUtils.hasLength(request.getParameterValues("chkTypesOfProperty")[0]) ? request.getParameterValues("chkTypesOfProperty") : null);
    		minBudget = new BigDecimal(StringUtils.hasLength(request.getParameter("txtMinBudget")) ? request.getParameter("txtMinBudget") : "0"); // Bug #36627 By Jitendra.
    		maxBudget = new BigDecimal(StringUtils.hasLength(request.getParameter("txtMaxBudget")) ? request.getParameter("txtMaxBudget") : "0");
    		areaOrLocation = StringUtils.hasLength(request.getParameter("txtAreaOrLocation")) ? request.getParameter("txtAreaOrLocation") : null;
    		city = StringUtils.hasLength(request.getParameter("txtCity")) ? request.getParameter("txtCity") : null;
    		stateIds = abcUtility.convertArrayToCommas(StringUtils.hasLength(request.getParameterValues("chkState")[0]) ? request.getParameterValues("chkState") : null);
    		tblBidderAdditionalFields.setTypeOfInvestor(typesOfInvestor);
    		tblBidderAdditionalFields.setPropertyLookingFor(propertyLookingFor);
    		tblBidderAdditionalFields.setTypeOfProperty(typesOfProperty.replaceAll("\\,", "|"));
    		tblBidderAdditionalFields.setMinBudget(minBudget);
    		tblBidderAdditionalFields.setMaxBudget(maxBudget);
    		tblBidderAdditionalFields.setIsLoanRequired(isLoanRequired);
    		tblBidderAdditionalFields.setAreaOrLocation(areaOrLocation);
    		tblBidderAdditionalFields.setCity(city);
    		tblBidderAdditionalFields.setStateId(stateIds.replaceAll("\\,", "|"));
    		tblBidderAdditionalFields.setTblClient(new TblClient(clientId));
    		tblBidderAdditionalFields.setTblUserLogin(new TblUserLogin(userId));
    		tblBidderAdditionalFields.setTblBidderStatus(new TblBidderStatus(bidderId));
    		tblBidderAdditionalFields.setCStatus(1);
    		tblBidderAdditionalFields.setCreatedBy(abcUtility.getSessionUserId(request));
    		
    		if(!manageBidderService.checkIfExistsBidderFieldDetails(userId)){
    			success = manageBidderService.addOrUpdateBidderAdditionalFields(tblBidderAdditionalFields);
    			if(success){
        			retVal="redirect:/common/admin/managebidder"+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
        			redirectAttributes.addFlashAttribute("successMsg", "redirect_success_bidderadditionalfields");
        		}else{
        			retVal="redirect:/common/admin/addNewFieldDetails/"+userId+"/"+bidderId + encryptDecryptUtils.generateRedirect("common/admin/addNewFieldDetails/"+userId+"/"+bidderId, request);
            		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
        		}
    		}else{
    			retVal="redirect:/common/admin/addNewFieldDetails/"+userId+"/"+bidderId + encryptDecryptUtils.generateRedirect("common/admin/addNewFieldDetails/"+userId+"/"+bidderId, request);
    			redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_fail_existbidderadditionalfields");
    		}
    	}catch(Exception ex){
    		return exceptionHandlerService.writeLog(ex);
    	}
    	finally{
       		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),addNewFieldDetails, getAddNewFieldDetailsCreation, 0,0);
       	}
    	return retVal;
    }
    
    @RequestMapping(value = "/admin/manageregisteredbidders/{enc}", method = RequestMethod.GET)                       
    public String mangeRegisteredBidders(ModelMap modelMap, HttpServletRequest request){
        String retVal=null;
        try{
            modelMap.addAttribute("reportId", manageRegisteredBidderReportId);
            reportGeneratorService.getReportConfigDetails(manageRegisteredBidderReportId, modelMap);
            
            retVal="common/admin/ManageRegisteredBidder";
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }
        finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, auditManageBidder, 0,0);
        }
        
        return retVal;
    }
    
    @RequestMapping(value = "/admin/editregisteredbidderprofile/{bidderId}/{enc}", method = RequestMethod.GET)                       
    public String editRegisteredBidderProfile(@PathVariable("bidderId") int bidderId, @ModelAttribute BidderRegistrationDataBean bidderRegistrationDataBean, HttpSession session, HttpServletRequest request, ModelMap map){
        String retVal=null;
        try{
        	List<Object[]> bidderDetails = manageBidderService.viewBidderProfile(bidderId, 0, false);
                DataObject dataObject = WSCheckAvail.getSSOLoginMastreDetailasObject(bidderDetails.get(0)[9].toString());
        	bidderRegistrationDataBean.setTxtFullName((dataObject!=null && dataObject.getData7()!=null && !"".equalsIgnoreCase(dataObject.getData7().toString()))?dataObject.getData7().toString():bidderDetails.get(0)[0].toString());
        	bidderRegistrationDataBean.setTxtCompanyName((dataObject!=null && dataObject.getData6()!=null && !"".equalsIgnoreCase(dataObject.getData6().toString()))?dataObject.getData6().toString():bidderDetails.get(0)[1].toString());
        	bidderRegistrationDataBean.setTxtaAddress((dataObject!=null && dataObject.getData9()!=null && !"".equalsIgnoreCase(dataObject.getData9().toString()))?dataObject.getData9().toString():bidderDetails.get(0)[2].toString());
        	
        	TblCountry tblCountry = dataObject != null && dataObject.getData13() != null && !"".equalsIgnoreCase(dataObject.getData13().toString()) ? commonService.getCountryIdByName(dataObject.getData13().toString()) : null;
        	bidderRegistrationDataBean.setSelCountry(tblCountry != null ? tblCountry.getCountryId():(Integer)bidderDetails.get(0)[3]);
        	
        	TblState tblState = dataObject != null && dataObject.getData14()!=null && !"".equalsIgnoreCase(dataObject.getData14().toString()) ? commonService.getStateIdByName(dataObject.getData14().toString()) : null;
        	bidderRegistrationDataBean.setSelState(tblState != null ? tblState.getStateId().toString() : bidderDetails.get(0)[4].toString());
        	
        	bidderRegistrationDataBean.setTxtCity((dataObject!=null && dataObject.getData15()!=null && !"".equalsIgnoreCase(dataObject.getData15().toString()))?dataObject.getData15().toString():bidderDetails.get(0)[5].toString());
        	bidderRegistrationDataBean.setTxtPhone((dataObject!=null && dataObject.getData10()!=null && !"".equalsIgnoreCase(dataObject.getData10().toString()))?dataObject.getData10().toString():bidderDetails.get(0)[6].toString());
        	bidderRegistrationDataBean.setTxtMobileNo((dataObject!=null && dataObject.getData12()!=null && !"".equalsIgnoreCase(dataObject.getData12().toString()))?dataObject.getData12().toString():bidderDetails.get(0)[7].toString());
        	bidderRegistrationDataBean.setTxtWebsite((dataObject!=null && dataObject.getData22()!=null && !"".equalsIgnoreCase(dataObject.getData22().toString()))?dataObject.getData22().toString():bidderDetails.get(0)[8].toString());
        	bidderRegistrationDataBean.setTxtEmailId(bidderDetails.get(0)[9].toString());
        	bidderRegistrationDataBean.setHdBidderId((Integer)bidderDetails.get(0)[11]);
        	bidderRegistrationDataBean.setHdCompanyId((Integer)bidderDetails.get(0)[12]);
        	bidderRegistrationDataBean.setTxtAlternateLoginId(bidderDetails.get(0)[20]!=null ? bidderDetails.get(0)[20].toString() : "");
        	
        	TblTimeZone tblTimeZone = dataObject != null && dataObject.getData26()!=null && !"".equalsIgnoreCase(dataObject.getData26().toString()) ? commonService.getTimezoneIdByTimeZone(dataObject.getData26().toString()) : null;
        	bidderRegistrationDataBean.setSelTimezone(tblTimeZone != null?tblTimeZone.getTimeZoneId():Integer.parseInt(bidderDetails.get(0)[15].toString()));

        	int clientId = abcUtility.getSessionClientId(request);
        	int objectId = bidderId;
        	boolean isRegistrationByBidder = clientService.getBidderRegistrationBy(clientId) == 1;
        	boolean isEmailVerificationRequired = clientService.getBidderRegistrationVerifiedBy(clientId) != 0; 
        	boolean isEmailVerified = ((Integer)bidderDetails.get(0)[10]) == 1;
        	
        	List<Object[]> keywords = manageBidderService.getBidderKeywords(bidderId);
        	if(keywords != null && !keywords.isEmpty()) {
        		StringBuilder bidderKeywords = new StringBuilder();
        		for (int i=0; i<keywords.size(); i++) {
        			bidderKeywords.append(keywords.get(i)).append(",");
        		}
        		bidderRegistrationDataBean.setTxtaBusCatKeywords((dataObject!=null && dataObject.getData21()!=null && !"".equalsIgnoreCase(dataObject.getData21().toString()))?dataObject.getData21().toString():bidderKeywords.toString().substring(0, bidderKeywords.length()-1));
        	}
        	String langId=WebUtils.getCookie(request, "locale").getValue();
        	map.put("timezoneList", modelToSelectItem.convertListIntoSelectItemList(commonService.getTimeZoneList(), "timeZoneId", "lang"+langId));
        	map.put("countryList", modelToSelectItem.convertListIntoSelectItemList(commonService.getCountryList(langId), "countryId", "lang"+langId));
        	map.put("stateList", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(bidderRegistrationDataBean.getSelCountry()), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
        	/*map.put("bidderDocuments", value);*/
        	map.put("editProfileByBidder", false);
        	map.put("isRegistrationByBidder", isRegistrationByBidder);
        	map.put("isEmailVerified", isEmailVerified);
        	map.put("isEmailVerificationRequired", isEmailVerificationRequired);
        	map.addAttribute("homeUrl", "common/admin/manageregisteredbidders");
        	map.addAttribute("clientId",clientId);
        	map.addAttribute("objectId", objectId);
        	map.addAttribute("linkId", manageBidderFieldValueId);
        	map.addAttribute("bidderCstatus", bidderDetails.get(0)[18]);
        	
        	TblVendorCodeMapping tblVendorCodeMapping = manageBidderService.getVendorCode(bidderId,clientId);
        	if(tblVendorCodeMapping!=null){
        		bidderRegistrationDataBean.setTxtVendorCode(tblVendorCodeMapping.getVendorCode());
        	}else{
        		bidderRegistrationDataBean.setTxtVendorCode("");
        	}
        	
        	
        	map.addAttribute("dynFieldMap", dynamicFieldService.setDynamicField(manageBidderFieldValueId, clientId, objectId));
        	
        	if(abcUtility.isModuleAssignToClient(request,9)){ //spend analysis and statistic module.  PT: 20745
        		map.put("isCategoryAllow",commonService.isCategoryAllow(abcUtility.getSessionClientId(request)));
            }else{
            	map.put("isCategoryAllow",0);
            }
            if(map.get("isCategoryAllow").equals(1))
            {
            	List<Object[]> selectedCategory = commonService.getCategoryIdList(bidderId,registrationLinkId);
            	map.put("selectedCategory",selectedCategory);
            }
            
            // PT : #35308 By Jitendra. Adding new fields in the bidder profile
            boolean isClientSectorApplicable = manageBidderService.isClientSectorApplicable(clientId);
            boolean isBidderApproved = manageBidderService.isBidderApproved(bidderId, clientId); // Bug #35556 By Jitendra
            int countryId = commonService.getCountryIdFromIsoCode(indiaISOCode);
            int bidderFieldId = 0;
            map.put("isClientSectorApplicable", isClientSectorApplicable);
            map.put("isBidderApproved", isBidderApproved);
            map.put("actualBidderId", bidderDetails.get(0)[19].toString());
            
            if(isClientSectorApplicable && isBidderApproved){
            	List<SelectItem> investorType = new ArrayList<SelectItem>();   
            	investorType.add(new SelectItem(investorTypeOwner, 1));
            	investorType.add(new SelectItem(investorTypeAgent, 2));
            	investorType.add(new SelectItem(investorTypeNA, 3)); 	// PT : #38862 By Jitendra.
            	
            	List<SelectItem> propertyLookingFor = new ArrayList<SelectItem>();
            	propertyLookingFor.add(new SelectItem(propertyLookingForOwnUse, 1));
            	propertyLookingFor.add(new SelectItem(propertyLookingForInvestment, 2));
            	propertyLookingFor.add(new SelectItem(propertyLookingForRent, 3));
            	
            	List<SelectItem> loanRequired = new ArrayList<SelectItem>();
            	loanRequired.add(new SelectItem(loanRequiredNo, 0));
            	loanRequired.add(new SelectItem(loanRequiredYes, 1));

                map.put("investorType", investorType);
                map.put("propertyLookingFor", propertyLookingFor);
            	map.put("loanRequired", loanRequired);
            	map.put("propertyTypeList", modelToSelectItem.convertListIntoSelectItemList(manageBidderService.getPropertyTypeList(), "propertyTypeId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
            	map.put("stateList", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(countryId), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
            	
                List<Object[]> bidderAdditionalFields = manageBidderService.getBidderAdditionalFields(bidderId, clientId);
                if(bidderAdditionalFields != null && !bidderAdditionalFields.isEmpty()){
                	bidderRegistrationDataBean.setSelTypesOfInvestor(bidderAdditionalFields.get(0)[0].toString());
                	bidderRegistrationDataBean.setSelPropertyLookingFor(bidderAdditionalFields.get(0)[1].toString());
                	bidderRegistrationDataBean.setChkTypesOfProperty(bidderAdditionalFields.get(0)[2].toString());
                	bidderRegistrationDataBean.setTxtMinBudget(bidderAdditionalFields.get(0)[3].toString());
                	bidderRegistrationDataBean.setTxtMaxBudget(bidderAdditionalFields.get(0)[4].toString());
                	bidderRegistrationDataBean.setSelLoanRequired(bidderAdditionalFields.get(0)[5].toString());
                	bidderRegistrationDataBean.setTxtAreaOrLocation(bidderAdditionalFields.get(0)[6].toString());
                	bidderRegistrationDataBean.setTxtAdditionalCity(bidderAdditionalFields.get(0)[7].toString());
                	bidderRegistrationDataBean.setChkAdditionalState(bidderAdditionalFields.get(0)[8].toString());
                	
                	String[] typeOfPropertyArr = bidderAdditionalFields.get(0)[2].toString().split("\\|");
                	List<Object> propertyTypeList = new ArrayList<Object>();
                	for (String typeOfProperty : typeOfPropertyArr) {
                		propertyTypeList.add(manageBidderService.getPropertyTypeById(Integer.parseInt(typeOfProperty)));
					}
                	
                	// PT : 36402 By Jitendra. 
                	String[] stateIdArr = bidderAdditionalFields.get(0)[8].toString().split("\\|");
                	List<Object> stateIdList = new ArrayList<Object>();
                	for (String stateId : stateIdArr) {
                		stateIdList.add(manageBidderService.getStateById(Integer.parseInt(stateId)));
					}
                	map.put("additionalState", abcUtility.converObjectArrayToCommas(stateIdList));
                	map.put("typesOfProperty", abcUtility.converObjectArrayToCommas(propertyTypeList));
                	bidderFieldId = Integer.parseInt(bidderAdditionalFields.get(0)[10].toString());
                }
                map.put("bidderFieldsId", bidderFieldId);
               
            }
            map.put("domainName", manageBidderService.getDomainByUserId(bidderId));
        	retVal="common/admin/EditBidderProfile";
        }
        catch(Exception ex){
        	return exceptionHandlerService.writeLog(ex);
        } finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editBidderLinkId, auditEditBidderProfile, 0, 0);
        }
        return retVal;
    }
    
    @RequestMapping(value = "/admin/viewregisteredbidderprofile/{bidderId}/{enc}", method = RequestMethod.GET)                       
    public String viewRegisteredBidderProfile(@PathVariable("bidderId") int bidderId,ModelMap modelMap, HttpServletResponse response, HttpServletRequest request){
        String retVal=null;
        int clientId=0;
        try{
        	clientId=abcUtility.getSessionClientId(request);
        	modelMap.addAttribute("bidderDetailMap", getViewBidderDetails(bidderId, 0,WebUtils.getCookie(request, "locale").getValue()));//for registrationdetails.jsp page
        	modelMap.addAttribute("documentList", manageBidderService.getBidderDocs(bidderId, clientId));//For document list
        	modelMap.addAttribute("isWorkFlow", 0);
        	// TODO : To get Certificate Details of Bidder 
        	List<Object[]> certDetails= manageBidderService.getBidderCertiDetails(bidderId,abcUtility.getSessionIsDualCerti(request)==true?2:1);
        	List<Map<String,Object>> certiDetailsList = new ArrayList<Map<String,Object>>();
        	if(!certDetails.isEmpty()){
        		for (int i = 0; i < certDetails.size(); i++) {
        			Map<String,Object> certDetail= new HashMap<String, Object>();
            		Object[] object = certDetails.get(i);
            		certDetail.put("subject", object[0]);
            		certDetail.put("issuer", object[1]);
            		certDetail.put("serialNumber", object[2]);
            		certDetail.put("publicKey", object[3]);
            		certDetail.put("keyUsage", object[4]);
            		certDetail.put("endDate", object[5]);
            		certiDetailsList.add(certDetail);
    			}
        	}
            int sessionUserId = abcUtility.getSessionUserId(request);
            int i = commonService.checkAbcUser(Integer.toString(sessionUserId));
            if(i>0)
            {
            	modelMap.addAttribute("isAbcUser", i);
            }            
        	modelMap.addAttribute("certiDetailsList", certiDetailsList);
        	request.setAttribute("certDetail", manageBidderService.getBidderCertiDetailsNew(bidderId,abcUtility.getSessionIsDualCerti(request)==true?2:1));
        	
        	boolean isRegApplicable=clientService.checkIsRegChargesApplicable(clientId);
        	request.setAttribute("isRegApplicable", isRegApplicable);
        	if(isRegApplicable){
        		
				TblPayment tblPayment = manageBidderService.getPaymentDetailByBidderId(bidderId, clientId,3,1);
				request.setAttribute("tblPayment",tblPayment);

				if (tblPayment != null) {

					int paymentId = 0;
					paymentId = tblPayment.getPaymentId();
				
					
					request.setAttribute("payType",commonService.getPaymentTypeDetail(tblPayment.getTblPaymentType().getPaymentTypeId()).getLang1());
					request.setAttribute("paymentTypeId",tblPayment.getTblPaymentType().getPaymentTypeId());
					request.setAttribute("registrationCharges",tblPayment.getAmount().intValue());
					
					TblOfflinePayment tblOfflinePayment = manageBidderService.getOfflinePaymentDetail(paymentId);
							
					if (tblOfflinePayment != null) {
						
						request.setAttribute("payDate",tblOfflinePayment.getReferenceDate());
						request.setAttribute("payMode", "Offline");		
						request.setAttribute("referenceNo",tblOfflinePayment.getReferenceNo());
						request.setAttribute("bankName1", tblOfflinePayment.getBankName());	
						TblBidderDocMapping tblBidderDocMapping=manageBidderService.getBidderDocDetails(paymentId,uploadBidderChargesOfflineLink);
						request.setAttribute("tblBidderDocMapping",	tblBidderDocMapping);
						
					} else {
					
						TblOnlinePayment tblOnlinePayment = manageBidderService.getOnlinePaymentDetail(paymentId);
						if(tblOnlinePayment != null){
							request.setAttribute("payDate",	tblOnlinePayment.getUpdatedOn());							
							request.setAttribute("payMode", "Online");
							request.setAttribute("referenceNo",tblPayment.getPaymentId());
						}
					}
					
					//request.setAttribute("paymentType",tblPayment.getTblPaymentType().getLang1());
			
				}
        	}
        	int objectId = bidderId;
        	if(abcUtility.getSessionUserTypeId(request) == 1 || abcUtility.getSessionUserTypeId(request) == 3){
        		TblVendorCodeMapping tblVendorCodeMapping = manageBidderService.getVendorCode(bidderId, clientId);
        		if(tblVendorCodeMapping != null){
        			modelMap.addAttribute("vendorCode",tblVendorCodeMapping.getVendorCode());
        		}else{
        			modelMap.addAttribute("vendorCode","");
        		}
            	
        	}
        	modelMap.addAttribute("clientId",clientId);
        	modelMap.addAttribute("objectId", objectId);
        	modelMap.addAttribute("linkId", manageBidderFieldValueId);
        	modelMap.addAttribute("dynFieldMap", dynamicFieldService.setDynamicField(manageBidderFieldValueId, clientId, objectId));
			if(CommonUtility.isClientConditionExistInProperty(gslClientIds, clientId)){
				modelMap.addAttribute("bidderRegisteredInDocList", manageBidderService.getBidderRegisteredInDocs(bidderId, abcUtility.getSessionClientId(request)));//For GSL bidder Registered In Document list
				modelMap.addAttribute("bidderIndustryAndClass", manageBidderService.getBidderIndustryAndClassificationWithDoc(bidderId, abcUtility.getSessionClientId(request)));//For GSL bidder Registered In Document list
			}
			if(CommonUtility.isClientConditionExistInProperty(rciClientIds, clientId)){
				boolean isOfficerOrAdmin = abcUtility.getSessionUserTypeId(request) != 2 ? true : false;
				ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
				if(isOfficerOrAdmin && clientBean.getClientModules().contains("8")){ // if vendor enlistment module configure
					int companyId = commonService.getCompanyId(bidderId, clientId);
					List<TblCompanyEnlistment> appovedVendorEnlistedFileList=  vendorEnlistmentService.getApprovedCompanyEnlistedFile(clientId,companyId);
					if (appovedVendorEnlistedFileList != null && !appovedVendorEnlistedFileList.isEmpty() && appovedVendorEnlistedFileList.get(0) !=null) {
						modelMap.addAttribute("appovedVendorEnlistedFileList",appovedVendorEnlistedFileList);
			        }
				}
			}
			
			// PT : #35308 By Jitendra. Adding new fields in the bidder profile
            boolean isClientSectorApplicable = manageBidderService.isClientSectorApplicable(clientId);
            boolean isBidderApproved = manageBidderService.isBidderApproved(bidderId, clientId); // Bug #35556 By Jitendra
            modelMap.addAttribute("isClientSectorApplicable", isClientSectorApplicable);
            modelMap.addAttribute("isBidderApproved", isBidderApproved);
            
            if(isClientSectorApplicable && isBidderApproved){
                List<Object[]> bidderAdditionalFields = manageBidderService.getBidderAdditionalFields(bidderId, clientId);
                if(bidderAdditionalFields != null && !bidderAdditionalFields.isEmpty()){
                	String[] typeOfPropertyArr = bidderAdditionalFields.get(0)[2].toString().split("\\|");
                	List<Object> propertyTypeList = new ArrayList<Object>();
                	for (String typeOfProperty : typeOfPropertyArr) {
                		propertyTypeList.add(manageBidderService.getPropertyTypeById(Integer.parseInt(typeOfProperty)));
					}
                	
                	// PT : 36402 By Jitendra. 
                	String[] stateIdArr = bidderAdditionalFields.get(0)[8].toString().split("\\|");
                	List<Object> stateIdList = new ArrayList<Object>();
                	for (String stateId : stateIdArr) {
                		stateIdList.add(manageBidderService.getStateById(Integer.parseInt(stateId)));
					}
                	modelMap.addAttribute("typeOfInvestor", bidderAdditionalFields.get(0)[0].toString());
                	modelMap.addAttribute("propertyLookingFor", bidderAdditionalFields.get(0)[1].toString());
                	modelMap.addAttribute("typeOfProperty", abcUtility.converObjectArrayToCommas(propertyTypeList));
                	modelMap.addAttribute("minBudget", bidderAdditionalFields.get(0)[3].toString());
                	modelMap.addAttribute("maxBudget", bidderAdditionalFields.get(0)[4].toString());
                	modelMap.addAttribute("isLoanRequired", bidderAdditionalFields.get(0)[5].toString());
                	modelMap.addAttribute("areaOrLocation", bidderAdditionalFields.get(0)[6].toString());
                	modelMap.addAttribute("additionalCity", bidderAdditionalFields.get(0)[7].toString());
                	modelMap.addAttribute("additionalState", abcUtility.converObjectArrayToCommas(stateIdList));
                }
            }
            modelMap.put("domainName", manageBidderService.getDomainByUserId(bidderId));
            retVal="common/admin/ViewBidderProfile";
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        }
        finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewBidderLinkId, auditViewBidderProfile, 0, bidderId);
        }
        return retVal;
    }
    /**
     * CR. #38251 Providing access of desired domains in the mobile app 
     * @author Dhruvil.panchal
     * @param request
     * @param session
     * @param redirectAttributes
     * @return
     * 
     */
    @RequestMapping(value = "/admin/approvebidderonmobile", method = RequestMethod.POST)      
    public String submitApproveBidderOnMoblieApp(HttpServletRequest request, HttpSession session,RedirectAttributes redirectAttributes){
        String retVal = null;
        int userId = 0;
        int status = 0;
        int cStatus = 0;
        boolean success =false;
        String clientIds = null;
        int oprType=StringUtils.hasLength(request.getParameter("hdOprType")) ? Integer.parseInt(request.getParameter("hdOprType")) : 0;
        try {
        	
            userId = StringUtils.hasLength(request.getParameter("hdUserId")) ? Integer.parseInt(request.getParameter("hdUserId")) : 0;
            status = StringUtils.hasLength(request.getParameter("selAction")) ? Integer.parseInt(request.getParameter("selAction")) : 0;
            String remark=StringUtils.hasLength(request.getParameter("txtaRemarks")) ? request.getParameter("txtaRemarks") : null;
            String clientArr[]=request.getParameterValues("chkMultipleDomain");
            TblBidderStatus tblBidderStatus=null;
            TblPayment tblPayment=null;
            TblOfflinePayment tblOfflinePayment=null;
              String emailId=null;
              String refdate=null;
              String remarks=null;
              int validUpto=0;
            
            if(clientArr == null){
                clientIds = defaultAPClientId;
            }else{
                clientIds = abcUtility.convertArrayToCommas(clientArr).replaceAll("~~0~~0", "").trim();
            }
            int clientId =abcUtility.getSessionClientId(request);
            int sessionUserId=abcUtility.getSessionUserId(request);
            List<TblBidderStatus> listBidderStatus = new ArrayList();
            String endDate=null;
            String paymentAplicable=StringUtils.hasLength(request.getParameter("txtPaymentApp")) ? request.getParameter("txtPaymentApp") : "";
            remarks=StringUtils.hasLength(request.getParameter("txtaRemarks")) ? request.getParameter("txtaRemarks") : null;
            int companyId=Integer.parseInt(commonService.getCompanyIdByUserId(userId).toString());
            if(("Y".equalsIgnoreCase(paymentAplicable) && oprType == 2) || (oprType==1 && status!=7)){
                refdate=StringUtils.hasLength(request.getParameter("txtPaymentDate")) ? request.getParameter("txtPaymentDate") : null;
                String startDate=StringUtils.hasLength(request.getParameter("txtStartDate")) ? request.getParameter("txtStartDate") : null;
                startDate+=" "+CommonUtility.getTimeZone().substring(1)+":00";
                endDate=StringUtils.hasLength(request.getParameter("txtEndDate")) ? startDate != null ?request.getParameter("txtEndDate"):null : null;
                endDate+=" "+CommonUtility.getTimeZone().substring(1)+":00";
                validUpto=StringUtils.hasLength(request.getParameter("txtRegistrationValidity")) ? Integer.parseInt(request.getParameter("txtRegistrationValidity")) : 0;
              //clientIds=StringUtils.hasLength(request.getParameter("txtRegChargesApplClient")) ? request.getParameter("txtRegChargesApplClient").substring(0, request.getParameter("txtRegChargesApplClient").length()-1): "";
                String bankName=StringUtils.hasLength(request.getParameter("txtBankName")) ? request.getParameter("txtBankName") : "";
                Double amount=StringUtils.hasLength(request.getParameter("txtAmount")) ? Double.parseDouble(request.getParameter("txtAmount")) : 0;
                int offlinePaymentApplicable=StringUtils.hasLength(request.getParameter("hdOfflinePaymentMode")) ? Integer.parseInt(request.getParameter("hdOfflinePaymentMode")) : 0;
                List<TblBidderStatus> bidderStatusList=new ArrayList<TblBidderStatus>();
                List<TblUserHistory> userHistoryList=new ArrayList<TblUserHistory>();
                TblUserHistory  tblUserHistory = null;
            if(oprType == 2 || offlinePaymentApplicable == 1){
                tblPayment=new TblPayment();
                tblOfflinePayment=new TblOfflinePayment();
                tblPayment.setTblClient(new TblClient(clientId));
                tblPayment.setTblCompany(new TblCompany(companyId));
                tblPayment.setTblPaymentType(new TblPaymentType(request.getParameter("selPaymentMode") != null && !"".equalsIgnoreCase(request.getParameter("selPaymentMode")) ? Integer.parseInt(request.getParameter("selPaymentMode")) : 0));
                tblPayment.setTblUserLogin(new TblUserLogin(userId));
                tblPayment.setTblLink(new TblLink(oprType == 2 ? renewRegistrationLinkId : bidderAproveLinkId));//need to change from static one
                tblPayment.setAmount(new BigDecimal(amount));
                tblPayment.setExemptionAmt(new BigDecimal(0));
                tblPayment.setObjectId(0);
                tblPayment.setClientIds(clientIds);
                tblPayment.setCreatedBy(sessionUserId);
                tblPayment.setRemark(remarks);
                tblPayment.setPaymentFor(3);
                tblPayment.setCstatus(1);
                tblPayment.setTblDepartment(new TblDepartment(Integer.parseInt(clientService.getClientField(clientId, "deptId").toString())));                
                tblPayment.setTblModule(new TblModule(commonService.getModuleIdbyLinkId(oprType == 2 ? renewRegistrationLinkId : bidderAproveLinkId)));
                tblOfflinePayment.setReferenceNo(request.getParameter("txtPaymentReferenceNo") !=null && !"".equals(request.getParameter("txtPaymentReferenceNo")) ? request.getParameter("txtPaymentReferenceNo") : "");
                tblOfflinePayment.setReferenceDate(conversionService.convert(refdate,Date.class));
                tblOfflinePayment.setBankName(bankName);
                tblBidderStatus = manageBidderService.getBidderObjectByUserIdAndClientId(userId, clientId);
                if(tblBidderStatus !=null)
                {
                    tblBidderStatus.setCstatus(Integer.parseInt(bidderStatusApprove));
                    tblBidderStatus.setTblRegistrationWorkflow(new TblRegistrationWorkflow(9));
                    tblBidderStatus.setTblCompany(new TblCompany(companyId));
                    tblBidderStatus.setUpdatedOn(new Date());
                    tblBidderStatus.setUpdatedBy(sessionUserId);
                    tblBidderStatus.setStartDate(startDate != null && !"".equals(startDate) ?  conversionService.convert(startDate,Date.class) :null);
                    tblBidderStatus.setEndDate(endDate != null && !"".equals(endDate) ?  conversionService.convert(endDate,Date.class) :null);
                    tblBidderStatus.setValidityUpto(validUpto);
                    tblBidderStatus.setApprovedBy(sessionUserId);
                    tblBidderStatus.setApprovedOn(new Date());
                    tblBidderStatus.setTwoStageStatus(0);
                    tblBidderStatus.setRemarks(remarks);
                    bidderStatusList.add(tblBidderStatus);
                    
                    tblUserHistory=new TblUserHistory();
                    if(oprType == 2){
                        tblUserHistory.setActionType(Integer.parseInt(userHistRenew));
                    }else{
                        tblUserHistory.setActionType(Integer.parseInt(userHistApprove));
                    }
                    tblUserHistory.setTblUserLogin(new TblUserLogin(userId));
                    tblUserHistory.setTblClient(new TblClient(clientId));
                    tblUserHistory.setCreatedBy(sessionUserId);
                    userHistoryList.add(tblUserHistory);
                    success=manageBidderService.approveBidder(tblPayment, tblOfflinePayment, bidderStatusList, userHistoryList);
                }
            }else{
                tblBidderStatus = manageBidderService.getBidderObjectByUserIdAndClientId(userId, clientId);
                if(tblBidderStatus !=null)
                {
                    tblBidderStatus.setApprovedOn(new Date());
                    tblBidderStatus.setApprovedBy(sessionUserId);
                    tblBidderStatus.setRemarks(remarks);
                    tblBidderStatus.setUpdatedBy(sessionUserId);
                    tblBidderStatus.setUpdatedOn(new Date());
                    listBidderStatus.add(tblBidderStatus);
                    success = manageBidderService.saveOrUpdateBidderList(listBidderStatus);
                }
            }
            }else{ 
            	success = manageBidderService.updateBidderStatus(status, userId, sessionUserId,Integer.parseInt(defaultAPClientId)); // Rejected cstatus = 7 update in bidderstatus
            }
            success  = mobilebidderstatusservice.isBidderExistOnMobile(userId);
            if(!success){
                TblMobileBidderStatus tblMobileBidderStatus = new TblMobileBidderStatus();
                tblMobileBidderStatus.setTblUserLogin(new TblUserLogin(userId));
                tblMobileBidderStatus.setClientIds(clientIds);
                tblMobileBidderStatus.setApprovedbyclientId(clientId);
                tblMobileBidderStatus.setApprovedby(sessionUserId);
                tblMobileBidderStatus.setCstatus(status);
                tblMobileBidderStatus.setRemark(remark);
                tblMobileBidderStatus.setApprovedOn(new Date());
                tblMobileBidderStatus.setUpdatedOn(new Date());
                tblMobileBidderStatus.setUpdatedby(sessionUserId);
                success = mobilebidderstatusservice.addMobileBidderStatus(tblMobileBidderStatus);
            }else {
                cStatus = (status == 7) ? 0 : 1;   
                success = mobilebidderstatusservice.updateMobileBiddercStatus(userId,cStatus,clientIds,remark,sessionUserId);
            }
            if(!success){
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
                retVal="redirect:/common/admin/managebidder"+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
                return retVal;
            } else{
            	retVal="redirect:/common/admin/managebidder"+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
            	redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), oprType == 2 ? "redirect_success_renew" : "redirect_success_aproved");
                return retVal;
            }
        } catch(Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        }
        finally{
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidderAproveLinkId, auditApprovedBidder, 0,userId);
        } 
    }
    /**
     * @author um@ng.rathod
     * @param bidderId
     * @param request
     * @param session
     * @param redirectAttributes
     * @return
     * CR. #48742 Upload document in manage bidder 
     * 
     */    
    @RequestMapping(value = "/admin/uploadDocument/{bidderId}/{enc}", method = RequestMethod.GET)                       
    public String uploadBidderDocument(@PathVariable("bidderId") int bidderId,HttpSession session, HttpServletRequest request, ModelMap map){
        String retVal=null;
        try{
        	int clientId=0;
        	int mandatoryDocs = 0;
			int remainingDocs = 0;
        	try{
        		clientId=abcUtility.getSessionClientId(request);
        		List<Object[]> lstClientRegDocs = manageBidderService.getClientRegDoc(clientId);

				List<SelectItem> mandatoryDocList = abcUtility.convert(lstClientRegDocs);
				
				List<Object[]> list = manageBidderService.getMandatoryPendingDocCount(clientId, bidderId);
				mandatoryDocs = Integer.parseInt(list.get(0)[0].toString());
				remainingDocs = mandatoryDocs - Integer.parseInt(list.get(0)[1].toString());
				
        		
				List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(14, clientId);
				int allowedSize = lstDocUploadConf.get(0).getMaxSize();

				StringBuilder allowedExt = new StringBuilder();
				allowedExt.append(lstDocUploadConf.get(0).getType());

				int index = allowedExt.toString().indexOf(",");
				allowedExt.insert(index + 1, "*.");
				while (index >= 0) {
					index = allowedExt.toString().indexOf(",",index + ",".length());
					allowedExt.insert(index + 1, "*.");
				}
				
				if (remainingDocs == 0) {
					int regWorkflowId = manageBidderService.getClientRegWorkflowId(clientId, 5);
					map.put("clientRegWorkflowId", regWorkflowId);
				}
				
				Map uploadedDocBucket = new HashMap();

				List<Map> manDocSummary = new ArrayList<Map>();
				List<Object[]> lstManDoc = manageBidderService.getUploadedPendingManDocLst(clientId, bidderId);
				List<Object> lstBidderDocMappingChId = manageBidderService.getBidderDocMappingChildId(clientId, bidderId);
				List<Object[]> lstUploadedDoc = manageBidderService.getBidderDocs(bidderId, clientId);
				
				if (!lstUploadedDoc.isEmpty()) {
					for (Object[] uploadedDocObj : lstUploadedDoc) {
						if (((Integer) uploadedDocObj[5]) == 1) {
							if (uploadedDocBucket
									.containsKey(uploadedDocObj[4])) {
								String docName = (String) uploadedDocBucket
										.get(uploadedDocObj[4]);
								docName += ", " + (String) uploadedDocObj[0];

								uploadedDocBucket.remove(uploadedDocObj[4]);
								uploadedDocBucket.put(uploadedDocObj[4],
										docName);
							} else {
								uploadedDocBucket.put(uploadedDocObj[4],
										uploadedDocObj[0]);
							}
						}
					}
				}
				if (!lstManDoc.isEmpty()) {
					for (Object[] objects : lstManDoc) {
						Map docSummaryMap = new HashMap();
						docSummaryMap.put("clientRegDocId", objects[0]);
						docSummaryMap.put("mandatoryDocName", objects[1]);

						if (!lstBidderDocMappingChId.isEmpty()) {
							if (lstBidderDocMappingChId.contains(objects[0])) {
								docSummaryMap.put("isuploaded", "1");
							} else {
								docSummaryMap.put("isuploaded", "0");
							}
						} else {
							docSummaryMap.put("isuploaded", "0");
						}
						manDocSummary.add(docSummaryMap);
					}
				}
				map.addAttribute("uploadedDocBucket", uploadedDocBucket);
				map.addAttribute("manDocSummary", manDocSummary);
				map.addAttribute("allowedSize", allowedSize / 1024);
				map.addAttribute("allowedExt", allowedExt.toString());
				map.addAttribute("uploadedDoc", manageBidderService.getTotalUploadedDocs(clientId, bidderId));
				map.addAttribute("mandatoryDocs", mandatoryDocs);
				map.addAttribute("remainingDocs", remainingDocs);
				map.addAttribute("documentList", lstUploadedDoc);		
				map.addAttribute("mandatoryDocList", mandatoryDocList);
				map.addAttribute("userId", bidderId);
				map.addAttribute("officerDocUpload", false);
				map.addAttribute("isRegistrationLinkHidden", clientService.isRegistrationLinkHidden(clientId, hideRegistrationLinkId, 1));
        	}catch(Exception e){
        		return exceptionHandlerService.writeLog(e);
        	}finally{
        		//auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), docUploadLinkId, getUploadDocumentsRemark, indentId, 0);
        	}
        	retVal = "common/admin/UploadDocument";
        }
        catch(Exception ex){
        	return exceptionHandlerService.writeLog(ex);
        } finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editBidderLinkId, auditEditBidderProfile, 0, 0);
        }
        return retVal;
    }
    
    
    /**
     * @author nitin.w
     * @param bidderId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/detachdc/{bidderId}/{enc}", method = RequestMethod.GET)                       
    public String detachDC(@PathVariable("bidderId") int bidderId,ModelMap modelMap,HttpServletRequest request){
    	String retVal=null;
        try{
        	int clientId=abcUtility.getSessionClientId(request);
        	modelMap.addAttribute("bidderDetailMap", getViewBidderDetails(bidderId, clientId,WebUtils.getCookie(request, "locale").getValue()));//for registrationdetails.jsp page
        	ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        	String publicKey=null;
        	//TODO:For sign generation code
        	if(abcUtility.getSessionIsPkiEnabled(request)==1){
        		String certIds[] = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getCertId().split(",");
        		if(certIds!=null && certIds.length!=0){
        			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
        		}
        		modelMap.addAttribute("publicKeyForSign", publicKey);
    		}
        	List<Object[]> unmapCertDetails= manageBidderService.getDetachCertDetails(bidderId, clientId);
        	/*&& unmapCertDetails.size() != 3*/
        	if(!unmapCertDetails.isEmpty()){
        		for (int i = 0; i < unmapCertDetails.size(); i++) {
        			Map<String,Object> certDetail= new HashMap<String, Object>();
            		Object[] object = unmapCertDetails.get(i);
            		certDetail.put("loginId", object[0]);
            		certDetail.put("keyUsage", object[11]);
            		certDetail.put("subject", object[2]);
            		certDetail.put("issuer", object[3]);
            		certDetail.put("publicKey", object[4]);
            		certDetail.put("serialNumber", object[5]);
            		certDetail.put("validFrom", object[6]);
            		certDetail.put("validTo", object[7]);
            		certDetail.put("certId",object[8]);
            		certDetail.put("userCertId",object[9]);
            		certDetail.put("isDual",object[10]);
            		if((Integer)object[11] == 1){
            			modelMap.addAttribute("SigningCerti", certDetail);
            		}else if((Integer)object[11] == 2){
            			modelMap.addAttribute("EncryptionCerti", certDetail);
            		}
    			}
        	}
        	modelMap.addAttribute("rowSize", unmapCertDetails.size());// for count how many rows return. It means is dual certi or single certi
        	modelMap.addAttribute("clientName", clientService.getClientNameByClientId(clientBean.getClientId()));
        	modelMap.put("EmailId",commonService.getEmailByUserId(bidderId));
        	retVal="common/admin/DetachDC";
        }catch(Exception ex){
       	 return exceptionHandlerService.writeLog(ex);
       }
       finally{
       	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),detachDCLinkId, auditDetachDc, 0,abcUtility.getSessionUserId(request));
       }
        return retVal;
    }
    
    /**
     * @author nitin.w
     * @param redirectAttributes
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/adddetachdc", method = RequestMethod.POST)                       
    public String addDetachDC(RedirectAttributes redirectAttributes, HttpServletResponse response, HttpServletRequest request){
    	
    	boolean success = false;
        String retVal = null;
        String bidderId = null;
        ClientBean clientBean=null;
        String remark = null;
        String msg = null;
        String msgAudit = null;
        try{
        	clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        	String encryCertId = request.getParameter("hdEncryCertId");;
        	String encryUserCertId = request.getParameter("hdEncryUserCertId");
        	String encryKeyUsage = request.getParameter("hdEncryKeyUsage");
        	String encryIsDual = request.getParameter("hdEncryIsDual");
        	//String encryCertIdDual = null;
        	String userCertIds[] = null;
        	String signingCertId = request.getParameter("hdSigningCertId");
        	String signingUserCertId = request.getParameter("hdSigningUserCertId");
        	String signingKeyUsage = request.getParameter("hdSigningKeyUsage");
        	String signingIsDual = request.getParameter("hdSigningIsDual");
        	bidderId = request.getParameter("hdBidderId");//it's a bidder id
        	//remark = request.getParameter("txtaRemarks");
        	remark = "Detached DC";
        	String rowSize = request.getParameter("hdRowSize");
        	String loginId = request.getParameter("hdLoginId");
        	String encCertiId = request.getParameter("certIsSelect_enc");
        	String signCertiId = request.getParameter("certIsSelect_sign");
                
        	int createdBy = abcUtility.getSessionUserId(request);
        	
        	
        	List<TblUserCertificate> tblUserCertificates = null;
        	if(StringUtils.hasLength(loginId) /*&& StringUtils.hasLength(signingUserCertId)*/  && StringUtils.hasLength(remark) && StringUtils.hasLength(bidderId) /*&& StringUtils.hasLength(signingCertId)*/){
        		//List<TblCertUnMapHistory> tblCertUnMapHistorys = new ArrayList<TblCertUnMapHistory>();
        		List<TblDCDetachHistory> tblDetachCertHistorys = new ArrayList<TblDCDetachHistory>();
        		tblUserCertificates = new ArrayList<TblUserCertificate>();
        		if ( signCertiId != null  &&  !signCertiId.isEmpty()) {
        				TblDCDetachHistory tblDetachCertHistory = new TblDCDetachHistory();
        				tblDetachCertHistory.setTblUserLogin(new TblUserLogin(Integer.parseInt(bidderId)));
        				tblDetachCertHistory.setTblCertificate(new TblCertificate(Integer.parseInt(signingCertId)));
        				tblDetachCertHistory.setTblClient(new TblClient(clientBean.getClientId()));
        				
        				int clientId = abcUtility.getSessionClientId(request);
        				int userTypeId = commonService.getUserTypeIdFromUserId(Integer.parseInt(bidderId), clientId);
        				int companyId=Integer.parseInt(commonService.getCompanyIdByUserId(Integer.parseInt(bidderId)).toString());
        				String ipAddress = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR) : request.getRemoteAddr();
        				
        				tblDetachCertHistory.setCompanyId(userTypeId==2?companyId:0);
        				tblDetachCertHistory.setIsDualCert(Integer.parseInt(signingIsDual));
        				tblDetachCertHistory.setKeyUsage(Integer.parseInt(signingKeyUsage));
        				tblDetachCertHistory.setIpAddress(ipAddress);
        				tblDetachCertHistory.setCreatedOn(commonService.getServerDateTime());
        				tblDetachCertHistory.setCreatedBy(createdBy);
                        
                        TblUserCertificate tblUserCertificate = new TblUserCertificate();
                        tblUserCertificate.setUserCertId(Integer.parseInt(signingUserCertId));
                        tblUserCertificates.add(tblUserCertificate);
                        tblDetachCertHistorys.add(tblDetachCertHistory);
                        
                      }
	                if (encCertiId != null && !encCertiId.isEmpty()) {
	                	TblDCDetachHistory tblDetachCertHistory = new TblDCDetachHistory();
	                	
        				tblDetachCertHistory.setTblUserLogin(new TblUserLogin(Integer.parseInt(bidderId)));
        				tblDetachCertHistory.setTblCertificate(new TblCertificate(Integer.parseInt(encryCertId)));
        				tblDetachCertHistory.setTblClient(new TblClient(clientBean.getClientId()));
        				
        				int clientId = abcUtility.getSessionClientId(request);
        				int userTypeId = commonService.getUserTypeIdFromUserId(Integer.parseInt(bidderId), clientId);
        				int companyId=Integer.parseInt(commonService.getCompanyIdByUserId(Integer.parseInt(bidderId)).toString());
        				String ipAddress = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR) : request.getRemoteAddr();
        				
        				tblDetachCertHistory.setCompanyId(userTypeId==2?companyId:0);
        				tblDetachCertHistory.setIsDualCert(Integer.parseInt(encryIsDual));
        				tblDetachCertHistory.setKeyUsage(Integer.parseInt(encryKeyUsage));
        				tblDetachCertHistory.setIpAddress(ipAddress);
        				tblDetachCertHistory.setCreatedOn(commonService.getServerDateTime());
        				tblDetachCertHistory.setCreatedBy(createdBy);
                        
                        TblUserCertificate tblUserCertificate = new TblUserCertificate();
                        tblUserCertificate.setUserCertId(Integer.parseInt(encryUserCertId));
                        tblUserCertificates.add(tblUserCertificate);
                        tblDetachCertHistorys.add(tblDetachCertHistory);
                    }
            	success = manageBidderService.addDetachCertHistory(tblDetachCertHistorys,tblUserCertificates);
        	}
    	
        	retVal = "common/admin/detachdc/"+bidderId;
        	
        	if(signCertiId != null  &&  !signCertiId.isEmpty() && encCertiId != null && !encCertiId.isEmpty()){
        		msg = "reiderct_success_sinenc_detached_certificate";
        		msgAudit=auditDetachDcWithSignEnc;
        	}
        	else if (signCertiId != null  &&  !signCertiId.isEmpty()){
        		msg = "reiderct_success_sin_detached_certificate";
        		msgAudit=auditDetachDcWithSign;
        	}
        	else if (encCertiId != null && !encCertiId.isEmpty()){
        		msg = "reiderct_success_encr_detached_certificate";
        		msgAudit=auditDetachDcWithEnc;
        	}
        	
        	//Move bidder to incomplete status if we are detaching DC from the pending tab.
        	int[] bidderStatus = loginService.getBidderStatus(Integer.parseInt(bidderId), clientBean.getClientId());
        	if(signCertiId != null  &&  !signCertiId.isEmpty())
        	{
	        	if(bidderStatus[1]==0)
	        	{
	        		manageBidderService.updateRegistrationFinalStepBidderStatus(clientBean.getClientId(),Integer.parseInt(bidderId), 4, 5);
	        	}
        	}
    }
        catch(Exception ex){
        	retVal = "common/admin/detachdc/"+bidderId;
        	exceptionHandlerService.writeLog(ex);
        }
        finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),detachDCLinkId, msgAudit, 0,abcUtility.getSessionUserId(request));
        }
        redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? msg : CommonKeywords.ERROR_MSG_KEY.toString());
        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }
    
    //Aditya
    
    
    @RequestMapping(value = "/admin/selectbiddertype/{enc}", method = RequestMethod.GET)                       
    public String selectBidderType(HttpServletRequest request, ModelMap map){
    	String retVal = "redirect:/sessionexpired";
    	try {
    		List<SelectItem> bidderTypeList = new ArrayList<SelectItem>();
    		bidderTypeList.add(new SelectItem("Main user","Main user"));
    		bidderTypeList.add(new SelectItem("Sub user","Sub user"));
    		map.addAttribute("bidderTypeList",bidderTypeList);
    		retVal="SelectBidderType";
    	}catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}
    	
    	return retVal;
    }
    
    
    @RequestMapping(value = "/admin/submitusertype", method = RequestMethod.POST)
	public String submitUserType(HttpServletRequest request) {
		String retVal = "redirect:/sessionexpired";
		String userType = request.getParameter("seltypeOfUser") != null
				? request.getParameter("seltypeOfUser")
				: "Main user";
		try {
			if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
				switch (userType) {
				case "Main user":
					retVal = "redirect:/common/admin/registerbidderbyuser"
							+ encryptDecryptUtils.generateRedirect("common/admin/registerbidderbyuser", request);
					break;
				case "Sub user":
					retVal = "redirect:/common/admin/registersubbidderbyuser"
							+ encryptDecryptUtils.generateRedirect("common/admin/registersubbidderbyuser", request);
					break;

				}
			}
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}
		return retVal;
	}
    
    @RequestMapping(value = "/admin/registersubbidderbyuser/{enc}", method = RequestMethod.GET)                       
    public String registerSubBidderByUser(@ModelAttribute BidderRegistrationDataBean bidderRegistrationDataBean, HttpServletRequest request, ModelMap map){
    	String retVal="SubBidderRegistration";
    	return retVal;
    }
    
    @RequestMapping(value = "/admin/addsubbidderbyuser", method = RequestMethod.POST)                       
    public String addSubBidderByUser(@ModelAttribute BidderRegistrationDataBean bidderRegistrationDataBean,HttpServletRequest request, ModelMap map,BindingResult result, RedirectAttributes redirectAttributes){
    		int clientId = abcUtility.getSessionClientId(request);
    		String retVal="";
    		String mainUserEmailId=request.getParameter("txtMainUserEmailId");
    		String subUserEmailId=request.getParameter("txtSubUserEmailId");
    		String subUserName=request.getParameter("txtSubUserName");
    		String companyId=request.getParameter("jhdCompanyId");
    		
    		try {
    		TblCompany tblCompany = tblCompanyDao.findTblCompany("companyId",Operation_enum.EQ,Integer.valueOf(companyId)).get(0);
        	int userId = commonService.getUserIdByLoginId(mainUserEmailId);
        	int bidderId = commonService.getUserIdByLoginId(mainUserEmailId);
    		ArrayList<BidderRegistrationDataBean> bidderList = new ArrayList<>();
			BidderRegistrationDataBean bidderRegistrationDataBean1 = new BidderRegistrationDataBean();
//			String subUserEmailId=request.getParameter("txtEmailId_"+i);
//			String name=request.getParameter("txtFullName_"+j);
			if(subUserEmailId!= "" &&  subUserName!=null && subUserEmailId!=null &&  subUserName!="" ) {
			bidderRegistrationDataBean1.setTxtEmailId(subUserEmailId);
			 bidderRegistrationDataBean1.setTxtFullName(subUserName);
			 bidderRegistrationDataBean1.setTxtMobileNo("");
			 bidderRegistrationDataBean1.setTxtHintAns("");
			 bidderRegistrationDataBean1.setTxtUserPassword("");
			 bidderRegistrationDataBean1.setTxtConfirmPassword("");
			 bidderRegistrationDataBean1.setSelHintQue("1");
			 bidderRegistrationDataBean1.setSelTimezone(1);
			 
			 bidderRegistrationDataBean1.setTxtCity("");
			 bidderRegistrationDataBean1.setTxtWebsite("");
			 bidderRegistrationDataBean1.setTxtaAddress("");
			 bidderRegistrationDataBean1.setTxtPhone("");
			 bidderRegistrationDataBean1.setSelCountry(1);
			 bidderRegistrationDataBean1.setSelState("");
			 bidderRegistrationDataBean1.setTxtCompanyName(tblCompany.getCompanyName());
			 bidderRegistrationDataBean1.setHdCompanyId(tblCompany.getCompanyId());
			 
			 List<Object[]> clientDetails = commonService.getClientCountryStateTimezone(clientId);						 
				if (clientDetails != null && !clientDetails.isEmpty()) {
					bidderRegistrationDataBean1.setSelTimezone(Integer.parseInt(clientDetails.get(0)[0].toString()));
					bidderRegistrationDataBean1.setSelCountry(Integer.parseInt(clientDetails.get(0)[1].toString()));
					bidderRegistrationDataBean1.setSelState(clientDetails.get(0)[2].toString());
				}
										                                              
				addBidderSubBidder(bidderRegistrationDataBean1, result, request, redirectAttributes, map,Integer.valueOf(userId),Integer.valueOf(companyId),tblCompany);
				bidderRegistrationDataBean1.setHdBidderId(bidderId);
			 bidderList.add(bidderRegistrationDataBean1);
		 }					
		  	
		
			retVal = "redirect:/common/admin/managebidder"+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);

		redirectAttributes.addFlashAttribute("successMsg", "redirect_success_subbidder_registration");								
}
    
catch(Exception ex){
	return exceptionHandlerService.writeLog(ex);
} 
return retVal;
}


public String addBidderSubBidder(@ModelAttribute BidderRegistrationDataBean bidderRegistrationDataBean,
		BindingResult result, HttpServletRequest request, RedirectAttributes redirectAttributes,ModelMap modelMap, int parentUserId, int parentcompanyId,TblCompany tblCompany) {
	boolean success = false;
	String retVal = "";
	int userId = 0;
	int clientId = abcUtility.getSessionClientId(request);
	int contentManagementId = 0;
	String selectedCategory[] = null;
	String isCategoryAllow = "0";
	List<Object> busCatKeywords = null;

	ClientBean clientBean = (ClientBean) (request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null
					? request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()): null);
	try {
		// PT : #38537 by Jitendra. Don't allow bidder registration if register link
		// hidden starts.
		 String ipAddress = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR)
					: request.getRemoteAddr();
		boolean isRegistrationLinkHidden = clientService.isRegistrationLinkHidden(clientId, hideRegistrationLinkId,1);
		boolean isUserNotValid = clientService.isUserNotBlock(bidderRegistrationDataBean.getTxtEmailId(),
				bidderRegistrationDataBean.getTxtMobileNo(), 1);
		if (!isRegistrationLinkHidden && !isUserNotValid) {
			bidderRegistrationDataBean.setCommonValidators(commonValidators);

			List<LinkedHashMap<String, Object>> list = commonService.checkValidUserInClient(clientId,
					bidderRegistrationDataBean.getTxtEmailId(), 2);
			selectedCategory = request.getParameterValues("txtCategory");
			isCategoryAllow = request.getParameter("hdIsCategoryAllow");
			int bidderId = 0;
			int officerId = 0;
			int actionType = 0;
			if (list != null && !list.isEmpty()) {
				Map<String, Object> map  = list.get(0);
				if (map.get("actionType") != null) {
					actionType = Integer.parseInt(map.get("actionType").toString());
					bidderId = Integer.parseInt(map.get("bidderId").toString());
					officerId = Integer.parseInt(map.get("officerId").toString());
				}
			}
		
			if (isCategoryAllow != null && isCategoryAllow.equals("1") && selectedCategory != null) {
				busCatKeywords = commonService.getKeywordNamesByIds(selectedCategory);
				bidderRegistrationDataBean
						.setTxtaBusCatKeywords(abcUtility.converObjectArrayToCommas(busCatKeywords));
			}

			boolean isCheckPassword = true;
			boolean isCheckEmail = true;
			boolean isCheckHintQnA = true;
			if (actionType == 4 && officerId > 0) {
				isCheckHintQnA = false;
				isCheckPassword = false;
				isCheckHintQnA = false;
			} else if (clientBean.getIsDIYClient() == 1)// Skip QnA validation in DIY client
			{
				isCheckHintQnA = false;
			}

			bidderRegistrationDataBean.validate(result, isCheckEmail, isCheckPassword, isCheckHintQnA, actionType);
			String pass = null;
			
			if(actionType == 1) {
				pass = UUID.randomUUID().toString().substring(0, 4)+"@"+UUID.randomUUID().toString().substring(0, 4);
				String encryptedPassword = sha256HashEncryption.encodeStringSHA256(pass);
				bidderRegistrationDataBean.setTxtUserPassword(encryptedPassword);
				bidderRegistrationDataBean.setTxtConfirmPassword(encryptedPassword);						
				isCheckPassword = true;
			}

			if (actionType == 2 && bidderId > 0) {
				result.rejectValue("txtEmailId", "msg_js_registration_bidderexists",
						"Email id already registered as bidder on this domain");
			} else if (actionType == 2 && officerId > 0) {
				result.rejectValue("txtEmailId", "msg_js_registration_officerexists",
						"Email id already registered as department user on this domain");
			}

			String successMsgCode = "";
			String langId = WebUtils.getCookie(request, "locale").getValue();
			//Error
			 if (actionType == 3) {
				success = true;
				successMsgCode = "msg_js_registration_bidderprofileexists";
				retVal = "redirect:/";
			} else if (actionType != 3 && actionType != 2) {
				int bidderVerificationBy = clientService.getBidderRegistrationVerifiedBy(clientId);
				String verificationCode = "";
				if (bidderVerificationBy != 0 && bidderVerificationBy != 3) {
					verificationCode = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 10);
				} else {
					verificationCode = "0";
				}
				TblUserLogin tblUserLogin = null;
				int registrationWorkflowId = 0;
				if (actionType == 4) {
					List<TblUserLogin> tblUserLogins = commonService.getUserLoginById(officerId);
					if (tblUserLogins != null && !tblUserLogins.isEmpty()) {
						tblUserLogin = tblUserLogins.get(0);
					}
					registrationWorkflowId = manageBidderService.getClientRegWorkflowId(clientId,tblUserLogin.getIsEmailVerified() == 1 ? 3 : 0);
				} else {
					tblUserLogin = bidderRegistrationDataBean._toTblUserLogin(bidderVerificationBy,
							verificationCode, 0, 0);
					tblUserLogin.setTblClient(new TblClient(clientId));
					registrationWorkflowId = manageBidderService.getClientRegWorkflowId(clientId, 0);
				}

				int cstatus = cstatusIncomplete;
				
				if (registrationWorkflowId == 9) {
					cstatus = cstatusPending;
				}
				int isAutoApprove = Integer.parseInt(
						commonService.getField("TblClient", "isTwoStepBidderApproval", "clientId", clientId));
				if (isAutoApprove == 2) {
					registrationWorkflowId = 9;
					cstatus = 1;
				}
				
				// For CR #25825 - Keval Soni
				if (rciClientIds != null && !"".equals(rciClientIds)) {
					String[] rciIds = rciClientIds.split(",");
					if (rciIds.length != 0) {
						for (int i = 0; i < rciIds.length; i++) {
							if (!"".equals(rciIds[i])) {
								if (clientId == Integer.parseInt(rciIds[i])) {
									if (actionType == 1) {
										int clientCountryId = clientService.getCountryIdByClientId(clientId);
										int bidderCountryId = Integer.parseInt(request.getParameter("selCountry"));
										if (clientCountryId != bidderCountryId && registrationWorkflowId == 5) {
											registrationWorkflowId = 8;
											break;
										}
									}
								}
							}
						}
					}
				}

				contentManagementId = StringUtils.hasLength(request.getParameter("hdContentManagementId"))
						? Integer.parseInt(request.getParameter("hdContentManagementId").toString())
						: 0;
				TblBidderStatus tblBidderStatus = bidderRegistrationDataBean._toTblBidderStatus(clientId, cstatus,null, contentManagementId);
				tblBidderStatus.setTblRegistrationWorkflow(new TblRegistrationWorkflow(4));
				 
				if (tblUserLogin.getPasswordUpdatedOn() == null) {
					tblUserLogin.setPasswordUpdatedOn(commonService.getServerDateTime());
				}
				
				tblBidderStatus.setIsParentBidderId(parentUserId);
				tblBidderStatus.setTblCompany(tblCompany);
				tblBidderStatus.setIsAdminBidder(0);
				TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();// Bug:18917
				tblPasswordHistory.setCreatedOn(commonService.getServerDateTime());
				tblPasswordHistory.setOldPassword(tblUserLogin.getPassword());
				tblPasswordHistory.setPasswordUpdatedFrom(4);
				TblUserLogin tblUserLog = bidderRegistrationDataBean._toTblUserLogin(clientId, verificationCode, isAutoApprove, isAutoApprove);
				tblUserLog.setMobileNo("");
				tblUserLog.setUserName("");
				tblUserLogin.setIsFirstLogin(0);
				tblBidderStatus.setTblRegistrationWorkflow(new TblRegistrationWorkflow(4));
				 tblUserLogin.setIpAddress("");
				 
		        List<Object[]> clientCountryStateTimezone = commonService.getClientCountryStateTimezone(clientId);
		        tblUserLogin.setTblTimeZone(new TblTimeZone((Integer.valueOf(clientCountryStateTimezone.get(0)[0].toString()))));
				success = manageBidderService.addBidderRegistration(tblUserLogin,
						bidderRegistrationDataBean._toTblUserDetail(0),
						tblCompany, tblBidderStatus,
						bidderRegistrationDataBean._toTblUserHistory(userHistoryCreate, clientId),
						tblPasswordHistory, actionType);
				userId = tblUserLogin.getUserId();
				if (success) {
					// PT: 20745
					if (abcUtility.isModuleAssignToClient(request, 9) && isCategoryAllow != null
							&& isCategoryAllow.equals("1")) {// Module assign Spend Analysis
						commonService.insertUpdateCategory("edit", userId, selectedCategory, registrationLinkId);
					}
					success = dynamicFieldService.addDynamicFieldValueProcess(
							dynamicFieldService.dynFieldSetUp(request.getParameterMap(), request), clientId,
							manageBidderFieldValueId, userId, userId);
				}
				if (success && CommonUtility.isClientConditionExistInProperty(gslClientIds, clientId)) {// CR:29488
																										// GSL
																										// Bidder
																										// Registration
																										// only
					String chkRegisteredIn[] = request.getParameterValues("hchkRegisteredIn");
					List<Integer> bidderDocIdList = new ArrayList<Integer>();
					if (chkRegisteredIn != null && chkRegisteredIn.length > 0) {
						List<TblBidderRegisteredIn> tblBidderRegisteredInList = new ArrayList<TblBidderRegisteredIn>();
						for (String registeredInId : chkRegisteredIn) {
							TblBidderRegisteredIn tblBidderRegisteredIn = new TblBidderRegisteredIn();
							tblBidderRegisteredIn
									.setTblRegisteredIn(new TblRegisteredIn(Integer.parseInt(registeredInId)));
							tblBidderRegisteredIn.setRegisteredNo(
									request.getParameter("txtRegisteredNo_" + registeredInId).toString());
							tblBidderRegisteredIn.setTblUserLogin(new TblUserLogin(userId));
							tblBidderRegisteredIn.setTblClient(new TblClient(clientId));
							tblBidderRegisteredInList.add(tblBidderRegisteredIn);
							bidderDocIdList.add(Integer.parseInt(encryptDecryptUtils
									.decrypt(
											request.getParameter("uploadedBidderFile_" + registeredInId).toString())
									.toString()));
						}
						if (tblBidderRegisteredInList != null && !tblBidderRegisteredInList.isEmpty()) {
							manageBidderService.addBidderRegistreredIn(tblBidderRegisteredInList);
						}
					}
					String industryType = request.getParameterValues("selIndustryType")[0];
					int industryTypeId = StringUtils.hasLength(industryType) && !"".equals(industryType)
							? Integer.parseInt(industryType)
							: 0;
					String industryClassification = request.getParameterValues("selIndClassification")[0];
					int industryClassificationId = StringUtils.hasLength(industryClassification)
							&& !"".equals(industryClassification) ? Integer.parseInt(industryClassification) : 0;
					String registeredInNo = request.getParameter("registreredInCapAndNo").toString();
					registeredInNo = StringUtils.hasLength(registeredInNo) && !"".equals(registeredInNo)
							? registeredInNo
							: "";
					if (industryTypeId != 0 && industryClassificationId != 0) {
						TblBidderIndustry tblBidderIndustry = new TblBidderIndustry();
						tblBidderIndustry.setTblIndustryType(new TblIndustryType(industryTypeId));
						tblBidderIndustry.setTblIndustryClassification(
								new TblIndustryClassification(industryClassificationId));
						tblBidderIndustry.setTblUserLogin(new TblUserLogin(userId));
						tblBidderIndustry.setTblClient(new TblClient(clientId));
						tblBidderIndustry.setRegisteredIn(registeredInNo);
						tblBidderIndustry.setUpdatedOn(commonService.getServerDateTime());
						manageBidderService.addBidderIndustry(tblBidderIndustry);

						bidderDocIdList.add(Integer.parseInt(encryptDecryptUtils
								.decrypt(request.getParameter("uploadedBidderFile_0").toString()).toString()));
						fileUploadService.updateRegistedInBidderDocPath(bidderDocIdList, clientId, userId,
								request.getSession().getId().toString(), false);
					}
				}
				if(success) {
					boolean isRegister = wSCheckAvailService.registerSSA(bidderRegistrationDataBean,null,tblUserLogin.getUserId(),2,clientId,true);
					if(isRegister){
						loginService.updateLoginSSOStatus(userId);//Is bidder register in SSO,change SSO-status 0 to 1 in TblUserLogin
					}
					URL url = new URL(request.getRequestURL().toString());
					Map<String, Object> emailDataMap = new HashMap<String, Object>();
					emailDataMap.put("to", tblUserLogin.getLoginId());
					emailDataMap.put("subdomainname", url.getHost());
					emailDataMap.put("emailid", tblUserLogin.getLoginId());
					emailDataMap.put("password", pass);
					emailDataMap.put("SubDomainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
					emailDataMap.put("RegByAdminLink","<a href=\"/bidderregistrationByAdmin/"+tblUserLogin.getUserId() + "/"+ commonService.getCompanyIdByuserId(userId) + generateRedirect("bidderregistrationByAdmin/" + tblUserLogin.getUserId() + "/"+ commonService.getCompanyIdByuserId(userId),tblUserLogin.getUserName(), request)+"\">Registration Link</a>");
					
					Map<String, Object> mailParams = new HashMap<String, Object>();
					mailParams.put("to", tblUserLogin.getLoginId());
					mailParams.put("ClientName",clientService.getClientNameByClientId(abcUtility.getSessionClientId(request)));
					mailParams.put("RegisteredEmailID", tblUserLogin.getLoginId());
					mailParams.put("Password", pass);
					mailParams.put("SubDomainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
					
					boolean isGslClient = CommonUtility.isClientConditionExistInProperty(gslClientIds, clientId) && registrationWorkflowId==9; //for GSL client, sent mail to bidder for complete registration process as step-1
					switch (bidderVerificationBy) {
					case 3:
						if(actionType == 1) {
							if(isGslClient){
								mailContentUtillity.dynamicMailGeneration("241", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
							}else{
								mailContentUtillity.dynamicMailGeneration("18", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
							}
						} else {
							if(isGslClient){
								mailContentUtillity.dynamicMailGeneration("240", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
							}else{
								mailContentUtillity.dynamicMailGeneration("26", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");
							}
						}
					case 2:
						if(actionType == 1) {
							if(tblUserLogin.getIsEmailVerified() == 0) {
								emailDataMap.put("link1", "<a href=\"/authbiddermail/"+encryptDecryptUtils.encrypt(bidderRegistrationDataBean.getTxtEmailId()+"@@"+2+"_"+0)+"\">Email Verification Link</a>");
								mailContentUtillity.dynamicMailGeneration("19", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");
								// TODO :: Mobile verification code by SMS.
							} else {
								mailContentUtillity.dynamicMailGeneration("18", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
							}
						} else {
							mailContentUtillity.dynamicMailGeneration("26", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");
						}
						break;

					case 1:
						if(actionType == 1) {
							emailDataMap.put("link1", "<a href=\"/authbiddermail/"+encryptDecryptUtils.encrypt(bidderRegistrationDataBean.getTxtEmailId()+"@@"+2+"_"+0)+"/"+encryptDecryptUtils.encrypt(tblUserLogin.getVerificationCode())+"\">Email Verification Link</a>");
							mailContentUtillity.dynamicMailGeneration("20", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");  //This template is getting called
						} else {
							mailContentUtillity.dynamicMailGeneration("26", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");
						}
						break;

					case 0:
						if(actionType == 1) {
							if(isGslClient){
								mailContentUtillity.dynamicMailGeneration("241", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
							}else{
								mailContentUtillity.dynamicMailGeneration("18", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
							}
						} else {
							if(isGslClient){
								mailContentUtillity.dynamicMailGeneration("240", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
							}else{
								mailContentUtillity.dynamicMailGeneration("26", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");
							}
						}
						break;

					default:
						break;
					}
					// PT: 20745
					if(abcUtility.isModuleAssignToClient(request,9) && isCategoryAllow != null && isCategoryAllow.equals("1")){ // Module assign Spend Analysis and Statistic 
                    	commonService.insertUpdateCategory("edit",userId,selectedCategory,registrationLinkId);
                    }
					successMsgCode = "redirect_success_bidder_registration";
				}
				if (success && bidderVerificationBy == 3 && tblUserLogin.getIsMobileNoVerified() == 0) {
					// Mobile Number verification
					successMsgCode = "redirect_msg_otp_sent_registered_mobileno";
					retVal = "redirect:/registrationOTPGenerate/0/"
							+ encryptDecryptUtils.encrypt(String.valueOf(tblUserLogin.getUserId()));
				} else {
					retVal = "redirect:/";
				}

			}

			redirectAttributes.addFlashAttribute(
					success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(),
					success ? successMsgCode : CommonKeywords.ERROR_MSG_KEY.toString());
		} else {
			if (isUserNotValid) {
				String ipAddress2 = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR)
						: request.getRemoteAddr();
				Map<String, Object> mailParamsEmail = new HashMap<String, Object>();
				mailParamsEmail.put("ClientName", clientService.getClientNameById(clientId));
				mailParamsEmail.put("to", block_user_mail_Id);
				mailParamsEmail.put("emailId", bidderRegistrationDataBean.getTxtEmailId());
				mailParamsEmail.put("mobileNo", bidderRegistrationDataBean.getTxtMobileNo());
				mailParamsEmail.put("ipAddress", ipAddress);
				mailContentUtillity.dynamicMailGeneration("360", String.valueOf(userId), String.valueOf(clientId),
						mailParamsEmail, "");
				redirectAttributes.addFlashAttribute("phoneno", contact_phoneno);
				redirectAttributes.addFlashAttribute("emailId", contact_emailId);
				redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),
						"redirect_registration_not_allow_contact");
				retVal = "redirect:/";
			} else {
				redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),
						"redirect_registration_not_allow");
				retVal = "redirect:/";
			}

		}
	} catch (Exception ex) {
		return exceptionHandlerService.writeLog(ex);
	} finally {
		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
				registrationLinkId, auditBidderRegistered, 0, userId);
	}
	return retVal;
}

@RequestMapping(value = "/admin/sendregistrationlink/{bidderId}/{enc}", method = RequestMethod.GET)                       
public String sendRegistrationLink(@PathVariable("bidderId") int bidderId, @ModelAttribute BidderRegistrationDataBean bidderRegistrationDataBean, HttpSession session, HttpServletRequest request, ModelMap map,RedirectAttributes redirectAttributes){
	
	try {
		URL url = new URL(request.getRequestURL().toString());
		Map<String, Object> emailDataMap = new HashMap<String, Object>();
		List<Object> data=loginService.getLoginIdByUserId(bidderId);
		String loginId=!data.isEmpty() ? (String) data.get(0) : "";
		int clientId = abcUtility.getSessionClientId(request);
		int companyId=Integer.parseInt(commonService.getCompanyIdByUserId(bidderId).toString());
		
		emailDataMap.put("to", loginId);
		emailDataMap.put("subdomainname", url.getHost());
		emailDataMap.put("emailid", loginId);
		emailDataMap.put("SubDomainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
		emailDataMap.put("RegByAdminLink","<a href=\"/bidderregistrationByAdmin/"+bidderId + "/"+ companyId +encryptDecryptUtils.generateRedirect("bidderregistrationByAdmin/" + bidderId + "/"+ companyId,request)+"\">Registration Link</a>");
		mailContentUtillity.dynamicMailGeneration("20", String.valueOf(bidderId), String.valueOf(clientId), emailDataMap,"");		
	}catch (Exception ex) {
		return exceptionHandlerService.writeLog(ex);
	}
	String retVal="redirect:/common/admin/managebidder"+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
	String successMsgCode = "redirect_success_bidder_registration_link_sent";
	redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),successMsgCode);
	return retVal;
}

//SubBidderMail_encryptDecrypt
 public String generateRedirect(String href, String userName, HttpServletRequest request) {
		StringBuilder data = new StringBuilder();
		Object sessionStr = userName;
		boolean ISSECURE = true;
		data.append("/").append(ISSECURE ? encryptDecryptUtils.encrypt(href + sessionStr.toString()) : "abc123");
		return data.toString();
}

}
