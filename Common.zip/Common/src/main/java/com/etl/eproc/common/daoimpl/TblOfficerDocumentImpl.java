package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblOfficerDocumentDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblOfficerDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblOfficerDocumentImpl extends AbcAbstractClass<TblOfficerDocument> implements TblOfficerDocumentDao {

    @Override
    public void addTblOfficerDocument(TblOfficerDocument tblOfficerDocument){
        super.addEntity(tblOfficerDocument);
    }

    @Override
    public void deleteTblOfficerDocument(TblOfficerDocument tblOfficerDocument) {
        super.deleteEntity(tblOfficerDocument);
    }

    @Override
    public void updateTblOfficerDocument(TblOfficerDocument tblOfficerDocument) {
        super.updateEntity(tblOfficerDocument);
    }

    @Override
    public List<TblOfficerDocument> getAllTblOfficerDocument() {
        return super.getAllEntity();
    }

    @Override
    public List<TblOfficerDocument> findTblOfficerDocument(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblOfficerDocumentCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblOfficerDocument> findByCountTblOfficerDocument(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblOfficerDocument(List<TblOfficerDocument> tblOfficerDocuments){
        super.updateAll(tblOfficerDocuments);
    }

	@Override
	public void saveOrUpdateTblOfficerDocument(TblOfficerDocument tblOfficerDocument) {
		super.saveOrUpdateEntity(tblOfficerDocument);
	}
}
