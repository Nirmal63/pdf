package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientCurrency;
import java.util.List;

public interface TblClientCurrencyDao  {

    public void addTblClientCurrency(TblClientCurrency tblClientCurrency);

    public void deleteTblClientCurrency(TblClientCurrency tblClientCurrency);

    public void updateTblClientCurrency(TblClientCurrency tblClientCurrency);

    public List<TblClientCurrency> getAllTblClientCurrency();

    public List<TblClientCurrency> findTblClientCurrency(Object... values) throws Exception;

    public List<TblClientCurrency> findByCountTblClientCurrency(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientCurrencyCount();

    public void saveUpdateAllTblClientCurrency(List<TblClientCurrency> tblClientCurrencys);
}