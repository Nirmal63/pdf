package com.etl.eproc.common.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.databean.MailDataBean;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblMessage;
import com.etl.eproc.common.model.TblMessageDetail;
import com.etl.eproc.common.model.TblMessageFolder;
import com.etl.eproc.common.model.TblTaskList;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.services.MailBoxService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;

/**
 * @author nirav.modi
 *
 */
@Controller
@RequestMapping(value="common")
public class MailBoxController {
	private static final String SESSION_OBJECT="sessionObject";
	private static final String TXT_LINKID ="txtlinkId";
	private static final String TXT_OBJECTID ="txtobjectId";
	private static final String TXT_DOCID ="txtdocIds";
	@Autowired
    private CommonService commonService;
	@Autowired
    private ExceptionHandlerService exceptionHandlerService;
	@Autowired
	private MailBoxService mailBoxService;
	@Autowired
	private AbcUtility abcUtility;
	@Autowired
    private FileUploadService fileUploadService;
	@Autowired
	private EncryptDecryptUtils encryptDecryptUtils;
	@Autowired
	private ConversionService conversionService;
	@Autowired
	private AuditTrailService auditTrailService;
	@Autowired
	private ReportGeneratorService reportGeneratorService;
	@Autowired
    private MessageSource messageSource;
	@Autowired
    private LoginService loginService;
	
	@Value("#{linkProperties['report_todo_list']?:51}")
	private int toDoListingReportId;
	@Value("#{linkProperties['message_box_mail_attachment']?:464}")
	private int mailAttachmentLinkId;
	@Value("#{linkProperties['message_box_message_box_add_task']?:747}")
	private int addTaskLinkId;
	@Value("#{linkProperties['message_box_message_box_edit_task']?:748}")
	private int editTaskLinkId;
	@Value("#{linkProperties['message_box_message_box_delete_task']?:749}")
	private int deleteTaskLinkId;
	@Value("#{adminAuditTrailProperties['getAddTask']}")
    private String getAddTaskAuditMsg;
	@Value("#{adminAuditTrailProperties['postAddTask']}")
    private String postAddTaskAuditMsg;
	@Value("#{adminAuditTrailProperties['getEditTask']}")
    private String getEditTaskAuditMsg;
	@Value("#{adminAuditTrailProperties['postEditTask']}")
    private String postEditTaskAuditMsg;
	@Value("#{adminAuditTrailProperties['postDeleteTask']}")
    private String postDeleteTaskAuditMsg;
	private static final String REDIRECT_SESSION_EXPIRED = "redirect:/sessionexpired";
	
	@RequestMapping(value="/maildashboard/{operationType}/{folderId}/{enc}",method=RequestMethod.GET)
    public String mailDashboard(@PathVariable(value="operationType") int operationType,@PathVariable(value="folderId") int folderId,HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) {
		Object[] folderDetails=mailBoxService.getFoldersById(folderId);
		if(folderDetails!=null){
			modelMap.addAttribute("folderName", folderDetails[1]);
			modelMap.addAttribute("txtOperationType", operationType);
		}
		return "common/MailDashboard";
	}
	@ResponseBody
	@RequestMapping(value="/getfolernamebyid",method=RequestMethod.POST)
    public String getFolderNameById(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) {
		int folderId = StringUtils.hasLength(request.getParameter("hdFolderId"))?Integer.parseInt(request.getParameter("hdFolderId")):1;
		Object[] folderDetails=mailBoxService.getFoldersById(folderId);
		return folderDetails[1].toString();
	}
	@RequestMapping(value="/draftmaildashboard/{operationType}/{folderId}/{messageId}/{messageDetailId}/{enc}",method=RequestMethod.GET)
    public String drafMailDashboard(@PathVariable(value="operationType") int operationType,@PathVariable(value="folderId") int folderId,@PathVariable(value="messageId") int messageId,@PathVariable(value="messageDetailId") int messageDetailId,HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) {
		Object[] folderDetails=mailBoxService.getFoldersById(folderId);
		if(folderDetails!=null){
			modelMap.addAttribute("folderName", folderDetails[1]);
			modelMap.addAttribute("txtOperationType", operationType);
		}
		return "common/MailDashboard";
	}
	/*@RequestMapping(value="/maildashboard/{labelId}/{operationType}/{folderId}/{enc}",method=RequestMethod.GET)
    public String updatelabel(@PathVariable(value="labelId") int labelId,@PathVariable(value="operationType") int operationType,@PathVariable(value="folderId") int folderId,HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) {
		return "common/MailDashboard";
	}*/
	
	@RequestMapping(value="/searchmailcontent",method=RequestMethod.POST)
	public String searchMailContent(@RequestParam("txtOperationType") int operationType,HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) {
		String retVal="sessionexpired";
		int userId = abcUtility.getSessionUserId(request);
		if(userId!=0){
			try {
				modelMap.addAttribute("txtOperationType", operationType);
				int folderId = StringUtils.hasLength(request.getParameter("hdFolderId"))?Integer.parseInt(request.getParameter("hdFolderId")):1;
				int pageNo = StringUtils.hasLength(request.getParameter("txtPageNo"))?Integer.parseInt(request.getParameter("txtPageNo")):1;
				String keyword = request.getParameter("txtKeyword");
				String txtKeywordWith = request.getParameter("txtKeywordWith");
				String txtTo = request.getParameter("txtTo");
				String txtFrom = request.getParameter("txtFrom");
				String txtSubject = request.getParameter("txtSubject");
				String selFolderWise = StringUtils.hasLength(request.getParameter("selFolderWise"))?request.getParameter("selFolderWise"):"";
				String txtDateTo = request.getParameter("txtDateTo");
				String txtDateFrom = request.getParameter("txtDateFrom");
				String txtSorting = StringUtils.hasLength(request.getParameter("txtSorting"))?request.getParameter("txtSorting"):"3";
				String txtSortingOrder1 = request.getParameter("txtSortingOrder1");
				String txtSortingOrder2 = request.getParameter("txtSortingOrder2");
				String txtSortingOrder3 = StringUtils.hasLength(request.getParameter("txtSortingOrder3"))?request.getParameter("txtSortingOrder3"):"1";
				
				if(StringUtils.hasLength(txtKeywordWith)){
					keyword=txtKeywordWith.trim();
				}
				Map<String,Object> searchCriteriaMap = new HashMap<String, Object>();
				searchCriteriaMap.put("txtTo",txtTo.trim());
				searchCriteriaMap.put("txtFrom",txtFrom.trim());
				searchCriteriaMap.put("txtSubject",txtSubject.trim());
				searchCriteriaMap.put("selFolderWise",selFolderWise.trim());
				searchCriteriaMap.put("txtSorting",txtSorting.trim());
				searchCriteriaMap.put("txtDateTo",StringUtils.hasLength(txtDateTo.trim())?CommonUtility.convertUtcTimezone(txtDateTo.trim()):"");
				searchCriteriaMap.put("txtDateFrom",StringUtils.hasLength(txtDateFrom.trim())?CommonUtility.convertUtcTimezone(txtDateFrom.trim()):"");
				if(txtSorting.trim().equals("1") || txtSorting.trim().equals("4")){
					searchCriteriaMap.put("txtSortingOrder",txtSortingOrder1);
					modelMap.addAttribute("SortSqu1", txtSortingOrder1);
				}
				else if(txtSorting.trim().equals("2")){
					searchCriteriaMap.put("txtSortingOrder",txtSortingOrder2);
					modelMap.addAttribute("SortSqu2", txtSortingOrder2);
				}
				else if(txtSorting.trim().equals("3")){
					searchCriteriaMap.put("txtSortingOrder",txtSortingOrder3);
					modelMap.addAttribute("SortSqu3", txtSortingOrder3);
				}
				getInboxDetails(userId,folderId,modelMap,pageNo,keyword,searchCriteriaMap,abcUtility.getSessionClientId(request));
				modelMap.addAttribute("SortOrd", txtSorting);
			
			} catch (Exception e) {
				e.printStackTrace();
			}
			retVal="common/SearchMail";
		}
		return retVal;
	}
	
	@RequestMapping(value="/mailcontent",method=RequestMethod.POST)
    public String mailContent(@RequestParam("txtOperationType") int operationType,HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) {
        try {
        	int userId = abcUtility.getSessionUserId(request);
        	int clientId = abcUtility.getSessionClientId(request);
        	if(userId!=0){
        		modelMap.addAttribute("txtOperationType", operationType);
        		int hdsfolderId=StringUtils.hasLength(request.getParameter("hdFolderId"))?Integer.parseInt(request.getParameter("hdFolderId")):1;
        		modelMap.addAttribute("hdFolderId", hdsfolderId);
        		MailDataBean mailDataBean = new MailDataBean();
    			switch(operationType){
    				case 1://compose
    					modelMap.addAttribute("messageId", 0);
    					mailDataBean.setParentMessageId(0);
    					mailDataBean.setActionType(1);
    					modelMap.put("mailDataBean", mailDataBean);
    					//get the max size and format from DB.
    					getUploadDocConfigDetails(clientId, modelMap);
    					break;
    				case 2:// Inbox
    					int folderId = StringUtils.hasLength(request.getParameter("hdFolderId"))?Integer.parseInt(request.getParameter("hdFolderId")):1;
    					int pageNo = StringUtils.hasLength(request.getParameter("txtPageNo"))?Integer.parseInt(request.getParameter("txtPageNo")):1;
    					String keyword = request.getParameter("txtKeyword");
    					getInboxDetails(userId,folderId,modelMap,pageNo,keyword,null, abcUtility.getSessionClientId(request));//By default inbox
    					break;
    				case 3:// View Mail operation
    					int messageDetailId = StringUtils.hasLength(request.getParameter("hdMessageDetailId"))?Integer.parseInt(request.getParameter("hdMessageDetailId")):0;
    					int messageId = StringUtils.hasLength(request.getParameter("hdMessageId"))?Integer.parseInt(request.getParameter("hdMessageId")):0;
    					StringBuilder toEmailIds = new StringBuilder(); 
						StringBuilder ccEmailIds = new StringBuilder(); 
    					if(messageDetailId!=0 && messageId!=0){
    						List<Object[]> mailDetailList=mailBoxService.viewMail(messageId,4);
    					
    						//TO ,cc String build
    						for(Object[] mailDetailArrObj : mailDetailList){
    							if((Integer)mailDetailArrObj[3]==2){//Send Type = 2 then CC & Not the own
    								ccEmailIds.append(mailDetailArrObj[12]).append(",");
    							}
    							if( (Integer)mailDetailArrObj[3]==1){// || (Integer)mailDetailArrObj[3]==3)){//Send Type = 1 then TO excet sender & 3 for sender         //(Integer)mailDetailArrObj[0]!=userId
    								toEmailIds.append(mailDetailArrObj[12]).append(",");
    							}
							}
							if(toEmailIds.toString().endsWith(",")){
								toEmailIds.deleteCharAt(toEmailIds.length()-1);
							}
							if(ccEmailIds.toString().endsWith(",")){
								ccEmailIds.deleteCharAt(ccEmailIds.length()-1);
							}
							modelMap.addAttribute("toEmailIds",toEmailIds);
							modelMap.addAttribute("ccEmailIds",ccEmailIds.toString());
    						modelMap.addAttribute("folders", abcUtility.convert(mailBoxService.getFoldersByUserId(userId,clientId)));
    						mailDetailList=mailBoxService.viewMail(messageDetailId,3);
    						modelMap.addAttribute("mailDetailList", mailDetailList);
    						if(mailDetailList!=null && !mailDetailList.isEmpty()){
    							Object[] mailDetailArr= mailDetailList.get(0);
    							if(mailDetailArr!=null && mailDetailArr.length!=0){
    								if((Integer)mailDetailArr[9]==1){//For attachment
    									if((Integer)mailDetailArr[15] ==1 || (Integer)mailDetailArr[15] == 3){
    										modelMap.addAttribute("uploadedDocumentList", fileUploadService.getOfficerDocs((Integer)mailDetailArr[1], clientId, mailAttachmentLinkId, 1));
    									}else if((Integer)mailDetailArr[15] == 2){
    										modelMap.addAttribute("uploadedDocumentList", fileUploadService.getBidderDocs((Integer)mailDetailArr[1], clientId, mailAttachmentLinkId, 1,(Integer)mailDetailArr[7]));
    									}
    									modelMap.addAttribute("usertypeIds",(Integer)mailDetailArr[15]);
    								}
    								if((Integer)mailDetailArr[4]==0){//Mail read
    									mailBoxService.readMail(String.valueOf(messageDetailId),1);
    								}
    							}
    						}
    					}
    					break;
    				case 4:// Get Draft Mail operation
    					 messageDetailId = StringUtils.hasLength(request.getParameter("hdMessageDetailId"))?Integer.parseInt(request.getParameter("hdMessageDetailId")):0;
    					 messageId = StringUtils.hasLength(request.getParameter("hdMessageId"))?Integer.parseInt(request.getParameter("hdMessageId")):0;
    					if(messageId!=0){
    						List<Object[]> mailDetailList=mailBoxService.viewMail(messageId,4);
    						List<Object[]> docList=null;
    						modelMap.addAttribute("mailDetailList", mailDetailList);
    						if(mailDetailList!=null && !mailDetailList.isEmpty()){
    							Object[] mailDetailArr= mailDetailList.get(0);
    							if(mailDetailArr!=null && mailDetailArr.length!=0){
    								if((Integer)mailDetailArr[9]==1){//For Attachment details
    									if((Integer)mailDetailArr[15] ==1 || (Integer)mailDetailArr[15] == 3){
    										docList=fileUploadService.getOfficerDocs((Integer)mailDetailArr[1], clientId, mailAttachmentLinkId, 1);
    									}else if((Integer)mailDetailArr[15] == 2){
    										docList=fileUploadService.getBidderDocs((Integer)mailDetailArr[1], clientId, mailAttachmentLinkId, 1,(Integer)mailDetailArr[7]);
    									}
    									if(docList!=null && !docList.isEmpty()){
    										StringBuilder docIds=new StringBuilder();
    										modelMap.addAttribute("uploadedDocumentList",docList);
    										for(Object [] docArr : docList){
    											docIds.append(docArr[0]).append(",");
    										}
    										docIds=docIds.deleteCharAt(docIds.length()-1);
    										mailDataBean.setDocIds(docIds.toString());
    									}
    								}
    								mailDataBean.setSubject((String)mailDetailArr[5]);
    								mailDataBean.setMessageText((String)mailDetailArr[6]);
    								mailDataBean.setIsDocUpload((Integer)mailDetailArr[9]);
    								mailDataBean.setParentMessageId((Integer)mailDetailArr[8]);
    								mailDataBean.setActionType((Integer)mailDetailArr[10]);
    							}
    							 toEmailIds = new StringBuilder(); 
    							 ccEmailIds = new StringBuilder(); 
    							for(Object[] mailDetailArrObj : mailDetailList){
    								if((Integer)mailDetailArrObj[3]==1){//Send Type = 1 then To 
    									toEmailIds.append(mailDetailArrObj[12]).append(",");
    								}else if((Integer)mailDetailArrObj[3]==2){//Send Type = 2 then CC
    									ccEmailIds.append(mailDetailArrObj[12]).append(",");
    								}
    							}
    							if(toEmailIds.toString().endsWith(",")){
    								toEmailIds.deleteCharAt(toEmailIds.length()-1);
    							}
    							if(ccEmailIds.toString().endsWith(",")){
    								ccEmailIds.deleteCharAt(ccEmailIds.length()-1);
    							}
    							mailDataBean.setToEmailIds(toEmailIds.toString());
    							mailDataBean.setCcEmailIds(ccEmailIds.toString());
    							modelMap.addAttribute("mailDataBean", mailDataBean);
    							modelMap.addAttribute("messageId", messageId);
    							modelMap.addAttribute("isDraft",true);
    							//unread the mail
    							mailBoxService.readMail(messageDetailId+"", 1);
    							//get Doc Config
    							getUploadDocConfigDetails(clientId, modelMap);
    						}
    					}
    					break;
    				case 5:// Get Reply Mail operation
    					messageDetailId = StringUtils.hasLength(request.getParameter("hdMessageDetailId"))?Integer.parseInt(request.getParameter("hdMessageDetailId")):0;
    					if(messageDetailId!=0){
    						int actionType=2;
    						getReplyMailDetail(mailDataBean,modelMap,messageDetailId,clientId,operationType,actionType,userId);
    					}
    					break;
    				case 6:// Get Reply All Mail operation
    					messageId = StringUtils.hasLength(request.getParameter("hdMessageId"))?Integer.parseInt(request.getParameter("hdMessageId")):0;
    					if(messageId!=0){
    						int actionType=3;
    						getReplyMailDetail(mailDataBean,modelMap,messageId,clientId,operationType,actionType,userId);
    					}
    					break;
    				case 7:// Get Forward Mail operation
    					messageDetailId = StringUtils.hasLength(request.getParameter("hdMessageDetailId"))?Integer.parseInt(request.getParameter("hdMessageDetailId")):0;
    					if(messageDetailId!=0){
    						int actionType=4;
    						getReplyMailDetail(mailDataBean,modelMap,messageDetailId,clientId,operationType,actionType,userId);
    					}
    					break;
    				case 8: /*For To Do List*/
    					messageDetailId = StringUtils.hasLength(request.getParameter("hdMessageDetailId"))?Integer.parseInt(request.getParameter("hdMessageDetailId")):0;
    					if(messageDetailId!=0){
							List<Object[]> lstMessage = mailBoxService.getMessage(messageDetailId);
							if(lstMessage!=null && !lstMessage.isEmpty()){
								modelMap.addAttribute("mailSubject", lstMessage.get(0)[0]);
								modelMap.addAttribute("mailDescription", lstMessage.get(0)[1]);
							}
    					}
						break;
    				case 9: /*Create label*/
    					if(userId!=0){
    						List<Object[]> folderDetails=mailBoxService.getFoldersByUserId(userId,clientId);
    						modelMap.addAttribute("folderDetails",folderDetails);
    					}
						break;	
    				case 10: /*get label details*/
    					if(userId!=0){
    						List<Object[]> folderDetails=mailBoxService.getFoldersByUserId(userId,clientId);
    						modelMap.addAttribute("folderDetails",folderDetails);
    					}
						break;	
    			}
    		}
        } catch (Exception e) {
        	exceptionHandlerService.writeLog(e);
        } finally {
//       	 makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, 0, 0, 0);
        }
        return "common/MailContent";
    }
	
	private void getUploadDocConfigDetails(int clientId,ModelMap modelMap) throws Exception
	{
		List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(102, clientId);
        int allowedSize = 0;
        StringBuilder allowedExt = new StringBuilder();
        if(lstDocUploadConf != null && !lstDocUploadConf.isEmpty()){
        	allowedSize = lstDocUploadConf.get(0).getMaxSize();
        	allowedExt.append(lstDocUploadConf.get(0).getType());
        	modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
        }
        int index = allowedExt.toString().indexOf(",");
        allowedExt.insert(index + 1, "*.");
        while (index >= 0) {
            index = allowedExt.toString().indexOf(",", index + ",".length());
            allowedExt.insert(index + 1, "*.");
        }
        modelMap.addAttribute("allowedExt", allowedExt);
        modelMap.addAttribute("allowedSize", allowedSize/1024);
        modelMap.put("allowFileExist", "y");
	}
	
	@ResponseBody
	@RequestMapping(value="/removelabel",method=RequestMethod.POST)
	private String removeLabel(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap)
	{
		boolean success = false;
		String retVal="sessionexpired";
		int userId= abcUtility.getSessionUserId(request);
		try {
			int createdBy= abcUtility.getSessionUserDetailId(request);
			
			int folderId = StringUtils.hasLength(request.getParameter("folderId"))?Integer.parseInt(request.getParameter("folderId")):0;
			if(userId!=0 && createdBy !=0 ){
				
				success=mailBoxService.removeLabel(folderId);
				retVal="$10@@";
			}
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		}
		finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, "label deleted successfully", 0,0);
		}
		return success?retVal:userId==0?retVal:"error";
	}
	@RequestMapping(value="/getlabeldetail/{labelId}/{txtOperationType}/{hdFolderId}/{enc}",method=RequestMethod.GET)
	private String getlabeldetail(@PathVariable("labelId")Integer labelId,@PathVariable("txtOperationType") int operationType,@PathVariable("hdFolderId") String hdFolderId,HttpServletRequest request,HttpServletResponse response, ModelMap modelMap)
	{
		String retVal="common/ManageMailLabel";
		int userId = abcUtility.getSessionUserId(request);
    	int clientId = abcUtility.getSessionClientId(request);
    	if(userId!=0){
    		modelMap.addAttribute("txtOperationType", operationType);
    		modelMap.addAttribute("hdFolderId", hdFolderId);
    	}
		Object[] folderDetails=mailBoxService.getFoldersById(labelId);
		if(folderDetails!=null && folderDetails.length>0)
			modelMap.addAttribute("folderobj",folderDetails);
		List<Object[]> ListfolderDetails=mailBoxService.getFoldersByUserId(userId,clientId);
		modelMap.addAttribute("folderDetails",ListfolderDetails);
		modelMap.addAttribute("isLabelUpdate",true);
		return retVal;
	}
	
	@ResponseBody
	@RequestMapping(value="/updatelabel", method=RequestMethod.POST)
	public String updatelabel(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap, RedirectAttributes redirectAttributes){
		
		boolean success = false;
		String retVal="sessionexpired";
		int userId= abcUtility.getSessionUserId(request);
		try {
			int createdBy= abcUtility.getSessionUserDetailId(request);
			String txtLabelName = request.getParameter("txtLabelName");
			int hdLabelId = StringUtils.hasLength(request.getParameter("hdLabelId"))?Integer.parseInt(request.getParameter("hdLabelId")):0;
			if(userId!=0 && createdBy !=0 && StringUtils.hasLength(txtLabelName)){
				TblMessageFolder tblMessageFolder = new TblMessageFolder();
				tblMessageFolder.setFolderId(hdLabelId);
				tblMessageFolder.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
				tblMessageFolder.setCreatedBy(createdBy);
				tblMessageFolder.setFolderName(txtLabelName);
				tblMessageFolder.setUserId(userId);
				
				success=mailBoxService.updateLabel(tblMessageFolder);
				retVal="$10@@";
			}
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		}
		finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, "label updated successfully", 0,0);
		}
		return success?retVal:userId==0?retVal:"error";
	}
	private void getReplyMailDetail(MailDataBean mailDataBean, ModelMap modelMap, int messageDetailId,int clientId,int operationType, int actionType,int userId) throws Exception {
		List<Object[]> mailDetailList=mailBoxService.viewMail(messageDetailId,actionType==2 || actionType==4 ? 3 : 4);
		modelMap.addAttribute("mailDetailList", mailDetailList);
		List<Object[]> docList=null;
		if(mailDetailList!=null && !mailDetailList.isEmpty()){
			Object[] mailDetailArr= mailDetailList.get(0);
			if(mailDetailArr!=null && mailDetailArr.length!=0){
				if((Integer)mailDetailArr[9]==1){//For Attachment details
					if((Integer)mailDetailArr[15] ==1 || (Integer)mailDetailArr[15] == 3){
						docList=fileUploadService.getOfficerDocs((Integer)mailDetailArr[1], clientId, mailAttachmentLinkId, 1);
					}else if((Integer)mailDetailArr[15] == 2){
						docList=fileUploadService.getBidderDocs((Integer)mailDetailArr[1], clientId, mailAttachmentLinkId, 1,(Integer)mailDetailArr[7]);
					}
					modelMap.addAttribute("usertypeIds",(Integer)mailDetailArr[15]);
					if(docList!=null && !docList.isEmpty()){
						StringBuilder docIds=new StringBuilder();
						modelMap.addAttribute("uploadedDocumentList",docList);
						for(Object [] docArr : docList){
							docIds.append(docArr[0]).append(",");
						}
						docIds=docIds.deleteCharAt(docIds.length()-1);
						mailDataBean.setDocIds(docIds.toString());
					}
				}
				mailDataBean.setActionType(actionType);
				mailDataBean.setFromEmailId((String)mailDetailArr[13]);//From emailId
				mailDataBean.setSubject((String)mailDetailArr[5]);
				mailDataBean.setMessageText((String)mailDetailArr[6]);
				mailDataBean.setIsDocUpload((Integer)mailDetailArr[9]);
				mailDataBean.setParentMessageId((Integer)mailDetailArr[1]);
				modelMap.addAttribute("messageId",0);
			}
			StringBuilder ccEmailIds = new StringBuilder(); 
			StringBuilder ToEmailIds = new StringBuilder(); 
			for(Object[] mailDetailArrObj : mailDetailList){
				if((Integer)mailDetailArrObj[0]!=userId && (Integer)mailDetailArrObj[3]==2){//Send Type = 2 then CC & Not the own
					ccEmailIds.append(mailDetailArrObj[12]).append(",");
				}
				if((Integer)mailDetailArrObj[0]!=userId && (Integer)mailDetailArrObj[3]==3){//Send Type = 1 then TO excet sender & 3 for sender
					ToEmailIds.append(mailDetailArrObj[12]).append(",");
				}
				else if(actionType == 3 && (Integer)mailDetailArrObj[0]==userId && (Integer)mailDetailArrObj[3]==3){//ReplyAll
					ToEmailIds.append(mailDetailArrObj[12]).append(",");
				}
			}
			if(ccEmailIds.toString().endsWith(",")){
				ccEmailIds.deleteCharAt(ccEmailIds.length()-1);
			}
			if(ToEmailIds.toString().endsWith(",")){
				ToEmailIds.deleteCharAt(ToEmailIds.length()-1);
			}
			mailDataBean.setToEmailIds(ToEmailIds.toString());
			mailDataBean.setCcEmailIds(ccEmailIds.toString());
			mailDataBean.setOperationType(operationType);
			modelMap.addAttribute("mailDataBean", mailDataBean);
			modelMap.addAttribute("messageDetailId", messageDetailId);
			//get upload Config details
			getUploadDocConfigDetails(clientId, modelMap);
		}
	}

	private void getInboxDetails(int userId,int folderId, ModelMap modelMap,int pageNo,String keyword,Map<String, Object> searchCriteriaMap,int clientId) throws Exception {
		int pagePerRecordN=20;
		modelMap.addAttribute("folderId", folderId);
		Map<String, Object> dataMap =mailBoxService.getInboxDetails(userId,folderId,clientId,pagePerRecordN,pageNo,keyword,searchCriteriaMap);
    	if (dataMap != null && !dataMap.isEmpty()) {
    		List<Map<String, Object>> folderList = (List<Map<String, Object>>) dataMap.get("#result-set-1");
			List<SelectItem> searchFolderItems= new ArrayList<SelectItem>();
    		if(folderList!=null && !folderList.isEmpty()){
    			List<SelectItem> folderItems= new ArrayList<SelectItem>();
    			for(Map<String, Object> data: folderList){
    				if((Integer)data.get("folderId")==folderId){//To display folder Name
    					modelMap.addAttribute("folderName",data.get("folderName"));
    				}
    				if((Integer)data.get("userId")!=0 && (Integer)data.get("folderId")!=folderId){//User folder 
    					folderItems.add(new SelectItem(data.get("folderName"), data.get("folderId")));
    				}
    				searchFolderItems.add(new SelectItem(data.get("folderName"), data.get("folderId")));
    			}
    			modelMap.addAttribute("folders"  ,folderItems);
    		}
    		modelMap.addAttribute("searchFolders",searchFolderItems);
    		modelMap.addAttribute("markList",mailBoxService.getMarkList());
    		modelMap.addAttribute("inboxDetails"   ,dataMap.get("#result-set-2"));
    		List<Map<String, Object>> paginationDetailsList = (List<Map<String, Object>>) dataMap.get("#result-set-3");
    		if(paginationDetailsList!=null && !paginationDetailsList.isEmpty()){
    			modelMap.addAttribute("paginationMap" ,paginationDetailsList.get(0));
    		}
    	}
	}

	@ResponseBody
	@RequestMapping(value="/mailoperation",method=RequestMethod.POST)
	public String mailOperation(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap,HttpSession session) {
		int objectId=-1;
		boolean success=false;
		StringBuilder retVal=new StringBuilder();
		int userId = 0;
		try {
			// send operation
			userId=abcUtility.getSessionUserId(request);
			String txtHidDocIds=null;
			String messageTo=null;
			String cc = null;
			String messageText=null;
			String subject=null;
			Object sessionBean=session.getAttribute(SESSION_OBJECT);
			int userTypeId=sessionBean !=null ? ((SessionBean)session.getAttribute(SESSION_OBJECT)).getUserTypeId() : 0;

			if(userId!=0){
				int clientId=abcUtility.getSessionClientId(request);
				int operationType=StringUtils.hasLength(request.getParameter("hdOperationType"))?Integer.parseInt(request.getParameter("hdOperationType")):0;
				int actionType=StringUtils.hasLength(request.getParameter("hdActionType"))?Integer.parseInt(request.getParameter("hdActionType")):0;
				objectId=StringUtils.hasLength(request.getParameter("txtObjectId"))?Integer.parseInt(request.getParameter("txtObjectId")):-1;
				messageTo=request.getParameter("txtMessageTo");
				cc=request.getParameter("txtMessageCC");
				if(objectId!=-1 && operationType!=0 && actionType!=0){
					String error= new String();
					int parentMessageId=StringUtils.hasLength(request.getParameter("hdParentMessageId"))?Integer.parseInt(request.getParameter("hdParentMessageId")):0;
					txtHidDocIds=request.getParameter("txtHidDocIds");
					messageText=request.getParameter("rtfMessageText");
					subject=request.getParameter("txtSubject");
					MailDataBean mailDataBean= new MailDataBean();
					mailDataBean.setMessageFrom(userId);
					//get the login id from userId
					List<Object> loginId=loginService.getLoginIdByUserId(userId);
					mailDataBean.setFromEmailId(loginId.get(0).toString());
					mailDataBean.setMessageText(messageText);
					mailDataBean.setMessageTo(messageTo);
					mailDataBean.setSubject(subject);
					mailDataBean.setMessageCC(cc);
					mailDataBean.setObjectId(objectId);
					mailDataBean.setParentMessageId(parentMessageId);
					mailDataBean.setActionType(actionType);
					mailDataBean.setOperationType(operationType);
					mailDataBean.setClientId(clientId);
					mailDataBean.setUserTypeId(userTypeId);
					if(StringUtils.hasLength(txtHidDocIds)){
						mailDataBean.setIsDocUpload(1);
						mailDataBean.setDocIds(txtHidDocIds);
					}
					if(StringUtils.hasLength(messageTo) || StringUtils.hasLength(cc)){
						error = checkEmailIds(mailDataBean);
					}
					if(error.contains("Invalid")){
						modelMap.addAttribute("mailDataBean", mailDataBean);
					}else{
						TblMessage tblMessage = mailDataBean.toTblMessage();
						success=mailBoxService.addMail(tblMessage, getTblMessageDetailList(mailDataBean),mailDataBean.getDocIds(),userTypeId);
						if(operationType==1 || operationType==5){//Send
							retVal.append("$1@@");	
						}else if(operationType==3){//Draft
							retVal.append("$3@@");//.append(tblMessage.getMessageId()).append("@@");	
						//	retVal.append("mailcontent");//.append(tblMessage.getMessageId()).append("@@");
						//	modelMap.addAttribute("draftmail", true);
						}
						else if(operationType==7){//forward
							retVal.append("$7@@");
						}
					}
				}
			}else{
				retVal.append("sessionexpired");
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return success?retVal.toString():userId==0?retVal.toString():"error";
	}
	
	@ResponseBody
	@RequestMapping(value="/discardmail",method=RequestMethod.POST)
	public String discardMailOperation(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) {
		boolean success=false;
		StringBuilder retVal=new StringBuilder();
		int userId = 0;
		int messageId=-1;
		try {
			userId=abcUtility.getSessionUserId(request);
			if(userId!=0){
				String  txtHidDocIds=request.getParameter("txtHidDocIds");
				messageId=StringUtils.hasLength(request.getParameter("hdMessageId"))?Integer.parseInt(request.getParameter("hdMessageId")):-1;
				if(messageId!=-1){
					if(messageId==0){// Only compose not as a Draft at that time it will delete only attachment
						if(StringUtils.hasLength(txtHidDocIds)){
							success=mailBoxService.deleteAttachmentByDocIds(String.valueOf(txtHidDocIds));
						}else{//if there is no document
							success=true;
						}
					}else{
						success=mailBoxService.deleteDraftMail(String.valueOf(messageId),1);
					}
					retVal.append("$3@@");	
				}
			}else{
				retVal.append("sessionexpired");
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return success?retVal.toString():userId==0?retVal.toString():"error";
	}
	
	@ResponseBody
	@RequestMapping(value="/deletemail",method=RequestMethod.POST)
	public String deleteMailOperation(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) {
		boolean success=false;
		StringBuilder retVal=new StringBuilder();
		int userId = 0;
		try {
			userId=abcUtility.getSessionUserId(request);
			if(userId!=0){
				String messageDetailId=request.getParameter("hdMessageDetailId");
				int TrashfolderId=StringUtils.hasLength(request.getParameter("hdSFolderId"))?Integer.parseInt(request.getParameter("hdSFolderId")):0;
				if(StringUtils.hasLength(messageDetailId)){
					success=mailBoxService.updateFolder(messageDetailId,5,TrashfolderId);//5=Trash
				}
				retVal.append("$4@@");	
			}else{
				retVal.append("sessionexpired");
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return success?retVal.toString():userId==0?retVal.toString():"error";
	}
	
	@ResponseBody
	@RequestMapping(value="/movetofolder",method=RequestMethod.POST)
	public String moveToFolder(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) {
		boolean success=false;
		StringBuilder retVal=new StringBuilder();
		int userId = 0;
		try {
			userId=abcUtility.getSessionUserId(request);
			if(userId!=0){
				int folderId=StringUtils.hasLength(request.getParameter("hdFolderId"))?Integer.parseInt(request.getParameter("hdFolderId")):0;
				int TrashfolderId=StringUtils.hasLength(request.getParameter("hdSFolderId"))?Integer.parseInt(request.getParameter("hdSFolderId")):0;
				String encMessageDetailIds=request.getParameter("messageDetailIds");
				if(StringUtils.hasLength(encMessageDetailIds) && folderId!=0){
					List<String> messageDetailIdsList = new ArrayList<String>();
			    	String[] valueArr= encMessageDetailIds.split(",");
			    	for(int i=0;i<valueArr.length;i++){
			    		if(StringUtils.hasLength(valueArr[i])){
			    			messageDetailIdsList.add(encryptDecryptUtils.decrypt(valueArr[i]));
			        	}
			    	}
			    	if(TrashfolderId==5) //Added by Mitesh Patel
			    	{
			    		success=mailBoxService.deleteMassage(StringUtils.collectionToCommaDelimitedString(messageDetailIdsList));//5=Trash delete permenently
			    		retVal.append("$51@@");	
			    	}
			    	else{
			    		success=mailBoxService.updateFolder(StringUtils.collectionToCommaDelimitedString(messageDetailIdsList),folderId,TrashfolderId);//5=Trash
			    		retVal.append("$5@@");	
			    	}
				}
				
			}else{
				retVal.append("sessionexpired");
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return success?retVal.toString():userId==0?retVal.toString():"error";
	}
	
	@ResponseBody
	@RequestMapping(value="/markmail",method=RequestMethod.POST)
	public String markMail(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) {
		boolean success=false;
		StringBuilder retVal=new StringBuilder();
		int userId = 0;
		try {
			userId=abcUtility.getSessionUserId(request);
			if(userId!=0){
				int markId=StringUtils.hasLength(request.getParameter("hdMarkId"))?Integer.parseInt(request.getParameter("hdMarkId")):-1;
				String encMessageDetailIds=request.getParameter("messageDetailIds");
				if(StringUtils.hasLength(encMessageDetailIds) && markId!=-1){
					List<String> messageDetailIdsList = new ArrayList<String>();
			    	String[] valueArr= encMessageDetailIds.split(",");
			    	for(int i=0;i<valueArr.length;i++){
			    		if(StringUtils.hasLength(valueArr[i])){
			    			messageDetailIdsList.add(encryptDecryptUtils.decrypt(valueArr[i]));
			        	}
			    	}
					success=mailBoxService.readMail(StringUtils.collectionToCommaDelimitedString(messageDetailIdsList),markId);//Read = 1 , un read=0
				}
				retVal.append("$6@@");	
			}else{
				retVal.append("sessionexpired");
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return success?retVal.toString():userId==0?retVal.toString():"error";
	}
	
	@ResponseBody
	@RequestMapping(value="/messageboxdetails",method=RequestMethod.POST)
	public String messageBoxDetails(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) {
		StringBuilder retVal=new StringBuilder();
		int userId = 0;
		int clientId=0;
		
		try {
			userId=abcUtility.getSessionUserId(request);
			clientId=abcUtility.getSessionClientId(request);
			boolean isInboxFound=false;
			if(userId!=0){
				List<Object[]> inboxCountDetails=mailBoxService.getInboxCount(userId,clientId,abcUtility.getSessionUserTypeId(request));
				List<Object[]> draftCountDetails=mailBoxService.getDraftCount(userId,clientId,abcUtility.getSessionUserTypeId(request));
				if(inboxCountDetails!=null && !inboxCountDetails.isEmpty()){
					for(Object[] data: inboxCountDetails){
						retVal.append(encryptDecryptUtils.encrypt(data[0].toString())).append("@@").append(data[1]).append(" (").append(data[2]).append(")").append(",");
						if(data[1].toString().equalsIgnoreCase("inbox")){
							retVal.append(encryptDecryptUtils.encrypt("6")).append("@@").append(messageSource.getMessage("lbl_mailbox", null, LocaleContextHolder.getLocale())).append(" (").append(data[2]).append(")").append(",");
							if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())!=null){
					            SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
					            sessionBean.setUnReadCount((Long)data[2]);
					        }
							isInboxFound=true;
						}
					}
				}
				if(!isInboxFound){
					if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())!=null){
			            SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
			            sessionBean.setUnReadCount(0);
			        }
				}
				
				if(draftCountDetails!=null && !draftCountDetails.isEmpty()){
					Object[] draftArr= draftCountDetails.get(0);
					retVal.append(encryptDecryptUtils.encrypt(draftArr[0].toString())).append("@@").append("Draft").append(" (").append(draftArr[1]).append(")").append(",");
				}
				
				if(retVal.toString().endsWith(",")){
					retVal.deleteCharAt(retVal.lastIndexOf(","));
				}
				
			}else{
				retVal.append("sessionexpired");
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return retVal.toString();
	}
	
	@ResponseBody
	@RequestMapping(value="/folderdetails",method=RequestMethod.POST)
	public String folderDetails(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) {
		StringBuilder retVal=new StringBuilder();
		int userId = 0;
		int clientId=0;
		try {
			userId=abcUtility.getSessionUserId(request);
			clientId=abcUtility.getSessionClientId(request);
			if(userId!=0){
				List<Object[]> folderDetails=mailBoxService.getFoldersByUserId(userId,clientId);
				if(folderDetails!=null && !folderDetails.isEmpty()){
					//retVal.append("<li id='FolderDetails'><a class='trigger open' onclick='foldersDetail();' href='javascript:void(0);'>Folders</a>");
					retVal.append("<ul class='submenu submenu-sub'>");
					for(Object[] data: folderDetails){
						retVal.append("<li class='last-child'>");
						retVal.append("<a href='").append(request.getServletContext().getContextPath()).append("/common/maildashboard/2/").append(data[0]).append(encryptDecryptUtils.generateRedirect("common/maildashboard/2/"+data[0], request)).append("'").append(" class='trigger'").append("id='href").append(data[0]).append("'>").append(data[1]).append("</a></li>");
					}
					retVal.append("</ul>");
					//retVal.append("</li>");
				}
			}else{
				retVal.append("sessionexpired");
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return retVal.toString();
	}
	
	private String checkEmailIds(MailDataBean mailDataBean) throws Exception{
		List<Object[]> list = mailBoxService.getUserIdByEmailIds((mailDataBean.getMessageTo()),mailDataBean.getClientId());
        StringBuilder invalidEmail = new StringBuilder();
        String array[]=mailDataBean.getMessageTo().split(",");
        if(list!=null && !list.isEmpty()){
        	int totalCount=0;
        	for(int i=0;i<array.length;i++){
        		int matchCount=0;
        		for(int j =0;j<list.size();j++){
        			if(((String)list.get(j)[1]).equals(array[i])){
        				matchCount++;
        				totalCount++;
        			}
        		}
        		if(matchCount==0){
        			if(invalidEmail.length()==0){
        				invalidEmail.append("<span class='mandatory'>Please entervalid Email ID ");
        			}
        			/*invalidEmail.append(array[i]);
        			if(i!=array.length-1){
        				invalidEmail.append(",");
        			}*/
        		}
        	}
        	if(totalCount>=list.size() && invalidEmail.length()==0){
        		invalidEmail.append("<span><font color='green'>Valid</font>");
        	}
        }else{
    		invalidEmail.append("<span class='mandatory'>Please entervalid Email ID ");
//        	invalidEmail.append(mailDataBean.getMessageTo());
        }
        invalidEmail.append("</span>");
        mailDataBean.setErrorOrSuccessMessage(invalidEmail.toString());
        return invalidEmail.toString();
	}

	private List<TblMessageDetail> getTblMessageDetailList(MailDataBean mailDataBean) throws Exception {
		List<TblMessageDetail> tblMessageDetailList = new ArrayList<TblMessageDetail>();
		if(mailDataBean!=null){
			/* :: Below Logic for To 
			 * :: sendType = Message send type. 0 for Not Set, 1 for To Email Address, 2 for CC Email Address ,3 for From Address
			 * :: actionType = 0 for Not Set, 1 for Create, 2 for Reply, 3 for Reply All, 4 Forward
			 * :: Folder Id 1=Inbox ,2=Starred,3=Draft,4=Sent,5=Trash
			 */
			
			TblMessageDetail messageDetail = new TblMessageDetail();	
			List<Object[]> list = mailBoxService.getUserIdByEmailIds((mailDataBean.getMessageTo()),mailDataBean.getClientId());
			if(list!=null && !list.isEmpty()){
				for(Object[] obj:list){
					messageDetail = new TblMessageDetail();	
					messageDetail.setIsMessageRead(0);
					messageDetail.setFolderId(mailDataBean.getFolderId());
					messageDetail.setSendType(1);//To
					messageDetail.setMessageTo((Integer)obj[0]);
					messageDetail.setEmailId((String)obj[1]);
					messageDetail.setUpdatedBy(mailDataBean.getMessageFrom());
					tblMessageDetailList.add(messageDetail);
				}
			}
			/* for the sent & draft problem fix*/
			if(list!=null && !list.isEmpty()){
				
					messageDetail = new TblMessageDetail();	
					messageDetail.setIsMessageRead(0);//0 UnRead, 1 Read
					messageDetail.setFolderId(mailDataBean.getOperationType()==3?3:4);//sent 4 ,draft 3
					messageDetail.setSendType(3);//From
					messageDetail.setMessageTo(mailDataBean.getMessageFrom());
					messageDetail.setEmailId(mailDataBean.getFromEmailId());
					messageDetail.setUpdatedBy(mailDataBean.getMessageFrom());
					tblMessageDetailList.add(messageDetail);
				
			}
			/* Below Logic for CC empty*/
			if(mailDataBean!=null && !mailDataBean.getMessageCC().isEmpty()){
				list = mailBoxService.getUserIdByEmailIds((mailDataBean.getMessageCC()),mailDataBean.getClientId());
				if(list!=null && !list.isEmpty()){
					for(Object[] obj:list){
						messageDetail = new TblMessageDetail();	
						messageDetail.setIsMessageRead(0);
						messageDetail.setFolderId(mailDataBean.getFolderId());
						messageDetail.setSendType(2);//CC
						messageDetail.setMessageTo((Integer)obj[0]);
						messageDetail.setEmailId((String)obj[1]);
						messageDetail.setUpdatedBy(mailDataBean.getMessageFrom());
						tblMessageDetailList.add(messageDetail);
					}
				}
			}
			
			if(mailDataBean.getOperationType()==3 && mailDataBean.getMessageCC().isEmpty() && mailDataBean.getMessageTo().isEmpty()){// Case only for Draft where To or CC empty 
				messageDetail = new TblMessageDetail();	
				messageDetail.setIsMessageRead(0);
				messageDetail.setFolderId(mailDataBean.getFolderId());
				messageDetail.setSendType(1);//To
				messageDetail.setMessageTo(0);
				messageDetail.setEmailId("");
				messageDetail.setUpdatedBy(mailDataBean.getMessageFrom());
				tblMessageDetailList.add(messageDetail);
			}
		}
		return tblMessageDetailList;
	}

	@ResponseBody
	@RequestMapping(value="/checkemailids",method=RequestMethod.POST)
    public String checkEmailIds(@RequestParam("txtaMailIds") String mailIds,HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) {
		String data=null;
		MailDataBean mailDataBean= new MailDataBean();
		mailDataBean.setMessageTo(mailIds);
		mailDataBean.setMessageFrom(abcUtility.getSessionUserId(request));
		try {
			mailDataBean.setClientId(abcUtility.getSessionClientId(request));
			data=checkEmailIds(mailDataBean);
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return data;
	}
	/**
	 * To Add mail to To Do List from inbox
	 * 
	 * @author purvesh
	 * @param request
	 * @param response
	 * @param modelMap
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/addtodolist",method=RequestMethod.POST)
	public String addToDoListOperation(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap){
		boolean success=false;
		StringBuilder retVal=new StringBuilder();
		int userId = 0;
		try {
			userId=abcUtility.getSessionUserId(request);
			if(userId!=0){
				String scheduledOn=StringUtils.hasLength(request.getParameter("txtScheduledOn")) ? request.getParameter("txtScheduledOn") : "";
				String subject=StringUtils.hasLength(request.getParameter("txtSubject")) ? request.getParameter("txtSubject") : "";
				String messageText=StringUtils.hasLength(request.getParameter("rtfMessageText")) ? request.getParameter("rtfMessageText") : "";
				if(scheduledOn!=null && !"".equalsIgnoreCase(scheduledOn) && subject!=null && !"".equalsIgnoreCase(subject)){
					TblTaskList tblTaskList = new TblTaskList();
					tblTaskList.setTblUserLogin(new TblUserLogin(userId));
					tblTaskList.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
					tblTaskList.setSubject(subject);
					tblTaskList.setDescription(messageText);
					tblTaskList.setScheduledOn(conversionService.convert(scheduledOn,Date.class));
					tblTaskList.setEventColor("#c9c9c9");
					// When adding mail on todo list then end date is same as schedule date. Bug #32785 By Jitendra
					tblTaskList.setEndDate(conversionService.convert(scheduledOn, Date.class));
					tblTaskList.setIsCompleted(0);
					mailBoxService.addTask(tblTaskList);
					/**
					 * 		start - Project Task #14831 
					 * 		if scheduledOn is on same day then update session variable too. - purvesh
					 */
					//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					/*Date scheduledOnDt =  CommonUtility.converTotUtcTimezone(scheduledOn);
					Date currentDate =  commonService.getServerDateTime();
					if(currentDate.compareTo(scheduledOnDt)==0){*/
						setTaskListData(userId, abcUtility.getSessionClientId(request), request);
		        	//}
					/* 		End - Project Task #14831 */
					success = true;
				}
				retVal.append("$8@@");	
			}else{
				retVal.append("sessionexpired");
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return success?retVal.toString():userId==0?retVal.toString():"error";
	}
	 /**
     * To set task list data
     * 
     * @author purvesh
     * @param request
     * @throws Exception
     */
	 private void setTaskListData(int userId, int clientId, HttpServletRequest request) throws Exception {
    	String taskLists = new String();
        String currentTask = "";
        List<Object[]> taskListData = mailBoxService.getTaskListData(userId, clientId);
        request.getSession().removeAttribute("taskLists");
    	request.getSession().removeAttribute("isFirstTime");
        if(taskListData!=null && !taskListData.isEmpty()) {
        	for(Object[] task : taskListData) {
        		currentTask="";
        		currentTask= task[0] +"|~|"+ task[1] +"|~|"+ task[2] +"|~|"+ CommonUtility.convertTimezoneToClientTimezone(task[3]) +"|~|"+ task[4]+ "|~|"+ task[5]+"|#|";
        		taskLists+=currentTask;
        	}        	        	
    		request.getSession().setAttribute("taskLists", taskLists);        		 	 
    		request.getSession().setAttribute("isFirstTime", true);        	
        }
     }
	/**
	 * To Show create task page (To Do List)
	 * 
	 * @author purvesh
	 * @param request
	 * @param response
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="createtask/{enc}", method=RequestMethod.GET)
	public String createTask( HttpServletRequest request,HttpServletResponse response, ModelMap modelMap){
		String retVal="common/EditToDoList";
		try {
			modelMap.addAttribute("isEditToDoList", false);
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		}
		finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), addTaskLinkId, getAddTaskAuditMsg, 0,0);
		}
		return retVal;
	}
	
	/**
	 * To Create task (To Do List)
	 * 
	 * @author purvesh
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value="/addtask", method=RequestMethod.POST)
	public String addTask( HttpServletRequest request,HttpServletResponse response, ModelMap modelMap, RedirectAttributes redirectAttributes){
		boolean success=false;
		String retVal="redirect:/common/createtask" + encryptDecryptUtils.generateRedirect("/common/createtask", request);
		int userId = 0;
		try {
			modelMap.addAttribute("isEditToDoList", false);
			userId = abcUtility.getSessionUserId(request);
			if(userId!=0){
				String scheduledOn=StringUtils.hasLength(request.getParameter("txtScheduledOn")) ? request.getParameter("txtScheduledOn") : "";
				String subject=StringUtils.hasLength(request.getParameter("txtSubject")) ? request.getParameter("txtSubject") : "";
				String messageText=StringUtils.hasLength(request.getParameter("rtfMessageText")) ? request.getParameter("rtfMessageText") : "";
				if(scheduledOn!=null && !"".equalsIgnoreCase(scheduledOn) && subject!=null && !"".equalsIgnoreCase(subject)){
					TblTaskList tblTaskList = new TblTaskList();
					tblTaskList.setTblUserLogin(new TblUserLogin(userId));
					tblTaskList.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
					tblTaskList.setSubject(subject);
					tblTaskList.setDescription(messageText);
					tblTaskList.setScheduledOn(conversionService.convert(scheduledOn,Date.class));
					tblTaskList.setEventColor("#c9c9c9");
					tblTaskList.setIsCompleted(0);
					tblTaskList.setEndDate(conversionService.convert(scheduledOn,Date.class));
					mailBoxService.addTask(tblTaskList);
					/**
					 * 		start - Project Task #14831 
					 * 		if scheduledOn is on same day then update session variable too. - purvesh
					 */
					/*SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					Date scheduledOnDt = sdf.parse(sdf.format(conversionService.convert(scheduledOn,Date.class)));
					Date currentDate = sdf.parse(sdf.format(new Date()));
					if(currentDate.compareTo(scheduledOnDt)==0){*/
					setTaskListData(userId, abcUtility.getSessionClientId(request), request);
		        	//}
					/* 		End - Project Task #14831 */
					success = true;
					if(success){
						retVal="redirect:/common/managetodolist" + encryptDecryptUtils.generateRedirect("common/managetodolist", request);
					}
				}
				redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG_KEY.toString(), success ? "msg_redirect_tasklist_created_successfully" : CommonKeywords.ERROR_MSG.toString());
			}
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		}
		finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), addTaskLinkId, postAddTaskAuditMsg, 0,0);
		}
		return retVal;
	}
	/**
	 * To Show edit task page (To Do List)
	 * 
	 * @author purvesh
	 * @param taskId
	 * @param request
	 * @param response
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="showedittask/{taskId}/{enc}",method=RequestMethod.GET)
	public String showTask(@PathVariable("taskId")int taskId, HttpServletRequest request,HttpServletResponse response, ModelMap modelMap){
		String retVal="common/EditToDoList";
		try {
			List<Object[]> lstTask = mailBoxService.getTask(taskId);
			if(lstTask!=null && !lstTask.isEmpty()){
				modelMap.addAttribute("isEditToDoList", true);
				modelMap.addAttribute("taskId", taskId);
				modelMap.addAttribute("ScheduledOn", lstTask.get(0)[0]);
				modelMap.addAttribute("mailSubject", lstTask.get(0)[1]);
				modelMap.addAttribute("mailDescription", lstTask.get(0)[2]);
			}
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		}
		finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editTaskLinkId, getEditTaskAuditMsg, 0,0);
		}
		return retVal;
	}
	
	/**
	 * To Update task (To Do List)
	 * 
	 * @author purvesh
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value="/edittask", method=RequestMethod.POST)
	public String editTask( HttpServletRequest request,HttpServletResponse response, ModelMap modelMap, RedirectAttributes redirectAttributes){
		int taskId = StringUtils.hasLength(request.getParameter("hdTaskId")) ? Integer.parseInt(request.getParameter("hdTaskId")) : 0;
		boolean success = false;
		String retVal="redirect:/showedittask/"+taskId+ encryptDecryptUtils.generateRedirect("showedittask/"+taskId, request);
		try {
			int userId = abcUtility.getSessionUserId(request);
			if(userId!=0){
				String scheduledOn=StringUtils.hasLength(request.getParameter("txtScheduledOn")) ? CommonUtility.convertUtcTimezone(request.getParameter("txtScheduledOn").replace("-", "/")) : "";
				String subject=StringUtils.hasLength(request.getParameter("txtSubject")) ? request.getParameter("txtSubject") : "";
				String messageText=StringUtils.hasLength(request.getParameter("rtfMessageText")) ? request.getParameter("rtfMessageText") : "";
				if(taskId!=0 && scheduledOn!=null && !"".equalsIgnoreCase(scheduledOn) && subject!=null && !"".equalsIgnoreCase(subject) && messageText!=null && !"".equalsIgnoreCase(messageText)){
					success = mailBoxService.updateTask(taskId, subject, messageText, scheduledOn,scheduledOn,0);
					/**
					 * 		start - Project Task #14831 
					 * 		if scheduledOn is on same day then update session variable too. - purvesh
					 */
					/*Date scheduledOnDt =  CommonUtility.converTotUtcTimezone(scheduledOn);
					Date currentDate =  commonService.getServerDateTime();
					if(currentDate.compareTo(scheduledOnDt)==0){*/
						setTaskListData(userId, abcUtility.getSessionClientId(request), request);
		        	//}
					/* 		End - Project Task #14831 */
					if(success){
						retVal="redirect:/common/managetodolist" + encryptDecryptUtils.generateRedirect("common/managetodolist", request);
					}
				}
				redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG_KEY.toString(), success ? "msg_redirect_tasklist_updated_successfully" : CommonKeywords.ERROR_MSG.toString());
			}
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		}
		finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editTaskLinkId, postEditTaskAuditMsg, 0,0);
		}
		return retVal;
	}
	/**
	 * To show complete task page (To Do List)
	 * 
	 * @author purvesh
	 * @param taskId
	 * @param request
	 * @param response
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="showcompletetask/{taskId}/{forViewTask}",method=RequestMethod.POST)
	public String completeTask(@PathVariable("taskId")int taskId, @PathVariable("forViewTask")int forViewTask, 
						HttpServletRequest request,HttpServletResponse response, ModelMap modelMap){
		String retVal="common/CompleteToDoList";
		try {
			List<Object[]> lstTask = mailBoxService.getTask(taskId);
			if(lstTask!=null && !lstTask.isEmpty()){
				modelMap.addAttribute("isCompleteToDoList", forViewTask!=1 ? true : false);
				modelMap.addAttribute("taskId", taskId);
				modelMap.addAttribute("ScheduledOn", lstTask.get(0)[0]);
				modelMap.addAttribute("mailSubject", lstTask.get(0)[1]);
				modelMap.addAttribute("mailDescription", lstTask.get(0)[2]);
			}
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		}
		finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, "Accessed complete task list page", 0,0);
		}
		return retVal;
	}
	/**
	 * To Update task (To Do List)
	 * 
	 * @author purvesh
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value="/completetask", method=RequestMethod.POST)
	public String completeTask( HttpServletRequest request,HttpServletResponse response, ModelMap modelMap, RedirectAttributes redirectAttributes){
		int taskId = StringUtils.hasLength(request.getParameter("hdTaskId")) ? Integer.parseInt(request.getParameter("hdTaskId")) : 0;
		boolean success = false;
		String retVal="";
		try {
			int userId = abcUtility.getSessionUserId(request);
			if(userId!=0){
				String scheduledOn=StringUtils.hasLength(request.getParameter("hdScheduledOn")) ? request.getParameter("hdScheduledOn") : "";
				String subject=StringUtils.hasLength(request.getParameter("hdSubject")) ? request.getParameter("hdSubject") : "";
				String messageText=StringUtils.hasLength(request.getParameter("hdDescription")) ? request.getParameter("hdDescription") : "";
				if(taskId!=0 && scheduledOn!=null && !"".equalsIgnoreCase(scheduledOn) && subject!=null && !"".equalsIgnoreCase(subject) && messageText!=null && !"".equalsIgnoreCase(messageText)){
					success = mailBoxService.updateTask(taskId, subject, messageText, scheduledOn,scheduledOn,1);
					setTaskListData(userId, abcUtility.getSessionClientId(request), request);
					if(success){
						retVal="redirect:/common/managetodolist" + encryptDecryptUtils.generateRedirect("common/managetodolist", request);
					}
				}
				redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG_KEY.toString(), success ? "msg_redirect_tasklist_completed_successfully" : CommonKeywords.ERROR_MSG.toString());
			}
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		}
		finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, "Complete task", 0,0);
		}
		return retVal;
	}
	
	/**
	 * To Show manage To Do list page
	 * 
	 * @author purvesh
	 * @param request
	 * @param response
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="managetodolist/{enc}", method=RequestMethod.GET)
	public String manageToDoList(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap){
		String retVal="common/ManageToDoList";
		try {
			modelMap.addAttribute("reportId",toDoListingReportId);
			reportGeneratorService.getReportConfigDetails(toDoListingReportId, modelMap);
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		}
		finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, "Manage to do list", 0,0);
		}
		return retVal;
	}
	/**
	 * To Remove task (To Do List)
	 * 
	 * @author purvesh
	 * @param taskId
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value="deletetask/{taskId}/{enc}", method=RequestMethod.GET)
	public String deleteTask(@PathVariable("taskId")int taskId, HttpServletRequest request,HttpServletResponse response, ModelMap modelMap, RedirectAttributes redirectAttributes){

		boolean success = false;
		String retVal="redirect:/common/managetodolist" + encryptDecryptUtils.generateRedirect("common/managetodolist", request);
		try {
			success = mailBoxService.removeTask(taskId);
			setTaskListData(abcUtility.getSessionUserId(request), abcUtility.getSessionClientId(request), request);
			redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG_KEY.toString(), success ? "msg_redirect_tasklist_deleted_successfully" : CommonKeywords.ERROR_MSG.toString());
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		}
		finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deleteTaskLinkId, postDeleteTaskAuditMsg, 0,0);
		}
		return retVal;
	}
	@RequestMapping(value = "/admin/deletetodotask", method = RequestMethod.POST)                       
	  public String deleteTodoTask(ModelMap modelMap, HttpServletResponse response, HttpServletRequest  request,RedirectAttributes redirectAttributes){
		  	String retVal=REDIRECT_SESSION_EXPIRED;
		  	boolean bSuccess = false;
		      try{
		     	int sessionUserId = abcUtility.getSessionUserId(request);
		  		if(sessionUserId!=0){
		  			 String[] todoIds = request.getParameterValues("hdToDoId");
		  			 if(todoIds != null && todoIds.length >0){
		  				List<Integer> processed = new ArrayList<Integer>();
		  				for(int i=0;i<todoIds.length;i++)
		  	            {
		  					processed.add(Integer.parseInt(todoIds[i]));
		  	            }
		  				bSuccess =mailBoxService.multipledelete(processed);
		  			 }
		  		}
		      }
		      catch(Exception e){
		    	  return exceptionHandlerService.writeLog(e);
		      }
		      retVal= "common/managetodolist";
		      retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
		      redirectAttributes.addFlashAttribute(bSuccess ? CommonKeywords.SUCCESS_MSG.toString() :CommonKeywords.ERROR_MSG.toString(), bSuccess ? "msg_redirect_tasklist_multiple_deleted_successfully" : CommonKeywords.ERROR_MSG_KEY.toString());
		      return retVal;   
	    }
	
	  @RequestMapping(value="completetask/{taskId}/{enc}",method=RequestMethod.GET)
		public String complate(@PathVariable("taskId")String eventId, HttpServletRequest request,HttpServletResponse response, ModelMap modelMap,RedirectAttributes redirectAttributes){
		 String retVal=REDIRECT_SESSION_EXPIRED;
		  	boolean bSuccess = false;
		  	String successMsg=null;
		  try
			{
				if(eventId!=null)
				{
					int taskId = Integer.parseInt(eventId);
					 bSuccess = mailBoxService.completetask(taskId);
					bSuccess = true;
				}
				else
				{
					return "false";
				}	 
		      }
		  catch(Exception e){
	    	  return exceptionHandlerService.writeLog(e);
	      }
		      retVal= "common/managetodolist";
		      retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
		      redirectAttributes.addFlashAttribute(bSuccess ? CommonKeywords.SUCCESS_MSG.toString() :CommonKeywords.ERROR_MSG.toString(), bSuccess ? "msg_redirect_tasklist_complete_successfully" : CommonKeywords.ERROR_MSG_KEY.toString());
		      return retVal;   
	    }
	  
	    @RequestMapping(value="favourite/{taskId}/{enc}",method=RequestMethod.GET)
		public String favourite(@PathVariable("taskId")String eventId, HttpServletRequest request,HttpServletResponse response, ModelMap modelMap,RedirectAttributes redirectAttributes){
		  String retVal=REDIRECT_SESSION_EXPIRED;
		  	boolean bSuccess = false;
		  try
			{
				if(eventId!=null)
				{
					int taskId = Integer.parseInt(eventId);
					 bSuccess = mailBoxService.favourite(taskId);
				}	 
		      }
		  catch(Exception e){
	    	  return exceptionHandlerService.writeLog(e);
	      }
		      retVal= "common/managetodolist";
		      retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
		      redirectAttributes.addFlashAttribute(bSuccess ? CommonKeywords.SUCCESS_MSG.toString() :CommonKeywords.ERROR_MSG.toString(), bSuccess ? "msg_redirect_tasklist_favourite_successfully" : CommonKeywords.ERROR_MSG_KEY.toString());
		      return retVal;   
	    }
	  
	   @RequestMapping(value="disfavourite/{taskId}/{enc}",method=RequestMethod.GET)
		public String disfavourite(@PathVariable("taskId")String eventId, HttpServletRequest request,HttpServletResponse response, ModelMap modelMap,RedirectAttributes redirectAttributes){
		  String retVal=REDIRECT_SESSION_EXPIRED;
		  	boolean bSuccess = false;
		  	String successMsg=null;
		  try
			{
				if(eventId!=null)
				{
					int taskId = Integer.parseInt(eventId);
					 bSuccess = mailBoxService.disfavourite(taskId);
					bSuccess = true;
				}
				else
				{
					return "false";
				}	 
		      }
		    catch(Exception e){
	    	  return exceptionHandlerService.writeLog(e);
	          }
		      retVal= "common/managetodolist";
		      retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
		      redirectAttributes.addFlashAttribute(bSuccess ? CommonKeywords.SUCCESS_MSG.toString() :CommonKeywords.ERROR_MSG.toString(), bSuccess ? "msg_redirect_tasklist_complete_successfully" : CommonKeywords.ERROR_MSG_KEY.toString());
		      return retVal;   
	    }
	@ResponseBody
	@RequestMapping(value="/updateclosedtasks", method=RequestMethod.POST)
	public String updateClosedTasks(HttpServletRequest request,HttpServletResponse response) {
		String retVal="";
		String txtTaskIds=null;
		int userId=0;
		try {
			userId = abcUtility.getSessionUserId(request);
			if(userId!=0) {
				txtTaskIds=StringUtils.hasLength(request.getParameter("txtTaskIds")) ? request.getParameter("txtTaskIds") : "";
				if(txtTaskIds!=null && !"".equalsIgnoreCase(txtTaskIds)) {
					txtTaskIds = txtTaskIds.substring(0, txtTaskIds.length()-1);
					String taskLists = new String();
			        String currentTask = "";
			        List<Object[]> taskListData = mailBoxService.getTaskListData(userId, abcUtility.getSessionClientId(request));
			        request.getSession().removeAttribute("taskLists"); 			
	        		request.getSession().removeAttribute("isFirstTime");
			        if(taskListData!=null && !taskListData.isEmpty()) {
			        	for(Object[] task : taskListData) {
			        		currentTask="";
			        		if(txtTaskIds.contains(task[0].toString())) {
			        			currentTask= task[0] +"|~|"+ task[1] +"|~|"+ task[2] +"|~|"+ CommonUtility.convertTimezoneToClientTimezone(task[3]) +"|~|"+ 0 + "|#|";
			        			//System.out.println(currentTask);
			        		}
			        		else{
			        			currentTask= task[0] +"|~|"+ task[1] +"|~|"+ task[2] +"|~|"+ CommonUtility.convertTimezoneToClientTimezone(task[3]) +"|~|"+ task[4]+ "|#|";
			        		}
			        		taskLists+=currentTask;
			        	}
		        		request.getSession().setAttribute("taskLists", taskLists);  
		        		request.getSession().setAttribute("isFirstTime", false);
			        }
			        retVal=taskLists;
				}
				
			}
			else {
				retVal="sessionexpired";
			}
			
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		}
		return retVal;
	}
	/**
	 * To add label
	 * 
	 * @author Nirav modi
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/addlabel", method=RequestMethod.POST)
	public String createLabel(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap, RedirectAttributes redirectAttributes){
		boolean success = false;
		String retVal="sessionexpired";
		int userId= abcUtility.getSessionUserId(request);
		try {
			int createdBy= abcUtility.getSessionUserDetailId(request);
			String txtLabelName = request.getParameter("txtLabelName");
			if(userId!=0 && createdBy !=0 && StringUtils.hasLength(txtLabelName)){
				TblMessageFolder tblMessageFolder = new TblMessageFolder();
				tblMessageFolder.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
				tblMessageFolder.setCreatedBy(createdBy);
				tblMessageFolder.setFolderName(txtLabelName);
				tblMessageFolder.setUserId(userId);
				success=mailBoxService.addLabel(tblMessageFolder);
				retVal="$9@@";
			}
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		}
		finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, "label created successfully", 0,0);
		}
		return success?retVal:userId==0?retVal:"error";
	}
	
	/**
     * to get uploaded document in the listing
     * @param request
     * @param response
     * @param session
     */
	@ResponseBody
    @RequestMapping(value = {"/getattachment"},method=RequestMethod.POST)
	public void getUploadedDocs(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
		List<Object[]> lstDocumentDetails = null;
		StringBuilder strDocList = new StringBuilder();
		int objectId=0;
		int linkId=0;
		try {
			Object sessionBean=session.getAttribute(SESSION_OBJECT);
			int userId=abcUtility.getSessionUserId(request);
			objectId=StringUtils.hasLength(request.getParameter(TXT_OBJECTID)) ? Integer.parseInt(request.getParameter(TXT_OBJECTID)) : 0; 
			linkId=StringUtils.hasLength(request.getParameter(TXT_LINKID)) ? Integer.parseInt(request.getParameter(TXT_LINKID)) : 0;
			String docIds=StringUtils.hasLength(request.getParameter(TXT_DOCID)) ? request.getParameter(TXT_DOCID) : "0";
			int clientId=abcUtility.getSessionClientId(request);
			int userTypeId=sessionBean !=null ? ((SessionBean)session.getAttribute(SESSION_OBJECT)).getUserTypeId() : 0;
			int status=1;
			String isAuctionDocDownload=StringUtils.hasLength(request.getParameter("txtisAuctionDocDownload")) ? request.getParameter("txtisAuctionDocDownload"): null;
			if(userTypeId ==1 || userTypeId == 3 || "Y".equalsIgnoreCase(isAuctionDocDownload)){
				if(objectId!=0){
					lstDocumentDetails=fileUploadService.getOfficerDocs(objectId, clientId, linkId,status);
				}else{
					lstDocumentDetails=fileUploadService.getOfficerDocs(objectId, clientId, linkId,status,docIds);
				}
			}else if(userTypeId == 2){
				if(objectId!=0){
					lstDocumentDetails=fileUploadService.getBidderDocs(objectId, clientId, linkId,status,userId);
				}else{
					lstDocumentDetails=fileUploadService.getBidderDocs(objectId, clientId, linkId,status,userId,docIds);
				}
			}
			if (lstDocumentDetails != null && !lstDocumentDetails.isEmpty()) {
				 strDocList.append("     <tr class='gradi border-right'>");
		            strDocList.append("         <th width='8%'>").append(messageSource.getMessage("column_srno", null, LocaleContextHolder.getLocale())).append("</th>");
		            strDocList.append("         <th width='67%' class='a-left'>").append(messageSource.getMessage("fields_document", null, LocaleContextHolder.getLocale())).append("</th>");
		            strDocList.append("         <th width='15%' class='a-left'>").append(messageSource.getMessage("col_size", null, LocaleContextHolder.getLocale())).append("</th>");
		            strDocList.append("         <th width='10%' class='a-left'>").append(messageSource.getMessage("column_action", null, LocaleContextHolder.getLocale())).append("</th>");
		            strDocList.append("         </tr>");
		            int counter=1;
				for (int i=0;i<lstDocumentDetails.size();i++) {
					strDocList.append("<tr id='docTr_").append(lstDocumentDetails.get(i)[0]).append("' class='border-bottom border-right'>");
					strDocList.append("<td width='8%'>");
					strDocList.append(counter++);
					strDocList.append("<td width='57%'>");
					strDocList.append(lstDocumentDetails.get(i)[1]);
					strDocList.append("</td>");
					strDocList.append("<td width='15%' class='a-center'>");
					strDocList.append(new BigDecimal(Double.parseDouble(lstDocumentDetails.get(i)[3].toString())/(1024*1024)).setScale(3, BigDecimal.ROUND_HALF_UP).doubleValue());
					strDocList.append(" MB</td>");
					strDocList.append("<td width='10%' class='a-center'>");
					//strDocList.append(" <input type='hidden' id='txtSignDoc_"+lstDocumentDetails.get(i)[0]).append("' name='txtSignDoc_").append(lstDocumentDetails.get(i)[0]).append("' value='").append(lstDocumentDetails.get(i)[1]).append("").append(lstDocumentDetails.get(i)[2]).append("").append(lstDocumentDetails.get(i)[4]).append("' />");
					strDocList.append("<a href='javascript:void(0);' onclick=\"removeFile('");
					strDocList.append(lstDocumentDetails.get(i)[0]);
					strDocList.append("','2');\">");
					strDocList.append(messageSource.getMessage("link_delete", null, LocaleContextHolder.getLocale())).append("</a></td>");
					strDocList.append("</tr>");
				}
			}
			response.getWriter().write(strDocList.toString());
		} catch (Exception ex) {
			exceptionHandlerService.writeLog(ex);
		}
		finally{
			//makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getDocumentDetails, objectId, 0);
			//auditTrailService.makeAuctionAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getDocumentDetails, objectId, 0);
		}
	}
	
	@RequestMapping(value="/viewmaillinkdetails",method=RequestMethod.POST)
    public String mailContent(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) {
		String retVal="sessionexpired";
		String urlVal;
		urlVal=request.getParameter("hdUrlValue");
		if(urlVal!=null && urlVal!="")
			retVal="redirect:/"+urlVal+encryptDecryptUtils.generateRedirect(urlVal,request);
//		System.out.println(retVal);
		return retVal;
	}
	/**
	 * @author mitesh
	 * @throws Exception 
	 */
	@RequestMapping(value="/checklabelexists",method=RequestMethod.POST)
	@ResponseBody
	public String checkLabelExists(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) throws Exception {
			long retVal=0;
			String labelName;
			labelName=request.getParameter("txtlabelName");
			int clientId=abcUtility.getSessionClientId(request);
			if(labelName!=null && labelName!="")
			{
				retVal= mailBoxService.checkLabelIsExists(clientId,labelName);
			}
			return retVal+"";
	}
	
	   /*Never Repeate*/
	@RequestMapping(value="/reminderlater",method=RequestMethod.POST)
	@ResponseBody
	public String reminderlater(@RequestParam("txttaskid") String txttaskid,@RequestParam("txtselected") String txtselected,HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) throws Exception {
		  String retVal=null;
		   try
		   {
			   String reminderdate;
			   int selectType = Integer.parseInt(txtselected); 
			   int reminder;
			   int repeate;
			   if(selectType==1)
			   {
				 reminderdate=null;
				   reminder=0;
				   repeate=0;
				   boolean isupdated = mailBoxService.remindnever(Integer.parseInt(txttaskid), reminder,repeate,reminderdate);	
			   }
			   else  if(selectType==2)
			   {
				   reminderdate = commonService.getServerDateTimesaddminute(15).toString();
				   boolean isupdated = mailBoxService.remindlater(Integer.parseInt(txttaskid),reminderdate);
			   }
			   else  if(selectType==3)
			   {
				   reminderdate = commonService.getServerDateTimesaddminute(30).toString(); 
				   boolean isupdated = mailBoxService.remindlater(Integer.parseInt(txttaskid),reminderdate);
			   }
			   else if(selectType==4)
			   {
				   reminderdate = commonService.getServerDateTimesaddminute(45).toString(); 
				   boolean isupdated = mailBoxService.remindlater(Integer.parseInt(txttaskid),reminderdate);
			   }
			   else  if(selectType==5)
			   {
				   reminderdate = commonService.getServerDateTimesaddminute(60).toString(); 
				   boolean isupdated = mailBoxService.remindlater(Integer.parseInt(txttaskid),reminderdate);
			   }
				/*System.out.println("hello"+txttaskid);
	 		System.out.println("hello check" + txtselected);*/
		   }
		   catch(Exception E)
		   {
			   System.out.println(E);
		   }
	 		return retVal;
		}
	
}
