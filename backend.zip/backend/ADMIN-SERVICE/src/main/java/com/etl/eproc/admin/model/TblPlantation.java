package com.etl.eproc.admin.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="tbl_Plantation" ,schema ="appmaster" )
public class TblPlantation {

      @Id
      @GeneratedValue(strategy = GenerationType.IDENTITY)
      @Column(name = "plantationId")
      private long plantationId;

      @Column(name = "plantationDistrictName")
      private String plantationDistrictName;

      @ManyToOne(fetch = FetchType.LAZY)
      @JoinColumn(name = "stateID")
      private  TblState tblState;

      @Column(name = "isActive")
      private int isActive;

      @ManyToOne(fetch = FetchType.LAZY)
      @JoinColumn(name = "createdBy")
      private TblUserLogin createdBy;

      @Column(name = "createdOn")
      private Date createdOn;

      @ManyToOne(fetch = FetchType.LAZY)
      @JoinColumn(name = "updatedBy")
      private  TblUserLogin updatedBy;

      @Column(name = "updatedOn")
      private Date updatedOn;



      @JsonManagedReference
      @OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="tblPlantation")
      private Set<TblRevenue> tblRevenue = new HashSet<>();


}
