package com.etl.eproc.admin.serviceI;

import com.etl.eproc.admin.dto.StateDto;
import com.etl.eproc.admin.dto.StateSearchDto;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface StateService {

    public ApiResponse<StateDto> saveState(StateDto statedto);

  //  public ApiResponse<List<StateDto>> getAllSates();

    public ApiResponse<StateDto> getStateById(Long stateId);

    public ApiResponse<StateDto> updateState(StateDto statedto);

 //   ApiResponse<?> searchStatePageable(int isActive, int offset, int page);

    ApiResponse<List<StateSearchDto>> searchState(StateSearchDto stateSearchDto);
}
