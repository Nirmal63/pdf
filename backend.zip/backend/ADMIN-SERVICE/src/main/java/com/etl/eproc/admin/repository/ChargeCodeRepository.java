package com.etl.eproc.admin.repository;

import com.etl.eproc.admin.model.TblChargeCode;
import com.etl.eproc.admin.model.TblPlantation;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ChargeCodeRepository extends JpaRepository<TblChargeCode,Long> {

    boolean existsByChargeCode(String chargeCodeDto);

    Optional<List<TblChargeCode>> findAllByIsActive(int isActive);

    boolean existsByChargeCodeName(String chargeCodeDto);
}
