package com.etl.eproc.admin.serviceI;

import com.etl.eproc.admin.dto.ChargeCodeDto;
import com.etl.eproc.admin.util.ApiResponse;
import com.etl.eproc.admin.util.SearchResponce;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface ChargeCodeServiceI {

    ApiResponse<?> createchargeCode(ChargeCodeDto chargeCodeDto);
    ApiResponse<?> updatechargeCode(ChargeCodeDto chargeCodeDto);
    SearchResponce getAllChargeCode( ChargeCodeDto searchDto);

    public ApiResponse<List<ChargeCodeDto>> getAllChargeCodes(int iActive);

    ApiResponse<?> getChargeCodeyId(long chargeCodeId);
    ApiResponse<?> getUploadDocumentById(long id) throws IOException;
    ApiResponse<?> getAllUploadDocument();
}
