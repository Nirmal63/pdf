package com.etl.eproc.admin.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Table(name = "tbl_ConfigureParameter",schema = "appmaster")
public class TblConfigureParameter {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int configParaId;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "auctionCenterId")
    private TblAuctionCenter auctionCenter;

    private int catalogClosingDay;
    private int catalogPublishingDay;
    private int buyersPromptDays;
    private int sellersPromptDay;
    private int intervalMin;
    private int isActive;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private TblUserLogin createdBy;
    private Date createdOn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updatedBy")
    private TblUserLogin updatedBy;
    private Date updatedOn;

}
