package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.StateDto;
import com.etl.eproc.admin.dto.StateSearchDto;
import com.etl.eproc.admin.model.TblState;
import com.etl.eproc.admin.serviceImpl.StateServiceImpl;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/admin/state")
public class StateController {

    @Autowired
    private StateServiceImpl stateService;

    @PostMapping(value = "/create")
    public ApiResponse<StateDto> createState(@Valid @RequestBody StateDto statedto) {
        try {
            return stateService.saveState(statedto);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }

  /*  @GetMapping("/getAll")
    public ApiResponse<List<StateDto>> getAllStates(){
        try {
            return stateService.getAllSates();
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }
*/
    @GetMapping("/get/{stateId}")
    public ApiResponse<StateDto> getStateById(@PathVariable("stateId") Long stateId) {
        try{
            return stateService.getStateById(stateId);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }

    @PostMapping(value = "/update")
    public ApiResponse<StateDto> updateStateById(@Valid @RequestBody StateDto statedto) {
        try{
            return stateService.updateState(statedto);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }

   /* @GetMapping("/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> searchStatePageable(int isActive, int offset, int page){
        try {
            return stateService.searchStatePageable(isActive,offset,page);
        } catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }*/
    @PostMapping("/search")
    public ApiResponse<?> searchState(@RequestBody StateSearchDto stateSearchDto) {
        try {
            return stateService.searchState(stateSearchDto);
        }catch (Exception e){
         //   return new ApiResponse<Optional<TblState>>(e.getMessage(),500,null);
            e.printStackTrace();
            ApiResponse<Optional<TblState>> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }
    }

  /*  @GetMapping("/getalluploadeddocument")
    public ApiResponse<?> getAllDocument(){
        return new ApiResponse<>("success",200,stateService.getAllUploadedDocument());
    }

    @GetMapping("/getdocument/{uploadeddocumentId}")
    public ApiResponse<?> getuploadDocument(@PathVariable("uploadeddocumentId") long id) throws IOException {
        return new ApiResponse<>("success",200,stateService.getUploadedDocumentById(id));
    }*/
}
