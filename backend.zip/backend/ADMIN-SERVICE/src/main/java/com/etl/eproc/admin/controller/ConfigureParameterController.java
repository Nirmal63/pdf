package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.ConfigureParameterDto;
import com.etl.eproc.admin.dto.ConfigureParameterSearchDto;
import com.etl.eproc.admin.model.TblConfigureParameter;
import com.etl.eproc.admin.serviceI.ConfigureParameterService;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.util.Optional;

@RestController
@RequestMapping("/admin/ConfigureParameter")
public class ConfigureParameterController {


    @Autowired
    private ConfigureParameterService configureParameterService;

    @PostMapping("/create")
    public ApiResponse<?> createConfigureParameter(@Valid @RequestBody ConfigureParameterDto configureParameterDto){
        try {
            ApiResponse<?> configureParameter = configureParameterService.createConfigureParameter(configureParameterDto);
            return configureParameter;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }

    @GetMapping("/getAll")
    public ApiResponse<?> getAllConfigureParameter(){
        try {
            ApiResponse<?> allConfigureParameter = configureParameterService.getAllConfigureParameter();
            return allConfigureParameter;

        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }

    }

    @GetMapping("/get/{configParaId}")
    public ApiResponse<?> getTeaTypeById(@PathVariable("configParaId") int configParaId){
        try {
            ApiResponse<?> configureParameterId = configureParameterService.findConfigureParameterId(configParaId);
            return configureParameterId;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }

    }

    @PostMapping("/update")
    public ApiResponse<?> updateTeaType(@Valid  @RequestBody ConfigureParameterDto configureParameterDto){
        try {
            ApiResponse<?> apiResponse = configureParameterService.updateConfigureParameter(configureParameterDto);
            return apiResponse;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }

    }

    @GetMapping(value = "/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> getAllConfigureParameterByActiveInActive(@PathVariable("isActive") int isActive,@PathVariable("offset") int offset,@PathVariable("page") int page){
        try {
            return configureParameterService.searchConfigureParameterPageable(isActive,offset,page);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }

    }


    @GetMapping(value = "/search")
    public ApiResponse<?> searchConfigureParameter(ConfigureParameterSearchDto configureParameterSearchDto){
        try{
            return configureParameterService.searchConfigureParameter(configureParameterSearchDto);
        }catch (Exception e){
            e.printStackTrace();
            ApiResponse<Optional<TblConfigureParameter>> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }
    }

}
