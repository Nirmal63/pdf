package com.etl.eproc.admin.repository;

import com.etl.eproc.admin.model.TblCategory;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;


public interface CategoryRepository extends JpaRepository<TblCategory,Long> {


    boolean existsByCategoryCode(String categoryCode);

    boolean existsByCategoryName(String categoryName);

//    TblCategory findByisActive(long id);
 Optional<List<TblCategory>> findAllByIsActive(int isActive);

}
