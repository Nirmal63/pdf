package com.etl.eproc.admin.serviceImpl;


import com.etl.eproc.admin.config.FileStorageProperties;
import com.etl.eproc.admin.dto.DownloadDto;
import com.etl.eproc.admin.dto.UploadDocumentConfDto;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.TblUploadDocumentConf;
import com.etl.eproc.admin.model.TblUserLogin;
import com.etl.eproc.admin.repository.CategoryRepository;
import com.etl.eproc.admin.repository.UploadDocumentConfRepository;
import com.etl.eproc.admin.repository.UserLoginRepository;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Date;
import java.util.Optional;


@Service
public class UploadDocumentConfServiceImpl implements UploadDocumentConfService {

    @Autowired
    private UploadDocumentConfRepository uploadDocumentConfRepository;
    @Autowired
    private UserLoginRepository userLoginRepository;
    @Autowired
    private CategoryRepository categoryRepository;
    @Autowired
    private ResourceLoader resourceLoader;
    @Autowired
    private ModelMapper mapper;
    private Paths paths;

    @Autowired
    FileStorageProperties  fileStorageProperties;

    @Override
    public TblUploadDocumentConf uploadDocument(UploadDocumentConfDto uploadDocumentConfDto) {
        try {
            TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin","userId",1));
            TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfRepository.updateIsActive(uploadDocumentConfDto.getTableID(),uploadDocumentConfDto.getTableName());
            TblUploadDocumentConf document = mapper.map(uploadDocumentConfDto,TblUploadDocumentConf.class);
            document.setTableName(uploadDocumentConfDto.getTableName());
            document.setDocumentSize(uploadDocumentConfDto.getDocumentSize());
            document.setRemarks(uploadDocumentConfDto.getRemarks());
            document.setStatus(uploadDocumentConfDto.getStatus());
            document.setFlag(uploadDocumentConfDto.getFlag());
            uploadDocumentConfDto.setFlag(1);
            uploadDocumentConfDto.setStatus(1);
            uploadDocumentConfDto.setIsActive(1);
            document.setCreatedBy(tblUserLogin);
            document.setCreatedOn(new Date());

            // Specify the folder path where the uploaded documents will be stored
            String folderPath = fileStorageProperties.getUploadDir();
            File masterfolder = new File(folderPath+"\\"+uploadDocumentConfDto.getFolderName()+"\\");
            boolean created = masterfolder.mkdirs();
            File folder = new File(masterfolder+"\\"+uploadDocumentConfDto.getTableID()+"\\");
            created = folder.mkdirs();
            // Save the document to the explorer folder
//            File folderActive = new File(folder+"\\Active\\");
//            Boolean created1 = folderActive.mkdirs();
//            File folderInActive = new File(folder+"\\InActive\\");
//            created = folderInActive.mkdirs();

            String filePath = folder +"\\"+ (uploadDocumentConfDto.getUploadDocumentName()+".pdf");
//            String filePath1 =folderInActive+"\\";
//            String filePath2 = folderActive+"\\";

            File sourceDirectory = ResourceUtils.getFile(filePath);
//            File targetDirectory = ResourceUtils.getFile(filePath1);

            String filecontent = uploadDocumentConfDto.getUploadDocumentContent();
            filecontent = (uploadDocumentConfDto.getUploadDocumentContent() != null ? uploadDocumentConfDto.getUploadDocumentContent().replaceAll("data:application/vnd.ms-excel;base64,", "") : "");
            byte[] decodedFile = Base64.getDecoder().decode(filecontent);

            if (sourceDirectory.exists()) {
                Files.createDirectories(sourceDirectory.toPath());
                // Move the directory
//                FileSystemUtils.copyRecursively(sourceDirectory, targetDirectory);
//                if(!created1) {
//                    // Delete the source directory
//                    FileSystemUtils.deleteRecursively(Paths.get(folderPath+tblUploadDocumentConf.getPath()));
//                }
            }

            FileOutputStream out = new FileOutputStream(filePath);
            out.write(decodedFile);
            document.setPath(filePath.replace(folderPath,""));
            out.close();
            // Save the document information to the repository
            return uploadDocumentConfRepository.save(document);
        } catch (Exception e) {
            throw new RuntimeException("Failed to upload document");
        }

    }


    @Override
    public DownloadDto downloadDocument(long Id) throws IOException {

        Optional<TblUploadDocumentConf> tblUploadDocumentConf = uploadDocumentConfRepository.findById(Id);
        String folderPath = fileStorageProperties.getUploadDir();
        File file = new File(folderPath+tblUploadDocumentConf.get().getPath());
        FileInputStream fis = new FileInputStream(file);
            byte[] fileBytes = new byte[(int) file.length()];
            fis.read(fileBytes);
        Base64.Encoder encoder = Base64.getEncoder();
        String encodedString = encoder.encodeToString(fileBytes);
        DownloadDto downloadDtos = new DownloadDto();
        downloadDtos.setDocumentContent(encodedString);
        downloadDtos.setDocumentName(file.getName());
        return downloadDtos;
    }


}


