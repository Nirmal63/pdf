package com.etl.eproc.admin.repository;

import com.etl.eproc.admin.model.TblWareHouseUserReg;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface WareHouseUserRepository extends JpaRepository<TblWareHouseUserReg,Long> {

     Optional<List<TblWareHouseUserReg>> findAllByIsActive(int isActive, Pageable pageable);
     @Query(value = "select * from appuser.tbl_WareHouseuserReg where auctionCenterId=:auctionCenterId and wareHouseCode=:wareHouseCode",nativeQuery = true)
     Optional<List<TblWareHouseUserReg>> findByauctionCenterIdAndWareHouseCode(long auctionCenterId,String wareHouseCode);
     boolean  existsByWareHouseCode(String wareHouseCode);

     boolean  existsBywareHouseLicenseNo(String wareHouseLicenseNo);

     boolean  existsBytaxIdentityNo(String taxMasterId);

      boolean existsByteaBoardRegistrationNo(String teaBoardRegistrationNo);

     boolean existsByPanNo(String panCard);

     boolean existsByGstNo(String gstNo);



}
