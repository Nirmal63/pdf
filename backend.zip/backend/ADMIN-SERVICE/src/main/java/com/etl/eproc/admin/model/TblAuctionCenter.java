package com.etl.eproc.admin.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(schema = "appmaster",name = "tbl_AuctionCenter")
public class TblAuctionCenter {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long auctionCenterId;

    private String auctionCenterName;

    private String auctionCenterCode;

    private String certificateNo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "stateId")
    private TblState stateId;
    private int isActive;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private TblUserLogin createdBy;
    private Date createdOn;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updatedBy")
    private TblUserLogin updatedBy;
    private Date updatedOn;

}
