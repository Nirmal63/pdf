package com.etl.eproc.admin.repository;

import com.etl.eproc.admin.model.TblGrade;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public interface GradeRepository extends JpaRepository<TblGrade,Long> {

  /*  @Query(value = "from TblGrade where isActive= :cStatus")*/
    Optional<List<TblGrade>> findAllByIsActive(int isActive, Pageable pageable);


  boolean existsByGradeName(String gradeName);

  boolean existsByGradeCode(String gradeCode);

  @Query(value = "select gradeName,gradeCode, isActive  from [appmaster].[tbl_Grade]",nativeQuery = true)
  List<Map<String,Object>> findAllData();
}
