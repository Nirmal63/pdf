package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserLoginDto {
    private long userId;
    @NotEmpty(message = "Please enter User Name")
    private String userName;

    private String UserCode;
    @NotNull(message = "Please select User Type")
    private long userType;

    @NotNull(message = "Please select Auction Center")
    private List<Long> auctionCenterId;

    private String address;
    @NotEmpty(message = "Please enter City Name")
    private String city;

    @NotNull(message = "Please select State")
    private long tblState;

    private String StateCode;

    @NotEmpty(message = "Please enter Person Name")
    private String contactPerson;

    private String phoneNo;

    private int mobileNo;

    private String fax;

    private String email;

    private long BankAccountStatus;

    private String entityCode;

    private String password;

    private String confirmPassword;

    private String fssaiNo;

    private String cinNo;

    private String teaBoardRegistrationNo;

    private String taxIdentityNo;

    private String panNo;

    private  String gstNo;

    private String headOfficeAddress;

    private String localOfficeAddress;

    private Date YearOfRegistration;

    private String tngstNo;

    private  String teaBoardExporterLicenseNo;

    private int isActive;

    private long sessionUserId;

    private Date createdOn;

    private Date updatedOn;

    private long isParentId;
}
