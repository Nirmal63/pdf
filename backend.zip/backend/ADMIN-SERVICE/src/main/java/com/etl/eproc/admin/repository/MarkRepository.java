package com.etl.eproc.admin.repository;

import com.etl.eproc.admin.model.TblBankAccountDetail;
import com.etl.eproc.admin.model.TblMark;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface MarkRepository extends JpaRepository<TblMark , Long> {

    public boolean existsByMarkCode(String markCode);

    Optional<List<TblMark>> findAllByIsActive(int isActive, Pageable pageable);
}
