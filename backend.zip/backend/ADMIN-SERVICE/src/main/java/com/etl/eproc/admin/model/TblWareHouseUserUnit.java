package com.etl.eproc.admin.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="tbl_WareHouseUserUnit",schema = "appuser")
public class TblWareHouseUserUnit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long wareHouseUnitId;

    @Column(name = "wareHouseUnitName")
    private String wareHouseUnitName;

    @Column(name = "wareHouseUnitCode")
    private String wareHouseUnitCode;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "wareHouseUserRegId")
    private TblWareHouseUserReg tblWareHouseUserReg;

    @Column(name="isActive",nullable = false)
    private int isActive;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private TblUserLogin createdBy;

    @Column(name="createdOn",nullable = false)
    private Date createdOn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updatedBy")
    private TblUserLogin updatedBy;

    @Column(name="updatedOn")
    private Date updatedOn;
}
