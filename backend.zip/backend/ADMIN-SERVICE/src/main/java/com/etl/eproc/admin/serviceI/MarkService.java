package com.etl.eproc.admin.serviceI;

import com.etl.eproc.admin.dto.BankAccountSearchDto;
import com.etl.eproc.admin.dto.MarkDto;
import com.etl.eproc.admin.dto.MarkSearchDto;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface MarkService {

    public ApiResponse<MarkDto> createMark(MarkDto markDto);

    public ApiResponse<MarkDto> getMarkById(Long markId);

   // public ApiResponse<List<MarkDto>> getAllMark();

    public ApiResponse<MarkDto> updateMark( MarkDto markDto);

  //  public  ApiResponse<?> searchMarkPageable(int isActive, int offset, int page);

    public ApiResponse<List<MarkSearchDto>> searchMarks(MarkSearchDto markSearchDto);
}
