package com.etl.eproc.admin.serviceI;


import com.etl.eproc.admin.dto.CategoryDto;
import com.etl.eproc.admin.util.ApiResponse;
import com.etl.eproc.admin.util.SearchResponce;

import java.io.IOException;
import java.util.List;

public interface CategoryService {
    ApiResponse<?> createCategory(CategoryDto categoryDto);
    ApiResponse<?> updateCategory(CategoryDto categoryDto);
    SearchResponce getAllCategory( CategoryDto categoryDto );
    public ApiResponse<List<CategoryDto>> getAllCategorys(int iActive);

    ApiResponse<?> getCategoryId(long categoryId);

    ApiResponse<?> getAllUploadDocument();

    ApiResponse<?> getUploadDocumentById(long id) throws IOException;




}
