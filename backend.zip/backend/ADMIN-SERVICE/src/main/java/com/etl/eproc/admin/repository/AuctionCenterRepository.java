package com.etl.eproc.admin.repository;

import com.etl.eproc.admin.model.TblAuctionCenter;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public interface AuctionCenterRepository extends JpaRepository<TblAuctionCenter, Long> {

    Optional<List<TblAuctionCenter>> findAllByIsActive(int isActive, Pageable pageable);

    boolean existsByAuctionCenterName(String auctionCenterName);

    boolean existsByAuctionCenterCode(String auctionCenterCode);

    boolean existsByCertificateNo(String certificateNo);

    @Query(value = "select auctionCenterName, auctionCenterCode,certificateNo,isActive from [appmaster].[tbl_AuctionCenter]",nativeQuery = true)
    List<Map<String,Object>> findAllData();
}
