package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.RevenueDto;
import com.etl.eproc.admin.dto.RevenueSearchDto;
import com.etl.eproc.admin.serviceI.RevenueServiceI;
import com.etl.eproc.admin.util.ApiResponse;
import com.etl.eproc.admin.util.SearchResponce;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/admin/revenue")
public class RevenueController {

    @Autowired
    private RevenueServiceI revenueServiceI;


    @PostMapping(value = "/create")
    public ApiResponse<?> saveData(@Valid @RequestBody RevenueDto revenueDto){
        try{
        ApiResponse<?> revenueDto1=revenueServiceI.createRevenue(revenueDto);
        return revenueDto1;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }

    @GetMapping("/get/{revenueId}")
    public ApiResponse<RevenueDto> getById(@PathVariable(name ="revenueId") long revenueId){
        try{
        ApiResponse<RevenueDto> revenueDto=revenueServiceI.getById(revenueId);
        return revenueDto;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }

    @GetMapping("/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> getAll(@PathVariable("isActive") long isActive, @PathVariable("offset") int offset, @PathVariable("page") int page){
        try{
        ApiResponse<?> revenueDtos=revenueServiceI.getAll(isActive,offset,page);
        return  revenueDtos;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }

    @PostMapping(value = "/update")
    public ApiResponse<?> updateData(@Valid @RequestBody RevenueDto revenueDto){
        try {
        ApiResponse<?> revenueDto1=revenueServiceI.updateBy(revenueDto);
        return revenueDto1;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }


    @PostMapping("/search")
    public ApiResponse<List<RevenueDto>> searchBy(@RequestBody RevenueSearchDto revenueSearchDto){
        try {
        ApiResponse<List<RevenueDto>> revenueDtos=revenueServiceI.searchRevenue(revenueSearchDto);
        return revenueDtos;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }


    @GetMapping("/getAllUploaddocument")
    public ApiResponse<?> getAllDocument(){
        return new ApiResponse<>("success",200,revenueServiceI.getAllUploadDocument());
    }

    @GetMapping("/getById/{uploaddocumentId}")
    public ApiResponse<?> getUploadDocument(@PathVariable("uploaddocumentId") long id) throws IOException {
        return new ApiResponse<>("success",200,revenueServiceI.getUploadDocumentById(id));

    }


}
