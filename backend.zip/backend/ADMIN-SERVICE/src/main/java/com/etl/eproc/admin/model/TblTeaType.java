package com.etl.eproc.admin.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

import java.util.Date;


@Entity
@Table(name = "tbl_TeaType",schema = "appmaster")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TblTeaType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int teaTypeId;
    private String teaTypeName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "categoryId")
    private TblCategory category;

    private int isActive;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private TblUserLogin createdBy;
    private Date createdOn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updatedBy")
    private TblUserLogin updatedBy;
    private Date updatedOn;


}
