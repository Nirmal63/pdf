package com.etl.eproc.admin.serviceImpl;

import com.etl.eproc.admin.dto.UserLoginDto;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.TblAuctionCenter;
import com.etl.eproc.admin.model.TblRole;
import com.etl.eproc.admin.model.TblState;
import com.etl.eproc.admin.model.TblUserLogin;
import com.etl.eproc.admin.repository.AuctionCenterRepository;
import com.etl.eproc.admin.repository.RoleRepository;
import com.etl.eproc.admin.repository.StateRepository;
import com.etl.eproc.admin.repository.UserLoginRepository;
import com.etl.eproc.admin.serviceI.UserLoginService;
import com.etl.eproc.admin.util.ApiResponse;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserLoginServiceImpl implements UserLoginService {

    @Autowired
    private ModelMapper mapper;
    @Autowired
    private UserLoginRepository userLoginRepository;

    @Autowired
    private StateRepository stateRepository;
    @Autowired
    private AuctionCenterRepository auctionCenterRepository;
    @Autowired
    private RoleRepository roleRepository;
    @Override
    public ApiResponse<?> createUser(UserLoginDto userLoginDto) {

        TblState tblState = stateRepository.findById(userLoginDto.getTblState()).orElseThrow(() -> new ResourceNotFoundException("TblState", "stateId", userLoginDto.getTblState()));
        TblRole tblRole = roleRepository.findById(userLoginDto.getUserType()).orElseThrow(()-> new ResourceNotFoundException("TblRole","roleId",userLoginDto.getUserType()));
        //TblAuctionCenter auctionCenter = auctionCenterRepository.findById(userLoginDto.getAuctionCenterId()).orElseThrow(() -> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId", userLoginDto.getAuctionCenterId()));
        TblUserLogin createdByTbl =userLoginRepository.findById(userLoginDto.getSessionUserId()).orElseThrow(()-> new ResourceNotFoundException("TblUserLogin","userId",userLoginDto.getSessionUserId()));
        List<TblAuctionCenter> auctionCenters=new ArrayList<>();
        for(long auctionCenterId:userLoginDto.getAuctionCenterId()){
            TblAuctionCenter auctionCenter = auctionCenterRepository.findById(auctionCenterId).orElseThrow(() -> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId",auctionCenterId));
            auctionCenters.add(auctionCenter);
        }
        TblUserLogin tblUserLogin = mapper.map(userLoginDto, TblUserLogin.class);
        tblUserLogin.setIsActive(1);
        tblUserLogin.setCreatedBy(createdByTbl.getUserId());
        tblUserLogin.setCreatedOn(new Date());
        tblUserLogin.setUserType(tblRole);
        tblUserLogin.setTblState(tblState);
        tblUserLogin.setStateCode(tblState.getStateCode());
        tblUserLogin.setAuctionCenter(auctionCenters);
        userLoginRepository.save(tblUserLogin);
        return new ApiResponse<UserLoginDto>("User created successfully", 200, userLoginDto);
    }


    public ApiResponse<?> updateUser(UserLoginDto userLoginDto) {
        TblState  tblState = stateRepository.findById(userLoginDto.getTblState()).orElseThrow(() -> new ResourceNotFoundException("TblState", "stateId", userLoginDto.getTblState()));
        //TblAuctionCenter auctionCenter = auctionCenterRepository.findById(userLoginDto.getAuctionCenterId()).orElseThrow(() -> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId", userLoginDto.getAuctionCenterId()));
        TblUserLogin updatedByTbl =userLoginRepository.findById(userLoginDto.getSessionUserId()).orElseThrow(()-> new ResourceNotFoundException("TblUserLogin","userId",userLoginDto.getSessionUserId()));
        TblUserLogin tblUserLogin1 = userLoginRepository.findById(userLoginDto.getUserId()).orElseThrow(()-> new ResourceNotFoundException("TblUserLogin","userId",userLoginDto.getUserId()));
        List<TblAuctionCenter> auctionCenters=new ArrayList<>();
        for(long auctionCenterId:userLoginDto.getAuctionCenterId()){
            TblAuctionCenter auctionCenter = auctionCenterRepository.findById(auctionCenterId).orElseThrow(() -> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId",auctionCenterId));
            auctionCenters.add(auctionCenter);
        }
         tblUserLogin1.setUserName(userLoginDto.getUserName());
         tblUserLogin1.setUserCode(userLoginDto.getUserCode());
         tblUserLogin1.setAuctionCenter(auctionCenters);
         tblUserLogin1.setAddress(userLoginDto.getAddress());
         tblUserLogin1.setCity(userLoginDto.getCity());
         tblUserLogin1.setContactPerson(userLoginDto.getContactPerson());
         tblUserLogin1.setPhoneNo(userLoginDto.getPhoneNo());
         tblUserLogin1.setFax(userLoginDto.getFax());
         tblUserLogin1.setEmail(userLoginDto.getEmail());
         tblUserLogin1.setTeaBoardRegistrationNo(userLoginDto.getTeaBoardRegistrationNo());
         tblUserLogin1.setTaxIdentityNo(String.valueOf(userLoginDto.getTaxIdentityNo()));
         tblUserLogin1.setMobileNo(userLoginDto.getMobileNo());
         tblUserLogin1.setEntityCode(userLoginDto.getEntityCode());
         tblUserLogin1.setPanNo(userLoginDto.getPanNo());
         tblUserLogin1.setCinNo(String.valueOf(userLoginDto.getCinNo()));
         tblUserLogin1.setFssaiNo(String.valueOf(userLoginDto.getFssaiNo()));
         tblUserLogin1.setGstNo(userLoginDto.getGstNo());
         tblUserLogin1.setIsActive(userLoginDto.getIsActive());
         tblUserLogin1.setTblState(tblState);
         tblUserLogin1.setStateCode(tblState.getStateCode());
         tblUserLogin1.setUpdatedBy(updatedByTbl.getUserId());
         tblUserLogin1.setUpdatedOn(new Date());
        userLoginRepository.save(tblUserLogin1);
        return  new ApiResponse<UserLoginDto>("User Updated successfully" ,200,userLoginDto);
    }

    @Override
    public ApiResponse<List<UserLoginDto>> getAllUser() {
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE).setAmbiguityIgnored(true);
        List<UserLoginDto> userLoginDtoList=userLoginRepository.findAll().stream().map(
                tblUserLogin -> {
                    UserLoginDto userLoginDto = mapper.map(tblUserLogin, UserLoginDto.class);
                    TblState tblState =stateRepository.findById(tblUserLogin.getTblState().getStateId()).orElseThrow(()->new ResourceNotFoundException("TblUserLogin","tblstate",userLoginDto.getTblState()));
                    userLoginDto.setSessionUserId(tblUserLogin.getCreatedBy());
                    userLoginDto.setTblState(tblState.getStateId());
                    userLoginDto.setUserType(tblUserLogin.getUserType().getRoleId());
                    return userLoginDto;
                } ).collect(Collectors.toList());
        return new ApiResponse<List<UserLoginDto>>("getAll User successfully" ,200,userLoginDtoList);
    }

    @Override
    public ApiResponse<UserLoginDto> getUserById(long userId) {
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE).setAmbiguityIgnored(true);
        TblUserLogin tblUserLogin = userLoginRepository.findById(userId).orElseThrow(()->new ResourceNotFoundException("TblUserLogin","userId",userId));
        UserLoginDto getUserByid = mapper.map(tblUserLogin,UserLoginDto.class);
        getUserByid.setSessionUserId(tblUserLogin.getCreatedBy());
        return  new ApiResponse<UserLoginDto>("User get by Id successfully" ,200,getUserByid);
    }

    @Override
    public ApiResponse<?> getAllUserPageable(int isActive, int offset, int page) {
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE).setAmbiguityIgnored(true);
        Pageable pageable= PageRequest.of(page,offset);
        Optional<List<TblUserLogin>> list =userLoginRepository.findAllByIsActive(isActive,pageable);
        if(!list.isEmpty() && list.isPresent()){
            List<UserLoginDto> dtos=list.get().stream().map(
                    tblUserLogin -> {
                        UserLoginDto userLoginDto = mapper.map(tblUserLogin, UserLoginDto.class);
                        userLoginDto.setIsActive(tblUserLogin.getIsActive());
                        return userLoginDto;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse("success",200,dtos);
        }

        return new ApiResponse("No Record Found",404,null);
    }

  /*    public ApiResponse<List<TblUserLogin>> getUsersByParentId(long isParentId){
         List<TblUserLogin> chieldtUsers = userLoginRepository.findUserByParentId(isParentId);
              return new ApiResponse("success",200,chieldtUsers);
      }*/
}
