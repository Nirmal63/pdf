package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.UserLoginDto;
import com.etl.eproc.admin.model.TblUserLogin;
import com.etl.eproc.admin.serviceI.UserLoginService;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Optional;

@RestController
@RequestMapping("/admin/user")
public class UserLoginController {

    @Autowired
    private UserLoginService userLoginService;

    @PostMapping("/create")
    public ApiResponse<?> createUser(@Valid @RequestBody UserLoginDto userLoginDto) {
        try {

            return userLoginService.createUser(userLoginDto);
        } catch (Exception e) {
            e.printStackTrace();
            ApiResponse<UserLoginDto> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }

    }

    @PostMapping("/update/{userId}")
    public ApiResponse<?> updateUser(@PathVariable("userId") int userId, @RequestBody UserLoginDto userLoginDto) {
        try {
            return userLoginService.updateUser(userLoginDto);
        } catch (Exception e) {
            ApiResponse<UserLoginDto> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }
    }

    @GetMapping("/getAll")
    public ApiResponse<?> getAllUser() {
        try {
            return userLoginService.getAllUser();
        } catch (Exception e) {
            ApiResponse<UserLoginDto> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }
    }

    @GetMapping("/getUserById/{userId}")
    public ApiResponse<?> getUserById(@PathVariable long userId) {
        try {
            return userLoginService.getUserById(userId);
        } catch (Exception e) {
            ApiResponse<UserLoginDto> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }
    }

    @GetMapping(value = "/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> searchAuctionCenterPageable(@PathVariable("isActive") int isActive, @PathVariable("offset") int offset, @PathVariable("page") int page) {
        try {
            return userLoginService.getAllUserPageable(isActive, offset, page);
        } catch (Exception e) {
            e.printStackTrace();
            ApiResponse<Optional<TblUserLogin>> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }
    }
  /*  @GetMapping(value = "/getAllchieldUser/{isParentId}")
    public ApiResponse<?> getChieldUsers(@PathVariable  long isParentId) {
        try {
            return userLoginService.getUsersByParentId(isParentId);
        } catch (Exception e) {
            e.printStackTrace();
            return new ApiResponse<>(e.getMessage(), 500, null);
        }
    }*/
}

