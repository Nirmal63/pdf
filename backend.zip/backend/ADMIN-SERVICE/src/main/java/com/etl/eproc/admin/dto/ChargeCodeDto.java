package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ChargeCodeDto {

    private long chargeCodeId;
    @NotEmpty(message = "please enter charge code name.")
    @Size(min = 2 ,message = "The charge code name should be at least 2 characters long")
    @Size(max = 50,message = "The charge code name should not exceed 50 characters.")
    private String chargeCodeName;
    @NotEmpty(message = "Please enter the charge code.")
    @Pattern(regexp = "^[A-Za-z0-9]*$",message = "The charge code should only contain alphanumeric characters.")
    @Size(min = 2,message = "The charge code should be at least 2 characters long.")
    @Size(max = 10,message = "The charge code should not exceed 10 characters.")
    private String chargeCode;
    private Integer isActive;
    private String uploadDocumentRemarks;
    private DownloadDto[] downloadDto;
}
