package com.etl.eproc.admin.repository;

import com.etl.eproc.admin.model.TblUserLogin;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface UserLoginRepository extends JpaRepository<TblUserLogin, Long> {


    Optional<List<TblUserLogin>> findAllByIsActive(int isActive, Pageable pageable);
        long findByIsParentId(long isParentId);

    @Query(value = "select * from appuser.tbl_UserLogin where isParentId=:isParentId",nativeQuery = true)
    List<Long> findByParentId(long isParentId);

    boolean existsByEmail(String email);
    boolean existsByUserCode(String userCode);
    boolean existsByTeaBoardRegistrationNo(String teaBoardRegistrationNo);
    boolean existsByTaxIdentityNo(String taxIdentityNo);
    boolean existsByCinNo(String cinNo);
    boolean existsByPanNo(String panNo);
    boolean existsByGstNo(String gstNo);
    boolean existsByFssaiNo(String fssaiNo);

      /*  @Query()
        long countParentId()*/
    @Query(value = "select * from appuser.tbl_UserLogin where userType=:userType",nativeQuery = true)
    List<TblUserLogin> findAllByUserType(long userType);

    @Query(value = "select userType from appuser.tbl_UserLogin where userId=:userId",nativeQuery = true)
    Integer getUserTypeByUserId(long userId);

    @Query(value = "select * from appuser.tbl_UserLogin where isParentId=:isParentId",nativeQuery = true)
    List<TblUserLogin>  findChieldUserByParentId(long isParentId);
}
