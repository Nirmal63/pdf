package com.etl.eproc.admin.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name="tbl_State",schema="appmaster")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

public class TblState {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long stateId;
    private String stateName;
    private String stateCode;
    private String stateInitial;
    private int isActive;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private TblUserLogin createdBy;
    private Date createdOn;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updatedBy")
    private TblUserLogin updatedBy;
    private Date updatedOn;
}
