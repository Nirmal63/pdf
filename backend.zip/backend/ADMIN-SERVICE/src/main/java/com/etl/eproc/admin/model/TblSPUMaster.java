package com.etl.eproc.admin.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(name = "tbl_SPUMaster",schema = "appmaster")
public class TblSPUMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int spuMasterId;
    @ManyToOne
    @JoinColumn(name = "auctionCenterId")
    private TblAuctionCenter auctionCenter;
    @ManyToOne
    @JoinColumn(name = "teaTypeId")
    private TblTeaType tblTeaType;
    @ManyToOne
    @JoinColumn(name = "gradeId")
    private TblGrade tblGrade;
    private String spuQuantity;
    private String manufacturingPeriod;
    private String minLotSize;
    private String factoryAnnualCapacity;
    private int isActive;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private TblUserLogin createdBy;
    private Date createdOn;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updatedBy")
    private TblUserLogin updatedBy;
    private Date updatedOn;
}
