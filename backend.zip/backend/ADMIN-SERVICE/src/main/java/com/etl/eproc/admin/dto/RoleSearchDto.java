package com.etl.eproc.admin.dto;

import lombok.*;

@Getter
@Setter
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoleSearchDto {

    private long roleId;
    private String roleName;
    private Integer isActive;
}
