package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.FactoryTypeDto;
import com.etl.eproc.admin.serviceI.FactoryTypeService;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.IOException;
@RestController
@RequestMapping("/admin/factorytype")
public class FactoryTypeController {
    @Autowired
    private FactoryTypeService factoryTypeService;
    @PostMapping(value = "/create")
    public ApiResponse<?> createFactoryType(@Valid @RequestBody FactoryTypeDto factoryTypeDto) {
        try {

            return factoryTypeService.createFactoryType(factoryTypeDto);
        } catch (Exception e) {
            ApiResponse<FactoryTypeDto> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }

    }
    @PostMapping(value = "/update")
    public ApiResponse<?> updateFactoryType(@Valid @RequestBody  FactoryTypeDto factoryTypeUpdateDto){
        try{
            return factoryTypeService.updateFactoryType(factoryTypeUpdateDto);
        }
        catch(Exception e){
            ApiResponse<FactoryTypeDto> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return  apiResponse ;
        }
    }

    @GetMapping("/get/{factoryTypeId}")
    public ApiResponse<?> getFactoryTypeById(@PathVariable("factoryTypeId") int factoryTypeId){
        try{
            return factoryTypeService.getFactoryTypeById(factoryTypeId);
        }
        catch(Exception e){
            ApiResponse<FactoryTypeDto> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return  apiResponse ;
        }
    }
   /* @GetMapping("/getAll")
    public ApiResponse<?> getAllFactoryType(){
        try{
            return factoryTypeService.getAllFactoryType();
        }
        catch(Exception e){
            ApiResponse<FactoryTypeDto> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return  apiResponse ;
        }
    }
    @GetMapping(value = "/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> getAllFactoryTypePageable(@PathVariable("isActive") int isActive,@PathVariable("offset") int offset,@PathVariable("page") int page) {

        try {
            return factoryTypeService.getAllFactoryTypePageable(isActive,offset,page);
        }catch (Exception e){
            e.printStackTrace();
            ApiResponse<Optional<TblFactoryType>> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }
    }*/
    @PostMapping(value = "/search")
    public ApiResponse<?> searchFactoryType(@RequestBody FactoryTypeDto factoryTypeDto){
        try {
            return factoryTypeService.searchFactoryType(factoryTypeDto);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }
    @GetMapping("/getalluploadeddocument")
    public ApiResponse<?> getAllDocument(){
        return new ApiResponse<>("success",200,factoryTypeService.getAllUploadedDocument());
    }

    @GetMapping("/getdocument/{uploadeddocumentId}")
    public ApiResponse<?> getuploadDocument(@PathVariable("uploadeddocumentId") long id) throws IOException {
        return new ApiResponse<>("success",200,factoryTypeService.getUploadedDocumentById(id));

    }
}
