package com.etl.eproc.admin.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RevenueDto {

    private long revenueId;

    @NotEmpty(message = "please enter revenue district name")
    @Size(min = 2,max = 50,message = "The revenue district name should be  at least 2 characters long and not exceed 50 characters")
    private String RevenueDistrictName;

    @NotNull(message = "Please select a state from the dropdown menu")
    private long StateId;

    @NotNull(message = "Please select a plantation district from the dropdown menu")
    private long plantationId;

    private Integer isActive;

    private String uploadDocumentRemarks;

    private String[] uploadDocumentContent;

    private String[] uploadDocumentName;

    private String uploadDocumentSize;

}
