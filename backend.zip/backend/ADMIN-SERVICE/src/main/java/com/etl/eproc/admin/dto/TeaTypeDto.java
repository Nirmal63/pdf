package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.math.BigInteger;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TeaTypeDto {

    private int teaTypeId;
    @NotEmpty(message = "Please enter the tea type.")
    @Size(min = 2,message = "The tea type should be at least 2 characters long.")
    @Size(max = 50,message = "The tea type should not exceed 50 characters.")
    private String TeaTypeName;
    @NotEmpty(message = "Please select category name")
    private String categoryName;
    @NotEmpty(message = "Please select category code")
    private String categoryCode;
    private int isActive;

    private String uploadDocumentRemarks;
    private String[] uploadDocumentContent;
    private String[] uploadDocumentName;
    private String uploadDocumentSize;

}
