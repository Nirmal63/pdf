package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.BankAccountDetailDto;
import com.etl.eproc.admin.dto.BankAccountSearchDto;
import com.etl.eproc.admin.serviceI.BankAccountDetailService;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/admin/bankAccountDetails")
public class BankAccountDetailController {

    @Autowired
    private BankAccountDetailService bankAccountDetailService;

    @PostMapping(value = "/create")
    public ApiResponse<BankAccountDetailDto> createBankAccountDetails(@Valid @RequestBody BankAccountDetailDto bankAccountDetailDto){
        try {
            return bankAccountDetailService.createBankAccount(bankAccountDetailDto);
        } catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }

    /*@GetMapping("/getAll/BankAccountDetails")
    public ApiResponse<List<BankAccountDetailDto>> getAllBankDetails(){
        try{
            return bankAccountDetailService.getAllBankAccount();
        } catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }*/

    @GetMapping("/get/{bankAccountDetailId}")
    public ApiResponse<BankAccountDetailDto> getBankDetailsById(@PathVariable("bankAccountDetailId") Long bankAccountDetailId){
        try{
            return bankAccountDetailService.getBankAccountById(bankAccountDetailId);
        } catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }

    @PostMapping(value = "/update")
    public ApiResponse<BankAccountDetailDto> updateBankAccountDetails(@Valid @RequestBody BankAccountDetailDto bankAccountDetailDto) {
    try {
        return bankAccountDetailService.updateBankAccount(bankAccountDetailDto);
    }catch (Exception e){
        return new ApiResponse<>(e.getMessage(), 500,null);
    }
    }

   /* @GetMapping("/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> searchBankAccountDetailPageable(@PathVariable("isActive") int isActive,@PathVariable("offset") int offset,@PathVariable("page") int page) {
        try {
            return bankAccountDetailService.searchBankAccountDetailPageable(isActive,offset,page);
        }catch (Exception e){
     return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }*/

    @PostMapping("/search")
    public ApiResponse<?> searchBankAccountDetail(@RequestBody  BankAccountSearchDto bankAccountSearchDto) {
        try {
            return bankAccountDetailService.searchBankAccountDetails(bankAccountSearchDto);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }
}
