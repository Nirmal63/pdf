package com.etl.eproc.admin.repository;

import com.etl.eproc.admin.model.TblPlantation;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public interface PlantationRepository extends JpaRepository<TblPlantation,Long> {

    Optional<List<TblPlantation>> findAllByIsActive(long isActive, Pageable pageable);

    boolean existsByPlantationDistrictName(String plantationDistrict);
}
