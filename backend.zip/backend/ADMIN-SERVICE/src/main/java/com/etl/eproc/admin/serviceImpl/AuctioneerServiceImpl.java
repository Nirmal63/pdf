package com.etl.eproc.admin.serviceImpl;

import com.etl.eproc.admin.dto.AuctioneerDto;
import com.etl.eproc.admin.dto.DownloadDto;
import com.etl.eproc.admin.dto.UploadDocumentConfDto;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.*;
import com.etl.eproc.admin.repository.*;
import com.etl.eproc.admin.serviceI.AuctioneerService;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AuctioneerServiceImpl implements AuctioneerService {

    @Autowired
    private StateRepository stateRepository;
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private AuctionCenterRepository auctionCenterRepository;
    @Autowired
    private UserLoginRepository userLoginRepository;
    @Autowired
    private ModelMapper mapper;
    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;
    @Autowired
    private UploadDocumentConfRepository uploadDocumentConfRepository;

    @Override
    @Transactional(propagation = Propagation.REQUIRED , rollbackFor = Exception.class)
    public ApiResponse<?> createAuctioneer(AuctioneerDto auctioneerDto) {
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
       if(auctioneerDto.getIsParentId()!=0){
           TblUserLogin parentUser=userLoginRepository.findById(auctioneerDto.getIsParentId()).orElseThrow(()-> new ResourceNotFoundException("TblUserLogin","parentUser",auctioneerDto.getIsParentId()));

           if(parentUser.getIsParentId()!=0){
               return new ApiResponse("Already register as chield Auctioneer.",500,false);
           }
           List<Long> parentUserCount =userLoginRepository.findByParentId(auctioneerDto.getIsParentId());
           System.out.print(parentUserCount);
           if(parentUserCount.size()>=5){
               return new ApiResponse("Already 5 Auctioneer Associate/Post Auctioneer Associate are Registered",500,false);
           }
       }
        ApiResponse<Boolean> apiResponse=validateUser(auctioneerDto.getEmail(), auctioneerDto.getAuctioneerCode(), auctioneerDto.getTeaBoardRegistrationNo(),auctioneerDto.getTaxIdentityNo(), auctioneerDto.getPanNo(),auctioneerDto.getGstNo(),auctioneerDto.getFssaiNo(),auctioneerDto.getCinNo() );
        if(apiResponse.getResponseData()==false) {
            TblState tblState = stateRepository.findById(auctioneerDto.getTblState()).orElseThrow(() -> new ResourceNotFoundException("TblState", "stateId", auctioneerDto.getTblState()));
            TblRole tblRole = roleRepository.findById(auctioneerDto.getUserType()).orElseThrow(() -> new ResourceNotFoundException("TblRole", "roleId", auctioneerDto.getUserType()));
          //  TblAuctionCenter auctionCenter = auctionCenterRepository.findById(auctioneerDto.getAuctionCenterId()).orElseThrow(() -> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId", auctioneerDto.getAuctionCenterId()));
            TblUserLogin createdByTbl = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
            List<TblAuctionCenter> auctionCenters=new ArrayList<>();
            for(long auctionCenterId:auctioneerDto.getAuctionCenterId()){
                TblAuctionCenter auctionCenter = auctionCenterRepository.findById(auctionCenterId).orElseThrow(() -> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId",auctionCenterId));
                auctionCenters.add(auctionCenter);
            }

            TblUserLogin tblUserLogin = mapper.map(auctioneerDto, TblUserLogin.class);
            //tblUserLogin.setCreatedOn(createdByTbl.getCreatedOn());
            tblUserLogin.setUserName(auctioneerDto.getAuctioneerName());
            tblUserLogin.setUserCode(auctioneerDto.getAuctioneerCode());
            tblUserLogin.setIsActive(1);
            tblUserLogin.setCreatedBy(createdByTbl.getUserId());
            tblUserLogin.setCreatedOn(new Date());
            tblUserLogin.setUserType(tblRole);
            tblUserLogin.setTblState(tblState);
            tblUserLogin.setMobileNo(Long.valueOf(auctioneerDto.getMobileNo()));
            tblUserLogin.setIsParentId(auctioneerDto.getIsParentId());
            tblUserLogin.setStateCode(tblState.getStateCode());
            tblUserLogin.setAuctionCenter(auctionCenters);
            userLoginRepository.save(tblUserLogin);
            //AuctioneerDto auctioneerDtonew = mapper.map(tblUserLogin, AuctioneerDto.class);
            if (!auctioneerDto.getDownloadDto()[0].getDocumentContent().isEmpty()) {
                int i = 0;
                for(int j=0;j<=auctioneerDto.getDownloadDto().length-1;j++) {
                    UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                    uploadDocumentConfDto.setRemarks(auctioneerDto.getUploadDocumentRemarks());
                    uploadDocumentConfDto.setTableID(tblUserLogin.getUserId());
                    uploadDocumentConfDto.setFlag(1);
                    uploadDocumentConfDto.setStatus(1);
                    uploadDocumentConfDto.setIsActive(1);
                    uploadDocumentConfDto.setDocumentSize(String.valueOf(auctioneerDto.getDownloadDto()[i].getDocumentSize()));
                    uploadDocumentConfDto.setTableName("tbl_UserLogin");
                    uploadDocumentConfDto.setFolderName("Auctioneer");
                    uploadDocumentConfDto.setUploadDocumentName(String.valueOf(auctioneerDto.getDownloadDto()[i].getDocumentName()));
                    uploadDocumentConfDto.setUploadDocumentContent(String.valueOf(auctioneerDto.getDownloadDto()[i].getDocumentContent()));
                    TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                    i++;
                }
            }
            return new ApiResponse<AuctioneerDto>("Auctioneer created successfully", 201, auctioneerDto);
        }
        return apiResponse;
    }


    @Override
    public ApiResponse<?> updateAuctioneer(AuctioneerDto auctioneerDto) {
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE).setAmbiguityIgnored(true);
        TblState  tblState = stateRepository.findById(auctioneerDto.getTblState()).orElseThrow(() -> new ResourceNotFoundException("TblState", "stateId", auctioneerDto.getTblState()));
        //TblAuctionCenter auctionCenter = auctionCenterRepository.findById(auctioneerDto.getAuctionCenterId()).orElseThrow(() -> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId", auctioneerDto.getAuctionCenterId()));
        TblUserLogin updatedByTbl =userLoginRepository.findById(1L).orElseThrow(()-> new ResourceNotFoundException("TblUserLogin","userId",1));
        TblUserLogin tblUserLogin1 = userLoginRepository.findById(auctioneerDto.getUserId()).orElseThrow(()-> new ResourceNotFoundException("TblUserLogin","userId",auctioneerDto.getUserId()));
        List<TblAuctionCenter> auctionCenters=new ArrayList<>();
        for(long auctionCenterId:auctioneerDto.getAuctionCenterId()){
            TblAuctionCenter auctionCenter = auctionCenterRepository.findById(auctionCenterId).orElseThrow(() -> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId",auctionCenterId));
            auctionCenters.add(auctionCenter);
        }
        tblUserLogin1.setUserName(auctioneerDto.getAuctioneerName());
        tblUserLogin1.setUserCode(auctioneerDto.getAuctioneerCode());
        tblUserLogin1.setAuctionCenter(auctionCenters);
        tblUserLogin1.setAddress(auctioneerDto.getAddress());
        tblUserLogin1.setCity(auctioneerDto.getCity());
        tblUserLogin1.setContactPerson(auctioneerDto.getContactPerson());
        tblUserLogin1.setPhoneNo(auctioneerDto.getPhoneNo());
        tblUserLogin1.setFax(auctioneerDto.getFax());
        tblUserLogin1.setEmail(auctioneerDto.getEmail());
        tblUserLogin1.setTeaBoardRegistrationNo(auctioneerDto.getTeaBoardRegistrationNo());
        tblUserLogin1.setTaxIdentityNo(auctioneerDto.getTaxIdentityNo());
        tblUserLogin1.setMobileNo(Long.valueOf(auctioneerDto.getMobileNo()));
        tblUserLogin1.setEntityCode(auctioneerDto.getEntityCode());
        tblUserLogin1.setPanNo(auctioneerDto.getPanNo());
        tblUserLogin1.setCinNo(auctioneerDto.getCinNo());
        tblUserLogin1.setFssaiNo(auctioneerDto.getFssaiNo());
        tblUserLogin1.setGstNo(auctioneerDto.getGstNo());
        tblUserLogin1.setIsActive(auctioneerDto.getIsActive());
        tblUserLogin1.setTblState(tblState);
        tblUserLogin1.setStateCode(tblState.getStateCode());
        tblUserLogin1.setUpdatedBy(updatedByTbl.getUserId());
        tblUserLogin1.setUpdatedOn(new Date());
        userLoginRepository.save(tblUserLogin1);
        //AuctioneerDto auctioneerDtonew = mapper.map(tblUserLogin1, AuctioneerDto.class);
        if (!auctioneerDto.getDownloadDto()[0].getDocumentContent().isEmpty()) {
            int i = 0;
            for(int j=0;j<=auctioneerDto.getDownloadDto().length-1;j++) {
                UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                uploadDocumentConfDto.setRemarks(auctioneerDto.getUploadDocumentRemarks());
                uploadDocumentConfDto.setTableID(tblUserLogin1.getUserId());
                uploadDocumentConfDto.setFlag(2);
                uploadDocumentConfDto.setStatus(1);
                uploadDocumentConfDto.setIsActive(1);
                uploadDocumentConfDto.setDocumentSize(String.valueOf(auctioneerDto.getDownloadDto()[i].getDocumentSize()));
                uploadDocumentConfDto.setTableName("tbl_UserLogin");
                uploadDocumentConfDto.setFolderName("Auctioneer");
                uploadDocumentConfDto.setUploadDocumentName(String.valueOf(auctioneerDto.getDownloadDto()[i].getDocumentName()));
                uploadDocumentConfDto.setUploadDocumentContent(String.valueOf(auctioneerDto.getDownloadDto()[i].getDocumentContent()));
                TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                i++;
            }
        }
        return  new ApiResponse<AuctioneerDto>("Auctioneer Updated successfully" ,200,auctioneerDto);
    }

   @Override
    public ApiResponse<List<AuctioneerDto>> getAllAuctioneer(long userType) {
       mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
       List<TblUserLogin> allByUserType=userLoginRepository.findAllByUserType(userType);
       List<AuctioneerDto> auctioneerDtos=allByUserType.stream().map(
               tblUserLogin -> {
                   AuctioneerDto auctioneerDto = mapper.map(tblUserLogin, AuctioneerDto.class);
                   TblState tblState =stateRepository.findById(tblUserLogin.getTblState().getStateId()).orElseThrow(()->new ResourceNotFoundException("TblState","tblstate",tblUserLogin.getTblState().getStateId()));
                   List<TblAuctionCenter> auctionCenters=tblUserLogin.getAuctionCenter();
                   List<Long> auctionCenterIds=new ArrayList<>();
                   for(TblAuctionCenter auctionCenter: auctionCenters){
                       auctionCenterIds.add(auctionCenter.getAuctionCenterId());
                   }
                   auctioneerDto.setAuctionCenterId(auctionCenterIds);
                   //auctioneerDto.setSessionUserId(tblUserLogin.getCreatedBy());
                   auctioneerDto.setTblState(tblState.getStateId());
                   auctioneerDto.setUserType(tblUserLogin.getUserType().getRoleId());
                   return auctioneerDto;
               } ).collect(Collectors.toList());
       return new ApiResponse<List<AuctioneerDto>>("getAll Auctioneer successfully" ,200,auctioneerDtos);
    }

    @Override
    public ApiResponse<AuctioneerDto> getAuctioneerById(long userId) {
        TblUserLogin tblUserLogin = userLoginRepository.findById(userId).get();
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
        AuctioneerDto auctioneerDtoget =new AuctioneerDto();
        List<TblAuctionCenter> auctionCenters=tblUserLogin.getAuctionCenter();
        List<Long> auctionCenterIds=new ArrayList<>();
        for(TblAuctionCenter auctionCenter:auctionCenters) {
            auctionCenterIds.add(auctionCenter.getAuctionCenterId());
            auctioneerDtoget.setAuctionCenterId(auctionCenterIds);
        }
        auctioneerDtoget.setUserId(tblUserLogin.getUserId());
        auctioneerDtoget.setTblState(tblUserLogin.getTblState().getStateId());
        auctioneerDtoget.setAuctioneerName(tblUserLogin.getUserName());
        auctioneerDtoget.setAuctioneerCode(tblUserLogin.getUserCode());
        auctioneerDtoget.setUserType(tblUserLogin.getUserType().getRoleId());
        auctioneerDtoget.setAddress(tblUserLogin.getAddress());
        auctioneerDtoget.setCity(tblUserLogin.getCity());
        auctioneerDtoget.setTblState(tblUserLogin.getTblState().getStateId());
        auctioneerDtoget.setContactPerson(tblUserLogin.getContactPerson());
        auctioneerDtoget.setPhoneNo(tblUserLogin.getPhoneNo());
        auctioneerDtoget.setMobileNo(String.valueOf(tblUserLogin.getMobileNo()));
        auctioneerDtoget.setFax(tblUserLogin.getFax());
        auctioneerDtoget.setEmail(tblUserLogin.getEmail());
        auctioneerDtoget.setEntityCode(tblUserLogin.getEntityCode());
        auctioneerDtoget.setPassword(tblUserLogin.getPassword());
        auctioneerDtoget.setConfirmPassword(tblUserLogin.getConfirmPassword());
        auctioneerDtoget.setFssaiNo(tblUserLogin.getFssaiNo());
        auctioneerDtoget.setCinNo(tblUserLogin.getCinNo());
        auctioneerDtoget.setTeaBoardRegistrationNo(tblUserLogin.getTeaBoardRegistrationNo());
        auctioneerDtoget.setTaxIdentityNo(tblUserLogin.getTaxIdentityNo());
        auctioneerDtoget.setPanNo(tblUserLogin.getPanNo());
        auctioneerDtoget.setGstNo(tblUserLogin.getGstNo());
        auctioneerDtoget.setIsActive(tblUserLogin.getIsActive());
        auctioneerDtoget.setIsParentId(tblUserLogin.getIsParentId());
        auctioneerDtoget.setStateCode(tblUserLogin.getStateCode());
        //getAuctioneerByid.setSessionUserId(tblUserLogin.getCreatedBy());
        return  new ApiResponse<AuctioneerDto>("User get by Id successfully" ,200,auctioneerDtoget);
    }

    @Override
    public ApiResponse<?> getAllAuctioneerPageable(int isActive, int offset, int page)  {
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
        Pageable pageable= PageRequest.of(page,offset);
        Optional<List<TblUserLogin>> list =userLoginRepository.findAllByIsActive(isActive,pageable);
        if(!list.isEmpty() && list.isPresent()){
            List<AuctioneerDto> dtos=list.get().stream().map(
                    tblUserLogin -> {
                        AuctioneerDto auctioneerDto = mapper.map(tblUserLogin, AuctioneerDto.class);
                        auctioneerDto.setIsActive(tblUserLogin.getIsActive());
                        return auctioneerDto;
                    }
            ).filter(x->x.getUserType()==5).collect(Collectors.toList());
            return new ApiResponse("success",200,dtos);
        }

        return new ApiResponse("No Record Found",404,null);
    }

    @Override
    public ApiResponse<Boolean> validateUser(String email,String userCode, String teaBoardRegistrationNo, String taxIdentityNo, String panNo,String gstNo,String fssaiNo,String cinNo ) {
        boolean duplicateEmail = userLoginRepository.existsByEmail(email);
        boolean duplicateUserCode = userLoginRepository.existsByUserCode(userCode);
        boolean duplicateTeaBoardregistrationNo = userLoginRepository.existsByTeaBoardRegistrationNo(teaBoardRegistrationNo);
        boolean duplicateTaxIdentityNo = userLoginRepository.existsByTaxIdentityNo(taxIdentityNo);
        boolean duplicateCinNo = userLoginRepository.existsByCinNo(cinNo);
        boolean duplicatePanNo = userLoginRepository.existsByPanNo(panNo);
        boolean duplicateGstNo = userLoginRepository.existsByGstNo(gstNo);
        boolean duplicateFssaiNo = userLoginRepository.existsByFssaiNo(fssaiNo);
        boolean validGSTCode = isValidGSTCode(gstNo);
        boolean validPanNO = isValidPanNO(panNo);
        if (duplicateEmail) {
            return new ApiResponse<>("Auctioneer with same Email id is already registered", 500, duplicateEmail);
        } else if (duplicateUserCode) {
            return new ApiResponse<>("Auctioneer with same Usercode is already registered", 500, duplicateUserCode);

        } else if (duplicateTeaBoardregistrationNo) {
            return new ApiResponse<>("Auctioneer with same Teaboard Registration Number is already registered", 500, duplicateTeaBoardregistrationNo);

        } else if (duplicateTaxIdentityNo) {
            return new ApiResponse<>("Auctioneer with same Tax Identity Number is already registered", 500, duplicateTaxIdentityNo);
        } else if (duplicateCinNo) {
            return new ApiResponse<>("Auctioneer with same Cin Number is already registered", 500, duplicateCinNo);

        } else if (duplicatePanNo) {
            return new ApiResponse<>("Auctioneer with same Pan Number is already registered", 500, duplicatePanNo);
        } else if(duplicateGstNo) {
            return new ApiResponse<>("Auctioneer with same Gst Number is already registered", 500, duplicateGstNo);
        } else if (duplicateFssaiNo) {
            return new ApiResponse<>("Auctioneer with same Fssai Number is already registered", 500, duplicateFssaiNo);
        } else if (validGSTCode) {
            return  new ApiResponse<>("Please enter Valid GST Number",500,validGSTCode);
        }else if (validPanNO){
            return  new ApiResponse<>("Please enter Valid PAN Number",500,validPanNO);
        } else {
        return new ApiResponse<>("",200,false);
        }
    }

    @Override
    public ApiResponse<?> getAllUploadedDocument() {
        Optional<List<TblUploadDocumentConf>> tblUploadDocumentConf= uploadDocumentConfRepository.findAllUploadDocument("tbl_userLogin");

        List<DownloadDto> downloadDtos = tblUploadDocumentConf.get().stream().map(
                tblUploadDocument ->{
                    DownloadDto downloadDto = new DownloadDto();
                    downloadDto.setUploadDocumentConfId(tblUploadDocument.getUploadDocumentConfId());
                    downloadDto.setUploadDocumentRemarks(tblUploadDocument.getRemarks());
                    downloadDto.setDocumentUploadTime(tblUploadDocument.getCreatedOn());
                    return downloadDto;
                }).collect(Collectors.toList());
        return  new ApiResponse<List<DownloadDto>>("success" ,200,downloadDtos);
    }

    @Override
    public ApiResponse<?> getUploadedDocumentById(long id) throws IOException {
        DownloadDto download = uploadDocumentConfService.downloadDocument(id);
        DownloadDto downloadDto = new DownloadDto();
        downloadDto.setDocumentName(download.getDocumentName());
        downloadDto.setDocumentContent(download.getDocumentContent());
        return  new ApiResponse<DownloadDto>("success" ,200,downloadDto);
    }


    public static boolean isValidGSTCode(String gstCode) {
        // Check if the input GST code is null or empty
        if (gstCode == null || gstCode.isEmpty()) {
            return false;
        }
        // Remove any spaces from the GST code
        gstCode = gstCode.replaceAll("\\s", "");

        // GSTIN must be exactly 15 characters long
        if (gstCode.length() != 15) {
            return true;
        }
        // Check if the first two characters are state codes (numeric)
        String stateCode = gstCode.substring(0, 2);
        if (!isNumeric(stateCode)) {
            return true;
        }
        // Check if the PAN is valid (alphanumeric with specific length)
        String pan = gstCode.substring(2, 12);
        if (!isValidPAN(pan)) {
            return true;
        }
        // The 14th character must be 'Z'
        if (gstCode.charAt(13) != 'Z') {
            return true;
        }
        // Checksum validation
        char checksumDigit = calculateChecksumDigit(gstCode);
        char actualChecksumDigit = gstCode.charAt(14);
        return checksumDigit == actualChecksumDigit;
    }
    private static boolean isNumeric(String str) {
        return str.matches("\\d+");
    }
    private static boolean isValidPAN(String pan) {
        return pan.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}");
    }
    private static char calculateChecksumDigit(String gstCode) {
        String pan = gstCode.substring(2, 12);
        int[] weights = { 1, 2, 4, 8, 5, 10, 9, 7, 3, 6 };
        int sum = 0;
        for (int i = 0; i < pan.length(); i++) {
            char ch = pan.charAt(i);
            int digit = Character.isDigit(ch) ? ch - '0' : ch - 'A' + 10;
            sum += digit * weights[i % 10];
        }
        int checksumValue = (36 - (sum % 36)) % 36;
        return (char) (checksumValue < 10 ? checksumValue + '0' : checksumValue - 10 + 'A');
    }
    public static boolean isValidPanNO(String pan) {
        // Check if the PAN is null or empty
        if (pan == null || pan.isEmpty()) {
            return true;
        }
        // PAN must be exactly 10 characters long
        if (pan.length() != 10) {
            return true;
        }
        // Check if the first five characters are uppercase letters
        String firstFiveChars = pan.substring(0, 5);
        if (!firstFiveChars.matches("[A-Z]{5}")) {
            return true;
        }
        // Check if the next four characters are digits
        String nextFourChars = pan.substring(5, 9);
        if (!nextFourChars.matches("\\d{4}")) {
            return true;
        }
        // Check if the last character is an uppercase letter
        char lastChar = pan.charAt(9);
        if (!Character.isUpperCase(lastChar)) {
            return true;
        }
        return false;
    }

}

