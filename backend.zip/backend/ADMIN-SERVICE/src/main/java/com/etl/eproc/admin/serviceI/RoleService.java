package com.etl.eproc.admin.serviceI;


import com.etl.eproc.admin.dto.RoleDto;
import com.etl.eproc.admin.dto.RoleSearchDto;
import com.etl.eproc.admin.util.ApiResponse;


import java.util.List;

public interface RoleService {

    public ApiResponse<RoleDto> createRole(RoleDto roleDto );

    public ApiResponse<RoleDto> getRoleById(Long roleId);

    //public ApiResponse<List<RoleDto>> getAllRole();

    public ApiResponse<RoleDto> updateRole(RoleDto roleDto );

    public ApiResponse<List<RoleSearchDto>> searchRoles(RoleSearchDto roleSearchDto);
}
