package com.etl.eproc.admin.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;
import java.util.Date;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="tbl_Revenue",schema = "appmaster")
public class TblRevenue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "revenueId")
    private long revenueId;

    @Column(name = "revenueDistrictName")
    private String revenueDistrictName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "stateID")
    private  TblState tblState;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name ="plantationId")
    private TblPlantation tblPlantation;

    @Column(name = "isActive")
    private long isActive;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private TblUserLogin createdBy;

    @Column(name = "createdOn")
    private Date createdOn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updatedBy")
    private  TblUserLogin updatedBy;

    @Column(name = "updatedOn")
    private Date updatedOn;

}
