package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TestDTO {

    private long uploadDocumentConfId;
    private String uploadDocumentContent;
    private String uploadDocumentName;
    private String DocumentSize;
    private String remarks;
    private Date documentUploadTime;

}
