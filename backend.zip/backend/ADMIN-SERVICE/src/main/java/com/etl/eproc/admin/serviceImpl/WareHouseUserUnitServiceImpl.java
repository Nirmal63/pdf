package com.etl.eproc.admin.serviceImpl;

import com.etl.eproc.admin.dto.DownloadDto;
import com.etl.eproc.admin.dto.UploadDocumentConfDto;
import com.etl.eproc.admin.dto.WareHouseUserUnitDto;
import com.etl.eproc.admin.dto.WareHouseUserUnitViewDto;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.TblUploadDocumentConf;
import com.etl.eproc.admin.model.TblUserLogin;
import com.etl.eproc.admin.model.TblWareHouseUserReg;
import com.etl.eproc.admin.model.TblWareHouseUserUnit;
import com.etl.eproc.admin.repository.UploadDocumentConfRepository;
import com.etl.eproc.admin.repository.UserLoginRepository;
import com.etl.eproc.admin.repository.WareHouseUserRepository;
import com.etl.eproc.admin.repository.WareHouseUserUnitRepository;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.serviceI.WareHouseUserUnitService;
import com.etl.eproc.admin.util.ApiResponse;
import com.etl.eproc.admin.util.AppConstants;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import org.springframework.stereotype.Service;
import javax.persistence.EntityManager;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class WareHouseUserUnitServiceImpl implements WareHouseUserUnitService {


    @Autowired
    private WareHouseUserUnitRepository wareHouseUserUnitRepository;

    @Autowired
    private UserLoginRepository userLoginRepository;

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private WareHouseUserRepository wareHouseUserRepository;

    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;


    @Autowired
    UploadDocumentConfRepository uploadDocumentConfRepository;




    @Override
    public ApiResponse<?> createWareHouseUserUnit(WareHouseUserUnitDto wareHouseUserUnitDto) {

        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
        TblWareHouseUserReg tblWareHouseUserReg = wareHouseUserRepository.findById(wareHouseUserUnitDto.getWareHouseUserRegId()).orElseThrow(() -> new ResourceNotFoundException("TblWareHouseUserReg", "wareHouseUserRegId", wareHouseUserUnitDto.getWareHouseUserRegId()));
            boolean flag = wareHouseUserUnitRepository.existsByWareHouseUnitCode(wareHouseUserUnitDto.getWareHouseUnitCode());
            if (!flag) {
                modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
                TblWareHouseUserUnit tblWareHouseUserUnit = modelMapper.map(wareHouseUserUnitDto, TblWareHouseUserUnit.class);
                tblWareHouseUserUnit.setTblWareHouseUserReg(tblWareHouseUserReg);
                tblWareHouseUserUnit.setCreatedBy(tblUserLogin);
                tblWareHouseUserUnit.setCreatedOn(new Date());
                TblWareHouseUserUnit tblWareHouseUserUnit1 = wareHouseUserUnitRepository.save(tblWareHouseUserUnit);
                WareHouseUserUnitDto wareHouseUserUnitDto1=modelMapper.map(tblWareHouseUserUnit1, WareHouseUserUnitDto.class);
                if(wareHouseUserUnitDto.getUploadDocumentContent()!=null) {
                    int i = 0;
                    for (String DocumentName : wareHouseUserUnitDto.getUploadDocumentName()) {
                        UploadDocumentConfDto documentConfDto = new UploadDocumentConfDto();
                        documentConfDto.setUploadDocumentName(DocumentName);
                        documentConfDto.setDocumentSize(wareHouseUserUnitDto.getUploadDocumentSize());
                        documentConfDto.setTableName(AppConstants.TBL_WAREHOUSEUSERUNIT);
                        documentConfDto.setTableID(wareHouseUserUnitDto1.getWareHouseUnitId());
                        documentConfDto.setDocumentSize(wareHouseUserUnitDto.getUploadDocumentSize());
                        documentConfDto.setFlag(1);
                        documentConfDto.setStatus(1);
                        documentConfDto.setIsActive(1);
                        documentConfDto.setFolderName(AppConstants.WAREHOUSEUSERUNIT);
                        documentConfDto.setRemarks(wareHouseUserUnitDto.getUploadDocumentRemarks());
                        documentConfDto.setUploadDocumentContent(wareHouseUserUnitDto.getUploadDocumentContent()[i]);
                        TblUploadDocumentConf document = uploadDocumentConfService.uploadDocument(documentConfDto);
                        i++;
                    }
                }
                return new ApiResponse<WareHouseUserUnitDto>("Warehouse User unit registered successfully", 200, wareHouseUserUnitDto1);
            }
            return new ApiResponse<WareHouseUserUnitDto>("Warehouse unit Code is already assigned to other Warehouse Unit", 400, null);

    }

    @Override
    public ApiResponse<?> getwareHouseUserUnitById(long id) {
        TblWareHouseUserUnit tblWareHouseUserUnit=wareHouseUserUnitRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("TblWareHouseUserUnit","wareHouseUserUnitId",id));
        WareHouseUserUnitViewDto houseUserUnitDto=new WareHouseUserUnitViewDto();
        houseUserUnitDto.setWareHouseUnitId(tblWareHouseUserUnit.getWareHouseUnitId());
        houseUserUnitDto.setWareHouseUnitName(tblWareHouseUserUnit.getWareHouseUnitName());
        houseUserUnitDto.setWareHouseUnitCode(tblWareHouseUserUnit.getWareHouseUnitCode());
        houseUserUnitDto.setIsActive(tblWareHouseUserUnit.getIsActive());
        TblWareHouseUserReg tblWareHouseUserReg=tblWareHouseUserUnit.getTblWareHouseUserReg();
        houseUserUnitDto.setAddress(tblWareHouseUserReg.getAddress());
        houseUserUnitDto.setCity(tblWareHouseUserReg.getCity());
        houseUserUnitDto.setContactPerson(tblWareHouseUserReg.getContactPerson());
        houseUserUnitDto.setEmail(tblWareHouseUserReg.getEmail());
        houseUserUnitDto.setEntityCode(tblWareHouseUserReg.getEntityCode());
        houseUserUnitDto.setFax(tblWareHouseUserReg.getFax());
        houseUserUnitDto.setMobileNo(tblWareHouseUserReg.getMobileNo());
        houseUserUnitDto.setPhoneNo(tblWareHouseUserReg.getPhoneNo());
        houseUserUnitDto.setShortName(tblWareHouseUserReg.getShortName());
        houseUserUnitDto.setWareHouseLicenseNo(tblWareHouseUserReg.getWareHouseLicenseNo());
        houseUserUnitDto.setTeaBoardRegistrationNo(tblWareHouseUserReg.getTeaBoardRegistrationNo());
        houseUserUnitDto.setWareHouseUserRegId(tblWareHouseUserUnit.getTblWareHouseUserReg().getWareHouseUserRegId());
        return  new ApiResponse<WareHouseUserUnitViewDto>("WareHouse User unit get by Id successfully" ,200,houseUserUnitDto);

    }

    @Override
    public ApiResponse<?> getAllWareHouseUserUnit(int isActive, int offset, int page) {
        Pageable pageable= PageRequest.of(page,offset);
        Optional<List<TblWareHouseUserUnit>> tblWareHouseUserUnits=wareHouseUserUnitRepository.findAllByIsActive(isActive,pageable);
        List<WareHouseUserUnitViewDto> houseUserUnitDtos=tblWareHouseUserUnits.get().stream().map(tblWareHouseUserUnit ->{
            WareHouseUserUnitViewDto houseUserUnitDto=new WareHouseUserUnitViewDto();
            houseUserUnitDto.setWareHouseUnitId(tblWareHouseUserUnit.getWareHouseUnitId());
            houseUserUnitDto.setWareHouseUnitName(tblWareHouseUserUnit.getWareHouseUnitName());
            houseUserUnitDto.setWareHouseUnitCode(tblWareHouseUserUnit.getWareHouseUnitCode());
            houseUserUnitDto.setIsActive(tblWareHouseUserUnit.getIsActive());
            TblWareHouseUserReg tblWareHouseUserReg=tblWareHouseUserUnit.getTblWareHouseUserReg();
            houseUserUnitDto.setAddress(tblWareHouseUserReg.getAddress());
            houseUserUnitDto.setCity(tblWareHouseUserReg.getCity());
            houseUserUnitDto.setContactPerson(tblWareHouseUserReg.getContactPerson());
            houseUserUnitDto.setEmail(tblWareHouseUserReg.getEmail());
            houseUserUnitDto.setEntityCode(tblWareHouseUserReg.getEntityCode());
            houseUserUnitDto.setFax(tblWareHouseUserReg.getFax());
            houseUserUnitDto.setMobileNo(tblWareHouseUserReg.getMobileNo());
            houseUserUnitDto.setPhoneNo(tblWareHouseUserReg.getPhoneNo());
            houseUserUnitDto.setShortName(tblWareHouseUserReg.getShortName());
            houseUserUnitDto.setWareHouseLicenseNo(tblWareHouseUserReg.getWareHouseLicenseNo());
            houseUserUnitDto.setTeaBoardRegistrationNo(tblWareHouseUserReg.getTeaBoardRegistrationNo());
            houseUserUnitDto.setWareHouseUserRegId(tblWareHouseUserUnit.getTblWareHouseUserReg().getWareHouseUserRegId());
        return houseUserUnitDto;
        }).collect(Collectors.toList());
        return new ApiResponse<List<WareHouseUserUnitViewDto>>("getAll WareHouse user units successfully" ,200,houseUserUnitDtos);

    }

    @Override
    public ApiResponse<?> updateWareHouserUserUnitBy(WareHouseUserUnitDto wareHouseUserUnitDto) {
            TblWareHouseUserUnit tblWareHouseUserUnit = wareHouseUserUnitRepository.findById(wareHouseUserUnitDto.getWareHouseUnitId()).orElseThrow(() -> new ResourceNotFoundException("TblWareHouseUserUnit", "wareHouseUserUnitId", wareHouseUserUnitDto.getWareHouseUnitId()));
            TblWareHouseUserReg wareHouseUserReg = wareHouseUserRepository.findById(wareHouseUserUnitDto.getWareHouseUserRegId()).orElseThrow(() -> new ResourceNotFoundException("TblWareHouseUserReg", "WareHouseUserRegId", wareHouseUserUnitDto.getWareHouseUserRegId()));
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));            tblWareHouseUserUnit.setWareHouseUnitName(wareHouseUserUnitDto.getWareHouseUnitName());
            tblWareHouseUserUnit.setWareHouseUnitCode(wareHouseUserUnitDto.getWareHouseUnitCode());
            tblWareHouseUserUnit.setTblWareHouseUserReg(wareHouseUserReg);
            tblWareHouseUserUnit.setIsActive(wareHouseUserUnitDto.getIsActive());
            tblWareHouseUserUnit.setUpdatedBy(tblUserLogin);
            tblWareHouseUserUnit.setUpdatedOn(new Date());
            TblWareHouseUserUnit tblWareHouseUserUnit1 = wareHouseUserUnitRepository.save(tblWareHouseUserUnit);
            WareHouseUserUnitDto wareHouseUserUnitDto1=modelMapper.map(tblWareHouseUserUnit1, WareHouseUserUnitDto.class);
        if(wareHouseUserUnitDto.getUploadDocumentContent()!=null) {
            int i = 0;
            for (String DocumentName : wareHouseUserUnitDto.getUploadDocumentName()) {
                UploadDocumentConfDto documentConfDto = new UploadDocumentConfDto();
                documentConfDto.setUploadDocumentName(DocumentName);
                documentConfDto.setDocumentSize(wareHouseUserUnitDto.getUploadDocumentSize());
                documentConfDto.setTableName(AppConstants.TBL_WAREHOUSEUSERUNIT);
                documentConfDto.setTableID(wareHouseUserUnitDto1.getWareHouseUnitId());
                documentConfDto.setDocumentSize(wareHouseUserUnitDto.getUploadDocumentSize());
                documentConfDto.setFlag(2);
                documentConfDto.setStatus(1);
                documentConfDto.setIsActive(1);
                documentConfDto.setFolderName(AppConstants.WAREHOUSEUSERUNIT);
                documentConfDto.setRemarks(wareHouseUserUnitDto.getUploadDocumentRemarks());
                documentConfDto.setUploadDocumentContent(wareHouseUserUnitDto.getUploadDocumentContent()[i]);
                TblUploadDocumentConf document = uploadDocumentConfService.uploadDocument(documentConfDto);
                i++;
            }
        }
            return new ApiResponse<WareHouseUserUnitDto>("Warehouse User unit updated successfully", 200, wareHouseUserUnitDto1);

    }

    @Override
    public ApiResponse<List<?>> searchWareHouseUserUnit(long wareHouseUserRegId) {
        Optional<List<TblWareHouseUserUnit>> tblWareHouseUserUnits=wareHouseUserUnitRepository.findBywareHouseUserRegId(wareHouseUserRegId);
        List<WareHouseUserUnitViewDto> houseUserUnitDtos=tblWareHouseUserUnits.get().stream().map(tblWareHouseUserUnit ->{
            WareHouseUserUnitViewDto houseUserUnitDto=new WareHouseUserUnitViewDto();
            houseUserUnitDto.setWareHouseUnitId(tblWareHouseUserUnit.getWareHouseUnitId());
            houseUserUnitDto.setWareHouseUnitName(tblWareHouseUserUnit.getWareHouseUnitName());
            houseUserUnitDto.setWareHouseUnitCode(tblWareHouseUserUnit.getWareHouseUnitCode());
            houseUserUnitDto.setIsActive(tblWareHouseUserUnit.getIsActive());
            TblWareHouseUserReg tblWareHouseUserReg=tblWareHouseUserUnit.getTblWareHouseUserReg();
            houseUserUnitDto.setAddress(tblWareHouseUserReg.getAddress());
            houseUserUnitDto.setCity(tblWareHouseUserReg.getCity());
            houseUserUnitDto.setContactPerson(tblWareHouseUserReg.getContactPerson());
            houseUserUnitDto.setEmail(tblWareHouseUserReg.getEmail());
            houseUserUnitDto.setEntityCode(tblWareHouseUserReg.getEntityCode());
            houseUserUnitDto.setFax(tblWareHouseUserReg.getFax());
            houseUserUnitDto.setMobileNo(tblWareHouseUserReg.getMobileNo());
            houseUserUnitDto.setPhoneNo(tblWareHouseUserReg.getPhoneNo());
            houseUserUnitDto.setShortName(tblWareHouseUserReg.getShortName());
            houseUserUnitDto.setWareHouseLicenseNo(tblWareHouseUserReg.getWareHouseLicenseNo());
            houseUserUnitDto.setTeaBoardRegistrationNo(tblWareHouseUserReg.getTeaBoardRegistrationNo());
            houseUserUnitDto.setWareHouseUserRegId(tblWareHouseUserUnit.getTblWareHouseUserReg().getWareHouseUserRegId());
            return houseUserUnitDto;
        }).collect(Collectors.toList());
        return new ApiResponse<List<?>>("getAll WareHouse user units successfully" ,200,houseUserUnitDtos);
    }

    @Override
    public ApiResponse<?> getAllUploadDocument() {
        Optional<List<TblUploadDocumentConf>> tblUploadDocumentConf= uploadDocumentConfRepository.findAllUploadDocument(AppConstants.TBL_WAREHOUSEUSERUNIT);

        List<DownloadDto> downloadDtos = tblUploadDocumentConf.get().stream().map(
                tblUploadDocument ->{
                    DownloadDto downloadDto = new DownloadDto();
                    downloadDto.setUploadDocumentConfId(tblUploadDocument.getUploadDocumentConfId());
                    downloadDto.setUploadDocumentRemarks(tblUploadDocument.getRemarks());
                    downloadDto.setDocumentUploadTime(tblUploadDocument.getCreatedOn());
                    return downloadDto;
                }).collect(Collectors.toList());
        return  new ApiResponse<List<DownloadDto>>("success" ,200,downloadDtos);
    }

    @Override
    public ApiResponse<?> getUploadDocumentById(long id) throws IOException {
        DownloadDto download = uploadDocumentConfService.downloadDocument(id);
        DownloadDto downloadDto = new DownloadDto();
        downloadDto.setDocumentName(download.getDocumentName());
        downloadDto.setDocumentContent(download.getDocumentContent());
        return  new ApiResponse<DownloadDto>("success" ,200,downloadDto);
    }


}
