package com.etl.eproc.admin.serviceImpl;


import com.etl.eproc.admin.dto.*;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.*;
import com.etl.eproc.admin.repository.*;
import com.etl.eproc.admin.serviceI.RevenueServiceI;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import com.etl.eproc.admin.util.AppConstants;
import com.etl.eproc.admin.util.SearchResponce;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Service
public class RevenueServiceImpl implements RevenueServiceI {

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    private UserLoginRepository userLoginRepository;

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private StateRepository stateRepository;

    @Autowired
    PlantationRepository plantationRepository;
    @Autowired
    private RevenueRepository revenueRepository;

    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;

    @Autowired
    UploadDocumentConfRepository uploadDocumentConfRepository;

    @Override
    public ApiResponse<?> createRevenue(RevenueDto revenueDto) {

        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));            boolean flag = revenueRepository.existsByrevenueDistrictName(revenueDto.getRevenueDistrictName());
            if (!flag) {
                TblPlantation tblPlantation = plantationRepository.findById(revenueDto.getPlantationId()).orElseThrow(() -> new ResourceNotFoundException("TblPlantation", "planationId", revenueDto.getPlantationId()));
                TblState tblState = stateRepository.findById(revenueDto.getStateId()).orElseThrow(() -> new ResourceNotFoundException("TblState", "stateId", revenueDto.getStateId()));
                TblRevenue tblRevenue = new TblRevenue();
                tblRevenue.setRevenueDistrictName(revenueDto.getRevenueDistrictName());
                tblRevenue.setIsActive(revenueDto.getIsActive());
                tblRevenue.setCreatedBy(tblUserLogin);
                tblRevenue.setCreatedOn(new Date());
                tblRevenue.setTblPlantation(tblPlantation);
                tblRevenue.setTblState(tblState);
                TblRevenue tblRevenue1 = revenueRepository.save(tblRevenue);
                RevenueDto revenueDto1=modelMapper.map(tblRevenue1,RevenueDto.class);
                if(revenueDto.getUploadDocumentContent()!=null) {

                    int i = 0;
                    for (String DocumentName : revenueDto.getUploadDocumentName()) {
                        UploadDocumentConfDto documentConfDto = new UploadDocumentConfDto();
                        documentConfDto.setUploadDocumentName(DocumentName);
                        documentConfDto.setDocumentSize(revenueDto.getUploadDocumentSize());
                        documentConfDto.setTableName(AppConstants.TBL_REVENUE);
                        documentConfDto.setTableID(revenueDto1.getRevenueId());
                        documentConfDto.setDocumentSize(revenueDto.getUploadDocumentSize());
                        documentConfDto.setFlag(1);
                        documentConfDto.setStatus(1);
                        documentConfDto.setIsActive(1);
                        documentConfDto.setFolderName(AppConstants.REVENUE);
                        documentConfDto.setRemarks(revenueDto.getUploadDocumentRemarks());
                        documentConfDto.setUploadDocumentContent(revenueDto.getUploadDocumentContent()[i]);
                        TblUploadDocumentConf document = uploadDocumentConfService.uploadDocument(documentConfDto);
                        i++;
                    }
                }
                return new ApiResponse<RevenueDto>("Revenue District created successfully", 200, revenueDto1);
            }
            return new ApiResponse<RevenueDto>("Revenue District Name already exists", 400, null);

    }

    @Override
    public ApiResponse<RevenueDto> getById(long id) {
        TblRevenue tblRevenue=revenueRepository.findById(id).get();
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
       RevenueDto revenueDto=modelMapper.map(tblRevenue, RevenueDto.class);
       revenueDto.setPlantationId(tblRevenue.getTblPlantation().getPlantationId());
        revenueDto.setStateId(tblRevenue.getTblState().getStateId());
        return new ApiResponse<RevenueDto>("success", 200, revenueDto);
    }

    @Override
    public ApiResponse<?> getAll(long iActive, int offset, int page) {
        Pageable pageable= PageRequest.of(page,offset);
        Optional<List<TblRevenue>> tblRevenues=revenueRepository.findAllByIsActive(iActive,pageable);
        if(!tblRevenues.isEmpty() && tblRevenues.isPresent()) {
            List<RevenueDto> revenueDtos = tblRevenues.get().stream().map(
                    tblRevenue -> {
                 RevenueDto revenueDto=new RevenueDto();
                 revenueDto.setRevenueId(tblRevenue.getRevenueId());
                 revenueDto.setRevenueDistrictName(tblRevenue.getRevenueDistrictName());
                revenueDto.setPlantationId(tblRevenue.getTblPlantation().getPlantationId());
                revenueDto.setStateId(tblRevenue.getTblState().getStateId());
                revenueDto.setIsActive((int) tblRevenue.getIsActive());
                 return revenueDto;
                    }).collect(Collectors.toList());
                        return new ApiResponse("success",200,revenueDtos);
                    }
            return new ApiResponse("success",200,null);
        }

    @Override
    public ApiResponse<?> updateBy(RevenueDto revenueDto) {

        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));            TblRevenue tblRevenue = revenueRepository.findById(revenueDto.getRevenueId()).orElseThrow(() -> new ResourceNotFoundException("TblRecenue", "revenueId", revenueDto.getRevenueId()));
            TblPlantation tblPlantation = plantationRepository.findById(revenueDto.getPlantationId()).orElseThrow(() -> new ResourceNotFoundException("TblPlantation", "planationId", revenueDto.getPlantationId()));
            TblState tblState = stateRepository.findById(revenueDto.getStateId()).orElseThrow(() -> new ResourceNotFoundException("TblState", "stateId", revenueDto.getStateId()));
            tblRevenue.setUpdatedBy(tblUserLogin);
            tblRevenue.setRevenueDistrictName(revenueDto.getRevenueDistrictName());
            tblRevenue.setUpdatedOn(new Date());
            tblRevenue.setTblPlantation(tblPlantation);
            tblRevenue.setTblState(tblState);
            tblRevenue.setIsActive(revenueDto.getIsActive());
            TblRevenue tblRevenue1 = revenueRepository.save(tblRevenue);
        RevenueDto revenueDto1=modelMapper.map(tblRevenue1,RevenueDto.class);
        if(revenueDto.getUploadDocumentContent()!=null) {
            int i = 0;
            for (String DocumentName : revenueDto.getUploadDocumentName()) {
                UploadDocumentConfDto documentConfDto = new UploadDocumentConfDto();
                documentConfDto.setUploadDocumentName(DocumentName);
                documentConfDto.setDocumentSize(revenueDto.getUploadDocumentSize());
                documentConfDto.setTableName(AppConstants.TBL_REVENUE);
                documentConfDto.setTableID(revenueDto1.getRevenueId());
                documentConfDto.setDocumentSize(revenueDto.getUploadDocumentSize());
                documentConfDto.setFlag(2);
                documentConfDto.setStatus(1);
                documentConfDto.setIsActive(1);
                documentConfDto.setFolderName(AppConstants.REVENUE);
                documentConfDto.setRemarks(revenueDto.getUploadDocumentRemarks());
                documentConfDto.setUploadDocumentContent(revenueDto.getUploadDocumentContent()[i]);
                TblUploadDocumentConf document = uploadDocumentConfService.uploadDocument(documentConfDto);
                i++;
            }
        }
            return new ApiResponse("Revenue District Updated successfully", 200, revenueDto1);

    }

    @Override
    public ApiResponse<List<RevenueDto>> searchRevenue(RevenueSearchDto revenueSearchDto) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appmaster.Get_tbl_Revenue_Search")
                .registerStoredProcedureParameter("@V_isactive", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_revenueDistrictName", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_stateId", Long.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_plantationId", Long.class, ParameterMode.IN)
                .setParameter("@V_isactive", revenueSearchDto.getIsActive())
                .setParameter("@V_revenueDistrictName", revenueSearchDto.getRevenueDistrictName())
                .setParameter("@V_stateId", revenueSearchDto.getStateId())
                .setParameter("@V_plantationId", revenueSearchDto.getPlantationId());
        List<Object[]> execute = storedProcedureQuery.getResultList();
        if (!execute.isEmpty()) {
            List<RevenueDto> revenueDtos = execute.stream().map(
                    objects -> {
                        RevenueDto revenueDto1 = new RevenueDto();
                        revenueDto1.setRevenueId(Long.valueOf(objects[0].toString()));
                        revenueDto1.setRevenueDistrictName(objects[1].toString());
                        revenueDto1.setStateId(Long.valueOf(objects[2].toString()));
                        revenueDto1.setPlantationId(Long.valueOf(objects[3].toString()));
                        revenueDto1.setIsActive((Boolean) objects[4] == true ? 1 : 0);
                        return revenueDto1;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse<List<RevenueDto>>("get All Success", 200, revenueDtos);
        } else {
            return new ApiResponse<List<RevenueDto>>("No record found", 404, null);
        }
    }
    @Override
    public ApiResponse<?> getAllUploadDocument() {
        Optional<List<TblUploadDocumentConf>> tblUploadDocumentConf= uploadDocumentConfRepository.findAllUploadDocument(AppConstants.TBL_REVENUE);

        List<DownloadDto> downloadDtos = tblUploadDocumentConf.get().stream().map(
                tblUploadDocument ->{
                    DownloadDto downloadDto = new DownloadDto();
                    downloadDto.setUploadDocumentConfId(tblUploadDocument.getUploadDocumentConfId());
                    downloadDto.setUploadDocumentRemarks(tblUploadDocument.getRemarks());
                    downloadDto.setDocumentUploadTime(tblUploadDocument.getCreatedOn());
                    return downloadDto;
                }).collect(Collectors.toList());
        return  new ApiResponse<List<DownloadDto>>("success" ,200,downloadDtos);
    }

    @Override
    public ApiResponse<?> getUploadDocumentById(long id) throws IOException {
        DownloadDto download = uploadDocumentConfService.downloadDocument(id);
        DownloadDto downloadDto = new DownloadDto();
        downloadDto.setDocumentName(download.getDocumentName());
        downloadDto.setDocumentContent(download.getDocumentContent());
        return  new ApiResponse<DownloadDto>("success" ,200,downloadDto);
    }


}
