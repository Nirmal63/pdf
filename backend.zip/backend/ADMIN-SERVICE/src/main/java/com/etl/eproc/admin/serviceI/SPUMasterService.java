package com.etl.eproc.admin.serviceI;


import com.etl.eproc.admin.dto.SPUMasterDto;
import com.etl.eproc.admin.dto.SPUMasterSearchDto;
import com.etl.eproc.admin.util.ApiResponse;

public interface SPUMasterService {

    ApiResponse<?> createSPUMaster(SPUMasterDto spuMasterDto);

    ApiResponse<?> getAllSPUMaster();

    ApiResponse<?> updateSPUMaster(SPUMasterDto spuMasterDto);

    ApiResponse<?> findSPUMasterById(int spuMasterId);


    ApiResponse<?> searchSPUMasterPageable(int isActive, int offset, int page);

    ApiResponse<?> searchSPUMaster(SPUMasterSearchDto spuMasterDto);
}
