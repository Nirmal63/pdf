package com.etl.eproc.admin.serviceI;

import com.etl.eproc.admin.dto.AuctioneerDto;
import com.etl.eproc.admin.util.ApiResponse;

import java.io.IOException;
import java.util.List;

public interface AuctioneerService {
    public ApiResponse<?> createAuctioneer(AuctioneerDto auctioneerDto);
    public ApiResponse<?> updateAuctioneer(AuctioneerDto auctioneerDto);
    public ApiResponse<List<AuctioneerDto>> getAllAuctioneer(long userType);
    public ApiResponse<AuctioneerDto> getAuctioneerById(long userId);
    public ApiResponse<?> getAllAuctioneerPageable(int isActive, int offset, int page);
    public ApiResponse<?> validateUser(String email,String userCode, String teaBoardRegistrationNo, String taxIdentityNo, String panNo,String gstNo,String fssaiNo,String cinNo);

    ApiResponse<?> getAllUploadedDocument();

    ApiResponse<?> getUploadedDocumentById(long id) throws IOException;
}
