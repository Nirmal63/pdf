package com.etl.eproc.admin.controller;


import com.etl.eproc.admin.dto.WareHouseUserUnitDto;
import com.etl.eproc.admin.serviceI.WareHouseUserUnitService;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/admin/wareHouseUserUnitReg")
public class WareHouseUserUnitController {

    @Autowired
    private WareHouseUserUnitService wareHouseUserUnitService;


    @PostMapping(value = "/create")
    public ApiResponse<?> saveWareHouseUserUnit(@Valid @RequestBody WareHouseUserUnitDto wareHouseUserUnitDto) {
        try {
            return wareHouseUserUnitService.createWareHouseUserUnit(wareHouseUserUnitDto);
        } catch (Exception e) {
            return new ApiResponse<>(e.getMessage(), 500,null);

        }
    }


    @GetMapping("/get/{wareHouseUnitId}")
    public ApiResponse<?> getWareHouseUserById(@PathVariable(name ="wareHouseUnitId") long wareHouseUnitId){
        try {
            return wareHouseUserUnitService.getwareHouseUserUnitById(wareHouseUnitId);
        }catch(Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);

        }
    }



    @GetMapping("/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> getAllWareHouseUser(@PathVariable("isActive") int isActive, @PathVariable("offset") int offset, @PathVariable("page") int page){
        try {
            ApiResponse<?> allWareHouseUserUnit = wareHouseUserUnitService.getAllWareHouseUserUnit(isActive, offset, page);
            return allWareHouseUserUnit;
        }catch(Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);

        }
    }

    @PostMapping(value = "/update")
    public ApiResponse<?> updateWareHouseUser(@Valid  @RequestBody WareHouseUserUnitDto wareHouseUserUnitDto){
        try {
            ApiResponse<?> wareHouseUserUnitDtoApiResponse = wareHouseUserUnitService.updateWareHouserUserUnitBy(wareHouseUserUnitDto);
            return wareHouseUserUnitDtoApiResponse;
        }catch(Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);

        }
    }


    @GetMapping("/search/{wareHouseUserRegId}")
    public ApiResponse<List<?>> searchBy(@PathVariable("wareHouseUserRegId") long wareHouseUserRegId){
        try {
            ApiResponse<List<?>> searchWareHouseUserUnit = wareHouseUserUnitService.searchWareHouseUserUnit(wareHouseUserRegId);
            return searchWareHouseUserUnit;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);

        }
    }
    @GetMapping("/getAllUploaddocument")
    public ApiResponse<?> getAllDocument(){
        return new ApiResponse<>("success",200,wareHouseUserUnitService.getAllUploadDocument());
    }

    @GetMapping("/getById/{uploaddocumentId}")
    public ApiResponse<?> getUploadDocument(@PathVariable("uploaddocumentId") long id) throws IOException {
        return new ApiResponse<>("success",200,wareHouseUserUnitService.getUploadDocumentById(id));

    }


}
