package com.etl.eproc.admin.serviceI;

import com.etl.eproc.admin.dto.AuctionCenterDto;
import com.etl.eproc.admin.util.ApiResponse;

import java.io.IOException;
import java.util.List;

public interface AuctionCenterService {
    ApiResponse<?> createAuctionCenter(AuctionCenterDto auctionCenterDto);

    ApiResponse<?>  updateAuctionCenter(AuctionCenterDto auctionCenterUpdateDto);


    ApiResponse<AuctionCenterDto>  getAuctionCenterById(long auctionCenterId);

    ApiResponse<List<AuctionCenterDto>> getAllAuctionCenter();

    ApiResponse<?> searchAuctionCenterPageable(int cStatus, int offset, int page);
    ApiResponse<?> searchAuctionCenter(AuctionCenterDto auctionCenterDto);
    ApiResponse<?> getAllUploadedDocument();
    ApiResponse<?> getUploadedDocumentById(long id) throws IOException;

}
