package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ChargeMasterDto {
    private long chargeMasterId;
    private String chargesName;
    @NotNull(message = "Please select a charge code from the dropdown menu.")
    private long chargeCodeId;
    @NotNull(message = "Please select whether the charges are in percentage or rupees from the dropdown menu.")
    @Pattern(regexp = "^[A-Za-z \\\\s\\\\-]*$",message = "The Auction Center Name should contain alphabetic characters only")
    private String chargeType;
    @NotNull(message = "Please enter the charge value.")
    @Pattern(regexp = "^[0-9 \\\\s\\\\-]*$",message = "The charge value should be a numeric value.")
    @Size(min = 2,message = "")
    @Size(max= 100,message = "")
    private long chargesValue;
    private Integer isActive;
    @NotNull(message = "Please enter the effective from date.")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private Date effectiveFromDate;
    @NotNull(message = "Please enter the effective end date.")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private Date effectiveEndDate;
    @NotNull(message = "Please select an auction center name from the dropdown menu.")
    private long auctionCenterId;
    //private long sessionUserId;
    private String uploadDocumentRemarks;
    private DownloadDto[] downloadDto;

}
