package com.etl.eproc.admin.serviceI;


import com.etl.eproc.admin.dto.WareHouseUserUnitDto;
import com.etl.eproc.admin.util.ApiResponse;

import java.io.IOException;
import java.util.List;

public interface WareHouseUserUnitService {

    public ApiResponse<?> createWareHouseUserUnit(WareHouseUserUnitDto wareHouseUserUnitDto);

    public ApiResponse<?> getwareHouseUserUnitById(long id);

    public ApiResponse<?> getAllWareHouseUserUnit(int iActive, int offset, int page);

    public ApiResponse<?> updateWareHouserUserUnitBy(WareHouseUserUnitDto wareHouseUserUnitDto);


    public ApiResponse<List<?>> searchWareHouseUserUnit(long wareHouseUserRegId);

    ApiResponse<?> getAllUploadDocument();

    ApiResponse<?> getUploadDocumentById(long id) throws IOException;
}
