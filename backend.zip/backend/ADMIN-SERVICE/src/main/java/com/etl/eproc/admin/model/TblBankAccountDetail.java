package com.etl.eproc.admin.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_BankAccountDetail",schema = "appuser")
public class TblBankAccountDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bankAccountDetailId",nullable = false)
    private Long bankAccountDetailId;

    @Column(name = "bankAccountNumber",nullable = false)
    private Long bankAccountNumber;

    @Column(name = "bankName",nullable = false)
    private String bankName;

    @Column(name = "branchAddress",nullable = false)
    private String branchAddress;

    @Column(name = "ifscCode",nullable = false)
    private String ifscCode;

    @ManyToOne
    @JoinColumn(name = "userId", nullable = false)
    private TblUserLogin userId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "auctionCenterId", nullable = false)
    private TblAuctionCenter auctionCenterId;

    @Column(name = "beneficiaryName",nullable = false)
    private String beneficiaryName;

    @Column(name = "contactPerson" ,nullable = false)
    private String contactPerson;

    @Column(name = "email",nullable = false)
    private String email;

    @Column(name = "contactNumber")
    private Long contactNumber;

    @Column(name = "isActive",nullable = false)
    private int isActive;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy", nullable = false)
    private TblUserLogin createdBy;

    @Column(name = "createdOn",nullable = false)
    private Date createdOn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updatedBy", nullable = false)
    private TblUserLogin updatedBy;

    @Column(name = "updatedOn")
    private Date updatedOn;

    @Column(name = "contactPersonAddress")
    private String contactPersonAddress;
}
