package com.etl.eproc.admin.serviceI;

import com.etl.eproc.admin.dto.ChargeMasterDto;
import com.etl.eproc.admin.dto.ChargeMasterSearchDto;
import com.etl.eproc.admin.util.ApiResponse;

import java.io.IOException;
import java.util.List;

public interface ChargeMasterService {
    ApiResponse<?> createChargeMaster(ChargeMasterDto chargeMasterDto);
    ApiResponse<?> updateChargeMaster(ChargeMasterDto chargeMasterDto);
    ApiResponse<ChargeMasterDto> getChargeMasterById(long chargeMasterId );
    ApiResponse<List<ChargeMasterDto>> getAllChargeMaster();
    ApiResponse<?> getAllChargeMasterPageable(int cStatus, int offset, int page);
    ApiResponse<?> searchChargeMaster(ChargeMasterSearchDto chargeMasterSearchDto);

    ApiResponse<?> getAllUploadedDocument();

    ApiResponse<?> getUploadedDocumentById(long id) throws IOException;
}
