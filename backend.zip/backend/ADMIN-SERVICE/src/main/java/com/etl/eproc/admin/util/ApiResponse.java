package com.etl.eproc.admin.util;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ApiResponse<T> {

    private String message;

    private int statusCode;
    private T ResponseData;

    public ApiResponse(String message, int statusCode, T ResponseData) {
        this.message = message;
        this.statusCode = statusCode;
        this.ResponseData = ResponseData;
    }
}
