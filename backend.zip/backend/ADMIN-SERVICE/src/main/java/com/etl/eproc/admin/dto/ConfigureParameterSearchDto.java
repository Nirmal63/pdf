package com.etl.eproc.admin.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ConfigureParameterSearchDto {

    private int configParaId;
    private String auctionCenterName;
    private int catalogClosingDay;
    private int catalogPublishingDay;
    private int buyersPromptDays;
    private int sellersPromptDay;
    private int intervalMin;
    private int isActive;
}
