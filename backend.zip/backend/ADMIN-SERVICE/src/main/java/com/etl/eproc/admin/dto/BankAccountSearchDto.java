package com.etl.eproc.admin.dto;

import lombok.*;

import java.math.BigDecimal;

@Data
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class BankAccountSearchDto {

    private long bankAccountDetailId;

    private String bankAccountNumber;

    private String bankName;

    private String ifscCode;

    private String auctionCenterName;

    private Integer isActive;
}
