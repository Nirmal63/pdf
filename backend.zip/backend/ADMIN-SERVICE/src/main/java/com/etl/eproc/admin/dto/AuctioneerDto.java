package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.*;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AuctioneerDto {
    private long userId;

    @NotEmpty(message = "Please enter the Auctioneer Name.")
    @Pattern(regexp = "^[A-Za-z \\\\s\\\\-]*$",message = "The Auctioneer Name should only contain alphabetic characters.")
    @Size(min = 1,max = 50,message = "The Auctioneer Name should not exceed 50 characters.")
    private String auctioneerName;

    @NotEmpty(message = "Please enter the Auctioneer Code.")
    @Pattern(regexp = "^[A-Za-z0-9 \\\\s\\\\-]*$",message = "Please enter a valid Auctioneer Code with alphanumeric characters ")
    @Size(min = 1,max = 10,message = "The Auctioneer Code should not exceed 10 characters.")
    private String auctioneerCode;

    @NotNull(message = "Please select User Type")
    private long userType;

    @NotNull(message = "Please select an auction center from the dropdown list.")
    private List<Long> auctionCenterId;

    @NotEmpty(message = "Please enter Address")
    @Size(min = 1,max = 500,message = "The address should not exceed 500 characters.")
    @Pattern(regexp = "^[A-Za-z0-9 \\\\s\\\\-]*$",message = "The Address should only contain alphanumeric characters.")
    private String address;
    @NotEmpty(message = "Please enter the city.")
    @Pattern(regexp = "^[A-Za-z0-9 \\\\s\\\\-]*$",message = "The city should only contain alphabetic characters, numeric values,")
    @Size(min = 1,max = 50,message = "The city should not exceed 50 characters.")
    private String city;

    @NotNull(message = "Please select a state from the dropdown list.")
    private long tblState;

    @NotNull
    private String StateCode;

    @NotEmpty(message = "Please enter Person Name")
    @Pattern(regexp = "^[A-Za-z \\\\s\\\\-]*$",message = "The contact person should contain alphabetic characters only.")
    @Size(min = 1,max = 100,message = "The contact person should not exceed 100 characters.")
    private String contactPerson;


    @Pattern(regexp = "^[0-9 \\\\s\\\\-]*$",message = "The phone number should follow a specific format (e.g., digits only, with or without country code).")
    @Size(min=1, max=15, message = "The phone number should not exceed 15 characters.")
    private String phoneNo;

    @NotNull(message = "Please enter the mobile number.")
    @Pattern(regexp = "^[0-9 \\\\s\\\\-]*$",message = "Please enter a valid mobile number.")
    @Size(min = 1,max = 15, message = "The mobile number should not exceed 15 characters.")
    private String mobileNo;

    @Pattern(regexp = "^[0-9 \\\\s\\\\-]*$",message = "The fax number should follow a specific format (e.g., digits only, with or without country code).")
    @Size(min = 1,max = 15,message = "The fax number should not exceed 15 characters.")
    private String fax;

    @NotNull(message = "Please enter the email ID.")
    @Email(regexp = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}$",message = "Please enter a valid email ID with alphanumeric characters and special characters allowed.")
    @Size(min = 6,max = 50,message = "Allows Min 6 Max. 50 alphabets, numbers and Special Characters (@,.,-,_)")
    private String email;

    private String entityCode;

    private String password;

    private String confirmPassword;


    @Pattern(regexp = "^[0-9 \\\\s\\\\-]*$",message = "Please enter a valid FSSAI No consisting of numeric characters ")
    @Size(min = 1,max = 14,message = "The FSSAI No should not exceed 14 characters." )
    private String fssaiNo;


    @Pattern(regexp = "^[A-Za-z0-9 \\\\s\\\\-]*$",message = "Please enter a valid CIN no with alphanumeric characters ")
    @Size(min = 1,max = 21,message = "The CIN No should not exceed 21 characters.")
    private String cinNo;

    @NotNull(message = "Please enter the Teaboard Reg No.")
    @Pattern(regexp = "^[A-Za-z0-9 \\\\s\\\\-]*$",message = "Please enter a valid Teaboard Reg No with alphanumeric characters ")
    @Size(min = 1,max = 15,message = "The Teaboard Registration No should not exceed 15 characters.")
    private String teaBoardRegistrationNo;


    @Pattern(regexp = "^[A-Za-z0-9 \\\\s\\\\-]*$",message = "Please enter a valid TaxId No with alphanumeric characters and a length of 15.")
    @Size(min = 1,max = 15, message = "The Tax Identity No should not exceed 15 characters.")
    private String taxIdentityNo;

    @NotEmpty(message = "Please enter the PANno.")
    @Pattern(regexp = "^[A-Za-z0-9 \\\\s\\\\-]*$",message = "The PANno should follow a specific format (e.g., alphanumeric characters(UpperCase) and a length of 10.")
    @Size(min = 1,max =10,message = "The Pan No should not exceed 10 characters.")
    private String panNo;

    @NotNull(message = "Please enter the GSTNo.")
    @Pattern(regexp = "^[A-Za-z0-9 \\\\s\\\\-]*$",message = "Please enter a valid GSTNo with alphanumeric characters(UpperCase) and a maximum length of 15 characters.")
    @Size(min = 1,max = 15,message = "Please enter a valid GSTNo with alphanumeric characters and a maximum length of 15 characters.")
    private  String gstNo;

    private int isActive;

    //private long sessionUserId;

    private long isParentId;

    private String uploadDocumentRemarks;

    private DownloadDto[] downloadDto;

}
