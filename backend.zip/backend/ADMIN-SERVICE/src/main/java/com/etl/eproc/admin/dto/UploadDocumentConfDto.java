package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class UploadDocumentConfDto {

    private  long uploadDocumentConfId;
    private String tableName;
    private long tableID;
    private String remarks;
    private int isActive;
    private String DocumentSize;
    private int status;
    private int flag;

    private String folderName;
    private long categoryId;
    private String uploadDocumentContent;
    private String uploadDocumentName;

}