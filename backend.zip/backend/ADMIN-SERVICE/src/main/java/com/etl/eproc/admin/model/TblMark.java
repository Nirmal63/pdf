package com.etl.eproc.admin.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbl_Mark" , schema = "appuser")
public class TblMark {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long markId;

    @Column(name = "markName" ,nullable = false)
    private String markName;

    @Column(name = "markCode" ,nullable = false)
    private String markCode;

    @Column(name = "ownerName")
    private String ownerName;

    @Column(name = "manufacturerName")
    private String manufacturerName;

    @Column(name = "bankAccStatus")
    private int bankAccStatus;

    @ManyToOne
    @JoinColumn(name = "factoryId")
    private TblFactory factory;

    @ManyToOne
    @JoinColumn(name = "auctionCenterId")
    private TblAuctionCenter tblAuctionCenter;

    @Column(name="isActive",nullable = false)
    private int isActive;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private TblUserLogin createdBy;

    @Column(name="createdOn",nullable = false)
    private Date createdOn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updatedBy")
    private TblUserLogin updatedBy;

    @Column(name="updatedOn")
    private Date updatedOn;

}


