package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TaxMasterDto {

    private long taxMasterId;

    @NotNull(message = "please select chargeMasterId ")
    private long chargeMasterId;


    @NotNull(message = "Please select a charge code from the dropdown menu ")
    private long chargeCodeId;

    @NotEmpty(message = "please enter hsc/Sac")
    private String hsnOrsac;

    @NotEmpty(message = "please enter description")
    @Size(max = 100,message = "The description should not exceed 100 characters")
    @Pattern(regexp = "^[a-zA-Z0-9]+$")
    private  String description;

    @NotEmpty(message = "please enter value")
    private String value;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private Date effectiveFromDate;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private Date effectiveEndDate;

    @NotNull(message = "please select auction center")
    private Long auctionCenterId;

    private int isActive;

    private String uploadDocumentRemarks;

    private String[] uploadDocumentContent;

    private String[] uploadDocumentName;

    private String uploadDocumentSize;


}
