package com.etl.eproc.admin.dto;

import lombok.*;

import javax.validation.constraints.NotEmpty;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StateSearchDto {

    private long stateId;

    @NotEmpty(message = "please enter State name")
    private String stateName;

    @NotEmpty(message = "please enter State code")
    private String stateCode;

    @NotEmpty(message = "please enter stateInitial")
    private String stateInitial;

    private Integer isActive;

}
