package com.etl.eproc.admin.serviceI;

import com.etl.eproc.admin.dto.UserLoginDto;
import com.etl.eproc.admin.util.ApiResponse;

import java.util.List;

public interface UserLoginService {
    ApiResponse<?> createUser(UserLoginDto userLoginDto);
    ApiResponse<?> updateUser(UserLoginDto userLoginDto);

    ApiResponse<List<UserLoginDto>> getAllUser();

    ApiResponse<UserLoginDto> getUserById(long userId);

    ApiResponse<?> getAllUserPageable(int isActive, int offset, int page);

  /*  ApiResponse<List<TblUserLogin>> getUsersByParentId(long isParendId);*/

}
