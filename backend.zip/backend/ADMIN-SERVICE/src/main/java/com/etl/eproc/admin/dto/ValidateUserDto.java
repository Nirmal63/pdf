package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ValidateUserDto {
    private String email;
    private String userCode;
    private String fssaiNo;
    private String cinNo;
    private String teaBoardRegistrationNo;
    private String taxIdentityNo;
    private String panNo;
    private  String gstNo;
}
