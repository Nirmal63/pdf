package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.RoleDto;
import com.etl.eproc.admin.dto.RoleSearchDto;
import com.etl.eproc.admin.serviceI.RoleService;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/admin/role")
public class RoleController {

    @Autowired
    private RoleService roleService;

    @PostMapping("/create")
    public ApiResponse<RoleDto> createRole(@Valid @RequestBody RoleDto roleDto) {
        try {
            return roleService.createRole(roleDto);
        } catch (Exception e) {
            return new ApiResponse<>(e.getMessage(), 500, null);
        }
    }

    @GetMapping("/get/{roleId}")
    public ApiResponse<RoleDto> getRoleById(@PathVariable("roleId") Long roleId){
        try {
            return roleService.getRoleById(roleId);
        } catch (Exception e){
            return new ApiResponse<RoleDto>(e.getMessage(), 500 , null);
        }
    }

 /*   @GetMapping("/get/AllRoles")
    public  ApiResponse<List<RoleDto>> getAllRoles(){
        try {
            return roleService.getAllRole();
        } catch (Exception e) {
            return new ApiResponse<List<RoleDto>>(e.getMessage(),500,null);
        }
    }*/

    @PostMapping("/update")
    public ApiResponse<RoleDto> updateRole(@Valid @RequestBody RoleDto roleDto){
        try {
            return roleService.updateRole(roleDto);
        } catch (Exception e){
            return new ApiResponse<RoleDto>(e.getMessage(), 500, null);
        }
    }

    @PostMapping("/search")
    public  ApiResponse<List<RoleSearchDto>> searchRoles(@RequestBody  RoleSearchDto roleSearchDto){
        try {
            return roleService.searchRoles(roleSearchDto);
        } catch (Exception e) {
            return new ApiResponse<List<RoleSearchDto>>(e.getMessage(),500,null);
        }
    }
}
