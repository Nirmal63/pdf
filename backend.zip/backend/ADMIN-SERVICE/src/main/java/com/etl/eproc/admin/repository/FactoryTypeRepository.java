package com.etl.eproc.admin.repository;

import com.etl.eproc.admin.model.TblFactoryType;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface FactoryTypeRepository extends JpaRepository<TblFactoryType, Long> {
    Optional<List<TblFactoryType>> findAllByIsActive(int isActive, Pageable pageable);

    boolean existsByFactoryTypeName(String factoryTypeName);

    boolean existsByFactoryType(String factoryType);

    @Query(value = "select factoryTypeName, factoryType, isActive from [appmaster].[tbl_FactoryType]",nativeQuery = true)
    List<Map<String,Object>> findAllData();

}
