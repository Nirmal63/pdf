package com.etl.eproc.admin.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(schema = "appmaster",name = "tbl_ChargeMaster")
public class TblChargeMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long chargeMasterId;
    private String chargesName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "chargeCodeId")
    private TblChargeCode tblChargeCode;

    private String chargeType;
    private long chargesValue;

    private Date effectiveFromDate;

    private Date effectiveEndDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "auctionCenterId")
    private TblAuctionCenter tblAuctionCenter;

    private int isActive;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private TblUserLogin createdBy;

    private Date createdOn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updatedBy")
    private TblUserLogin updatedBy;

    private Date updatedOn;

}
