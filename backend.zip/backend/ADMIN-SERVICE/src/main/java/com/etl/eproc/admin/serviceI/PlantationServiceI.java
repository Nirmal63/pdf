package com.etl.eproc.admin.serviceI;

import com.etl.eproc.admin.dto.PlantationDto;
import com.etl.eproc.admin.dto.PlantationSearchDto;
import com.etl.eproc.admin.util.ApiResponse;

import java.io.IOException;
import java.util.List;


public interface PlantationServiceI {

    ApiResponse<?> createPlantation(PlantationDto plantationDto);

    public ApiResponse<PlantationDto> getPlantationById(long id);

    public ApiResponse<List<PlantationDto>> getAllPlantation(long iActive, int offset, int page);

    public ApiResponse<?> updateplantation(PlantationDto plantationDto);

    public ApiResponse<List<PlantationDto>> getAllPlantationDrop();

    public ApiResponse<List<PlantationDto>>searchPlantation(PlantationSearchDto plantationSearchDto);

    ApiResponse<?> getAllUploadDocument();

    ApiResponse<?> getUploadDocumentById(long id) throws IOException;




}
