package com.etl.eproc.admin.dto;

import lombok.*;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.*;

@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BankAccountDetailDto {

    private Long bankAccountDetailId;

/*    @NotNull(message = "Please enter Bank Account Number")
    @Size(max = 16,message = "The bank account number should not exceed 16 characters.")
    @Pattern(regexp =  "^[0-9]+$",message = "Please enter a numeric value for the bank account number")*/
    private Long bankAccountNumber;

    @NotEmpty(message = "Please enter Bank Name")
    private String bankName;

    @NotEmpty(message = "Please enter Branch Address")
    private String branchAddress;

    @NotEmpty(message = "Please enter ifsc COde")
    private String ifscCode;

    private long auctionCenterId;

    @NotEmpty(message = "Please enter BeneficiaryName")
    private String beneficiaryName;

    @NotEmpty(message = "Please enter Contact Person")
    private String contactPerson;

    @Email(message = "Invalid email address")
    @NotEmpty(message = "Please enter Email name")
    private String email;

   /* @Pattern(regexp = "^(\\+\\d{1,3}[- ]?)?\\d{10}$", message = "Invalid phone number")
    @NotNull(message = "Please enter Contact Number")*/
    private Long contactNumber;

    private int isActive;

    @NotEmpty(message = "Please enter Contact Person Address")
    private String contactPersonAddress;

    @NotEmpty(message = "Please enter Auction Center Name ")
    private String auctionCenterName;

    private String uploadDocumentRemarks;

    private String[] uploadDocumentContent;

    private String[] uploadDocumentName;

    private String uploadDocumentSize;

}
