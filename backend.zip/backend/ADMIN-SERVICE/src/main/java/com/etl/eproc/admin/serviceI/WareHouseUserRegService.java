package com.etl.eproc.admin.serviceI;
import com.etl.eproc.admin.dto.WareHouseUserRegDto;
import com.etl.eproc.admin.util.ApiResponse;

import java.io.IOException;
import java.util.List;

public interface WareHouseUserRegService {

    public ApiResponse<?> createWareHouseUser(WareHouseUserRegDto wareHouseUserRegDto);

    public ApiResponse<WareHouseUserRegDto> getWareHouseUserById(long id);

    public ApiResponse<?> getAllWareHouseUser(int iActive, int offset, int page);

    public ApiResponse<?> updateWareHouseUserBy(WareHouseUserRegDto wareHouseUserRegDto);


    public ApiResponse<List<WareHouseUserRegDto>> searchWareHouseUser(Long auctionCenter,String wareHouseCode);

    public ApiResponse<?> validateUser(String wareHouseCode,String wareHouseLicenceNo,String taxIdentificationNo,String teaBoardRegistrationNo,String PanNo,String gstNo);



    ApiResponse<?> getAllUploadDocument();

    ApiResponse<?> getUploadDocumentById(long id) throws IOException;
}
