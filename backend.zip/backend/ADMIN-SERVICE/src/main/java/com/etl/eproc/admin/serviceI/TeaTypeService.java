package com.etl.eproc.admin.serviceI;


import com.etl.eproc.admin.dto.TeaTypeDto;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface TeaTypeService {

    ApiResponse<?> createTeaType(TeaTypeDto teaTypeDto);

    ApiResponse<?> getAllTeaType();

    ApiResponse<?> updateTeaType(TeaTypeDto teaTypeDto);

    ApiResponse<?> findTeaTypeById(int teaTypeId);

    ApiResponse<?> searchTeaTypePageable(int isActive,int offset,int page);


    ApiResponse<?> searchTeaType(TeaTypeDto teaTypeDto);
}
