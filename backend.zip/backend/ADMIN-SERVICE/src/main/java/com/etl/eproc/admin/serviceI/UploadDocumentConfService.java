package com.etl.eproc.admin.serviceI;


import com.etl.eproc.admin.dto.DownloadDto;
import com.etl.eproc.admin.dto.UploadDocumentConfDto;
import com.etl.eproc.admin.model.TblUploadDocumentConf;

import java.io.IOException;


public interface UploadDocumentConfService {


    TblUploadDocumentConf uploadDocument(UploadDocumentConfDto uploadDocumentConfDto);

    DownloadDto downloadDocument(long Id)  throws IOException;

}
