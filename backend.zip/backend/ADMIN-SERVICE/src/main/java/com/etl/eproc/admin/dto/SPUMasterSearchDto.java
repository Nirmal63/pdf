package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SPUMasterSearchDto {
    private int spuMasterId;
    private String auctionCenterName;
    private String teaTypeName;
    private String gradeName;
    @NotEmpty(message = "Please enter details")
    private String SPUQuantity;
    @NotEmpty(message = "Please enter details")
    private String manufacturingPeriod;
    @NotEmpty(message = "Please enter details")
    private String minLotSize;
    @NotEmpty(message = "Please enter details")
    private String factoryAnnualCapacity;

    private int isActive;
}
