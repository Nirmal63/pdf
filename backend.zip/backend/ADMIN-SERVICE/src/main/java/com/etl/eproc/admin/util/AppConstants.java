package com.etl.eproc.admin.util;

public class AppConstants {

    public static final String DEFAULT_PAGE_NUMBER = "0";
    public  static final String DEFAULT_PAGE_SIZE = "10";
    public static final String DEFAULT_SORT_BY = "id";
    public static final String DEFAULT_SORT_DIRECTION = "asc";
    public static final String STATUS="Status";
    public static final String TBL_PLANTATION = "tbl_plantation";
    public static final String PLANTATION="Plantation";
    public static final String TBL_REVENUE = "tbl_revenue";
    public static final String REVENUE="Revenue";
    public static final String TBL_TAXMASTER = "tbl_taxMaster";
    public static final String TAXMASTER="TaxMaster";
    public static final String TBL_WAREHOUSEUSER = "tbl_wareHouseUserReg";
    public static final String WAREHOUSEUSER="WareHouseUserReg";
    public static final String TBL_WAREHOUSEUSERUNIT = "tbl_wareHouseUserUnitReg";
    public static final String WAREHOUSEUSERUNIT="WareHouseUserUnitReg";

}