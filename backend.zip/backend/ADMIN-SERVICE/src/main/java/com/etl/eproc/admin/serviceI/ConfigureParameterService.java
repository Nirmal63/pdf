package com.etl.eproc.admin.serviceI;

import com.etl.eproc.admin.dto.ConfigureParameterDto;
import com.etl.eproc.admin.dto.ConfigureParameterSearchDto;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.web.multipart.MultipartFile;

import java.text.ParseException;
import java.util.List;

public interface ConfigureParameterService {

    ApiResponse<?> createConfigureParameter(ConfigureParameterDto configureParameterDto) throws ParseException;

    ApiResponse<?> getAllConfigureParameter();

    ApiResponse<?> updateConfigureParameter(ConfigureParameterDto configureParameterDto);

    ApiResponse<?> findConfigureParameterId(int configParaId);

    ApiResponse<?> searchConfigureParameterPageable(int isActive,int offset,int page);


    ApiResponse<?> searchConfigureParameter(ConfigureParameterSearchDto configureParameterSearchDto);
}
