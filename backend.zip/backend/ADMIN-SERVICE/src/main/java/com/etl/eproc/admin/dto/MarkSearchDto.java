package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MarkSearchDto {

    private long markId;
    private String markName;
    private String markCode;
    private String ownerName;
    private String manufacturer;
    //private Byte bankAccountStatus;
    private String auctionCenterName;
    private Integer isActive;
}
