package com.etl.eproc.admin.serviceI;


import com.etl.eproc.admin.dto.RevenueDto;
import com.etl.eproc.admin.dto.RevenueSearchDto;
import com.etl.eproc.admin.util.ApiResponse;
import com.etl.eproc.admin.util.SearchResponce;

import java.io.IOException;
import java.util.List;

public interface RevenueServiceI {

    public ApiResponse<?> createRevenue(RevenueDto revenueDto);

    public ApiResponse<RevenueDto> getById(long id);

    public ApiResponse<?> getAll(long iActive, int offset, int page);

    public ApiResponse<?> updateBy(RevenueDto revenueDto);


    public ApiResponse<List<RevenueDto>> searchRevenue(RevenueSearchDto revenueSearchDto);


    ApiResponse<?> getAllUploadDocument();

    ApiResponse<?> getUploadDocumentById(long id) throws IOException;



}
