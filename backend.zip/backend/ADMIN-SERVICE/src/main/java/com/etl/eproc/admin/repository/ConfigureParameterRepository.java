package com.etl.eproc.admin.repository;


import com.etl.eproc.admin.model.TblConfigureParameter;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface ConfigureParameterRepository extends JpaRepository<TblConfigureParameter,Integer> {

    @Query(value = "select GETUTCDATE()",nativeQuery = true)
    Date getServerDateTime();

    Optional<List<TblConfigureParameter>> findAllByIsActive(int isActive, Pageable pageable);

    @Query(value = "select * from appmaster.tbl_ConfigureParameter where auctionCenterId=:auctionCenterId",nativeQuery = true)
    List<TblConfigureParameter> findByAuctionCenterId(@Param("auctionCenterId") int auctionCenterId);


}
