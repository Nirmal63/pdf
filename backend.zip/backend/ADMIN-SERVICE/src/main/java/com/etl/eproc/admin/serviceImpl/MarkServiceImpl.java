package com.etl.eproc.admin.serviceImpl;

import com.etl.eproc.admin.dto.MarkDto;
import com.etl.eproc.admin.dto.MarkSearchDto;
import com.etl.eproc.admin.dto.UploadDocumentConfDto;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.*;
import com.etl.eproc.admin.repository.AuctionCenterRepository;
import com.etl.eproc.admin.repository.FactoryRepository;
import com.etl.eproc.admin.repository.MarkRepository;
import com.etl.eproc.admin.repository.UserLoginRepository;
import com.etl.eproc.admin.serviceI.MarkService;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MarkServiceImpl implements MarkService {

    @Autowired
    private MarkRepository markRepository;

    @Autowired
    private ModelMapper mapper;

    @Autowired
    private UserLoginRepository userLoginRepository;

    @Autowired
    private FactoryRepository factoryRepository;

    @Autowired
    private AuctionCenterRepository auctionCenterRepository;

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;
    @Override
    public ApiResponse<MarkDto> createMark(MarkDto markDto) {
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin","userId",1));
        TblFactory tblFactory = factoryRepository.findById(markDto.getFactoryId()).orElseThrow(()-> new ResourceNotFoundException("TblFactory","factoryId",markDto.getFactoryId()));
        TblAuctionCenter tblAuctionCenter = auctionCenterRepository.findById(markDto.getAuctionCenterId()).orElseThrow(()-> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId ",markDto.getAuctionCenterId()));
        boolean isExistsByMarkCode =  markRepository.existsByMarkCode(markDto.getMarkCode());
        if(!isExistsByMarkCode){
            mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE).setAmbiguityIgnored(true);
            TblMark tblMark = mapper.map(markDto , TblMark.class);
            tblMark.setCreatedBy(tblUserLogin);
            tblMark.setCreatedOn(new Date());
            tblMark.setFactory(tblFactory);
            tblMark.setTblAuctionCenter(tblAuctionCenter);
            tblMark.setUpdatedBy(null);
            TblMark tblMark1 = markRepository.save(tblMark) ;
            MarkDto markDto1 =  mapper.map(tblMark1 , MarkDto.class);
            if (markDto.getUploadDocumentContent() != null) {
                int i = 0;
                for (String DocumenName:markDto.getUploadDocumentName()) {
                    UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                    uploadDocumentConfDto.setRemarks(markDto.getUploadDocumentRemarks());
                    uploadDocumentConfDto.setTableID(tblMark1.getMarkId());
                    
                    uploadDocumentConfDto.setFlag(1);
                    uploadDocumentConfDto.setStatus(1);
                    uploadDocumentConfDto.setIsActive(1);
                    uploadDocumentConfDto.setDocumentSize(markDto.getUploadDocumentSize());
                    uploadDocumentConfDto.setTableName("tbl_Mark");
                    uploadDocumentConfDto.setFolderName("Mark");
                    uploadDocumentConfDto.setUploadDocumentName(DocumenName);
                    uploadDocumentConfDto.setUploadDocumentContent(markDto.getUploadDocumentContent()[i]);
                    TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                    i++;
                }
            }

            return new ApiResponse<>("Mark Created Successfully ",201, markDto1);
        }
        else {
            return new ApiResponse<>("Mark Code Already exists ", 400, null);
        }
    }

    @Override
    public ApiResponse<MarkDto> getMarkById(Long markId) {
        TblMark tblMark = markRepository.findById(markId).orElseThrow(()-> new ResourceNotFoundException("TblMark " ,"markId ",markId));
        MarkDto markDto =  mapper.map(tblMark , MarkDto.class);
     //   markDto.setUserId(tblMark.getCreatedBy().getUserId());
        return new ApiResponse<>("Mark get By Id Successfully ",200, markDto);
    }

  /*  @Override
    public ApiResponse<List<MarkDto>> getAllMark() {
        List<MarkDto> markDto =  markRepository.findAll().stream().map(tblMark -> {
            MarkDto markDto1 = mapper.map(tblMark , MarkDto.class);
         //   markDto1.setUserId(tblMark.getCreatedBy().getUserId());
            return markDto1;
        }).collect(Collectors.toList());
        return new ApiResponse<>("Get All Mark Successfully ",200, markDto);
    }
*/
    @Override
    public ApiResponse<MarkDto> updateMark(MarkDto markDto) {
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin","userId",1));
        TblFactory tblFactory = factoryRepository.findById(markDto.getFactoryId()).orElseThrow(()-> new ResourceNotFoundException("TblFactory","factoryId",markDto.getFactoryId()));
        TblAuctionCenter tblAuctionCenter = auctionCenterRepository.findById(markDto.getAuctionCenterId()).orElseThrow(()-> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId ",markDto.getAuctionCenterId()));
        TblMark tblMark = markRepository.findById(markDto.getMarkId()).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin","userId",1));
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE).setAmbiguityIgnored(true);
        tblMark.setUpdatedOn(new Date());
        tblMark.setUpdatedBy(tblUserLogin);
        tblMark.setMarkName(markDto.getMarkName());
        tblMark.setMarkCode(markDto.getMarkCode());
        tblMark.setIsActive(markDto.getIsActive());
        tblMark.setTblAuctionCenter(tblAuctionCenter);
        tblMark.setFactory(tblFactory);
        tblMark.setOwnerName(markDto.getOwnerName());
        tblMark.setManufacturerName(markDto.getManufacturerName());
        tblMark.setBankAccStatus(markDto.getBankAccStatus());
        MarkDto markDto1 = mapper.map(markRepository.save(tblMark),MarkDto.class);
        if (markDto.getUploadDocumentContent() != null) {
            int i = 0;
            for (String DocumenName:markDto.getUploadDocumentName()) {
                UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                uploadDocumentConfDto.setRemarks(markDto.getUploadDocumentRemarks());
                uploadDocumentConfDto.setTableID(tblMark.getMarkId());
                
                uploadDocumentConfDto.setFlag(1);
                uploadDocumentConfDto.setStatus(1);
                uploadDocumentConfDto.setIsActive(1);
                uploadDocumentConfDto.setDocumentSize(markDto.getUploadDocumentSize());
                uploadDocumentConfDto.setTableName("tbl_Mark");
                uploadDocumentConfDto.setFolderName("Mark");
                uploadDocumentConfDto.setUploadDocumentName(DocumenName);
                uploadDocumentConfDto.setUploadDocumentContent(markDto.getUploadDocumentContent()[i]);
                TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                i++;
            }
        }
        return new ApiResponse<>("Mark Updated Successfully ",201, markDto1);
    }

  /*  @Override
    public ApiResponse<?> searchMarkPageable(int isActive, int offset, int page) {
        Pageable pageable= PageRequest.of(page,offset);
        Optional<List<TblMark>> list =markRepository.findAllByIsActive(isActive,pageable);
        if(!list.isEmpty() && list.isPresent()){
            List<MarkDto> dtos=list.get().stream().map(
                    tblMark -> {
                        MarkDto dto= new MarkDto();
                        dto.setMarkName(tblMark.getMarkName());
                        dto.setMarkCode(tblMark.getMarkCode());
                        dto.setOwnerName(tblMark.getOwnerName());
                        dto.setAuctionCenterId(tblMark.getTblAuctionCenter().getAuctionCenterId());
                        dto.setManufacturerName(tblMark.getManufacturerName());
                        dto.setFactoryId(tblMark.getFactory().getFactoryId());
                        dto.setIsActive(tblMark.getIsActive());
                        dto.setBankAccStatus(tblMark.getBankAccStatus());
                        return dto;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse("success",200,dtos);
        }
        return new ApiResponse("No Record Found",404,null);
    }*/


    @Override
    public ApiResponse<List<MarkSearchDto>> searchMarks(MarkSearchDto markSearchDto) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appuser.Get_tbl_Mark_Search")
                .registerStoredProcedureParameter("@V_markName", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_markCode", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_isactive", Integer.class, ParameterMode.IN)
                .setParameter("@V_markName", markSearchDto.getMarkName())
                .setParameter("@V_markCode", markSearchDto.getMarkCode())
                .setParameter("@V_isactive", markSearchDto.getIsActive());
        List<Object[]> execute = storedProcedureQuery.getResultList();
        if (!execute.isEmpty()) {
            List<MarkSearchDto> markSearchDtos = execute.stream().map(
                    objects -> {
                        MarkSearchDto markSearchDto1 = new MarkSearchDto();
                        markSearchDto1.setMarkId(Long.valueOf(objects[0].toString()));
                        markSearchDto1.setMarkName((String) objects[1]);
                        markSearchDto1.setMarkCode((String) objects[2]);
                        markSearchDto1.setOwnerName((String) objects[3]);
                        markSearchDto1.setManufacturer((String) objects[4]);
                       // markSearchDto1.setBankAccountStatus((Byte) objects[5]);
                        markSearchDto1.setAuctionCenterName((String) objects[6]);
                        markSearchDto1.setIsActive((Boolean) objects[7] == true ? 1 : 0);
                        return markSearchDto1;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse<List<MarkSearchDto>>("getAll Success", 200, markSearchDtos);
        }
        return new ApiResponse<>("No Record Found",404,null);
    }

}
