package com.etl.eproc.admin.serviceImpl;

import com.etl.eproc.admin.dto.*;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.*;
import com.etl.eproc.admin.repository.AuctionCenterRepository;
import com.etl.eproc.admin.repository.BankAccountDetailRepository;
import com.etl.eproc.admin.repository.UploadDocumentConfRepository;
import com.etl.eproc.admin.repository.UserLoginRepository;
import com.etl.eproc.admin.serviceI.BankAccountDetailService;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BankAccountDetailServiceImpl implements BankAccountDetailService {

    @Autowired
    private BankAccountDetailRepository bankAccountDetailRepository;

    @Autowired
    private ModelMapper mapper;

    @Autowired
    private UserLoginRepository userLoginRepository;

    @Autowired
    private AuctionCenterRepository auctionCenterRepository;

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;

    @Autowired
    private UploadDocumentConfRepository uploadDocumentConfRepository;
    @Override
    public ApiResponse<BankAccountDetailDto> createBankAccount(BankAccountDetailDto bankAccountDetailDto) {
       TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(()-> new ResourceNotFoundException("TblUserLogin " ,"userId" ,1));
      TblAuctionCenter tblAuctionCenter = auctionCenterRepository.findById(bankAccountDetailDto.getAuctionCenterId()).orElseThrow(()-> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId ",bankAccountDetailDto.getAuctionCenterId()));
       boolean isExistByBankAccountNumber = bankAccountDetailRepository.existsByBankAccountNumber(bankAccountDetailDto.getBankAccountNumber());
       boolean isExistByContactNumber = bankAccountDetailRepository.existsByContactNumber(bankAccountDetailDto.getContactNumber());
        boolean isExistByEmail = bankAccountDetailRepository.existsByEmail(bankAccountDetailDto.getEmail());
       //boolean isExistByAuctionCenterId = bankAccountDetailRepository.existsByAuctionCenterId(bankAccountDetailDto.getAuctionCenterId());
       if(!isExistByBankAccountNumber && !isExistByEmail && !isExistByContactNumber ) {
           mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE).setAmbiguityIgnored(true);
           TblBankAccountDetail tblBankAccountDetail =  mapper.map(bankAccountDetailDto, TblBankAccountDetail.class);
           tblBankAccountDetail.setCreatedBy(tblUserLogin);
           tblBankAccountDetail.setCreatedOn(new Date());
           tblBankAccountDetail.setAuctionCenterId(tblAuctionCenter);
           tblBankAccountDetail.setUserId(tblUserLogin);
           tblBankAccountDetail.setUpdatedBy(null);
           TblBankAccountDetail tblBankAccountDetail1 = bankAccountDetailRepository.save(tblBankAccountDetail);
           BankAccountDetailDto tblBankAccountDetailMap =  mapper.map(tblBankAccountDetail1, BankAccountDetailDto.class);
           tblBankAccountDetailMap.setAuctionCenterId(tblBankAccountDetail1.getAuctionCenterId().getAuctionCenterId());
           if (bankAccountDetailDto.getUploadDocumentContent() != null) {
               int i = 0;
               for (String DocumenName:bankAccountDetailDto.getUploadDocumentName()) {
                   UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                   uploadDocumentConfDto.setRemarks(bankAccountDetailDto.getUploadDocumentRemarks());
                   uploadDocumentConfDto.setTableID(tblBankAccountDetail1.getBankAccountDetailId());
                   
                   uploadDocumentConfDto.setFlag(1);
                   uploadDocumentConfDto.setStatus(1);
                   uploadDocumentConfDto.setIsActive(1);
                   uploadDocumentConfDto.setDocumentSize(bankAccountDetailDto.getUploadDocumentSize());
                   uploadDocumentConfDto.setTableName("tbl_State");
                   uploadDocumentConfDto.setFolderName("State");
                   uploadDocumentConfDto.setUploadDocumentName(DocumenName);
                   uploadDocumentConfDto.setUploadDocumentContent(bankAccountDetailDto.getUploadDocumentContent()[i]);
                   TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                   i++;
               }
           }
           return new ApiResponse<BankAccountDetailDto>("BankAccountDetail Was Created Successfuly" , 201, tblBankAccountDetailMap);
       }
        else if(isExistByBankAccountNumber){
           return new ApiResponse<>("Bank Account Number already exists",400,null);
        }
       else if(isExistByContactNumber){
           return new ApiResponse<>("Contact Number already exists",400,null);
       }
        return new ApiResponse<>("Email already exists",400,null);
    }

  /*  @Override
    public ApiResponse<List<BankAccountDetailDto>> getAllBankAccount() {
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE).setAmbiguityIgnored(true);
       List<BankAccountDetailDto> bankAccountDetailDtoList = bankAccountDetailRepository.findAll().stream().map(tblBankAccountDetail -> {
           BankAccountDetailDto bankAccountDetailDto = mapper.map(tblBankAccountDetail,BankAccountDetailDto.class);
          // bankAccountDetailDto.setUserId(tblBankAccountDetail.getCreatedBy().getUserId());
           return bankAccountDetailDto;
       }).collect(Collectors.toList());
        return new ApiResponse<List<BankAccountDetailDto>>("Get All Bank Account Successfully",200,bankAccountDetailDtoList);
    }*/

    @Override
    public ApiResponse<BankAccountDetailDto> getBankAccountById(Long bankAccountDetailId) {
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE).setAmbiguityIgnored(true);
       TblBankAccountDetail tblBankAccountDetail = bankAccountDetailRepository.findById(bankAccountDetailId).orElseThrow(()-> new ResourceNotFoundException("TblBankUserDetail ","bankAccountDetailId ",bankAccountDetailId));
        BankAccountDetailDto bankAccountDetailDto =  mapper.map(tblBankAccountDetail, BankAccountDetailDto.class);
      //  bankAccountDetailDto.setUserId(tblBankAccountDetail.getCreatedBy().getUserId());
        bankAccountDetailDto.setBankAccountDetailId(tblBankAccountDetail.getBankAccountDetailId());
        bankAccountDetailDto.setAuctionCenterId(tblBankAccountDetail.getAuctionCenterId().getAuctionCenterId());
        return new ApiResponse<BankAccountDetailDto>("Bank Account Get By Id Successfully", 200,bankAccountDetailDto);
    }

    @Override
    public ApiResponse<BankAccountDetailDto> updateBankAccount(BankAccountDetailDto bankAccountDetailDto) {
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE).setAmbiguityIgnored(true);
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin","userId",1));
        TblAuctionCenter tblAuctionCenter = auctionCenterRepository.findById(bankAccountDetailDto.getAuctionCenterId()).orElseThrow(()-> new ResourceNotFoundException("TblAuctionCenter ","auctionCenterId ",bankAccountDetailDto.getAuctionCenterId()));
        TblBankAccountDetail tblBankAccountDetail = bankAccountDetailRepository.findById(bankAccountDetailDto.getBankAccountDetailId()).orElseThrow(()-> new ResourceNotFoundException("TblBankAccountDetail","bankAccountDetail",bankAccountDetailDto.getBankAccountDetailId()));
        tblBankAccountDetail.setBankName(bankAccountDetailDto.getBankName());
        tblBankAccountDetail.setBankAccountNumber(bankAccountDetailDto.getBankAccountNumber());
        tblBankAccountDetail.setAuctionCenterId(tblAuctionCenter);
        tblBankAccountDetail.setEmail(bankAccountDetailDto.getEmail());
        tblBankAccountDetail.setBeneficiaryName(bankAccountDetailDto.getBeneficiaryName());
        tblBankAccountDetail.setBranchAddress(bankAccountDetailDto.getBranchAddress());
        tblBankAccountDetail.setContactNumber(bankAccountDetailDto.getContactNumber());
        tblBankAccountDetail.setIfscCode(bankAccountDetailDto.getIfscCode());
        tblBankAccountDetail.setIsActive(bankAccountDetailDto.getIsActive());
        tblBankAccountDetail.setUpdatedBy(tblUserLogin);
        tblBankAccountDetail.setUpdatedOn(new Date());
        tblBankAccountDetail.setContactPersonAddress(bankAccountDetailDto.getContactPersonAddress());
        TblBankAccountDetail tblBankAccountDetail1 = bankAccountDetailRepository.save(tblBankAccountDetail);
        BankAccountDetailDto bankAccountDetailDto1 = mapper.map(bankAccountDetailRepository.save(tblBankAccountDetail), BankAccountDetailDto.class);
        if (bankAccountDetailDto.getUploadDocumentContent() != null) {
            int i = 0;
            for (String DocumenName:bankAccountDetailDto.getUploadDocumentName()) {
                UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                uploadDocumentConfDto.setRemarks(bankAccountDetailDto.getUploadDocumentRemarks());
                uploadDocumentConfDto.setTableID(tblBankAccountDetail1.getBankAccountDetailId());
                
                uploadDocumentConfDto.setFlag(1);
                uploadDocumentConfDto.setStatus(1);
                uploadDocumentConfDto.setIsActive(1);
                uploadDocumentConfDto.setDocumentSize(bankAccountDetailDto.getUploadDocumentSize());
                uploadDocumentConfDto.setTableName("tbl_BankAccountDetails");
                uploadDocumentConfDto.setFolderName("BankAccountDetails");
                uploadDocumentConfDto.setUploadDocumentName(DocumenName);
                uploadDocumentConfDto.setUploadDocumentContent(bankAccountDetailDto.getUploadDocumentContent()[i]);
                TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                i++;
            }
        }
        return new ApiResponse<BankAccountDetailDto>("Bank Account Details Updated successfully" ,201,bankAccountDetailDto1);
    }

/*    @Override
    public ApiResponse<?> searchBankAccountDetailPageable(int isActive, int offset, int page) {
        Pageable pageable = PageRequest.of(page, offset);
        Optional<List<TblBankAccountDetail>> list = bankAccountDetailRepository.findAllByIsActive(isActive, pageable);
        if (!list.isEmpty() && list.isPresent()) {
            List<BankAccountDetailDto> dtos = list.get().stream().map(
                    tblBankAccountDetail -> {
                        BankAccountDetailDto dto = new BankAccountDetailDto();
                        dto.setBankAccountNumber(tblBankAccountDetail.getBankAccountNumber());
                        dto.setBankName(tblBankAccountDetail.getBankName());
                    //    dto.setUserId(tblBankAccountDetail.getCreatedBy().getUserId());
                        dto.setEmail(tblBankAccountDetail.getEmail());
                        dto.setBranchAddress(tblBankAccountDetail.getBranchAddress());
                        dto.setIfscCode(tblBankAccountDetail.getIfscCode());
                        dto.setContactNumber(tblBankAccountDetail.getContactNumber());
                        dto.setIsActive(tblBankAccountDetail.getIsActive());
                        dto.setBeneficiaryName(tblBankAccountDetail.getBeneficiaryName());
                        dto.setAuctionCenterId(tblBankAccountDetail.getAuctionCenterId().getAuctionCenterId());
                   //     dto.setUserId(tblBankAccountDetail.getUserId().getUserId());
                        dto.setContactPerson(tblBankAccountDetail.getContactPerson());
                        dto.setContactPersonAddress(tblBankAccountDetail.getContactPersonAddress());
                        return dto;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse("success", 200, dtos);
        }
        return new ApiResponse("No Record Found", 404, null);
    }*/

 @Override
    public ApiResponse<List<BankAccountSearchDto>> searchBankAccountDetails(BankAccountSearchDto bankAccountSearchDto) {
     StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appuser.Get_tbl_BankAccountDetail_Search")
             .registerStoredProcedureParameter("@V_bankAccountNumber", String.class, ParameterMode.IN)
             .registerStoredProcedureParameter("@V_bankName", String.class, ParameterMode.IN)
             .registerStoredProcedureParameter("@V_ifscCode", String.class, ParameterMode.IN)
             .registerStoredProcedureParameter("@V_auctionCenterName", String.class, ParameterMode.IN)
             .registerStoredProcedureParameter("@V_isactive", Integer.class, ParameterMode.IN)
             .setParameter("@V_bankAccountNumber", bankAccountSearchDto.getBankAccountNumber())
             .setParameter("@V_bankName", bankAccountSearchDto.getBankName())
             .setParameter("@V_ifscCode", bankAccountSearchDto.getIfscCode())
             .setParameter("@V_auctionCenterName", bankAccountSearchDto.getAuctionCenterName())
             .setParameter("@V_isactive", bankAccountSearchDto.getIsActive());
     List<Object[]> execute = storedProcedureQuery.getResultList();
     if (!execute.isEmpty()) {
         List<BankAccountSearchDto> bankAccountSearchDtoList = execute.stream().map(
                 objects -> {
                     BankAccountSearchDto bankAccountSearchDto1 = new BankAccountSearchDto();
                     bankAccountSearchDto1.setBankAccountDetailId(Long.valueOf(objects[0].toString()));
                     bankAccountSearchDto1.setBankAccountNumber(String.valueOf(objects[1].toString()));
                     bankAccountSearchDto1.setBankName((String) objects[2]);
                     bankAccountSearchDto1.setIfscCode((String) objects[3]);
                     bankAccountSearchDto1.setAuctionCenterName((String) objects[4]);
                     bankAccountSearchDto1.setIsActive((Boolean) objects[5] == true ? 1 : 0);
                     return bankAccountSearchDto1;
                 }
         ).collect(Collectors.toList());
         return new ApiResponse<List<BankAccountSearchDto>>("getAll Success", 200, bankAccountSearchDtoList);
     }
     return new ApiResponse<>("No Record Found",404,null);
 }
}
