package com.etl.eproc.admin.controller;


import com.etl.eproc.admin.dto.TeaTypeDto;
import com.etl.eproc.admin.model.TblTeaType;
import com.etl.eproc.admin.serviceI.TeaTypeService;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import javax.validation.Valid;
import java.util.Optional;

@RestController
@RequestMapping("admin/teaType")
public class TeaTypeController {

    @Autowired
    private TeaTypeService teaTypeService;



    @PostMapping("/create")
    public ApiResponse<?> createTeaType(@Valid  @RequestBody TeaTypeDto teaTypeDto){
        try {
            ApiResponse<?> teaType = teaTypeService.createTeaType(teaTypeDto);
            return teaType;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }

    @GetMapping("/getAll")
    public ApiResponse<?> getAllTeaType(){
        try {
            ApiResponse<?> allTeaType = teaTypeService.getAllTeaType();
            return allTeaType;

        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }

    }

    @GetMapping("/get/{teaTypeId}")
    public ApiResponse<?> getTeaTypeById(@PathVariable("teaTypeId") int teaTypeId){
        try {
            ApiResponse<?> teaTypeById = teaTypeService.findTeaTypeById(teaTypeId);
            return teaTypeById;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }

    }

    @PostMapping("/update")
    public ApiResponse<?> updateTeaType(@Valid @RequestBody TeaTypeDto teaTypeDto){
        try {
            ApiResponse<?> apiResponse = teaTypeService.updateTeaType(teaTypeDto);
            return apiResponse;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }

    }

    @GetMapping(value = "/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> getAllTeaTypeByActiveInActive(@PathVariable("isActive") int isActive,@PathVariable("offset") int offset,@PathVariable("page") int page){
        try {
            return teaTypeService.searchTeaTypePageable(isActive,offset,page);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }

    }

    @PostMapping(value = "/search")
    public ApiResponse<?> searchTeaType(@RequestBody TeaTypeDto teaTypeDto){
        try{
            return teaTypeService.searchTeaType(teaTypeDto);
        }catch (Exception e){
            e.printStackTrace();
            ApiResponse<Optional<TblTeaType>> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }
    }

}
