package com.etl.eproc.admin.repository;


import com.etl.eproc.admin.model.TblState;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface StateRepository extends JpaRepository<TblState,Long> {


    public boolean existsByStateName(String stateName);

    public boolean existsByStateCode(String stateCode);

    public boolean existsByStateInitial(String stateInitial);

    Optional<List<TblState>> findAllByIsActive(int isActive, Pageable pageable);
}
