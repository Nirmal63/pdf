package com.etl.eproc.admin.config;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CommonConfig {
    @Bean
    public ModelMapper modelMApper(){
        ModelMapper mapper=  new ModelMapper();

        return mapper;
    }
}
