package com.etl.eproc.admin.serviceI;


import com.etl.eproc.admin.dto.TaxMasterDto;
import com.etl.eproc.admin.dto.TaxMasterSearchDto;
import com.etl.eproc.admin.util.ApiResponse;

import java.io.IOException;
import java.util.List;

public interface TaxMasterService {

    public ApiResponse<?> createtax(TaxMasterDto taxMasterDto);

    public ApiResponse<TaxMasterDto> getTaxMasterById(long id);

    public ApiResponse<?> getAllTaxMaster(int iActive, int offset, int page);

    public ApiResponse<?> updateTaxMasterBy(TaxMasterDto taxMasterDto );


    public ApiResponse<List<TaxMasterSearchDto>> searchTaxMaster(TaxMasterSearchDto taxMasterSearchDto);


    ApiResponse<?> getAllUploadDocument();

    ApiResponse<?> getUploadDocumentById(long id) throws IOException;
}
