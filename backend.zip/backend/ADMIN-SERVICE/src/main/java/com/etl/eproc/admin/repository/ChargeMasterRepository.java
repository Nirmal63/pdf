package com.etl.eproc.admin.repository;

import com.etl.eproc.admin.model.TblChargeMaster;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface ChargeMasterRepository extends JpaRepository<TblChargeMaster,Long> {
    Optional<List<TblChargeMaster>> findAllByIsActive(int isActive, Pageable pageable);
    @Query(value = "select chargesName,chargeCodeId,chargeType,chargesValue,effectiveFromDate,effectiveEndDate,isActive from appmaster.tbl_ChargeMaster",nativeQuery = true)
    List<Map<String,Object>> findAllData();
}
