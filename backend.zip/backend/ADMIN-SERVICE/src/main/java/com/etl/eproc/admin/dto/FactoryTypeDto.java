package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FactoryTypeDto {
    private long factoryTypeId;
    @NotNull(message = "Please enter the factory type name.")
    @Pattern(regexp = "^[A-Za-z \\\\s\\\\-]*$",message = "The Factory Type Name should contain alphabetic characters only")
    @Size(min = 2,message = "The grade name should be at least 2 characters long.")
    @Size(max= 50,message = "The factory type name should not exceed 50 characters.")
    private String factoryTypeName;
    @NotNull(message ="Please enter the factory type.")
    @Pattern(regexp = "^[A-Za-z \\\\s\\\\-]*$",message = "The Factory Type should contain alphabetic characters only")
    @Size(min = 2,message = "The factory type should be at least 2 characters long.")
    @Size(max = 10,message = "The factory type should not exceed 50 characters.")
    private String factoryType;
    private Integer isActive;
    //private long sessionUserId;
    private String uploadDocumentRemarks;
    private DownloadDto[] downloadDto;



}
