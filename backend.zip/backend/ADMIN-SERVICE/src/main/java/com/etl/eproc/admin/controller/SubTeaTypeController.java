package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.SubTeaTypeDto;
import com.etl.eproc.admin.model.TblSubTeaType;
import com.etl.eproc.admin.serviceI.SubTeaTypeService;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.util.Optional;

@RestController
@RequestMapping("admin/subTeaType")
public class SubTeaTypeController {

    @Autowired
    private SubTeaTypeService subTeaTypeService;

    @PostMapping("/create")
    public ApiResponse<?> createSubTeaType(@Valid @RequestBody SubTeaTypeDto subTeaTypeDto){
        try{
            return subTeaTypeService.createSubTeaType(subTeaTypeDto);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }

    }

    @GetMapping("/getAll")
    public ApiResponse<?> getAllSubTeaType(){
        try{
            ApiResponse<?> allSubTeaType = subTeaTypeService.getAllSubTeaType();
            return  allSubTeaType;

        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }

    }

    @GetMapping("/get/{subTeaTypeId}")
    public ApiResponse<?> getSubTeaTypeById(@PathVariable("subTeaTypeId") int subTeaTypeId){
        try{
            ApiResponse<?> subTeaTypeById = subTeaTypeService.findSubTeaTypeById(subTeaTypeId);

            return  subTeaTypeById;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }

    }

    @PostMapping("/update")
    public ApiResponse<?> updateSubTeaType(@Valid @RequestBody SubTeaTypeDto subTeaTypeDto){
        try{
            ApiResponse<?> apiResponse = subTeaTypeService.updateSubTeaType(subTeaTypeDto);
            return apiResponse;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }

    @GetMapping(value = "/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> getAllSubTeaTypeByActiveInActive(@PathVariable("isActive") int isActive,@PathVariable("offset") int offset,@PathVariable("page") int page){
        try {
            return subTeaTypeService.searchSubTeaTypePageable(isActive,offset,page);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }

    }

    @PostMapping(value = "/search")
    public ApiResponse<?> searchTeaType(@RequestBody SubTeaTypeDto subTeaTypeDto){
        try{
            return subTeaTypeService.searchSubTeaType(subTeaTypeDto);
        }catch (Exception e){
            e.printStackTrace();
            ApiResponse<Optional<TblSubTeaType>> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }
    }
}
