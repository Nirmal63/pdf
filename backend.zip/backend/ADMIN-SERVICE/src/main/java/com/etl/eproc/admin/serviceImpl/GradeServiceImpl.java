package com.etl.eproc.admin.serviceImpl;

import com.etl.eproc.admin.dto.DownloadDto;
import com.etl.eproc.admin.dto.GradeDto;
import com.etl.eproc.admin.dto.UploadDocumentConfDto;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.TblGrade;
import com.etl.eproc.admin.model.TblUploadDocumentConf;
import com.etl.eproc.admin.model.TblUserLogin;
import com.etl.eproc.admin.repository.GradeRepository;
import com.etl.eproc.admin.repository.UploadDocumentConfRepository;
import com.etl.eproc.admin.repository.UserLoginRepository;
import com.etl.eproc.admin.serviceI.GradeService;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class GradeServiceImpl implements GradeService {

    @Autowired
    private ModelMapper mapper;
    @Autowired
    private GradeRepository gradeRepository;

    @Autowired
    private UserLoginRepository userLoginRepository;
    @Autowired
    private EntityManager entityManager;

    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;
    @Autowired
    private UploadDocumentConfRepository uploadDocumentConfRepository;

    public ApiResponse<?> createGrade(GradeDto gradeDto) {
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin","userId",1));
        boolean gradeNameDuplicate = gradeRepository.existsByGradeName(gradeDto.getGradeName());
        boolean gradeCodeDuplicate = gradeRepository.existsByGradeCode(gradeDto.getGradeCode());
        if (!gradeNameDuplicate && !gradeCodeDuplicate ) {
            mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
            TblGrade grade = mapper.map(gradeDto, TblGrade.class);
            grade.setIsActive(1);
            grade.setCreatedBy(tblUserLogin);
            grade.setCreatedOn(new Date());
            gradeRepository.save(grade);
            GradeDto gradeDtonew = mapper.map(grade, GradeDto.class);
            if (!gradeDto.getDownloadDto()[0].getDocumentContent().isEmpty()) {
                int i = 0;
                for(int j=0;j<=gradeDto.getDownloadDto().length-1;j++) {
                    UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                    uploadDocumentConfDto.setRemarks(gradeDto.getUploadDocumentRemarks());
                    uploadDocumentConfDto.setTableID(grade.getGradeId());
                    
                    uploadDocumentConfDto.setFlag(1);
                    uploadDocumentConfDto.setStatus(1);
                    uploadDocumentConfDto.setIsActive(1);
                    uploadDocumentConfDto.setDocumentSize(String.valueOf(gradeDto.getDownloadDto()[i].getDocumentSize()));
                    uploadDocumentConfDto.setTableName("tbl_Grade");
                    uploadDocumentConfDto.setFolderName("Grade");
                    uploadDocumentConfDto.setUploadDocumentName(String.valueOf(gradeDto.getDownloadDto()[i].getDocumentName()));
                    uploadDocumentConfDto.setUploadDocumentContent(String.valueOf(gradeDto.getDownloadDto()[i].getDocumentContent()));
                    TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                    i++;
                }
            }
            return new ApiResponse<GradeDto>("Grade created successfully", 201, gradeDtonew);
        }
        else if(gradeNameDuplicate) {
            return new ApiResponse<GradeDto>("Grade name must be unique. The entered value already exists.", 400, null);
        }
        else{
            return new ApiResponse<GradeDto>("Grade code must be unique. The entered value already exists.", 400, null);
        }
    }

    public ApiResponse<?> updateGrade(GradeDto updateGradeDto){
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin","userId",1));
        TblGrade grade1=gradeRepository.findById(updateGradeDto.getGradeId()).orElseThrow(()->new ResourceNotFoundException("TblGrade","gradeId",updateGradeDto.getGradeId()));
        grade1.setGradeName(updateGradeDto.getGradeName());
        grade1.setGradeCode(updateGradeDto.getGradeCode());
        grade1.setIsActive(updateGradeDto.getIsActive());
        grade1.setUpdatedBy(tblUserLogin);
        grade1.setUpdatedOn(new Date());
        gradeRepository.save(grade1);
        GradeDto gradeDtonew = mapper.map(grade1, GradeDto.class);
        if (!updateGradeDto.getDownloadDto()[0].getDocumentContent().isEmpty()) {
            int i = 0;
            for(int j=0;j<=updateGradeDto.getDownloadDto().length-1;j++) {
                UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                uploadDocumentConfDto.setRemarks(updateGradeDto.getUploadDocumentRemarks());
                uploadDocumentConfDto.setTableID(grade1.getGradeId());
                
                uploadDocumentConfDto.setFlag(2);
                uploadDocumentConfDto.setStatus(1);
                uploadDocumentConfDto.setIsActive(1);
                uploadDocumentConfDto.setDocumentSize(String.valueOf(updateGradeDto.getDownloadDto()[i].getDocumentSize()));
                uploadDocumentConfDto.setTableName("tbl_Grade");
                uploadDocumentConfDto.setFolderName("Grade");
                uploadDocumentConfDto.setUploadDocumentName(String.valueOf(updateGradeDto.getDownloadDto()[i].getDocumentName()));
                uploadDocumentConfDto.setUploadDocumentContent(String.valueOf(updateGradeDto.getDownloadDto()[i].getDocumentContent()));
                TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                i++;
            }
        }
        return  new ApiResponse<GradeDto>("Grade Updated successfully" ,200,gradeDtonew);
    }

    public ApiResponse<List<GradeDto>> getAllGrade(){
        List<GradeDto> gradeAllDtoList=gradeRepository.findAll().stream().map(
                tblGrade -> {
                    GradeDto gradeDto = mapper.map(tblGrade, GradeDto.class);
                    //gradeDto.setSessionUserId(tblGrade.getCreatedBy().getUserId());
                    return gradeDto;
                } ).collect(Collectors.toList());
        return new ApiResponse<List<GradeDto>>("getAll Grade successfully" ,200,gradeAllDtoList);
    }

    @Override
    public ApiResponse<?> getAllGradePageable(int isActive, int offset, int page) {
        Pageable pageable= PageRequest.of(page,offset);
        Optional<List<TblGrade>> list =gradeRepository.findAllByIsActive(isActive,pageable);
        if(!list.isEmpty() && list.isPresent()){
            List<GradeDto> dtos=list.get().stream().map(
                    tblGrade -> {
                        GradeDto dto= new GradeDto();
                        dto.setGradeId(tblGrade.getGradeId());
                        dto.setGradeName(tblGrade.getGradeName());
                        dto.setGradeCode(tblGrade.getGradeCode());
                        dto.setIsActive(tblGrade.getIsActive());
                        return dto;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse("success",200,dtos);
        }

        return new ApiResponse("No Record Found",404,null);
    }

    @Override
    public ApiResponse<?> searchGrade(GradeDto gradeDto){
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appmaster.Get_tbl_Grade_Search")
                .registerStoredProcedureParameter("@V_GradeName",String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_GradeCode",String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_isactive", Integer.class,ParameterMode.IN)
                .setParameter("@V_GradeName",gradeDto.getGradeName())
                .setParameter("@V_GradeCode",gradeDto.getGradeCode())
                .setParameter("@V_isactive",gradeDto.getIsActive());
        List<Object[]> execute = storedProcedureQuery.getResultList();
        if(!execute.isEmpty()) {
            List<GradeDto> gradeDtos = execute.stream().map(
                    objects -> {
                        GradeDto gradeDto1 = new GradeDto();
                        gradeDto1.setGradeId(Long.valueOf(objects[0].toString()));
                        gradeDto1.setGradeName((String) objects[1]);
                        gradeDto1.setGradeCode((String) objects[2]);
                        gradeDto1.setIsActive((Boolean) objects[3] == true ? 1 : 0);
                        return gradeDto1;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse("getBySearch Succees", 200, gradeDtos);
        }
        return  new ApiResponse<>("No Record Found",404,null);
    }
    public ApiResponse<GradeDto> getGradeById(long gradeId) {
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
        TblGrade grade = gradeRepository.findById(gradeId).orElseThrow(()->new ResourceNotFoundException("TblGrade","gradeId",gradeId));
        GradeDto gradeByid = mapper.map(grade, GradeDto.class);
        //gradeByid.setSessionUserId(grade.getCreatedBy().getUserId());
        return  new ApiResponse<GradeDto>("Grade get by Id successfully" ,200,gradeByid);
    }
    @Override
    public ApiResponse<?> getAllUploadedDocument() {
        Optional<List<TblUploadDocumentConf>> tblUploadDocumentConf= uploadDocumentConfRepository.findAllUploadDocument("tbl_Category");

        List<DownloadDto> downloadDtos = tblUploadDocumentConf.get().stream().map(
                tblUploadDocument ->{
                    DownloadDto downloadDto = new DownloadDto();
                    downloadDto.setUploadDocumentConfId(tblUploadDocument.getUploadDocumentConfId());
                    downloadDto.setUploadDocumentRemarks(tblUploadDocument.getRemarks());
                    downloadDto.setDocumentUploadTime(tblUploadDocument.getCreatedOn());
                    return downloadDto;
                }).collect(Collectors.toList());
        return  new ApiResponse<List<DownloadDto>>("success" ,200,downloadDtos);
    }

    @Override

    public ApiResponse<?> getUploadedDocumentById(long id) throws IOException {
        DownloadDto download = uploadDocumentConfService.downloadDocument(id);
        DownloadDto downloadDto = new DownloadDto();
        downloadDto.setDocumentName(download.getDocumentName());
        downloadDto.setDocumentContent(download.getDocumentContent());
        return  new ApiResponse<DownloadDto>("success" ,200,downloadDto);
    }


}

