package com.etl.eproc.admin.serviceImpl;

import com.etl.eproc.admin.dto.AuctionCenterDto;
import com.etl.eproc.admin.dto.DownloadDto;
import com.etl.eproc.admin.dto.UploadDocumentConfDto;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.TblAuctionCenter;
import com.etl.eproc.admin.model.TblState;
import com.etl.eproc.admin.model.TblUploadDocumentConf;
import com.etl.eproc.admin.model.TblUserLogin;
import com.etl.eproc.admin.repository.AuctionCenterRepository;
import com.etl.eproc.admin.repository.StateRepository;
import com.etl.eproc.admin.repository.UploadDocumentConfRepository;
import com.etl.eproc.admin.repository.UserLoginRepository;
import com.etl.eproc.admin.serviceI.AuctionCenterService;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AuctionCenterServiceImpl implements AuctionCenterService {


    @Autowired
    private ModelMapper mapper;
    @Autowired
    private AuctionCenterRepository auctionCenterRepository;

    @Autowired
    private UserLoginRepository userLoginRepository;

    @Autowired
    private EntityManager entityManager;
    @Autowired
    private StateRepository stateRepository;

    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;
    @Autowired
    private UploadDocumentConfRepository uploadDocumentConfRepository;

    public ApiResponse<?> createAuctionCenter(AuctionCenterDto auctionCenterDto) {
            TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
            TblState tblState = stateRepository.findById(auctionCenterDto.getStateId()).orElseThrow(() -> new ResourceNotFoundException("TblState", "stateId", auctionCenterDto.getStateId()));
            boolean auctionCenterDuplicatename = auctionCenterRepository.existsByAuctionCenterName(auctionCenterDto.getAuctionCenterName());
            boolean auctionCenterDuplicatecode = auctionCenterRepository.existsByAuctionCenterCode(auctionCenterDto.getAuctionCenterCode());
            boolean auctionCenterDuplicateCertno = auctionCenterRepository.existsByCertificateNo(auctionCenterDto.getCertificateNo());
            if (!auctionCenterDuplicatename && !auctionCenterDuplicatecode && !auctionCenterDuplicateCertno) {
                mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
                TblAuctionCenter auctionCenter = mapper.map(auctionCenterDto, TblAuctionCenter.class);
                auctionCenter.setStateId(tblState);
                auctionCenter.setIsActive(1);
                auctionCenter.setCreatedBy(tblUserLogin);
                auctionCenter.setCreatedOn(new Date());
                auctionCenterRepository.save(auctionCenter);
                AuctionCenterDto auctionCenterDtonew = mapper.map(auctionCenter, AuctionCenterDto.class);
                if (!auctionCenterDto.getDownloadDto()[0].getDocumentContent().isEmpty()) {
                    int i = 0;
                    for(int j=0;j<=auctionCenterDto.getDownloadDto().length-1;j++) {
                        UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                        uploadDocumentConfDto.setRemarks(auctionCenterDto.getUploadDocumentRemarks());
                        uploadDocumentConfDto.setTableID(auctionCenter.getAuctionCenterId());
                        uploadDocumentConfDto.setFlag(1);
                        uploadDocumentConfDto.setStatus(1);
                        uploadDocumentConfDto.setIsActive(1);
                        uploadDocumentConfDto.setDocumentSize(String.valueOf(auctionCenterDto.getDownloadDto()[i].getDocumentSize()));
                        uploadDocumentConfDto.setTableName("tbl_AuctionCenter");
                        uploadDocumentConfDto.setFolderName("AuctionCenter");
                        uploadDocumentConfDto.setUploadDocumentName(String.valueOf(auctionCenterDto.getDownloadDto()[i].getDocumentName()));
                        uploadDocumentConfDto.setUploadDocumentContent(String.valueOf(auctionCenterDto.getDownloadDto()[i].getDocumentContent()));
                        TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                        i++;
                    }
                }
                return new ApiResponse<AuctionCenterDto>("Auction Center created successfully", 201, auctionCenterDtonew);
            } else if (auctionCenterDuplicatename) {
                return new ApiResponse<AuctionCenterDto>("Auction Center name already exists", 400, null);
            } else if (auctionCenterDuplicatecode) {
                return new ApiResponse<AuctionCenterDto>("Auction Center code already exists", 400, null);
            } else {
                return new ApiResponse<AuctionCenterDto>("Auction Center Certificate Number already exists", 400, null);
            }

        }


    public ApiResponse<?> updateAuctionCenter(AuctionCenterDto auctionCenterUpdateDto){
            TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
            TblState tblState = stateRepository.findById(auctionCenterUpdateDto.getStateId()).orElseThrow(() -> new ResourceNotFoundException("TblState", "stateId", auctionCenterUpdateDto.getStateId()));
            TblAuctionCenter auctionCenter1 = auctionCenterRepository.findById(auctionCenterUpdateDto.getAuctionCenterId()).orElseThrow(() -> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId", auctionCenterUpdateDto.getAuctionCenterId()));
            auctionCenter1.setAuctionCenterName(auctionCenterUpdateDto.getAuctionCenterName());
            auctionCenter1.setAuctionCenterCode(auctionCenterUpdateDto.getAuctionCenterCode());
            auctionCenter1.setCertificateNo(auctionCenterUpdateDto.getCertificateNo());
            auctionCenter1.setStateId(tblState);
            auctionCenter1.setIsActive(auctionCenterUpdateDto.getIsActive());
            auctionCenter1.setUpdatedBy(tblUserLogin);
            auctionCenter1.setUpdatedOn(new Date());
            auctionCenterRepository.save(auctionCenter1);
         AuctionCenterDto auctionCenterDtonew = mapper.map(auctionCenter1, AuctionCenterDto.class);
        if (!auctionCenterUpdateDto.getDownloadDto()[0].getDocumentContent().isEmpty()) {
            int i = 0;
            for(int j=0;j<=auctionCenterUpdateDto.getDownloadDto().length-1;j++) {
                UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                uploadDocumentConfDto.setRemarks(auctionCenterUpdateDto.getUploadDocumentRemarks());
                uploadDocumentConfDto.setTableID(auctionCenter1.getAuctionCenterId());
                uploadDocumentConfDto.setFlag(2);
                uploadDocumentConfDto.setStatus(1);
                uploadDocumentConfDto.setIsActive(1);
                uploadDocumentConfDto.setDocumentSize(String.valueOf(auctionCenterUpdateDto.getDownloadDto()[i].getDocumentSize()));
                uploadDocumentConfDto.setTableName("tbl_AuctionCenter");
                uploadDocumentConfDto.setFolderName("AuctionCenter");
                uploadDocumentConfDto.setUploadDocumentName(String.valueOf(auctionCenterUpdateDto.getDownloadDto()[i].getDocumentName()));
                uploadDocumentConfDto.setUploadDocumentContent(String.valueOf(auctionCenterUpdateDto.getDownloadDto()[i].getDocumentContent()));
                TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                i++;
            }
        }
            return new ApiResponse<AuctionCenterDto>("Auction Center Updated successfully", 200, auctionCenterDtonew);
        }

    public ApiResponse<List<AuctionCenterDto>> getAllAuctionCenter(){
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE).setAmbiguityIgnored(true);
        List<AuctionCenterDto> auctionCenterAllDtoList=auctionCenterRepository.findAll().stream().map(
                tblAuctionCenter -> {
                    AuctionCenterDto auctionCenterDto = mapper.map(tblAuctionCenter, AuctionCenterDto.class);
                    //auctionCenterDto.setSessionUserId(tblAuctionCenter.getCreatedBy().getUserId());
                    auctionCenterDto.setStateId(tblAuctionCenter.getStateId().getStateId());
                    return auctionCenterDto;
                } ).collect(Collectors.toList());
        return new ApiResponse<List<AuctionCenterDto>>("getAll Auction Center successfully" ,200,auctionCenterAllDtoList);
    }

    @Override
    public ApiResponse<?> searchAuctionCenterPageable(int isActive, int offset, int page) {
        Pageable pageable= PageRequest.of(page,offset);
        Optional<List<TblAuctionCenter>> list =auctionCenterRepository.findAllByIsActive(isActive,pageable);
        if(!list.isEmpty() && list.isPresent()){
            List<AuctionCenterDto> dtos=list.get().stream().map(
                    tblAuctionCenter -> {
                        AuctionCenterDto dto= new AuctionCenterDto();
                        dto.setAuctionCenterName(tblAuctionCenter.getAuctionCenterName());
                        dto.setAuctionCenterCode(tblAuctionCenter.getAuctionCenterCode());
                        dto.setCertificateNo(tblAuctionCenter.getCertificateNo());
                        dto.setIsActive(tblAuctionCenter.getIsActive());
                        dto.setStateId(tblAuctionCenter.getStateId().getStateId());
                        return dto;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse("success",200,dtos);
        }

        return new ApiResponse("No Record Found",404,null);
    }

    @Override
    public ApiResponse<?> searchAuctionCenter(AuctionCenterDto auctionCenterDto) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appmaster.Get_tbl_auctionCenter_Search")
                .registerStoredProcedureParameter("@V_auctionCenterName",String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_auctionCenterCode",String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_certificateNo",String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_isactive", Integer.class,ParameterMode.IN)
                .setParameter("@V_auctionCenterName",auctionCenterDto.getAuctionCenterName())
                .setParameter("@V_auctionCenterCode",auctionCenterDto.getAuctionCenterCode())
                .setParameter("@V_certificateNo",auctionCenterDto.getCertificateNo())
                .setParameter("@V_isactive",auctionCenterDto.getIsActive());
        List<Object[]> executeAuctionCenter = storedProcedureQuery.getResultList();
        if(!executeAuctionCenter.isEmpty()) {
            List<AuctionCenterDto> auctionCenterDtos = executeAuctionCenter.stream().map(
                    objects -> {
                        AuctionCenterDto auctionCenterDto1 = new AuctionCenterDto();
                        auctionCenterDto1.setAuctionCenterId(Long.valueOf(objects[0].toString()));
                        auctionCenterDto1.setAuctionCenterName((String) objects[1]);
                        auctionCenterDto1.setAuctionCenterCode((String) objects[2]);
                        auctionCenterDto1.setCertificateNo((String) objects[3]);
                        auctionCenterDto1.setIsActive((Boolean) objects[4] == true ? 1 : 0);
                        auctionCenterDto1.setStateId(Long.valueOf(objects[5].toString()));
                        return auctionCenterDto1;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse<>("getBySearch Success", 200, auctionCenterDtos);
        }
        return  new ApiResponse<>(("No Record Found"),404,null);
    }

    @Override
    public ApiResponse<?> getAllUploadedDocument() {
        Optional<List<TblUploadDocumentConf>> tblUploadDocumentConf= uploadDocumentConfRepository.findAllUploadDocument("tbl_AuctionCenter");

        List<DownloadDto> downloadDtos = tblUploadDocumentConf.get().stream().map(
                tblUploadDocument ->{
                    DownloadDto downloadDto = new DownloadDto();
                    downloadDto.setUploadDocumentConfId(tblUploadDocument.getUploadDocumentConfId());
                    downloadDto.setUploadDocumentRemarks(tblUploadDocument.getRemarks());
                    downloadDto.setDocumentUploadTime(tblUploadDocument.getCreatedOn());
                    return downloadDto;
                }).collect(Collectors.toList());
        return  new ApiResponse<List<DownloadDto>>("success" ,200,downloadDtos);
    }

    @Override
    public ApiResponse<?> getUploadedDocumentById(long id) throws IOException {
        DownloadDto download = uploadDocumentConfService.downloadDocument(id);
        DownloadDto downloadDto = new DownloadDto();
        downloadDto.setDocumentName(download.getDocumentName());
        downloadDto.setDocumentContent(download.getDocumentContent());
        return  new ApiResponse<DownloadDto>("success" ,200,downloadDto);
    }

    public ApiResponse<AuctionCenterDto> getAuctionCenterById(long auctionCenterId) {
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE).setAmbiguityIgnored(true);

        TblAuctionCenter auctionCenter = auctionCenterRepository.findById(auctionCenterId).orElseThrow(()->new ResourceNotFoundException("TblAuctionCenter","auctionCenterId",auctionCenterId));
        AuctionCenterDto getauctionCenterByid = mapper.map(auctionCenter,AuctionCenterDto.class);
        //getauctionCenterByid.setSessionUserId(auctionCenter.getCreatedBy().getUserId());
        getauctionCenterByid.setStateId(auctionCenter.getStateId().getStateId());;
        return  new ApiResponse<AuctionCenterDto>("Auction Center get by Id successfully" ,200,getauctionCenterByid);
    }
}