package com.etl.eproc.admin.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CategoryDto {
    private long categoryId;
    @NotEmpty(message = "Please enter the category name.")
    @Size(min = 2 ,message = "The category name should be at least 2 characters long")
    @Size(max = 50,message = "The category name should not exceed 50 characters.")
    private  String categoryName;
    @NotEmpty(message = "Please enter the category code.")
    @Pattern(regexp = "^[A-Za-z0-9]*$",message = "The category code should only contain alphanumeric characters.")
    @Size(min = 2,message = "The category code should be at least 2 characters long.")
    @Size(max = 10,message = "The category code should not exceed 10 characters.")
    private String categoryCode;
    private Integer isActive;
    private String uploadDocumentRemarks;
    private TestDTO[] downloadDto;
}
