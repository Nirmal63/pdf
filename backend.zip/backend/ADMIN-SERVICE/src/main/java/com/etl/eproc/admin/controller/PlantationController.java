package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.PlantationDto;
import com.etl.eproc.admin.dto.PlantationSearchDto;
import com.etl.eproc.admin.serviceI.PlantationServiceI;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;


@RestController
@RequestMapping("/admin/plantation")
public class PlantationController {

    @Autowired
    private PlantationServiceI plantationServiceI;

    @PostMapping(value = "/create")
    public ApiResponse<?> savePlantationData(@Valid @RequestBody PlantationDto plantationDto) {
        try {
            return plantationServiceI.createPlantation(plantationDto);
        } catch (Exception e) {
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }

    @GetMapping("/get/{plantationId}")
    public ApiResponse<PlantationDto> getById(@PathVariable(name ="plantationId") long plantationId){
        try {
            ApiResponse<PlantationDto> plantationDto = plantationServiceI.getPlantationById(plantationId);
            return plantationDto;
        }catch(Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }

    @GetMapping("/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> getAllPlantation(@PathVariable("isActive") long isActive, @PathVariable("offset") int offset, @PathVariable("page") int page){
              try {
                  ApiResponse<List<PlantationDto>> plantationDtos = plantationServiceI.getAllPlantation(isActive, offset, page);
                  return plantationDtos;
              }catch(Exception e){
                  return new ApiResponse<>(e.getMessage(), 500,null);
              }
    }

    @GetMapping("/getAllPlantationDrop")
    public ApiResponse<?> getAllPlantationDrop(){
        try {
            ApiResponse<List<PlantationDto>> plantationDtos = plantationServiceI.getAllPlantationDrop();
            return plantationDtos;
        }catch(Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }


    @PostMapping(value="/update")
    public ApiResponse<?> updateData(@Valid @RequestBody PlantationDto plantationDto){
        try {
            ApiResponse<?> plantationDto1 = plantationServiceI.updateplantation(plantationDto);
            return plantationDto1;
        }catch(Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }


    @PostMapping("/search")
    public ApiResponse<List<PlantationDto>> searchBy(@RequestBody PlantationSearchDto plantationDto){
           try {

               ApiResponse<List<PlantationDto>>plantationDtos = plantationServiceI.searchPlantation(plantationDto);
               return plantationDtos;
           }catch (Exception e){
               return new ApiResponse<>(e.getMessage(), 500,null);
           }
    }


    @GetMapping("/getAllUploaddocument")
    public ApiResponse<?> getAllDocument(){
        return new ApiResponse<>("success",200,plantationServiceI.getAllUploadDocument());
    }

    @GetMapping("/getById/{uploaddocumentId}")
    public ApiResponse<?> getUploadDocument(@PathVariable("uploaddocumentId") long id) throws IOException {
        return new ApiResponse<>("success",200,plantationServiceI.getUploadDocumentById(id));

    }


   }
