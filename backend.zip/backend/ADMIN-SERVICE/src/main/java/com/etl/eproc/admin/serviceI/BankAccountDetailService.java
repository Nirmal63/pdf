package com.etl.eproc.admin.serviceI;

import com.etl.eproc.admin.dto.BankAccountDetailDto;
import com.etl.eproc.admin.dto.BankAccountSearchDto;
import com.etl.eproc.admin.dto.StateDto;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface BankAccountDetailService {

 public ApiResponse<BankAccountDetailDto> createBankAccount(BankAccountDetailDto bankAccountDetailDto);

// public ApiResponse<List<BankAccountDetailDto>> getAllBankAccount();

 public ApiResponse<BankAccountDetailDto> getBankAccountById(Long bankAccountDetailId);

 public ApiResponse<BankAccountDetailDto> updateBankAccount(BankAccountDetailDto bankAccountDetailDto);

  //public  ApiResponse<?> searchBankAccountDetailPageable(int isActive, int offset, int page);

 public ApiResponse<List<BankAccountSearchDto>> searchBankAccountDetails(BankAccountSearchDto BankAccountSearchDto);
}
