package com.etl.eproc.admin.repository;

import com.etl.eproc.admin.model.TblFactory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FactoryRepository extends JpaRepository<TblFactory,Long> {
}
