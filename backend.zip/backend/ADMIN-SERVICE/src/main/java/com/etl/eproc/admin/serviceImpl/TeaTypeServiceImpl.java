package com.etl.eproc.admin.serviceImpl;


import com.etl.eproc.admin.dto.CategoryDto;
import com.etl.eproc.admin.dto.TeaTypeDto;
import com.etl.eproc.admin.dto.UploadDocumentConfDto;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.TblCategory;
import com.etl.eproc.admin.model.TblTeaType;
import com.etl.eproc.admin.model.TblUploadDocumentConf;
import com.etl.eproc.admin.model.TblUserLogin;
import com.etl.eproc.admin.repository.CategoryRepository;
import com.etl.eproc.admin.repository.TeaTypeRepository;
import com.etl.eproc.admin.repository.UploadDocumentConfRepository;
import com.etl.eproc.admin.repository.UserLoginRepository;
import com.etl.eproc.admin.serviceI.TeaTypeService;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import com.etl.eproc.admin.util.SearchResponce;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.math.BigInteger;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TeaTypeServiceImpl implements TeaTypeService {
    @Autowired
    private EntityManager entityManager;

    @Autowired
    private UploadDocumentConfRepository uploadDocumentConfRepository;
    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;
    private TeaTypeRepository teaTypeRepository;
    private ModelMapper mapper;

    @Autowired
    private UserLoginRepository userLoginRepository;
    @Autowired
    private CategoryRepository categoryRepository;

    public TeaTypeServiceImpl(TeaTypeRepository teaTypeRepository, ModelMapper mapper) {
        this.teaTypeRepository = teaTypeRepository;
        this.mapper = mapper;
    }

    @Override
    public ApiResponse<?> createTeaType(TeaTypeDto teaTypeDto) {
        try {
            TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
            boolean teaTypeDuplicateName = teaTypeRepository.existsByTeaTypeName(teaTypeDto.getTeaTypeName());

            Integer categoryId = teaTypeRepository.findByCategoryCodeAndName(teaTypeDto.getCategoryName(), teaTypeDto.getCategoryCode());
            if (!teaTypeDuplicateName) {
                TblTeaType teaType =new TblTeaType();
                teaType.setTeaTypeName(teaTypeDto.getTeaTypeName());
                TblCategory category = categoryRepository.findById((long) categoryId).orElseThrow(
                        () -> new ResourceNotFoundException("category", "categoryId", categoryId)
                );

                teaType.setCategory(category);

                teaType.setIsActive(1);
                teaType.setCreatedBy(tblUserLogin);
                teaType.setCreatedOn(teaTypeRepository.getServerDateTime());

                TblTeaType teaType1 = teaTypeRepository.save(teaType);
                TeaTypeDto teaTypeDto2 = mapToDto(teaType1);
                if (teaTypeDto.getUploadDocumentContent() != null) {
                    int i = 0;
                    for (String DocumenName:teaTypeDto.getUploadDocumentName()) {
                        UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                        uploadDocumentConfDto.setRemarks(teaTypeDto.getUploadDocumentRemarks());
                        uploadDocumentConfDto.setTableID(teaType.getTeaTypeId());
                        uploadDocumentConfDto.setFlag(1);
                        uploadDocumentConfDto.setStatus(1);
                        uploadDocumentConfDto.setIsActive(1);
                        uploadDocumentConfDto.setDocumentSize(teaTypeDto.getUploadDocumentSize());
                        uploadDocumentConfDto.setTableName("tbl_TeaType");
                        uploadDocumentConfDto.setFolderName("Tea Type");
                        uploadDocumentConfDto.setUploadDocumentName(DocumenName);
                        uploadDocumentConfDto.setUploadDocumentContent(teaTypeDto.getUploadDocumentContent()[i]);
                        TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                        i++;
                    }
                }
                return new ApiResponse<>("Tea Type Created Successfully ", 200, teaTypeDto2);

            } else if (teaTypeDuplicateName) {
                return new ApiResponse<>("Tea type must be unique. The entered value already exists.", 400, null);
            } else {
                return new ApiResponse<>("Tea Type code already exists", 400, null);
            }
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 400, null);
        }
    }


    @Override
    public ApiResponse<?> getAllTeaType() {
        try {
            List<TblTeaType> page = teaTypeRepository.findAll();
            List<TeaTypeDto> collect = page.stream().map(t -> mapToDto(t)).collect(Collectors.toList());
            return  new ApiResponse<>("get All TeaType " ,200,collect) ;
        }catch (Exception e){
            return  new ApiResponse<>(e.getMessage(),500,null) ;
        }


    }

    @Override
    public ApiResponse<?> updateTeaType(TeaTypeDto teaTypeDto) {
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin","userId",1));
        boolean teaTypeDuplicateName = teaTypeRepository.existsByTeaTypeName(teaTypeDto.getTeaTypeName());
        if (!teaTypeDuplicateName) {
            TblTeaType teaType = teaTypeRepository.findById(teaTypeDto.getTeaTypeId()).orElseThrow(
                    () -> new ResourceNotFoundException("TeaType", "teaTypeId", teaTypeDto.getTeaTypeId())
            );
            Integer categoryId = teaTypeRepository.findByCategoryCodeAndName(teaTypeDto.getCategoryName(), teaTypeDto.getCategoryCode());
            teaType.setTeaTypeName(teaTypeDto.getTeaTypeName());
            TblCategory category = categoryRepository.findById((long) categoryId).orElseThrow(
                    () -> new ResourceNotFoundException("Category", "categoryId", categoryId)
            );

            teaType.setCategory(category);

            teaType.setIsActive(1);

            teaType.setUpdatedBy(tblUserLogin);
            teaType.setUpdatedOn(teaTypeRepository.getServerDateTime());
            TblTeaType tblTeaType = teaTypeRepository.save(teaType);
            TeaTypeDto teaTypeDto1 = mapToDto(tblTeaType);

            if (teaTypeDto.getUploadDocumentContent() != null) {
                int i = 0;
                for (String DocumenName : teaTypeDto.getUploadDocumentName()) {
                    UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                    uploadDocumentConfDto.setRemarks(teaTypeDto.getUploadDocumentRemarks());
                    uploadDocumentConfDto.setTableID(teaType.getTeaTypeId());
                    uploadDocumentConfDto.setFlag(1);
                    uploadDocumentConfDto.setStatus(1);
                    uploadDocumentConfDto.setIsActive(1);
                    uploadDocumentConfDto.setDocumentSize(teaTypeDto.getUploadDocumentSize());
                    uploadDocumentConfDto.setTableName("tbl_TeaType");
                    uploadDocumentConfDto.setFolderName("Tea Type");
                    uploadDocumentConfDto.setUploadDocumentName(DocumenName);
                    uploadDocumentConfDto.setUploadDocumentContent(teaTypeDto.getUploadDocumentContent()[i]);
                    TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                    i++;
                }
            }

            return new ApiResponse<>("TeaType updated Successfully ", 200, teaTypeDto1);
        }else if (teaTypeDuplicateName) {
            return new ApiResponse<>("Tea type must be unique. The entered value already exists.", 400, null);
        } else {
            return new ApiResponse<>("Tea Type code already exists", 400, null);
        }
    }


    @Override
    public  ApiResponse<?> findTeaTypeById(int teaTypeId) {
        TblTeaType teaType = teaTypeRepository.findById(teaTypeId).orElseThrow(
                () -> new ResourceNotFoundException("TeaType", "teaTypeId", teaTypeId)
        );
        TeaTypeDto teaTypeDto = mapToDto(teaType);
        return  new ApiResponse<>("get By  TeaTypeId" ,200,teaTypeDto) ;
    }

    @Override
    public ApiResponse<?> searchTeaTypePageable(int isActive, int offset, int page) {
       Pageable pageable=PageRequest.of(page,offset);
        Optional<List<TblTeaType>> list =teaTypeRepository.findAllByIsActive(isActive,pageable);
        if(!list.isEmpty() && list.isPresent()){
            List<TeaTypeDto> dtos=list.get().stream().map(
                    tblTeaType -> {
                        TeaTypeDto dto= new TeaTypeDto();
                        dto.setTeaTypeId(tblTeaType.getTeaTypeId());
                        dto.setTeaTypeName(tblTeaType.getTeaTypeName());
                        TblCategory category = tblTeaType.getCategory();
                        dto.setCategoryName(category.getCategoryName());
                        dto.setCategoryCode(category.getCategoryCode());
                        dto.setIsActive(tblTeaType.getIsActive());

                        return dto;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse("success",200,dtos);
        }

        return new ApiResponse("success",200,null);
    }

    @Override
    public ApiResponse<?> searchTeaType(TeaTypeDto teaTypeDto){
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appmaster.Get_tbl_TeaType_Search")

                .registerStoredProcedureParameter("@V_teaTypeName",String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_categoryName",String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_categoryCode",String.class, ParameterMode.IN)

                .setParameter("@V_teaTypeName",teaTypeDto.getTeaTypeName())
                .setParameter("@V_categoryName",teaTypeDto.getCategoryName())
                .setParameter("@V_categoryCode",teaTypeDto.getCategoryCode());

        List<Object[]> execute = storedProcedureQuery.getResultList();

        List<TeaTypeDto> teaTypeDto1 = execute.stream().map(
                objects ->{
                    TeaTypeDto teaTypeDto2 = new TeaTypeDto();
                    teaTypeDto2.setTeaTypeId(Integer.parseInt( objects[0].toString()));
                    teaTypeDto2.setTeaTypeName((String) objects[1]);
                    teaTypeDto2.setCategoryName((String) objects[2]);
                    teaTypeDto2.setCategoryCode((String) objects[3]);
                    teaTypeDto2.setIsActive((Boolean)objects[4]==true?1:0);
                    return teaTypeDto2;
                }
        ).collect(Collectors.toList());

        return new ApiResponse<List<TeaTypeDto>>("getAll Success",200 ,teaTypeDto1);
    }


    private TblTeaType mapToEntity(TeaTypeDto teaTypeDto) {
         return  mapper.map(teaTypeDto, TblTeaType.class);
    }

    private TeaTypeDto mapToDto(TblTeaType teaType1) {
        return mapper.map(teaType1, TeaTypeDto.class);
    }
}
