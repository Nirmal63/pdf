package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.AuctionCenterDto;
import com.etl.eproc.admin.serviceI.AuctionCenterService;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.IOException;

@RestController
@RequestMapping("/admin/auctionCenter")
public class AuctionCenterController {

    @Autowired
    private AuctionCenterService auctionCenterService;
    @PostMapping(value = "/create")
    public ApiResponse<?> createAuctionCenter(@Valid  @RequestBody AuctionCenterDto auctionCenterDto) {
        try {

            return auctionCenterService.createAuctionCenter(auctionCenterDto);
        } catch (Exception e) {
            return new ApiResponse<>(e.getMessage(), 500,null);
        }

    }
    @PostMapping(value = "/update")
    public ApiResponse<?> updateAuctionCenter(@Valid @RequestBody AuctionCenterDto auctionCenterUpdateDto){
        try{
            return auctionCenterService.updateAuctionCenter(auctionCenterUpdateDto);
        }
        catch(Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }
    @PostMapping(value = "/search")
    public ApiResponse<?> searchAuctionCenter(@RequestBody AuctionCenterDto auctionCenterDto){
        try {
            return auctionCenterService.searchAuctionCenter(auctionCenterDto);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }
    @GetMapping("/get/{auctionCenterId}")
    public ApiResponse<?> getAuctionCenterById(@PathVariable("auctionCenterId") long auctionCenterId){
        try{
            return auctionCenterService.getAuctionCenterById(auctionCenterId);
        }
        catch(Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }
/*    @GetMapping("/getAll")
    public ApiResponse<?> getAllAuctionCenter(){
        try{
            return auctionCenterService.getAllAuctionCenter();
        }
        catch(Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }


    @GetMapping(value = "/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> searchAuctionCenterPageable(@PathVariable("isActive") int isActive,@PathVariable("offset") int offset,@PathVariable("page") int page) {

        try {
            return auctionCenterService.searchAuctionCenterPageable(isActive,offset,page);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }*/
   @GetMapping("/getalluploadeddocument")
    public ApiResponse<?> getAllDocument(){
    return new ApiResponse<>("success",200,auctionCenterService.getAllUploadedDocument());
   }

    @GetMapping("/getdocument/{uploadeddocumentId}")
    public ApiResponse<?> getuploadDocument(@PathVariable("uploadeddocumentId") long id) throws IOException {
        return new ApiResponse<>("success",200,auctionCenterService.getUploadedDocumentById(id));

    }
}
