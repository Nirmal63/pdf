package com.etl.eproc.admin.serviceImpl;

import com.etl.eproc.admin.dto.DownloadDto;
import com.etl.eproc.admin.dto.PlantationDto;

import com.etl.eproc.admin.dto.PlantationSearchDto;
import com.etl.eproc.admin.dto.UploadDocumentConfDto;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.*;
import com.etl.eproc.admin.repository.PlantationRepository;
import com.etl.eproc.admin.repository.StateRepository;
import com.etl.eproc.admin.repository.UploadDocumentConfRepository;
import com.etl.eproc.admin.repository.UserLoginRepository;
import com.etl.eproc.admin.serviceI.PlantationServiceI;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import com.etl.eproc.admin.util.AppConstants;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PlantationServiceImpl implements PlantationServiceI {

   @Autowired
   private ModelMapper modelMapper;

    @Autowired
    private PlantationRepository plantationRepository;

    @Autowired
    private StateRepository stateRepository;
    @Autowired
    private EntityManager entityManager;
    @Autowired
    UserLoginRepository userLoginRepository;

    @Autowired
    UploadDocumentConfService uploadDocumentConfService;

    @Autowired
    UploadDocumentConfRepository uploadDocumentConfRepository;

    @Override
    public ApiResponse<?> createPlantation(PlantationDto plantationDto) {

            TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
            TblPlantation tblPlantation = modelMapper.map(plantationDto, TblPlantation.class);
            boolean districtName = plantationRepository.existsByPlantationDistrictName(plantationDto.getPlantationDistrictName());
            TblState tblState = stateRepository.findById(plantationDto.getStateId()).orElseThrow(() -> new ResourceNotFoundException("TblState", "stateId", plantationDto.getStateId()));
            if (!districtName) {
                tblPlantation.setCreatedOn(new Date());
                tblPlantation.setCreatedBy(tblUserLogin);
                tblPlantation.setTblState(tblState);
                TblPlantation tblPlantation1 = plantationRepository.save(tblPlantation);
                PlantationDto plantationDto1=modelMapper.map(tblPlantation1, PlantationDto.class);
                if(plantationDto.getUploadDocumentContent()!=null) {
                    int i = 0;
                    for (String DocumentName:plantationDto.getUploadDocumentName()) {
                        UploadDocumentConfDto documentConfDto = new UploadDocumentConfDto();
                        documentConfDto.setUploadDocumentName(DocumentName);
                        documentConfDto.setDocumentSize(plantationDto.getUploadDocumentSize());
                        documentConfDto.setTableName(AppConstants.TBL_PLANTATION);
                        documentConfDto.setTableID(tblPlantation1.getPlantationId());
                        documentConfDto.setDocumentSize(plantationDto.getUploadDocumentSize());
                        documentConfDto.setFlag(1);
                        documentConfDto.setStatus(1);
                        documentConfDto.setIsActive(1);
                        documentConfDto.setFolderName(AppConstants.PLANTATION);
                        documentConfDto.setRemarks(plantationDto.getUploadDocumentRemarks());
                        documentConfDto.setUploadDocumentContent(plantationDto.getUploadDocumentContent()[i]);
                        TblUploadDocumentConf document = uploadDocumentConfService.uploadDocument(documentConfDto);
                       i++;
                    }
                }
                return new ApiResponse<PlantationDto>("Plantation created successfully", 200, plantationDto1);

            }
            return new ApiResponse<PlantationDto>("Plantation District Name already exists", 400, null);

    }

    @Override
    public ApiResponse<PlantationDto> getPlantationById(long plantationId) {
        TblPlantation tblPlantation=plantationRepository.findById(plantationId).orElseThrow(()->new ResourceNotFoundException("TblPlantation","planationId",plantationId));
        PlantationDto planationDto=modelMapper.map(tblPlantation,PlantationDto.class);
        return new ApiResponse<>("plantation get successfully",200,planationDto);
    }

    @Override
    public ApiResponse<List<PlantationDto>> getAllPlantation(long iActive, int offset, int page) {
        Pageable pageable= PageRequest.of(page,offset);

        Optional<List<TblPlantation>> tblPlantations=plantationRepository.findAllByIsActive(iActive,pageable);
        if(!tblPlantations.isEmpty() && tblPlantations.isPresent()) {
            List<PlantationDto> plantations = tblPlantations.get().stream().map(
                    tblPlantation ->{
                        PlantationDto planationDto=new PlantationDto();
                        planationDto.setPlantationId(tblPlantation.getPlantationId());
                        planationDto.setPlantationDistrictName(tblPlantation.getPlantationDistrictName());
                        planationDto.setIsActive((int) tblPlantation.getIsActive());
                        planationDto.setStateId(tblPlantation.getTblState().getStateId());
                        return planationDto;
                    }).collect(Collectors.toList());
            return new ApiResponse("success",200,plantations);
       }
        return new ApiResponse("success",200,null);
        }


    @Override
    public ApiResponse<?> updateplantation(PlantationDto plantationDto) {

            TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
            TblPlantation tblPlantation = plantationRepository.findById(plantationDto.getPlantationId()).orElseThrow(() -> new ResourceNotFoundException("TblPlantation", "planationId", plantationDto.getPlantationId()));
            TblState tblState = stateRepository.findById(plantationDto.getStateId()).orElseThrow(() -> new ResourceNotFoundException("TblState", "stateId", plantationDto.getStateId()));
            tblPlantation.setPlantationDistrictName(plantationDto.getPlantationDistrictName());
            tblPlantation.setIsActive(plantationDto.getIsActive());
            tblPlantation.setUpdatedOn(new Date());
            tblPlantation.setTblState(tblState);
            tblPlantation.setUpdatedBy(tblUserLogin);
            TblPlantation tblPlantation1 = plantationRepository.save(tblPlantation);
            PlantationDto plantationDto1=modelMapper.map(tblPlantation1, PlantationDto.class);
        if(plantationDto.getUploadDocumentContent()!=null) {
            int i = 0;
            for (String DocumentName : plantationDto.getUploadDocumentName()) {
                UploadDocumentConfDto documentConfDto = new UploadDocumentConfDto();
                documentConfDto.setUploadDocumentName(DocumentName);
                documentConfDto.setDocumentSize(plantationDto.getUploadDocumentSize());
                documentConfDto.setTableName(AppConstants.TBL_PLANTATION);
                documentConfDto.setTableID(tblPlantation1.getPlantationId());
                documentConfDto.setDocumentSize(plantationDto.getUploadDocumentSize());
                documentConfDto.setFolderName(AppConstants.PLANTATION);
                documentConfDto.setRemarks(plantationDto.getUploadDocumentRemarks());
                documentConfDto.setUploadDocumentContent(plantationDto.getUploadDocumentContent()[i]);
                TblUploadDocumentConf document = uploadDocumentConfService.uploadDocument(documentConfDto);
                i++;
            }
        }
            return new ApiResponse<>("plantation updated successfully", 200, plantationDto1);
    }

    @Override
    public ApiResponse<List<PlantationDto>> getAllPlantationDrop() {
       List<TblPlantation> tblPlantations= plantationRepository.findAll();
        List<TblPlantation> tblPlantationList=tblPlantations.stream().filter(a-> a.getIsActive()==1).collect(Collectors.toList());
        List<PlantationDto> plantations = tblPlantationList.stream().map(
                tblPlantation ->{
                    PlantationDto planationDto=new PlantationDto();
                    planationDto.setPlantationId(tblPlantation.getPlantationId());
                    planationDto.setPlantationDistrictName(tblPlantation.getPlantationDistrictName());
                    planationDto.setIsActive((int) tblPlantation.getIsActive());
                    planationDto.setStateId(tblPlantation.getTblState().getStateId());
                    return planationDto;
                }).collect(Collectors.toList());
        return new ApiResponse<>("planation list get successfully",200,plantations);
    }


    @Override
    public ApiResponse<List<PlantationDto>> searchPlantation(PlantationSearchDto planationDto) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appmaster.Get_tbl_Plantation_Search")
                .registerStoredProcedureParameter("@V_isactive", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_plantationDistrictName", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_stateId", Long.class, ParameterMode.IN)
                .setParameter("@V_isactive", planationDto.getIsActive())
                .setParameter("@V_plantationDistrictName", planationDto.getPlantationDistrictName())
                .setParameter("@V_stateId", planationDto.getStateId());
        List<Object[]> execute = storedProcedureQuery.getResultList();
        if (!execute.isEmpty()) {
            List<PlantationDto> plantationDtos = execute.stream().map(
                    objects -> {
                        PlantationDto plantationDto = new PlantationDto();
                        plantationDto.setPlantationId(Long.valueOf(objects[0].toString()));
                        plantationDto.setPlantationDistrictName(objects[1].toString());
                        plantationDto.setStateId(Long.valueOf(objects[2].toString()));
                        plantationDto.setIsActive((Boolean) objects[3] == true ? 1 : 0);
                        return plantationDto;
                    }
            ).collect(Collectors.toList());

            return new ApiResponse<List<PlantationDto>>("getAll Success", 200, plantationDtos);
        } else {
            return new ApiResponse<List<PlantationDto>>("No record found", 404, null);
        }
    }
    @Override
    public ApiResponse<?> getAllUploadDocument() {
        Optional<List<TblUploadDocumentConf>> tblUploadDocumentConf= uploadDocumentConfRepository.findAllUploadDocument(AppConstants.TBL_PLANTATION);

        List<DownloadDto> downloadDtos = tblUploadDocumentConf.get().stream().map(
                tblUploadDocument ->{
                    DownloadDto downloadDto = new DownloadDto();
                    downloadDto.setUploadDocumentConfId(tblUploadDocument.getUploadDocumentConfId());
                    downloadDto.setUploadDocumentRemarks(tblUploadDocument.getRemarks());
                    downloadDto.setDocumentUploadTime(tblUploadDocument.getCreatedOn());
                    return downloadDto;
                }).collect(Collectors.toList());
        return  new ApiResponse<List<DownloadDto>>("success" ,200,downloadDtos);
    }


    @Override
    public ApiResponse<?> getUploadDocumentById(long id) throws IOException {
        DownloadDto download = uploadDocumentConfService.downloadDocument(id);
        DownloadDto downloadDto = new DownloadDto();
        downloadDto.setDocumentName(download.getDocumentName());
        downloadDto.setDocumentContent(download.getDocumentContent());
        return  new ApiResponse<DownloadDto>("success" ,200,downloadDto);
    }


}
