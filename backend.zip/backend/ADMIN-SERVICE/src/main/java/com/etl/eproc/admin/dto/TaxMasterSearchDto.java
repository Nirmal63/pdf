package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TaxMasterSearchDto {

    private Long taxMasterId;

    private Long chargeMasterId;

    private Long  chargeCodeId;

    private String hsnSac;

    private Long auctionCenterId;

    private Integer isActive;
}
