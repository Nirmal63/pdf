package com.etl.eproc.admin.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@AllArgsConstructor
@Table(name = "tbl_SubTeaType",schema = "appmaster")
@NoArgsConstructor
public class TblSubTeaType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int subTeaTypeId;
    private String subTeaTypeName;
    private String subTeaTypeCode;
    @ManyToOne
    @JoinColumn(name = "teaTypeId",nullable = false)
    private TblTeaType teaType;
    private int isActive;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private TblUserLogin createdBy;
    private Date createdOn;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updatedBy")
    private TblUserLogin updatedBy;
    private Date updatedOn;

}
