package com.etl.eproc.admin.serviceImpl;

import com.etl.eproc.admin.dto.ChargeCodeDto;
import com.etl.eproc.admin.dto.DownloadDto;
import com.etl.eproc.admin.dto.UploadDocumentConfDto;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.TblChargeCode;
import com.etl.eproc.admin.model.TblUploadDocumentConf;
import com.etl.eproc.admin.model.TblUserLogin;
import com.etl.eproc.admin.repository.ChargeCodeRepository;
import com.etl.eproc.admin.repository.UploadDocumentConfRepository;
import com.etl.eproc.admin.repository.UserLoginRepository;
import com.etl.eproc.admin.serviceI.ChargeCodeServiceI;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import com.etl.eproc.admin.util.SearchResponce;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ChargeCodeServiceImpl implements ChargeCodeServiceI {


    @Autowired
    private ModelMapper mapper;
    @Autowired
    private UserLoginRepository userLoginRepository;
    @Autowired
    private ChargeCodeRepository chargeCodeRepository;
    @Autowired
    private EntityManager entityManager;
    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;
    @Autowired
    private UploadDocumentConfRepository uploadDocumentConfRepository;
    @Override
    public ApiResponse<?> createchargeCode(@RequestBody ChargeCodeDto chargeCodeDto) {
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin","userId",1));
        boolean chargeCodeISexists = chargeCodeRepository.existsByChargeCode(chargeCodeDto.getChargeCode());
        boolean chargeCodeNameISexists = chargeCodeRepository.existsByChargeCodeName(chargeCodeDto.getChargeCodeName());
        if(!chargeCodeISexists) {
            if (!chargeCodeNameISexists){
                mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
            TblChargeCode tblChargeCode = mapper.map(chargeCodeDto, TblChargeCode.class);
            tblChargeCode.setCreatedOn(new Date());
            tblChargeCode.setCreatedBy(tblUserLogin);
            tblChargeCode.setIsActive(1);
            TblChargeCode tblChargeCodenew = chargeCodeRepository.save(tblChargeCode);
            ChargeCodeDto chargeCodeDtonew = mapper.map(tblChargeCode, ChargeCodeDto.class);
                if (!chargeCodeDto.getDownloadDto()[0].getDocumentContent().isEmpty()) {
                    int i = 0;
                    for(int j=0;j<=chargeCodeDto.getDownloadDto().length-1;j++) {
                        UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                        uploadDocumentConfDto.setRemarks(chargeCodeDto.getUploadDocumentRemarks());
                        uploadDocumentConfDto.setTableID(tblChargeCode.getChargeCodeId());
                        
                        uploadDocumentConfDto.setFlag(1);
                        uploadDocumentConfDto.setStatus(1);
                        uploadDocumentConfDto.setIsActive(1);
                        uploadDocumentConfDto.setDocumentSize(String.valueOf(chargeCodeDto.getDownloadDto()[i].getDocumentSize()));
                        uploadDocumentConfDto.setTableName("tbl_ChargeCode");
                        uploadDocumentConfDto.setFolderName("ChargeCode");
                        uploadDocumentConfDto.setUploadDocumentName(String.valueOf(chargeCodeDto.getDownloadDto()[i].getDocumentName()));
                        uploadDocumentConfDto.setUploadDocumentContent(String.valueOf(chargeCodeDto.getDownloadDto()[i].getDocumentContent()));
                        TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                        i++;
                    }
                }
            return new ApiResponse<>("Charge Code created successfully", 201, chargeCodeDtonew);
        }else {
                return new ApiResponse<>("Charge code name must be unique. The entered value already exists.", 500, null);
            }
        }else{
            return new ApiResponse<>("Charge code must be unique. The entered value already exists.", 500, null);
        }
    }

    @Override
    public ApiResponse<?> updatechargeCode(ChargeCodeDto chargeCodeDto) {

        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
        boolean ChargeCodeISexists = chargeCodeRepository.existsByChargeCode(chargeCodeDto.getChargeCode());
        boolean ChargeCodeNameIsExists = chargeCodeRepository.existsByChargeCodeName(chargeCodeDto.getChargeCodeName());
        if (!ChargeCodeNameIsExists) {
            if (!ChargeCodeISexists) {
                TblChargeCode tblChargeCode = chargeCodeRepository.findById(chargeCodeDto.getChargeCodeId()).orElseThrow(() -> new ResourceNotFoundException("tblChargeCode", "chargeCodeId", chargeCodeDto.getChargeCodeId()));
                tblChargeCode.setChargeCodeName(chargeCodeDto.getChargeCodeName());
                tblChargeCode.setChargeCode(chargeCodeDto.getChargeCode());
                tblChargeCode.setIsActive(chargeCodeDto.getIsActive());
                tblChargeCode.setUpdatedBy(tblUserLogin);
                tblChargeCode.setUpdatedOn(new Date());
                TblChargeCode tblChargeCodeNew = chargeCodeRepository.save(tblChargeCode);
                ChargeCodeDto chargeCodeDtoNew = mapper.map(tblChargeCodeNew, ChargeCodeDto.class);
                if (!chargeCodeDto.getDownloadDto()[0].getDocumentContent().isEmpty()) {
                    int i = 0;
                    for(int j=0;j<=chargeCodeDto.getDownloadDto().length-1;j++) {
                        UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                        uploadDocumentConfDto.setRemarks(chargeCodeDto.getUploadDocumentRemarks());
                        uploadDocumentConfDto.setTableID(tblChargeCode.getChargeCodeId());
                        
                        uploadDocumentConfDto.setFlag(1);
                        uploadDocumentConfDto.setStatus(1);
                        uploadDocumentConfDto.setIsActive(1);
                        uploadDocumentConfDto.setDocumentSize(String.valueOf(chargeCodeDto.getDownloadDto()[i].getDocumentSize()));
                        uploadDocumentConfDto.setTableName("tbl_ChargeCode");
                        uploadDocumentConfDto.setFolderName("ChargeCode");
                        uploadDocumentConfDto.setUploadDocumentName(String.valueOf(chargeCodeDto.getDownloadDto()[i].getDocumentName()));
                        uploadDocumentConfDto.setUploadDocumentContent(String.valueOf(chargeCodeDto.getDownloadDto()[i].getDocumentContent()));
                        TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                        i++;
                    }
                }
                return new ApiResponse<>("Charge Code Updated successfully", 201, chargeCodeDtoNew);
            } else {
                return new ApiResponse<>("Charge code must be unique. The entered value already exists.", 400, null);
            }
        }else {
            return new ApiResponse<>("Charge code name must be unique. The entered value already exists.", 400, null);
        }

    }



    @Override
    public SearchResponce getAllChargeCode( ChargeCodeDto searchDto) {
//        Pageable pageable = PageRequest.of(pageNo, pageSize);
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appmaster.Get_tbl_ChargeCode_Search")
                .registerStoredProcedureParameter("@V_isActive", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_chargeCodeName", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_chargeCode", String.class, ParameterMode.IN)
//                .registerStoredProcedureParameter("@V_StartPage", Integer.class, ParameterMode.IN)
//                .registerStoredProcedureParameter("@V_EndPage", Integer.class, ParameterMode.IN)
                .setParameter("@V_isActive", searchDto.getIsActive())
                .setParameter("@V_chargeCodeName", searchDto.getChargeCodeName())
                .setParameter("@V_chargeCode", searchDto.getChargeCode());
//                .setParameter("@V_StartPage", 0)
//                .setParameter("@V_EndPage", 10);
        List<Object[]> execute = storedProcedureQuery.getResultList();
        List<ChargeCodeDto> ChargeCodeDtos = execute.stream().map(
                objects ->{
                    ChargeCodeDto codeSearchDto = new ChargeCodeDto();
                    codeSearchDto.setChargeCodeId(Long.valueOf(objects[0].toString()));
                    codeSearchDto.setChargeCodeName((String) objects[1]);
                    codeSearchDto.setChargeCode((String) objects[2]);
                    codeSearchDto.setIsActive((Boolean)objects[3]==true?1:0);
                    return codeSearchDto;
                }
        ).collect(Collectors.toList());
//        Page<TblChargeCode> tblChargeCodes =chargeCodeRepository.findAll(pageable);
        SearchResponce searchResponce = new SearchResponce();
        searchResponce.setContent(ChargeCodeDtos);
//        searchResponce.setPageNo(tblChargeCodes.getNumber());
//        searchResponce.setPageSize(tblChargeCodes.getSize());
//        searchResponce.setTotalElements(tblChargeCodes.getTotalElements());
//        searchResponce.setTotalPages(tblChargeCodes.getTotalPages());
        return searchResponce;
    }

    @Override
    public ApiResponse<List<ChargeCodeDto>> getAllChargeCodes(int isActive) {
//            Pageable pageable= PageRequest.of(page,offset);

            Optional<List<TblChargeCode>> tblChargeCodes=chargeCodeRepository.findAllByIsActive(isActive);
            if(!tblChargeCodes.isEmpty() && tblChargeCodes.isPresent()) {
                List<ChargeCodeDto> chargeCodeDtos = tblChargeCodes.get().stream().map(
                        tblChargeCode ->{
                            ChargeCodeDto codeSearchDto = new ChargeCodeDto();
                            codeSearchDto.setChargeCodeId(tblChargeCode.getChargeCodeId());
                            codeSearchDto.setChargeCodeName(tblChargeCode.getChargeCodeName());
                            codeSearchDto.setIsActive(tblChargeCode.getIsActive());
                            codeSearchDto.setChargeCode(tblChargeCode.getChargeCode());
                            codeSearchDto.setChargeCode(tblChargeCode.getChargeCode());

                            return codeSearchDto;
                        }).collect(Collectors.toList());
                return new ApiResponse("success",200,chargeCodeDtos);
            }
            return new ApiResponse("failed",500,null);

    }

    @Override
    public ApiResponse<?> getChargeCodeyId(long chargeCodeId) {
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE).setAmbiguityIgnored(true);
        TblChargeCode chargeCode =  chargeCodeRepository.findById(chargeCodeId).orElseThrow(()->new ResourceNotFoundException("TblAuctionCenter","auctionCenterId",chargeCodeId));
        ChargeCodeDto chargeCodeDto = mapper.map(chargeCode,ChargeCodeDto.class);
        return  new ApiResponse<ChargeCodeDto>("Charge code get by Id successfully" ,200,chargeCodeDto);
    }

    @Override
    public ApiResponse<?> getUploadDocumentById(long id) throws IOException {
        DownloadDto download = uploadDocumentConfService.downloadDocument(id);
        DownloadDto downloadDto = new DownloadDto();
        downloadDto.setDocumentName(download.getDocumentName());
        downloadDto.setDocumentContent(download.getDocumentContent());
        return  new ApiResponse<DownloadDto>("success" ,200,downloadDto);
    }


    @Override
    public ApiResponse<?> getAllUploadDocument() {
            Optional<List<TblUploadDocumentConf>> tblUploadDocumentConf= uploadDocumentConfRepository.findAllUploadDocument("tbl_ChargeCode");

            List<DownloadDto> downloadDtos = tblUploadDocumentConf.get().stream().map(
                    tblUploadDocument ->{
                        DownloadDto downloadDto = new DownloadDto();
                        downloadDto.setUploadDocumentConfId(tblUploadDocument.getUploadDocumentConfId());
                        downloadDto.setUploadDocumentRemarks(tblUploadDocument.getRemarks());
                        downloadDto.setDocumentUploadTime(tblUploadDocument.getCreatedOn());
                        return downloadDto;
                    }).collect(Collectors.toList());
            return  new ApiResponse<List<DownloadDto>>("success" ,200,downloadDtos);
        }
    }


