package com.etl.eproc.admin.serviceI;


import com.etl.eproc.admin.dto.SubTeaTypeDto;
import com.etl.eproc.admin.util.ApiResponse;


public interface SubTeaTypeService {

    ApiResponse<?> createSubTeaType(SubTeaTypeDto subTeaTypeDto);

    ApiResponse<?> getAllSubTeaType();

    ApiResponse<?> updateSubTeaType(SubTeaTypeDto subTeaTypeDto);

    ApiResponse<?> findSubTeaTypeById(int subTeaTypeId);

    ApiResponse<?> searchSubTeaTypePageable(int isActive, int offset, int page);

    ApiResponse<?> searchSubTeaType(SubTeaTypeDto subTeaTypeDto);
}
