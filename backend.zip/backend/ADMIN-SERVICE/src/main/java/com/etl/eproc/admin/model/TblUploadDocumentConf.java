package com.etl.eproc.admin.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.util.Date;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Table(name = "tbl_UploadDocumentConf",schema = "appmaster")
public class TblUploadDocumentConf {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  long uploadDocumentConfId;
    private String tableName;
    private long tableID;
    private String path;
    private String remarks;
    private int isActive;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private TblUserLogin createdBy;
    private Date createdOn;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updatedBy")
    private TblUserLogin updatedBy;
    private Date updatedOn;
    private String DocumentSize;
    private int status;
    private int flag;

}
