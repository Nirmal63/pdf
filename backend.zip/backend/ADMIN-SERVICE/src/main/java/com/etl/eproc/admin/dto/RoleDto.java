package com.etl.eproc.admin.dto;

import lombok.*;

import javax.validation.constraints.NotEmpty;

@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoleDto {

    private long roleId;
    @NotEmpty(message = "please Enter role Name")
    private String roleName;
    private int isActive;
    private String uploadDocumentRemarks;
    private String[] uploadDocumentContent;
    private String[] uploadDocumentName;
    private String uploadDocumentSize;

}
