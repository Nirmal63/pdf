package com.etl.eproc.admin.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PlantationSearchDto {


    private String plantationDistrictName;

    private  Long stateId;


    private Integer  isActive;
}
