package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.ChargeMasterDto;
import com.etl.eproc.admin.dto.ChargeMasterSearchDto;
import com.etl.eproc.admin.serviceI.ChargeMasterService;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.IOException;

@RestController
@RequestMapping("/admin/chargeMaster")
public class ChargeMasterController {
    @Autowired
    private ChargeMasterService chargeMasterService;
    @PostMapping(value = "/create")
    public ApiResponse<?> createChargeMaster(@Valid @RequestBody ChargeMasterDto chargeMasterDto) {
        try {

            return chargeMasterService.createChargeMaster(chargeMasterDto);
        } catch (Exception e) {
            ApiResponse<ChargeMasterDto> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }
    }

    @PostMapping(value = "/update")
    public ApiResponse<?> updateChargeMaster(@Valid @RequestBody ChargeMasterDto chargeMasterDto){
        try{
            return chargeMasterService.updateChargeMaster(chargeMasterDto);
        }
        catch(Exception e){
            ApiResponse<ChargeMasterDto> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return  apiResponse ;
        }
    }
    @GetMapping("/get/{chargeMasterId}")
    public ApiResponse<?> getChargeMasterById(@PathVariable int chargeMasterId ){
        try{
            return  chargeMasterService.getChargeMasterById(chargeMasterId);
        }
        catch(Exception e){
            ApiResponse<ChargeMasterDto> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return  apiResponse ;
        }
    }
/*    @GetMapping("/getAllChargeMaster")
    public ApiResponse<?> getAllChargeMaster(){
        try{
            return  chargeMasterService.getAllChargeMaster();
        }
        catch(Exception e){
            ApiResponse<ChargeMasterDto> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return  apiResponse ;
        }
    }
    @GetMapping(value = "/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> getAllChargeMasterPageable(@PathVariable("isActive") int isActive,@PathVariable("offset") int offset,@PathVariable("page") int page) {

        try {
            return chargeMasterService.getAllChargeMasterPageable(isActive,offset,page);
        }catch (Exception e){
            e.printStackTrace();
            ApiResponse<Optional<TblChargeMaster>> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }
    }*/
    @PostMapping(value = "/search")
    public ApiResponse<?> searchChargeMaster(@RequestBody ChargeMasterSearchDto chargeMasterSearchDto){
        try {
            return chargeMasterService.searchChargeMaster(chargeMasterSearchDto);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }

    }
    @GetMapping("/getalluploadeddocument")
    public ApiResponse<?> getAllDocument(){
        return new ApiResponse<>("success",200,chargeMasterService.getAllUploadedDocument());
    }

    @GetMapping("/getdocument/{uploadeddocumentId}")
    public ApiResponse<?> getuploadDocument(@PathVariable("uploadeddocumentId") long id) throws IOException {
        return new ApiResponse<>("success",200,chargeMasterService.getUploadedDocumentById(id));

    }
}
