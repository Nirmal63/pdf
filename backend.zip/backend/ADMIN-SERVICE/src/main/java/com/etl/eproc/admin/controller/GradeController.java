package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.GradeDto;
import com.etl.eproc.admin.serviceI.GradeService;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.IOException;

@RestController
@RequestMapping("/admin/grade")
public class GradeController {

    @Autowired
    private GradeService gradeService;

    @PostMapping(value = "/create")
    public ApiResponse<?> createGrade(@Valid  @RequestBody GradeDto gradeDto) {
        try {

            return gradeService.createGrade(gradeDto);
        } catch (Exception e) {
            ApiResponse<GradeDto> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }

    }

    @PostMapping(value = "/update")
    public ApiResponse<?> updateGrade(@Valid @RequestBody GradeDto updateGradeDto) {
        try {
            return gradeService.updateGrade(updateGradeDto);
        } catch (Exception e) {
            ApiResponse<GradeDto> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }
    }
    @GetMapping("/get/{gradeId}")
    public ApiResponse<?> getGradeById(@PathVariable("gradeId") long gradeId) {
        try {
            return gradeService.getGradeById(gradeId);
        } catch (Exception e) {
            ApiResponse<GradeDto> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }
    }

    @PostMapping(value = "/search")
    public ApiResponse<?> searchGrade(@RequestBody  GradeDto gradeDto) {
        try {
            return gradeService.searchGrade(gradeDto);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }
    @GetMapping("/getalluploadeddocument")
    public ApiResponse<?> getAllDocument(){
        return new ApiResponse<>("success",200,gradeService.getAllUploadedDocument());
    }

    @GetMapping("/getdocument/{uploadeddocumentId}")
    public ApiResponse<?> getuploadDocument(@PathVariable("uploadeddocumentId") long id) throws IOException {
        return new ApiResponse<>("success",200,gradeService.getUploadedDocumentById(id));

    }

/*    @GetMapping(value = "/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> getAllGradePageable(@PathVariable("isActive") int isActive, @PathVariable("offset") int offset, @PathVariable("page") int page) {

        try {
            return gradeService.getAllGradePageable(isActive, offset, page);
        } catch (Exception e) {
            e.printStackTrace();
            ApiResponse<Optional<TblGrade>> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }
    }
    @GetMapping("/getAll")
    public ApiResponse<?> getAllGrade() {
        try {
            return gradeService.getAllGrade();
        } catch (Exception e) {
            ApiResponse<GradeDto> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }
    }*/

}
