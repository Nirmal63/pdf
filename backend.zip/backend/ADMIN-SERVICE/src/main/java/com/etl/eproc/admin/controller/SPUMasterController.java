package com.etl.eproc.admin.controller;


import com.etl.eproc.admin.dto.SPUMasterDto;
import com.etl.eproc.admin.dto.SPUMasterSearchDto;


import com.etl.eproc.admin.model.TblSPUMaster;
import com.etl.eproc.admin.serviceI.SPUMasterService;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Optional;

@RestController
@RequestMapping("/admin/SPUMaster")
public class SPUMasterController {

    @Autowired
    private SPUMasterService spuMasterService;

    @PostMapping("/create")
    public ApiResponse<?> createSPUMaster(@Valid  @RequestBody SPUMasterDto spuMasterDto){

        try {
            ApiResponse<?> spuMaster = spuMasterService.createSPUMaster(spuMasterDto);
            return spuMaster;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }

    @PostMapping("/update")
    public  ApiResponse<?> updateSPUMaster(@Valid @RequestBody SPUMasterDto spuMasterDto){
        try {
            ApiResponse<?> apiResponse = spuMasterService.updateSPUMaster(spuMasterDto);
            return apiResponse;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }

    @GetMapping("/getAll")
    public ApiResponse<?> getAllSPUMaster() {
        try {
            ApiResponse<?> allSPUMaster = spuMasterService.getAllSPUMaster();
            return allSPUMaster;

        } catch (Exception e) {
            return new ApiResponse<>(e.getMessage(), 500, null);
        }

    }

    @GetMapping("/get/{spuMasterId}")
    public ApiResponse<?> getSPUMasterById(@PathVariable("spuMasterId") int spuMasterId){
        try{
            ApiResponse<?> spuMasterById = spuMasterService.findSPUMasterById(spuMasterId);
            return  spuMasterById;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }

    }

    @GetMapping(value = "/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> getAllSPUMasterByActiveInActive(@PathVariable("isActive") int isActive,@PathVariable("offset") int offset,@PathVariable("page") int page){
        try {
            return spuMasterService.searchSPUMasterPageable(isActive,offset,page);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }

    }

    @GetMapping(value = "/search")
    public ApiResponse<?> searchSPUMaster(SPUMasterSearchDto spuMasterDto){
        try{
            return spuMasterService.searchSPUMaster(spuMasterDto);
        }catch (Exception e){
            e.printStackTrace();
            ApiResponse<Optional<TblSPUMaster>> apiResponse = new ApiResponse<>();
            apiResponse.setResponseData(null);
            apiResponse.setMessage(e.getMessage());
            apiResponse.setStatusCode(500);
            return apiResponse;
        }
    }


}
