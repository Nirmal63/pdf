package com.etl.eproc.admin.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table( schema = "appuser" , name ="tbl_UserLogin")
public class TblUserLogin {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long userId;

    private String userName;

    private String userCode;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userType")
    private TblRole userType;

    @ManyToMany
    @JoinTable(name = "tbl_UserMapping",schema = "appuser",
            joinColumns = @JoinColumn(name = "userId"),
            inverseJoinColumns = @JoinColumn(name = "auctionCenterId"))
    private List<TblAuctionCenter> auctionCenter;

    private String address;

    private String city;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "stateId")
    private TblState tblState;

    private String StateCode;

    private String contactPerson;

    private String phoneNo;

    private long mobileNo;

    private String fax;

    private String email;

    private long BankAccountStatus;

    private String entityCode;

    private String password;

    private String confirmPassword;

    private String fssaiNo;

    private String cinNo;

    private String teaBoardRegistrationNo;

    private String  taxIdentityNo;

    private String panNo;

    private  String gstNo;

    private String headOfficeAddress;

    private String localOfficeAddress;

    private Date YearOfRegistration;

    private String tngstNo;

    private String teaBoardExporterLicenseNo;

    private int isActive;

    private long createdBy;

    private Date createdOn;

    private Long updatedBy;

    private Date updatedOn;

    private Long isParentId;

}
