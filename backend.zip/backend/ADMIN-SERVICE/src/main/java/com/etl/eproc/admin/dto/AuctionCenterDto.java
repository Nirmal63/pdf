package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AuctionCenterDto {

    private long auctionCenterId;

    @NotNull(message = "Please enter Auction Center name")
    @Pattern(regexp = "^[A-Za-z \\\\s\\\\-]*$",message = "The Auction Center Name should contain alphabetic characters only")
    @Size(min = 2,message = "The auction center should be at least 2 characters long.")
    @Size(max= 100,message = "The auction center should not exceed 100 characters.")
    private String auctionCenterName;
    @NotNull(message ="Please enter Auction Center code")
    @Pattern(regexp = "^[A-Za-z0-9 \\\\s\\\\-]*$",message = "The auction center code should only contain alphanumeric characters.")
    @Size(min = 2,message = "The auction center code should be at least 2 characters long.")
    @Size(max= 10,message = "The auction center code should not exceed 10 characters.")
    private String auctionCenterCode;
    @NotNull(message = "Please enter Auction Center Registration Certificate Number")
    @Pattern(regexp = "^[A-Za-z0-9 \\\\s\\\\-]*$",message = "The auction center certificate number should only contain alphanumeric characters.")
    @Size(min = 1,message = "The auction center certificate number should be at least 1 character long.")
    @Size(max= 20,message = "The auction center certificate number should not exceed 20 characters.")
    private String certificateNo;
    //private long sessionUserId;
    private Integer isActive;
    private long stateId;
    private String uploadDocumentRemarks;
    private DownloadDto[] downloadDto;



}
