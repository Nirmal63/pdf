package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.*;
import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class WareHouseUserRegDto {

    private long wareHouseUserRegId;

    @NotEmpty(message = "Please enter wareHouse Name")
    @Size(max = 50,message = "The WareHouse Name should not exceed 50 characters")
    @Pattern(regexp ="^[a-zA-Z]+$",message = "The WareHouse Name should contain alphabetic characters only")
    private String wareHouseName;


    @NotEmpty(message = "Please enter wareHouse Code")
    @Size(max = 10,message = "The WareHouse Code should have a length of 10 characters")
    @Pattern(regexp = "^[a-zA-Z0-9]+$",message = "The WareHouse Code should only contain alphanumeric characters")
    private String wareHouseCode;


    @NotEmpty(message = "Please enter wareHouse License No")
    @Size(max = 15,message = "TheWareHouse License No should have a length of 15 characters")
    @Pattern(regexp = "^[a-zA-Z0-9]+$",message = "The WareHouse License No should only contain alphanumeric characters")
    private String wareHouseLicenseNo;

    @NotEmpty(message = "Please enter address")
    @Size(min = 1,max = 500,message = "The address should have a maximum length of 500 characters")
    @Pattern(regexp = "^[A-Za-z0-9 \\\\s\\\\-]*$",message = "The Address should only contain alphanumeric characters.")
    private String address;

    @NotEmpty(message = "Please enter City ")
    @Size(min = 1,max = 50,message = "The City should have a maximum length of 50 characters")
    @Pattern(regexp = "^[A-Za-z0-9 \\\\s\\\\-]*$",message = "The city should only contain alphabetic characters, numeric values,")
    private String city;

    @NotEmpty(message = "Please enter Person Name")
    @Pattern(regexp = "^[A-Za-z \\\\s\\\\-]*$",message = "The contact person should contain alphabetic characters only.")
    @Size(min = 1,max = 100,message = "The contact person should not exceed 100 characters.")
    private String contactPerson;

 //   @NotNull(message = "Please enter the email ID.")
    @Email(regexp = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}$",message = "Please enter a valid email ID with alphanumeric characters and special characters allowed.")
    @Size(min = 6,max = 50,message = "Allows Min 6 Max. 50 alphabets, numbers and Special Characters (@,.,-,_)")
    private String email;

    private String entityCode;

    @NotEmpty(message = "Please enter phone number")
    @Pattern(regexp = "^[0-9 \\\\s\\\\-]*$",message = "The phone number should follow a specific format (e.g., digits only, with or without country code).")
    @Size(min=1, max=15, message = "The phone number should not exceed 15 characters.")
    private String phoneNo;

//  @NotNull(message = "Please enter mobile number")
    @Pattern(regexp = "^(\\+\\d{1,3}[- ]?)?\\d{10}$", message = "Invalid phone number")
    @Size(max = 15,message = "The mobile number should have a maximum length of 15 characters ")
    private String mobileNo;


//  @NotEmpty(message = "Please enter fax")
    @Pattern(regexp = "^[0-9 \\\\s\\\\-]*$",message = "The fax number should follow a specific format (e.g., digits only, with or without country code).")
    @Size(min = 1,max = 15,message = "The fax number should not exceed 15 characters.")
    private String fax;

    @NotNull(message = "Please select Auction Center")
    private List<Long> auctionCenterId;

    @NotEmpty(message = "Please enter short Name")
    @Size(max = 15,message = "The ShortName should have a maximum length of 15 characters")
    @Pattern(regexp ="^[a-zA-Z]+$",message = "The ShortName should contain alphabetic characters only.")
    private String shortName;

    @NotNull(message = "Please select state")
    private long stateId;

    @NotEmpty(message = "Please enter the PANno.")
    @Pattern(regexp = "^[A-Za-z0-9 \\\\s\\\\-]*$",message = "The PANno should follow a specific format (e.g., alphanumeric characters(UpperCase) and a length of 10.")
    @Size(min = 1,max =10,message = "The Pan No should not exceed 10 characters.")
    private String panNo;

//  @NotEmpty(message = "Please enter gst No")
    @Pattern(regexp = "^[A-Za-z0-9 \\\\s\\\\-]*$",message = "Please enter a valid GSTNo with alphanumeric characters(UpperCase) and a maximum length of 15 characters.")
    @Size(min = 1,max = 15,message = "Please enter a valid GSTNo with alphanumeric characters and a maximum length of 15 characters.")
    private  String gstNo;

 // @NotNull(message = "Please enter Tax Identity No")
    @Pattern(regexp = "^[A-Za-z0-9 \\\\s\\\\-]*$",message = "Please enter a valid TaxId No with alphanumeric characters and a length of 15.")
    @Size(min = 1,max = 15, message = "The Tax Identity No should not exceed 15 characters.")
    private String taxIdentityNo;

    @NotNull(message = "Please enter the Teaboard Reg No.")
    @Pattern(regexp = "^[A-Za-z0-9 \\\\s\\\\-]*$",message = "Please enter a valid Teaboard Reg No with alphanumeric characters ")
    @Size(min = 1,max = 15,message = "The Teaboard Registration No should not exceed 15 characters.")
    private String teaBoardRegistrationNo;

    private int isActive;

    private String uploadDocumentRemarks;

    private String[] uploadDocumentContent;

    private String[] uploadDocumentName;

    private String uploadDocumentSize;

}


