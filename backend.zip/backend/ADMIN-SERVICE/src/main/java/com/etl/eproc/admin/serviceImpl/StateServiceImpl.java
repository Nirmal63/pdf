package com.etl.eproc.admin.serviceImpl;

import com.etl.eproc.admin.dto.DownloadDto;
import com.etl.eproc.admin.dto.StateDto;
import com.etl.eproc.admin.dto.StateSearchDto;
import com.etl.eproc.admin.dto.UploadDocumentConfDto;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.TblState;
import com.etl.eproc.admin.model.TblUploadDocumentConf;
import com.etl.eproc.admin.model.TblUserLogin;
import com.etl.eproc.admin.repository.StateRepository;
import com.etl.eproc.admin.repository.UploadDocumentConfRepository;
import com.etl.eproc.admin.repository.UserLoginRepository;
import com.etl.eproc.admin.serviceI.StateService;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.io.IOException;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class StateServiceImpl implements StateService {


    @Autowired
    private StateRepository stateRepository;

    @Autowired
    private UserLoginRepository userLoginRepository;

    @Autowired
    private ModelMapper mapper;

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;

    @Autowired
    private UploadDocumentConfRepository uploadDocumentConfRepository;

    @Override
    public ApiResponse<StateDto> saveState(StateDto statedto) {
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin ","userId ",1));
        boolean bolValueName=stateRepository.existsByStateName(statedto.getStateName());
        boolean bolValueCode=stateRepository.existsByStateCode(statedto.getStateCode());
        boolean bolValueInitial=stateRepository.existsByStateInitial(statedto.getStateInitial());
        if(!bolValueCode && !bolValueName && !bolValueInitial) {
            mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
            TblState tblState = mapper.map(statedto, TblState.class);
            tblState.setCreatedOn(new Date());
            tblState.setIsActive(1);
            tblState.setCreatedBy(tblUserLogin);
            TblState state = this.stateRepository.save(tblState);
            StateDto mapedState = mapper.map(state,StateDto.class);
            if (statedto.getUploadDocumentContent() != null) {
                int i = 0;
                for (String DocumenName:statedto.getUploadDocumentName()) {
                    UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                    uploadDocumentConfDto.setRemarks(statedto.getUploadDocumentRemarks());
                    uploadDocumentConfDto.setTableID(tblState.getStateId());
                    uploadDocumentConfDto.setFlag(1);
                    uploadDocumentConfDto.setStatus(1);
                    uploadDocumentConfDto.setIsActive(1);
                    uploadDocumentConfDto.setDocumentSize(statedto.getUploadDocumentSize());
                    uploadDocumentConfDto.setTableName("tbl_State");
                    uploadDocumentConfDto.setFolderName("State");
                    uploadDocumentConfDto.setUploadDocumentName(DocumenName);
                    uploadDocumentConfDto.setUploadDocumentContent(statedto.getUploadDocumentContent()[i]);
                    TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                    i++;
                }
            }
            return new ApiResponse<StateDto>("State created successfully", 201, mapedState);
        } else if (bolValueName) {
            return new ApiResponse<StateDto>("StateName is Already Exist", 400, null);
        } else if (bolValueCode) {
            return new ApiResponse<StateDto>("StateCode is Already Exist", 400, null);
        }
  else {
		return new ApiResponse<StateDto>("StateInitial is Already Exist", 400, null);
	}
    }

   /* @Override
    public ApiResponse<List<StateDto>> getAllSates() {
        List<StateDto> listSates=stateRepository.findAll().stream().map(
                tblState -> {
                       StateDto stateDto = mapper.map(tblState, StateDto.class);
                    //stateDto.setUserId(tblState.getCreatedBy().getUserId());
                    return stateDto;
                }).collect(Collectors.toList());
        listSates.sort(Comparator.comparing(StateDto::getStateName));
        return new ApiResponse<List<StateDto>>("getAll State successfully" ,200,listSates);
    }*/

    @Override
    public ApiResponse<StateDto> getStateById(Long stateId) {
        TblState tblState = stateRepository.findById(stateId).orElseThrow(() -> new ResourceNotFoundException("TblState ","stateID ", stateId));
        StateDto statemap = mapper.map(tblState, StateDto.class);
        //statemap.setUserId(tblState.getCreatedBy().getUserId());
        return new ApiResponse<StateDto>("State get by Id successfully" ,200,statemap);
    }

    @Override
    public ApiResponse<StateDto> updateState( StateDto statedto) {
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
            TblState tblState1 = this.stateRepository.findById(statedto.getStateId()).orElseThrow(() -> new ResourceNotFoundException("TblState ", "stateID ", 1));
            tblState1.setStateName(statedto.getStateName());
            tblState1.setStateInitial(statedto.getStateInitial());
            tblState1.setStateCode(statedto.getStateCode());
            tblState1.setIsActive(statedto.getIsActive());
            tblState1.setUpdatedBy(tblUserLogin);
            tblState1.setUpdatedOn(new Date());
            StateDto statedto1 = mapper.map(stateRepository.save(tblState1), StateDto.class);

        if (statedto.getUploadDocumentContent() != null) {
            int i = 0;
            for (String DocumenName:statedto.getUploadDocumentName()) {
                UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                uploadDocumentConfDto.setRemarks(statedto.getUploadDocumentRemarks());
                uploadDocumentConfDto.setTableID(tblState1.getStateId());
                uploadDocumentConfDto.setFlag(1);
                uploadDocumentConfDto.setStatus(1);
                uploadDocumentConfDto.setIsActive(1);
                uploadDocumentConfDto.setDocumentSize(statedto.getUploadDocumentSize());
                uploadDocumentConfDto.setTableName("tbl_State");
                uploadDocumentConfDto.setFolderName("State");
                uploadDocumentConfDto.setUploadDocumentName(DocumenName);
                uploadDocumentConfDto.setUploadDocumentContent(statedto.getUploadDocumentContent()[i]);
                TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                i++;
            }
        }

            return new ApiResponse<StateDto>("State Updated successfully", 201, statedto1);

    }

    @Override
    public ApiResponse<List<StateSearchDto>> searchState(StateSearchDto stateSearchDto) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appmaster.Get_tbl_State_Search")
                .registerStoredProcedureParameter("@V_StateName", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_StateCode", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_StateInitial", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_isactive", Integer.class, ParameterMode.IN)
                .setParameter("@V_StateName", stateSearchDto.getStateName())
                .setParameter("@V_StateCode", stateSearchDto.getStateCode())
                .setParameter("@V_StateInitial", stateSearchDto.getStateInitial())
                .setParameter("@V_isactive", stateSearchDto.getIsActive());
        List<Object[]> execute = storedProcedureQuery.getResultList();
        if (!execute.isEmpty()) {
            List<StateSearchDto> stateDtoList = execute.stream().map(
                    objects -> {
                        StateSearchDto stateSearchDto1 = new StateSearchDto();
                        stateSearchDto1.setStateId(Long.valueOf(objects[0].toString()));
                        stateSearchDto1.setStateName((String) objects[1]);
                        stateSearchDto1.setStateCode((String) objects[2]);
                        stateSearchDto1.setStateInitial((String) objects[3]);
                        stateSearchDto1.setIsActive((Boolean) objects[4] == true ? 1 : 0);
                        return stateSearchDto1;
                    }
            ).collect(Collectors.toList());
            stateDtoList.sort(Comparator.comparing(StateSearchDto::getStateName));
            return new ApiResponse<List<StateSearchDto>>("getAll Success", 200, stateDtoList);
        }
        return new ApiResponse<>("No Record Found",404,null);
    }

   /* @Override
    public ApiResponse<?> getAllUploadedDocument() {
        Optional<List<TblUploadDocumentConf>> tblUploadDocumentConf= uploadDocumentConfRepository.findAllUploadDocument("tbl_State");

        List<DownloadDto> downloadDtos = tblUploadDocumentConf.get().stream().map(
                tblUploadDocument ->{
                    DownloadDto downloadDto = new DownloadDto();
                    downloadDto.setUploadDocumentConfId(tblUploadDocument.getUploadDocumentConfId());
                    downloadDto.setDocumentRemarks(tblUploadDocument.getRemarks());
                    downloadDto.setDocumentUploadTime(tblUploadDocument.getCreatedOn());
                    return downloadDto;
                }).collect(Collectors.toList());
        return  new ApiResponse<List<DownloadDto>>("success" ,200,downloadDtos);

    }

    @Override
    public ApiResponse<?> getUploadedDocumentById(long id) throws IOException {
        DownloadDto download = uploadDocumentConfService.downloadDocument(id);
        DownloadDto downloadDto = new DownloadDto();
        downloadDto.setDocumentName(download.getDocumentName());
        downloadDto.setDocumentContent(download.getDocumentContent());
        return  new ApiResponse<DownloadDto>("success" ,200,downloadDto);
    }
*/
     /*  @Override
      public ApiResponse<?> searchStatePageable(int isActive, int offset, int page) {
        Pageable pageable = PageRequest.of(page, offset);
        Optional<List<TblState>> list = stateRepository.findAllByIsActive(isActive, pageable);
        if (!list.isEmpty() && list.isPresent()) {
            List<StateDto> dtos = list.get().stream().map(
                    tblState -> {
                        StateDto dto = new StateDto();
                   //     dto.setStateID(tblState.getStateId());
                    //    dto.setUserId(tblState.getCreatedBy().getUserId());
                        dto.setStateName(tblState.getStateName());
                        dto.setStateCode(tblState.getStateCode());
                        dto.setStateInitial(tblState.getStateInitial());
                        dto.setIsActive(tblState.getIsActive());
                        return dto;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse("success", 200, dtos);
        }
        return new ApiResponse("No Record Found", 404, null);
    }*/


}
