package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ConfigureParameterDto {


    private int configParaId;
    private int auctionCenterId;
    private int catalogClosingDay;
    private int catalogPublishingDay;
    private int buyersPromptDays;
    private int sellersPromptDay;

    private int intervalMin;
    private int isActive;
    private String uploadDocumentRemarks;
    private String[] uploadDocumentContent;
    private String[] uploadDocumentName;
    private String uploadDocumentSize;

}
