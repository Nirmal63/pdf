package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.CategoryDto;
import com.etl.eproc.admin.dto.DownloadDto;
import com.etl.eproc.admin.serviceI.CategoryService;
import com.etl.eproc.admin.util.ApiResponse;
import com.etl.eproc.admin.util.SearchResponce;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/admin/Category")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;


    @PostMapping(value = "/create")
    ApiResponse<?> createCategory(@Valid @RequestBody CategoryDto categoryDto){

        try {
            return categoryService.createCategory(categoryDto);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }

    @PostMapping(value = "/update")
    ApiResponse<?> updateCategory(@Valid @RequestBody CategoryDto categoryDto){
        try {
            return categoryService.updateCategory(categoryDto);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }

@GetMapping("/getcategory/{isactive}")
public ApiResponse<?> getAllcategorys(@PathVariable("isactive") int isActive){
//        , @PathVariable("offset") int offset, @PathVariable("page") int page

    try {
        ApiResponse<List<CategoryDto>> categoryDto = categoryService.getAllCategorys(isActive);
        return categoryDto;
    }catch(Exception e){
        return new ApiResponse<>(e.getMessage(),500,null);
    }
}

    @PostMapping("/search")
     public ApiResponse<SearchResponce> getAllcategory(
//            @RequestParam(value = "pageNo", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER, required = false) int pageNo,
//            @RequestParam(value = "pageSize", defaultValue = AppConstants.DEFAULT_PAGE_SIZE, required = false) int pageSize
           @RequestBody CategoryDto categoryDto
    ){
        try{
            return new ApiResponse<>("success",200,categoryService.getAllCategory(categoryDto));
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }
    @GetMapping("/getcategory/{categoryId}")
    public ApiResponse<?> getCategoryById(@PathVariable("categoryId") long categoryId){
        try{

            return new ApiResponse<>("success",200,categoryService.getCategoryId(categoryId));
        }
        catch(Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }

    @GetMapping("/getdocument/alluploaddocument")
    public ApiResponse<?> getAllDocument(){
        return new ApiResponse<>("success",200,categoryService.getAllUploadDocument());
    }

    @GetMapping("/getdocument/{uploaddocumentId}")
    public ApiResponse<?> getuploadDocument(@PathVariable("uploaddocumentId") long id) throws IOException {
        return new ApiResponse<>("success",200,categoryService.getUploadDocumentById(id));

    }

}
