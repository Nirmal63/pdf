package com.etl.eproc.admin.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="tbl_Role", schema = "appuser")
public class TblRole {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="roleId",nullable = false)
    private Long roleId;

    @Column(name="roleName", nullable = false)
    private String roleName;

    @Column(name="isActive",nullable = false)
    private int isActive;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy",nullable = false)
    private TblUserLogin createdBy;

    @Column(name="createdOn",nullable = false)
    private Date createdOn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updatedBy")
    private TblUserLogin updatedBy;

    @Column(name = "updatedOn")
    private Date updatedOn;
}
