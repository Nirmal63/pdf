package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.validation.constraints.NotEmpty;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MarkDto {

    private long markId;
    @NotEmpty(message = "Please Enter Mark Name ")
    private String markName;
    @NotEmpty(message = "Please Enter Mark Name ")
    private String markCode;
    private long factoryId;
    private long auctionCenterId;
    private String ownerName;
    private String manufacturerName;
    private int bankAccStatus;
    private int isActive;
    private String uploadDocumentRemarks;
    private String[] uploadDocumentContent;
    private String[] uploadDocumentName;
    private String uploadDocumentSize;
}
