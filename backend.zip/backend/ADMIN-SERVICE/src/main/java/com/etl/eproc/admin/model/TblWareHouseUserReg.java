package com.etl.eproc.admin.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="tbl_WareHouseUserReg",schema = "appuser")
public class TblWareHouseUserReg {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long wareHouseUserRegId;

    @Column(name = "address")
    private String address;

    @Column(name = "city")
    private String city;

    @Column(name = "contactPerson")
    private String contactPerson;

    @Column(name = "email")
    private String email;

    @Column(name = "entityCode")
    private String entityCode;

    @ManyToMany
    @JoinTable(name = "tbl_WarehouseMapping",schema = "appuser",
            joinColumns = @JoinColumn(name = "wareHouseUserRegId"),
            inverseJoinColumns = @JoinColumn(name = "auctionCenterId"))
    private List<TblAuctionCenter> auctionCenter;

    @Column(name = "phoneNo")
    private String phoneNo;

    @Column(name = "mobileNo")
    private long mobileNo;

    @Column(name = "fax")
    private String fax;

    @Column(name = "wareHouseName")
    private String wareHouseName;

    @Column(name = "wareHouseCode")
    private String wareHouseCode;

    @Column(name = "wareHouseLicenseNo")
    private String wareHouseLicenseNo;

    @Column(name = "panNo")
    private String panNo;

    @Column(name = "gstNo")
    private  String gstNo;

    @Column(name = "shortName")
    private String shortName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "stateId")
    private TblState state;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private TblUserLogin tblUserLogin;

    @JoinColumn(name = "taxIdentityNo")
    private String taxIdentityNo;

    @Column(name = "teaBoardRegistrationNo")
    private String teaBoardRegistrationNo;

    @Column(name = "isActive")
    private int isActive;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private TblUserLogin createdBy;

    @Column(name="createdOn",nullable = false)
    private Date createdOn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updatedBy")
    private TblUserLogin updatedBy;

    @Column(name="updatedOn")
    private Date updatedOn;


}

