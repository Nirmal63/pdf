package com.etl.eproc.admin.repository;

import com.etl.eproc.admin.model.TblRole;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<TblRole,Long> {

    public boolean existsByRoleName(String roleName);

}
