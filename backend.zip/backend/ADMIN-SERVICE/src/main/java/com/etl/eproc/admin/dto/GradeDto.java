package com.etl.eproc.admin.dto;

import lombok.*;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class GradeDto {
    private long gradeId;
    @NotNull(message = "Please enter the grade name.")
    @Pattern(regexp = "^[A-Za-z \\\\s\\\\-]*$",message = "The grade Name should contain alphabetic characters only")
    @Size(min = 2,message = "The grade name should be at least 2 characters long.")
    @Size(max= 50,message = "The grade name should not exceed 50 characters.")
    private String gradeName;
    @NotNull(message ="Please enter the grade code.")
    @Pattern(regexp = "^[A-Za-z \\\\s\\\\-]*$",message = "The grade Code should contain alphabetic characters only")
    @Size(min = 2,message = "The grade code should be at least 2 characters long.")
    @Size(max = 10,message = "The grade code should not exceed 10 characters.")
    private String gradeCode;
    private Integer isActive;
    //private long sessionUserId;
    private String uploadDocumentRemarks;
    private DownloadDto[] downloadDto;
}
