package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SubTeaTypeDto {


    private int subTeaTypeId;
    @NotEmpty(message = "Please enter the sub tea type name.")
    @Size(min = 2,message = "The sub tea type name should be at least 2 characters long.")
    @Size(max = 50,message = "The sub tea type name should not exceed 50 characters.")
    private String SubTeaTypeName;
    @NotEmpty(message = "Please enter the sub tea type code.")
    @Pattern(regexp = "^[A-Za-z0-9]*$",message = "The sub tea type code should only contain alphanumeric characters.")
    @Size(min = 2,message = "The sub tea type code should be at least 2 characters long.")
    @Size(max = 10,message = "The sub tea type code should not exceed 10 characters.")
    private String SubTeaTypeCode;
  //  @NotEmpty(message = "Please select Tea Type")
    private String TeaTypeName;
    private int teaTypeId;
    private int isActive;
    private String uploadDocumentRemarks;
    private String[] uploadDocumentContent;
    private String[] uploadDocumentName;
    private String uploadDocumentSize;
}
