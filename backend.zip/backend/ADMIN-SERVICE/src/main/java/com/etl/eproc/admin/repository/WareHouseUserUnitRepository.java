package com.etl.eproc.admin.repository;

import com.etl.eproc.admin.model.TblWareHouseUserUnit;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface WareHouseUserUnitRepository extends JpaRepository<TblWareHouseUserUnit,Long> {

    Optional<List<TblWareHouseUserUnit>> findAllByIsActive(int isActive, Pageable pageable);

    boolean  existsByWareHouseUnitCode(String WareHouseUnitCode);

    @Query(value = "select * from appuser.tbl_WareHouseUserUnit where wareHouseUserRegId=:wareHouseUserRegId",nativeQuery = true)
   Optional<List<TblWareHouseUserUnit>> findBywareHouseUserRegId(long wareHouseUserRegId);

}
