package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class WareHouseUserUnitViewDto {
    private long wareHouseUnitId;

    private String wareHouseUnitName;

    private String wareHouseUnitCode;

    private long wareHouseUserRegId;

    private int isActive;

    private long sessionUserId;

    private String remarks;

    private String address;

    private String city;

    private String contactPerson;

    private String email;

    private String entityCode;

    private String fax;

    private long mobileNo;

    private String phoneNo;

    private String shortName;

    private String wareHouseLicenseNo;

    private String teaBoardRegistrationNo;



}
