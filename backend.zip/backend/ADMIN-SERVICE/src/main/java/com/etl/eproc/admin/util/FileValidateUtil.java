package com.etl.eproc.admin.util;

import lombok.Data;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.multipart.MultipartFile;
@Data
@Configuration
public class FileValidateUtil {

    public ApiResponse<Boolean> validateFile(MultipartFile file) {
        if (file.getSize() > 10485760) {
            return new ApiResponse<>("File Size is Exceed than 10 MB", 500, true);
        } else if (!file.getOriginalFilename().contains(".pdf")) {
            return new ApiResponse<>("Incorrect file type(only PDF file is Allowed).", 500, true);
        }
        return new ApiResponse<>("", 200, false);
    }
}
