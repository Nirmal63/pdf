package com.etl.eproc.admin.serviceI;

import com.etl.eproc.admin.dto.FactoryTypeDto;
import com.etl.eproc.admin.util.ApiResponse;

import java.io.IOException;
import java.util.List;

public interface FactoryTypeService {
    ApiResponse<?> createFactoryType(FactoryTypeDto factoryTypeDto);

    ApiResponse<?>  updateFactoryType(FactoryTypeDto factoryTypeUpdateDto);


    ApiResponse<FactoryTypeDto>  getFactoryTypeById(long factoryTypeId);

    ApiResponse<List<FactoryTypeDto>> getAllFactoryType();

    ApiResponse<?> getAllFactoryTypePageable(int cStatus, int offset, int page);

    ApiResponse<?> searchFactoryType(FactoryTypeDto factoryTypeDto);

    ApiResponse<?> getAllUploadedDocument();
    ApiResponse<?> getUploadedDocumentById(long id) throws IOException;


}
