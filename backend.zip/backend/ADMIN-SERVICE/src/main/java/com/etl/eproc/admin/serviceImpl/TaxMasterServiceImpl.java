package com.etl.eproc.admin.serviceImpl;


import com.etl.eproc.admin.dto.*;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.*;
import com.etl.eproc.admin.repository.*;
import com.etl.eproc.admin.serviceI.TaxMasterService;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import com.etl.eproc.admin.util.AppConstants;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TaxMasterServiceImpl implements TaxMasterService {

    @Autowired
    private TaxMasterRepository taxMasterRepository;

    @Autowired
    private UserLoginRepository userLoginRepository;

    @Autowired
    private ChargeCodeRepository chargeCodeRepository;

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private AuctionCenterRepository auctionCenterRepository;


    @Autowired
    private ChargeMasterRepository chargeMasterRepository;

    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;

    @Autowired
    UploadDocumentConfRepository uploadDocumentConfRepository;



    @Override
    public ApiResponse<?> createtax(TaxMasterDto taxMasterDto) {

        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));            TblChargeCode tblChargeCode = chargeCodeRepository.findById(taxMasterDto.getChargeCodeId()).orElseThrow(() -> new ResourceNotFoundException("TblChargeCode", "chargeCodeId", taxMasterDto.getChargeCodeId()));
            TblChargeMaster tblChargeMaster = chargeMasterRepository.findById(taxMasterDto.getChargeMasterId()).orElseThrow(() -> new ResourceNotFoundException("tblChargeMaster", "chargeMasterId", taxMasterDto.getChargeMasterId()));
            TblAuctionCenter auctionCenter = auctionCenterRepository.findById(taxMasterDto.getAuctionCenterId()).orElseThrow(() -> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId", taxMasterDto.getAuctionCenterId()));
            modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
            TblTaxMaster taxMaster = modelMapper.map(taxMasterDto, TblTaxMaster.class);
            taxMaster.setTblChargeMaster(tblChargeMaster);
            taxMaster.setTblChargeCode(tblChargeCode);
            taxMaster.setHsnSac(taxMasterDto.getHsnOrsac());
            taxMaster.setDescription(taxMasterDto.getDescription());
            taxMaster.setValue(taxMasterDto.getValue());
            taxMaster.setEffectiveFromDate(taxMasterDto.getEffectiveFromDate());
            taxMaster.setEffectiveEndDate(taxMasterDto.getEffectiveEndDate());
            taxMaster.setAuctionCenter(auctionCenter);
            taxMaster.setIsActive(taxMasterDto.getIsActive());
            taxMaster.setCreatedBy(tblUserLogin);
            taxMaster.setCreatedOn(new Date());
            TblTaxMaster taxMaster1 = taxMasterRepository.save(taxMaster);
            TaxMasterDto taxMasterDto1=modelMapper.map(taxMaster1,TaxMasterDto.class);
        if(taxMasterDto.getUploadDocumentContent()!=null) {
            int i = 0;
            for (String DocumentName : taxMasterDto.getUploadDocumentName()) {
                UploadDocumentConfDto documentConfDto = new UploadDocumentConfDto();
                documentConfDto.setUploadDocumentName(DocumentName);
                documentConfDto.setDocumentSize(taxMasterDto.getUploadDocumentSize());
                documentConfDto.setTableName(AppConstants.TBL_TAXMASTER);
                documentConfDto.setTableID(taxMaster1.getTaxMasterId());
                documentConfDto.setDocumentSize(taxMasterDto.getUploadDocumentSize());
                documentConfDto.setFlag(1);
                documentConfDto.setStatus(1);
                documentConfDto.setIsActive(1);
                documentConfDto.setFolderName(AppConstants.TAXMASTER);
                documentConfDto.setRemarks(taxMasterDto.getUploadDocumentRemarks());
                documentConfDto.setUploadDocumentContent(taxMasterDto.getUploadDocumentContent()[i]);
                TblUploadDocumentConf document = uploadDocumentConfService.uploadDocument(documentConfDto);
                i++;
            }
        }
            return new ApiResponse<TaxMasterDto>("Tax master created successfully", 200, taxMasterDto1);

    }

    @Override
    public ApiResponse<TaxMasterDto> getTaxMasterById(long id) {
       TblTaxMaster taxMaster=taxMasterRepository.findById(id).get();
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
        TaxMasterDto taxMasterDto=modelMapper.map(taxMaster, TaxMasterDto.class);
        taxMasterDto.setTaxMasterId(taxMaster.getTaxMasterId());
        taxMasterDto.setHsnOrsac(taxMaster.getHsnSac());
        taxMasterDto.setChargeMasterId(taxMaster.getTblChargeMaster().getChargeMasterId());
        taxMasterDto.setChargeCodeId(taxMaster.getTblChargeCode().getChargeCodeId());
        taxMasterDto.setAuctionCenterId(taxMaster.getAuctionCenter().getAuctionCenterId());;
        return new ApiResponse<TaxMasterDto>("success", 200, taxMasterDto);

    }

    @Override
    public ApiResponse<?> getAllTaxMaster(int iActive, int offset, int page) {
        Pageable pageable= PageRequest.of(page,offset);
        Optional<List<TblTaxMaster>> taxMasters=taxMasterRepository.findAllByIsActive(iActive,pageable);
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
        List<TaxMasterDto> taxMasterDtos=taxMasters.get().stream().map(
                taxMaster -> {
                    TaxMasterDto taxMasterDto=modelMapper.map(taxMaster, TaxMasterDto.class);
                    taxMasterDto.setTaxMasterId(taxMaster.getTaxMasterId());
                    taxMasterDto.setHsnOrsac(taxMaster.getHsnSac());
                    taxMasterDto.setChargeMasterId(taxMaster.getTblChargeMaster().getChargeMasterId());
                    taxMasterDto.setChargeCodeId(taxMaster.getTblChargeCode().getChargeCodeId());
                    taxMasterDto.setAuctionCenterId(taxMaster.getAuctionCenter().getAuctionCenterId());
                    return taxMasterDto;
        }).collect(Collectors.toList());
        return new ApiResponse<List<TaxMasterDto>>("getAll Tax Master successfully" ,200,taxMasterDtos);

    }

    @Override
    public ApiResponse<?> updateTaxMasterBy(TaxMasterDto taxMasterDto) {

            TblTaxMaster taxMaster = taxMasterRepository.findById(taxMasterDto.getTaxMasterId()).orElseThrow(() -> new ResourceNotFoundException("TblTaxMaster", "taxmasterId", taxMasterDto.getTaxMasterId()));
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));            TblChargeCode tblChargeCode = chargeCodeRepository.findById(taxMasterDto.getChargeCodeId()).orElseThrow(() -> new ResourceNotFoundException("TblChargeCode", "chargeCodeId", taxMasterDto.getChargeCodeId()));
            TblAuctionCenter auctionCenter = auctionCenterRepository.findById(taxMasterDto.getAuctionCenterId()).orElseThrow(() -> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId", taxMasterDto.getAuctionCenterId()));
            TblChargeMaster tblChargeMaster = chargeMasterRepository.findById(taxMasterDto.getChargeMasterId()).orElseThrow(() -> new ResourceNotFoundException("TblTaxMaster", "taxmasterId", taxMasterDto.getChargeMasterId()));
            taxMaster.setTblChargeMaster(tblChargeMaster);
            taxMaster.setTblChargeCode(tblChargeCode);
            taxMaster.setHsnSac(taxMasterDto.getHsnOrsac());
            taxMaster.setDescription(taxMasterDto.getDescription());
            taxMaster.setValue(taxMasterDto.getValue());
            taxMaster.setEffectiveFromDate(taxMasterDto.getEffectiveFromDate());
            taxMaster.setEffectiveEndDate(taxMasterDto.getEffectiveEndDate());
            taxMaster.setAuctionCenter(auctionCenter);
            taxMaster.setIsActive(taxMasterDto.getIsActive());
            taxMaster.setUpdatedBy(tblUserLogin);
            taxMaster.setUpdatedOn(new Date());
            TblTaxMaster taxMaster1 = taxMasterRepository.save(taxMaster);
        if(taxMasterDto.getUploadDocumentContent()!=null) {

            int i = 0;
            for (String DocumentName : taxMasterDto.getUploadDocumentName()) {
                UploadDocumentConfDto documentConfDto = new UploadDocumentConfDto();
                documentConfDto.setUploadDocumentName(DocumentName);
                documentConfDto.setDocumentSize(taxMasterDto.getUploadDocumentSize());
                documentConfDto.setTableName(AppConstants.TBL_TAXMASTER);
                documentConfDto.setTableID(taxMaster1.getTaxMasterId());
                documentConfDto.setDocumentSize(taxMasterDto.getUploadDocumentSize());
                documentConfDto.setFlag(2);
                documentConfDto.setStatus(1);
                documentConfDto.setIsActive(1);
                documentConfDto.setFolderName(AppConstants.TAXMASTER);
                documentConfDto.setRemarks(taxMasterDto.getUploadDocumentRemarks());
                documentConfDto.setUploadDocumentContent(taxMasterDto.getUploadDocumentContent()[i]);
                TblUploadDocumentConf document = uploadDocumentConfService.uploadDocument(documentConfDto);
                i++;
            }


        }
            return new ApiResponse("Tax Master Updated successfully", 200, taxMasterDto);


    }

    @Override
    public ApiResponse<List<TaxMasterSearchDto>> searchTaxMaster(TaxMasterSearchDto taxMasterSearchDto) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appmaster.Get_tbl_TaxMaster_Search")
                .registerStoredProcedureParameter("@V_isactive",Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_chargemasterId",Long.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_chargecodeId",Long.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_hsnSaccode",String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_AuctioncenterId",Long.class, ParameterMode.IN)
                .setParameter("@V_isactive",taxMasterSearchDto.getIsActive())
                .setParameter("@V_chargemasterId",taxMasterSearchDto.getChargeMasterId())
                .setParameter("@V_chargecodeId",taxMasterSearchDto.getChargeCodeId())
                .setParameter("@V_hsnSaccode",taxMasterSearchDto.getHsnSac())
                .setParameter("@V_AuctioncenterId",taxMasterSearchDto.getAuctionCenterId());
        List<Object[]> execute = storedProcedureQuery.getResultList();
        if(!execute.isEmpty()){
        List<TaxMasterSearchDto> taxMasterSearchDtos = execute.stream().map(
                objects ->{
                    TaxMasterSearchDto taxMasterSearchDto1 = new TaxMasterSearchDto();
                    taxMasterSearchDto1.setTaxMasterId(Long.valueOf(objects[0].toString()));
                    taxMasterSearchDto1.setAuctionCenterId(Long.valueOf( objects[1].toString()));
                    taxMasterSearchDto1.setChargeMasterId(Long.valueOf( objects[2].toString()));
                    taxMasterSearchDto1.setChargeCodeId(Long.valueOf(objects[3].toString()));
                    taxMasterSearchDto1.setHsnSac(objects[4].toString());
                    taxMasterSearchDto1.setIsActive((Boolean)objects[5]==true?1:0);
                    return taxMasterSearchDto1;
                }
        ).collect(Collectors.toList());
        return new ApiResponse<List<TaxMasterSearchDto>>("get All Success",200 ,taxMasterSearchDtos);
    }else {
        return new ApiResponse<List<TaxMasterSearchDto>>("No record found", 404, null);
    }
}

    @Override
    public ApiResponse<?> getAllUploadDocument() {
        Optional<List<TblUploadDocumentConf>> tblUploadDocumentConf= uploadDocumentConfRepository.findAllUploadDocument(AppConstants.TBL_TAXMASTER);

        List<DownloadDto> downloadDtos = tblUploadDocumentConf.get().stream().map(
                tblUploadDocument ->{
                    DownloadDto downloadDto = new DownloadDto();
                    downloadDto.setUploadDocumentConfId(tblUploadDocument.getUploadDocumentConfId());
                    downloadDto.setUploadDocumentRemarks(tblUploadDocument.getRemarks());
                    downloadDto.setDocumentUploadTime(tblUploadDocument.getCreatedOn());
                    return downloadDto;
                }).collect(Collectors.toList());
        return  new ApiResponse<List<DownloadDto>>("success" ,200,downloadDtos);
    }

    @Override
    public ApiResponse<?> getUploadDocumentById(long id) throws IOException {
        DownloadDto download = uploadDocumentConfService.downloadDocument(id);
        DownloadDto downloadDto = new DownloadDto();
        downloadDto.setDocumentName(download.getDocumentName());
        downloadDto.setDocumentContent(download.getDocumentContent());
        return  new ApiResponse<DownloadDto>("success" ,200,downloadDto);
    }
}
