package com.etl.eproc.admin.serviceImpl;

import com.etl.eproc.admin.dto.DownloadDto;
import com.etl.eproc.admin.dto.FactoryTypeDto;
import com.etl.eproc.admin.dto.UploadDocumentConfDto;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.TblFactoryType;
import com.etl.eproc.admin.model.TblUploadDocumentConf;
import com.etl.eproc.admin.model.TblUserLogin;
import com.etl.eproc.admin.repository.FactoryTypeRepository;
import com.etl.eproc.admin.repository.UploadDocumentConfRepository;
import com.etl.eproc.admin.repository.UserLoginRepository;
import com.etl.eproc.admin.serviceI.FactoryTypeService;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
@Service
public class FactoryTypeServiceImpl implements FactoryTypeService {

    @Autowired
    private ModelMapper mapper;
    @Autowired
    private FactoryTypeRepository factoryTypeRepository;
    @Autowired
    private UserLoginRepository userLoginRepository;

    @Autowired
    private EntityManager entityManager;
    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;
    @Autowired
    private UploadDocumentConfRepository uploadDocumentConfRepository;

    public ApiResponse<?> createFactoryType(FactoryTypeDto factoryTypeDto) {
            TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
            boolean factoryTypeNameDuplicate = factoryTypeRepository.existsByFactoryTypeName(factoryTypeDto.getFactoryTypeName());
            boolean factoryTypeDuplicate = factoryTypeRepository.existsByFactoryType(factoryTypeDto.getFactoryType());
            if (!factoryTypeNameDuplicate && !factoryTypeDuplicate) {
                mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
                TblFactoryType factoryType = mapper.map(factoryTypeDto, TblFactoryType.class);
                factoryType.setIsActive(1);
                factoryType.setCreatedOn(new Date());
                factoryType.setCreatedBy(tblUserLogin);
                factoryTypeRepository.save(factoryType);
                FactoryTypeDto factoryTypeDtonew = mapper.map(factoryType, FactoryTypeDto.class);
                if (!factoryTypeDto.getDownloadDto()[0].getDocumentContent().isEmpty()) {
                    int i = 0;
                    for(int j=0;j<=factoryTypeDto.getDownloadDto().length-1;j++) {
                        UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                        uploadDocumentConfDto.setRemarks(factoryTypeDto.getUploadDocumentRemarks());
                        uploadDocumentConfDto.setTableID(factoryType.getFactoryTypeId());
                        
                        uploadDocumentConfDto.setFlag(1);
                        uploadDocumentConfDto.setStatus(1);
                        uploadDocumentConfDto.setIsActive(1);
                        uploadDocumentConfDto.setDocumentSize(String.valueOf(factoryTypeDto.getDownloadDto()[i].getDocumentSize()));
                        uploadDocumentConfDto.setTableName("tbl_FactoryType");
                        uploadDocumentConfDto.setFolderName("FactoryType");
                        uploadDocumentConfDto.setUploadDocumentName(String.valueOf(factoryTypeDto.getDownloadDto()[i].getDocumentName()));
                        uploadDocumentConfDto.setUploadDocumentContent(String.valueOf(factoryTypeDto.getDownloadDto()[i].getDocumentContent()));
                        TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                        i++;
                    }
                }
                return new ApiResponse<>("Factory Type created successfully", 201, factoryTypeDtonew);
            } else if (factoryTypeNameDuplicate) {
                return new ApiResponse<FactoryTypeDto>("Factory Type name already exists", 400, null);
            } else {
                return new ApiResponse<FactoryTypeDto>("Factory Type already exists", 400, null);
            }
    }

    public ApiResponse<?> updateFactoryType(FactoryTypeDto factoryTypeUpdateDto) {
            TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
            TblFactoryType factoryType1 = factoryTypeRepository.findById(factoryTypeUpdateDto.getFactoryTypeId()).orElseThrow(() -> new ResourceNotFoundException("TblGrade", "gradeId", factoryTypeUpdateDto.getFactoryTypeId()));
            factoryType1.setFactoryTypeName(factoryTypeUpdateDto.getFactoryTypeName());
            factoryType1.setFactoryType(factoryTypeUpdateDto.getFactoryType());
            factoryType1.setUpdatedBy(tblUserLogin);
            factoryType1.setUpdatedOn(new Date());
            factoryTypeRepository.save(factoryType1);
        FactoryTypeDto factoryTypeDtonew = mapper.map(factoryType1, FactoryTypeDto.class);
        if (!factoryTypeUpdateDto.getDownloadDto()[0].getDocumentContent().isEmpty()) {
            int i = 0;
            for(int j=0;j<=factoryTypeUpdateDto.getDownloadDto().length-1;j++) {
                UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                uploadDocumentConfDto.setRemarks(factoryTypeUpdateDto.getUploadDocumentRemarks());
                uploadDocumentConfDto.setTableID(factoryType1.getFactoryTypeId());
                
                uploadDocumentConfDto.setFlag(2);
                uploadDocumentConfDto.setStatus(1);
                uploadDocumentConfDto.setIsActive(1);
                uploadDocumentConfDto.setDocumentSize(String.valueOf(factoryTypeUpdateDto.getDownloadDto()[i].getDocumentSize()));
                uploadDocumentConfDto.setTableName("tbl_FactoryType");
                uploadDocumentConfDto.setFolderName("FactoryType");
                uploadDocumentConfDto.setUploadDocumentName(String.valueOf(factoryTypeUpdateDto.getDownloadDto()[i].getDocumentName()));
                uploadDocumentConfDto.setUploadDocumentContent(String.valueOf(factoryTypeUpdateDto.getDownloadDto()[i].getDocumentContent()));
                TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                i++;
            }
        }
            return new ApiResponse<FactoryTypeDto>("Factory Type Updated successfully", 200, factoryTypeDtonew);
        }


    public ApiResponse<List<FactoryTypeDto>> getAllFactoryType(){
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE).setAmbiguityIgnored(true);
        List<FactoryTypeDto> getAllChargeMasterList=factoryTypeRepository.findAll().stream().map(
                tblFactoryType -> {
                    FactoryTypeDto factoryTypeDto = mapper.map(tblFactoryType, FactoryTypeDto.class);
                    //factoryTypeDto.setSessionUserId(tblFactoryType.getCreatedBy().getUserId());
                    return factoryTypeDto;
                } ).collect(Collectors.toList());
        return new ApiResponse<List<FactoryTypeDto>>("get All Charge Master Successfully" ,200,getAllChargeMasterList);
    }


    public ApiResponse<?> getAllFactoryTypePageable(int isActive, int offset, int page) {
        Pageable pageable= PageRequest.of(page,offset);
        Optional<List<TblFactoryType>> list =factoryTypeRepository.findAllByIsActive(isActive,pageable);
        if(!list.isEmpty() && list.isPresent()){
            List<FactoryTypeDto> dtos=list.get().stream().map(
                    tblFactoryType -> {
                        FactoryTypeDto dto= new FactoryTypeDto();
                        dto.setFactoryTypeName(tblFactoryType.getFactoryTypeName());
                        dto.setFactoryType(tblFactoryType.getFactoryType());
                        dto.setIsActive(tblFactoryType.getIsActive());
                        return dto;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse("success",200,dtos);
        }

        return new ApiResponse("No Record Found",404,null);
    }


    public ApiResponse<?> searchFactoryType(FactoryTypeDto factoryTypeDto) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appmaster.Get_tbl_FactoryType_Search")
                .registerStoredProcedureParameter("@V_factoryTypeName",String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_factoryType",String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_isactive", Integer.class,ParameterMode.IN)
                .setParameter("@V_factoryTypeName",factoryTypeDto.getFactoryTypeName())
                .setParameter("@V_factoryType",factoryTypeDto.getFactoryType())
                .setParameter("@V_isactive",factoryTypeDto.getIsActive());
        List<Object[]> executeFactoryType = storedProcedureQuery.getResultList();
        if(!executeFactoryType.isEmpty()) {
            List<FactoryTypeDto> factoryTypeDtos = executeFactoryType.stream().map(
                    objects -> {
                        FactoryTypeDto factoryTypeDto1 = new FactoryTypeDto();
                        factoryTypeDto1.setFactoryTypeId(Long.valueOf(objects[0].toString()));
                        factoryTypeDto1.setFactoryTypeName((String) objects[1]);
                        factoryTypeDto1.setFactoryType((String) objects[2]);
                        factoryTypeDto1.setIsActive((Boolean) objects[3] == true ? 1 : 0);
                        return factoryTypeDto1;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse<>("getBySearch Success", 200, factoryTypeDtos);
        }
        return new ApiResponse<>(("No Record Found"),404,null);
    }

    @Override
    public ApiResponse<?> getAllUploadedDocument() {
        Optional<List<TblUploadDocumentConf>> tblUploadDocumentConf= uploadDocumentConfRepository.findAllUploadDocument("tbl_factoryType");

        List<DownloadDto> downloadDtos = tblUploadDocumentConf.get().stream().map(
                tblUploadDocument ->{
                    DownloadDto downloadDto = new DownloadDto();
                    downloadDto.setUploadDocumentConfId(tblUploadDocument.getUploadDocumentConfId());
                    downloadDto.setUploadDocumentRemarks(tblUploadDocument.getRemarks());
                    downloadDto.setDocumentUploadTime(tblUploadDocument.getCreatedOn());
                    return downloadDto;
                }).collect(Collectors.toList());
        return  new ApiResponse<List<DownloadDto>>("success" ,200,downloadDtos);
    }

    @Override
    public ApiResponse<?> getUploadedDocumentById(long id) throws IOException {
        DownloadDto download = uploadDocumentConfService.downloadDocument(id);
        DownloadDto downloadDto = new DownloadDto();
        downloadDto.setDocumentName(download.getDocumentName());
        downloadDto.setDocumentContent(download.getDocumentContent());
        return  new ApiResponse<DownloadDto>("success" ,200,downloadDto);
    }

    public ApiResponse<FactoryTypeDto> getFactoryTypeById(long factoryTypeId) {
        TblFactoryType factoryType = factoryTypeRepository.findById(factoryTypeId).orElseThrow(()->new ResourceNotFoundException("TblFactoryType","factoryTypeId",factoryTypeId));
        FactoryTypeDto factoryTypeById = mapper.map(factoryType,FactoryTypeDto.class);
        //factoryTypeById.setSessionUserId(factoryType.getCreatedBy().getUserId());
        return  new ApiResponse<FactoryTypeDto>("Factory Type get by Id successfully" ,200,factoryTypeById);
    }

}
