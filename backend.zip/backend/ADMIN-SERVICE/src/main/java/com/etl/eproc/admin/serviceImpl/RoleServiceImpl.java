package com.etl.eproc.admin.serviceImpl;


import com.etl.eproc.admin.dto.RoleDto;

import com.etl.eproc.admin.dto.RoleSearchDto;
import com.etl.eproc.admin.dto.UploadDocumentConfDto;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.TblRole;
import com.etl.eproc.admin.model.TblUploadDocumentConf;
import com.etl.eproc.admin.model.TblUserLogin;
import com.etl.eproc.admin.repository.RoleRepository;
import com.etl.eproc.admin.repository.UploadDocumentConfRepository;
import com.etl.eproc.admin.repository.UserLoginRepository;
import com.etl.eproc.admin.serviceI.RoleService;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RoleServiceImpl implements RoleService {

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private ModelMapper mapper;

    @Autowired
    private UserLoginRepository userLoginRepository;

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;

    @Autowired
    private UploadDocumentConfRepository uploadDocumentConfRepository;
    @Override
    public ApiResponse<RoleDto> createRole(RoleDto roleDto) {
        TblUserLogin tblUserLogin= userLoginRepository.findById(1L).orElseThrow(()-> new ResourceNotFoundException("TblUserLogin","userId", 1));
        boolean isRoleNameExist=roleRepository.existsByRoleName(roleDto.getRoleName());
        if(!isRoleNameExist) {
            mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
            TblRole tblRole=  mapper.map(roleDto, TblRole.class);
            tblRole.setCreatedBy(tblUserLogin);
            tblRole.setCreatedOn(new Date());
            tblRole.setIsActive(1);
            TblRole tblRole1 = roleRepository.save(tblRole);
            RoleDto roleDtoMap = mapper.map(tblRole1, RoleDto.class);

            if (roleDto.getUploadDocumentContent() != null) {
                int i = 0;
                for (String DocumenName:roleDto.getUploadDocumentName()) {
                    UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                    uploadDocumentConfDto.setRemarks(roleDto.getUploadDocumentRemarks());
                    uploadDocumentConfDto.setTableID(tblRole1.getRoleId());
                    uploadDocumentConfDto.setFlag(1);
                    uploadDocumentConfDto.setStatus(1);
                    uploadDocumentConfDto.setIsActive(1);
                    uploadDocumentConfDto.setDocumentSize(roleDto.getUploadDocumentSize());
                    uploadDocumentConfDto.setTableName("tbl_Role");
                    uploadDocumentConfDto.setFolderName("Role");
                    uploadDocumentConfDto.setUploadDocumentName(DocumenName);
                    uploadDocumentConfDto.setUploadDocumentContent(roleDto.getUploadDocumentContent()[i]);
                    TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                    i++;
                }
            }
            return new ApiResponse<>("Role created successfully", 201, roleDtoMap);
        }else{
            return new ApiResponse<>("Role Name already Exists", 400, null);
        }
    }

    @Override
    public ApiResponse<RoleDto> getRoleById(Long roleId) {
       TblRole tblRole= roleRepository.findById(roleId).orElseThrow(()-> new ResourceNotFoundException("TblRole","roleId",roleId));
       RoleDto roleDto= mapper.map(tblRole, RoleDto.class);
     //  roleDto.setUserId(tblRole.getCreatedBy().getUserId());
        return new ApiResponse<RoleDto>("Role get by Id successfully" ,200,roleDto);
    }

   /* @Override
    public ApiResponse<List<RoleDto>> getAllRole() {
        List<RoleDto> listRoles=roleRepository.findAll().stream().map(
                tblrole -> {
                    RoleDto roleDto=  mapper.map(tblrole,RoleDto.class);
             //       roleDto.setUserId(tblrole.getCreatedBy().getUserId());
                    return roleDto;
                }
        ).collect(Collectors.toList());
    return new ApiResponse<List<RoleDto>>("Get All Roles Successfully",200,listRoles);
    }*/

    @Override
    public ApiResponse<RoleDto> updateRole(RoleDto roleDto) {
           TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin","userId",1));
            TblRole tblRole = roleRepository.findById(roleDto.getRoleId()).orElseThrow(() -> new ResourceNotFoundException("TblRole", "roleId", roleDto.getRoleId()));
            tblRole.setRoleName(roleDto.getRoleName());
            tblRole.setCreatedBy(tblUserLogin);
            tblRole.setUpdatedOn(new Date());
            tblRole.setUpdatedBy(tblUserLogin);
            tblRole.setIsActive(roleDto.getIsActive());
            RoleDto roleDto1 = mapper.map(roleRepository.save(tblRole), RoleDto.class);
            if (roleDto.getUploadDocumentContent() != null) {
            int i = 0;
            for (String DocumenName:roleDto.getUploadDocumentName()) {
                UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                uploadDocumentConfDto.setRemarks(roleDto.getUploadDocumentRemarks());
                uploadDocumentConfDto.setTableID(roleDto1.getRoleId());
                uploadDocumentConfDto.setFlag(1);
                uploadDocumentConfDto.setStatus(1);
                uploadDocumentConfDto.setIsActive(1);
                uploadDocumentConfDto.setDocumentSize(roleDto.getUploadDocumentSize());
                uploadDocumentConfDto.setTableName("tbl_Role");
                uploadDocumentConfDto.setFolderName("Role");
                uploadDocumentConfDto.setUploadDocumentName(DocumenName);
                uploadDocumentConfDto.setUploadDocumentContent(roleDto.getUploadDocumentContent()[i]);
                TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                i++;
            }
        }
            return new ApiResponse<RoleDto>("Role Updated Successfully", 201, roleDto1);
        }

    @Override
    public ApiResponse<List<RoleSearchDto>> searchRoles(RoleSearchDto roleSearchDto) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appuser.Get_tbl_Role_Search")
                .registerStoredProcedureParameter("@V_roleName", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_isactive", Integer.class, ParameterMode.IN)
                //    .registerStoredProcedureParameter("@V_markCode" , String.class, ParameterMode.IN)
                .setParameter("@V_roleName", roleSearchDto.getRoleName())
                .setParameter("@V_isactive", roleSearchDto.getIsActive());
        ;
        List<Object[]> execute = storedProcedureQuery.getResultList();
        if (!execute.isEmpty()) {
            List<RoleSearchDto> markSearchDtos = execute.stream().map(
                    objects -> {
                        RoleSearchDto roleDto1 = new RoleSearchDto();
                        roleDto1.setRoleId(Long.valueOf(objects[0].toString()));
                        roleDto1.setRoleName((String) objects[1]);
                        roleDto1.setIsActive((Boolean) objects[2] == true ? 1 : 0);
                        return roleDto1;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse<List<RoleSearchDto>>("getAll Success", 200, markSearchDtos);
        }
        return new ApiResponse<>("No Record Found",404,null);
    }
}
