package com.etl.eproc.admin.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="tbl_TaxMaster",schema = "appmaster")
public class TblTaxMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long taxMasterId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "chargeMasterId")
    private TblChargeMaster tblChargeMaster;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "chargeCodeId")
    private TblChargeCode tblChargeCode;

    @Column(name="hsnSac",nullable = false)
    private String hsnSac;

    @Column(name="description",nullable = false)
    private  String description;

    @Column(name="value",nullable = false)
    private String value;

    @Column(name="effectiveFromDate",nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date effectiveFromDate;

    @Column(name="effectiveEndDate",nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date effectiveEndDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "auctionCenterId")
    private TblAuctionCenter auctionCenter;

    @Column(name="isActive",nullable = false)
    private int isActive;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private TblUserLogin createdBy;

    @Column(name="createdOn",nullable = false)
    private Date createdOn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updatedBy")
    private TblUserLogin updatedBy;

    @Column(name="updatedOn")
    private Date updatedOn;

    public TblTaxMaster(long taxMasterId) {
        this.taxMasterId = taxMasterId;
    }

    public TblTaxMaster(TblChargeMaster tblChargeMaster) {
        this.tblChargeMaster = tblChargeMaster;
    }

    public TblTaxMaster(TblChargeCode tblChargeCode) {
        this.tblChargeCode = tblChargeCode;
    }

    public TblTaxMaster(TblAuctionCenter auctionCenter) {
        this.auctionCenter = auctionCenter;
    }
}
