package com.etl.eproc.admin.controller;


import com.etl.eproc.admin.dto.ChargeCodeDto;
import com.etl.eproc.admin.serviceI.ChargeCodeServiceI;
import com.etl.eproc.admin.util.ApiResponse;
import com.etl.eproc.admin.util.AppConstants;
import com.etl.eproc.admin.util.SearchResponce;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/admin/chargecode/")
public class ChargeCodeController {

    @Autowired
    private ChargeCodeServiceI chargeCodeServiceI;
    @PostMapping(value = "/create")
    ApiResponse<?> chargeCode(@Valid @RequestBody ChargeCodeDto chargeCodeDto){

        try {
            return chargeCodeServiceI.createchargeCode(chargeCodeDto);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),200,null);
        }
    }

    @PostMapping(value = "/update")
    ApiResponse<?> updateChargeCode(@Valid @RequestBody ChargeCodeDto chargeCodeDto){
        try {
            return chargeCodeServiceI.updatechargeCode(chargeCodeDto);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }

    @PostMapping("/search")
    public ApiResponse<SearchResponce> getAllChargeCode(
//            @RequestParam(value = "pageNo", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER, required = false) int pageNo,
//            @RequestParam(value = "pageSize", defaultValue = AppConstants.DEFAULT_PAGE_SIZE, required = false) int pageSize,
           @RequestBody ChargeCodeDto searchDto   ){
        try {
            return new ApiResponse<>("success", 200, chargeCodeServiceI.getAllChargeCode(searchDto));
        } catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }


    @GetMapping("/getChargeCode/{isactive}")
    public ApiResponse<?> getAllChargeCode(@PathVariable("isactive") int isActive){
//            , @PathVariable("offset") int offset, @PathVariable("page") int page
        try {
            ApiResponse<List<ChargeCodeDto>> chargeCodeDto = chargeCodeServiceI.getAllChargeCodes(isActive);
            return chargeCodeDto;
        }catch(Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }
    @GetMapping("/getChargeCode/{ChargeCodeId}")
    public ApiResponse<?> getChargeCodeById(@PathVariable("ChargeCodeId") int ChargeCodeId){
        try{
            return chargeCodeServiceI.getChargeCodeyId(ChargeCodeId);
        }
        catch(Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }

    @GetMapping("/getdocument/{uploaddocumentId}")
    public ApiResponse<?> getuploadDocument(@PathVariable("uploaddocumentId") long id) throws IOException {
        return new ApiResponse<>("success",200,chargeCodeServiceI.getUploadDocumentById(id));

    }

    @GetMapping("/getdocument/alluploaddocument")
    public ApiResponse<?> getAllDocument(){
        return new ApiResponse<>("success",200,chargeCodeServiceI.getAllUploadDocument());
    }

}

