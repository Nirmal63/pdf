package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class WareHouseUserUnitDto {

    private long wareHouseUnitId;

   /* @NotEmpty(message = "Please enter wareHouseUnit Name")*/

    @Size(max = 50,message = "The Ware House Unit Name should not exceed 50 characters")
    @Pattern(regexp ="^(?:[A-Za-z \\\\s\\\\-]*|)$",message = "The Ware House Unit Name should contain alphabetic characters only")
    private String wareHouseUnitName;

    @NotEmpty(message = "Please enter wareHouseUnit Code")
    @Size(max = 15,message = "TheWare House Unit Code should have a length of 15 characters")
    @Pattern(regexp = "^[a-zA-Z0-9]+$",message = "The Ware House Unit Code should only contain alphanumeric characters")
    private String wareHouseUnitCode;

    @NotNull(message = "Please select wareHouseUser")
    private long wareHouseUserRegId;

    private int isActive;


 private String uploadDocumentRemarks;
 private String[] uploadDocumentContent;
 private String[] uploadDocumentName;
 private String uploadDocumentSize;
    

}
