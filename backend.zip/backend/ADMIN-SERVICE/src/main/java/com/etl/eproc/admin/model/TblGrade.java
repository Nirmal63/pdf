package com.etl.eproc.admin.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table( schema = "appmaster" , name ="tbl_Grade")
public class TblGrade {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long GradeId;

    private String gradeName;

    private String gradeCode;

    private int isActive;


    private Date createdOn;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updatedBy")
    private  TblUserLogin updatedBy;

    private Date updatedOn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private TblUserLogin createdBy;
    //private int userId;
}
