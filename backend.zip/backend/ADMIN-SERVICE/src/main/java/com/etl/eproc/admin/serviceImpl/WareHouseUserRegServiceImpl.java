package com.etl.eproc.admin.serviceImpl;


import com.etl.eproc.admin.dto.DownloadDto;
import com.etl.eproc.admin.dto.UploadDocumentConfDto;
import com.etl.eproc.admin.dto.WareHouseUserRegDto;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.*;
import com.etl.eproc.admin.repository.*;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.serviceI.WareHouseUserRegService;
import com.etl.eproc.admin.util.ApiResponse;
import com.etl.eproc.admin.util.AppConstants;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import javax.persistence.EntityManager;
import java.io.IOException;
import java.util.*;


import java.util.stream.Collectors;

@Service
public class WareHouseUserRegServiceImpl implements WareHouseUserRegService {

    @Autowired
    private WareHouseUserRepository wareHouseUserRepository;

    @Autowired
    private TaxMasterRepository taxMasterRepository;

    @Autowired
    private UserLoginRepository userLoginRepository;

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private AuctionCenterRepository auctionCenterRepository;

    @Autowired
    private StateRepository stateRepository;

    @Autowired
    UploadDocumentConfService uploadDocumentConfService;

    @Autowired
    UploadDocumentConfRepository uploadDocumentConfRepository;

    @Override
    public ApiResponse<?> createWareHouseUser(WareHouseUserRegDto wareHouseUserRegDto) {

        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
        TblState tblState = stateRepository.findById(wareHouseUserRegDto.getStateId()).orElseThrow(() -> new ResourceNotFoundException("TblState ", "stateID ", wareHouseUserRegDto.getStateId()));
            ApiResponse<Boolean> apiResponse = validateUser(wareHouseUserRegDto.getWareHouseCode(), wareHouseUserRegDto.getWareHouseLicenseNo(), wareHouseUserRegDto.getTaxIdentityNo(), wareHouseUserRegDto.getTeaBoardRegistrationNo(), wareHouseUserRegDto.getPanNo(), wareHouseUserRegDto.getGstNo());
            List<TblAuctionCenter> auctionCenters=new ArrayList<>();
            for(long auctionCenterId:wareHouseUserRegDto.getAuctionCenterId()){
                TblAuctionCenter auctionCenter = auctionCenterRepository.findById(auctionCenterId).orElseThrow(() -> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId",auctionCenterId));
                auctionCenters.add(auctionCenter);
            }
            if (apiResponse.getResponseData() == false) {
                modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
                TblWareHouseUserReg tblWareHouseUserReg = modelMapper.map(wareHouseUserRegDto, TblWareHouseUserReg.class);
                tblWareHouseUserReg.setCreatedBy(tblUserLogin);
                tblWareHouseUserReg.setCreatedOn(new Date());
                tblWareHouseUserReg.setMobileNo(Long.valueOf(wareHouseUserRegDto.getMobileNo()));
                //tblWareHouseUserReg.setTblUserLogin(tblUserLogin);
                tblWareHouseUserReg.setAuctionCenter(auctionCenters);
                tblWareHouseUserReg.setState(tblState);
                TblWareHouseUserReg tblWareHouseUserReg1 = wareHouseUserRepository.save(tblWareHouseUserReg);
                WareHouseUserRegDto wareHouseUserRegDto1=modelMapper.map(tblWareHouseUserReg, WareHouseUserRegDto.class);
                if(wareHouseUserRegDto.getUploadDocumentContent()!=null) {


                    int i = 0;
                    for (String DocumentName : wareHouseUserRegDto.getUploadDocumentName()) {
                        UploadDocumentConfDto documentConfDto = new UploadDocumentConfDto();
                        documentConfDto.setUploadDocumentName(DocumentName);
                        documentConfDto.setDocumentSize(wareHouseUserRegDto.getUploadDocumentSize());
                        documentConfDto.setTableName(AppConstants.TBL_WAREHOUSEUSER);
                        documentConfDto.setTableID(wareHouseUserRegDto1.getWareHouseUserRegId());
                        documentConfDto.setDocumentSize(wareHouseUserRegDto.getUploadDocumentSize());
                        documentConfDto.setFlag(1);
                        documentConfDto.setStatus(1);
                        documentConfDto.setIsActive(1);
                        documentConfDto.setFolderName(AppConstants.WAREHOUSEUSER);
                        documentConfDto.setRemarks(wareHouseUserRegDto.getUploadDocumentRemarks());
                        documentConfDto.setUploadDocumentContent(wareHouseUserRegDto.getUploadDocumentContent()[i]);
                        TblUploadDocumentConf document = uploadDocumentConfService.uploadDocument(documentConfDto);
                        i++;
                    }

                }
                return new ApiResponse<WareHouseUserRegDto>("Warehouse User registered successfully", 200, wareHouseUserRegDto1);
            }
            return apiResponse;

    }

    @Override
    public ApiResponse<WareHouseUserRegDto> getWareHouseUserById(long id) {

        TblWareHouseUserReg wareHouseUserReg = wareHouseUserRepository.findById(id).get();
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
        WareHouseUserRegDto wareHouseUserRegDto = modelMapper.map(wareHouseUserReg, WareHouseUserRegDto.class);
         List<TblAuctionCenter> auctionCenters=wareHouseUserReg.getAuctionCenter();
        List<Long> auctionCenterIds=new ArrayList<>();
         for(TblAuctionCenter auctionCenter:auctionCenters) {
         auctionCenterIds.add(auctionCenter.getAuctionCenterId());
        wareHouseUserRegDto.setAuctionCenterId(auctionCenterIds);

         }
        wareHouseUserRegDto.setStateId(wareHouseUserReg.getState().getStateId());
        return new ApiResponse<WareHouseUserRegDto>("WareHouse User get by Id successfully", 200, wareHouseUserRegDto);
    }

    @Override
    public ApiResponse<?> getAllWareHouseUser(int iActive, int offset, int page) {
        Pageable pageable = PageRequest.of(page, offset);
        Optional<List<TblWareHouseUserReg>> tblWareHouseUserRegs = wareHouseUserRepository.findAllByIsActive(iActive, pageable);
        List<WareHouseUserRegDto> wareHouseUserRegDtos = tblWareHouseUserRegs.get().stream().map(wareHouseUserReg -> {
            WareHouseUserRegDto wareHouseUserRegDto = modelMapper.map(wareHouseUserReg, WareHouseUserRegDto.class);
            //  wareHouseUserRegDto.setSessionUserId(wareHouseUserReg.getTblUserLogin().getUserId());
            List<TblAuctionCenter> auctionCenters=wareHouseUserReg.getAuctionCenter();
            List<Long> auctionCenterIds=new ArrayList<>();
            for(TblAuctionCenter auctionCenter:auctionCenters) {
                auctionCenterIds.add(auctionCenter.getAuctionCenterId());
                wareHouseUserRegDto.setAuctionCenterId(auctionCenterIds);
            }
            wareHouseUserRegDto.setStateId(wareHouseUserReg.getState().getStateId());
            return wareHouseUserRegDto;
        }).collect(Collectors.toList());
        return new ApiResponse<List<WareHouseUserRegDto>>("getAll WareHouse users successfully", 200, wareHouseUserRegDtos);

    }

    @Override
    public ApiResponse<?> updateWareHouseUserBy(WareHouseUserRegDto wareHouseUserRegDto) {

                TblWareHouseUserReg wareHouseUserReg = wareHouseUserRepository.findById(wareHouseUserRegDto.getWareHouseUserRegId()).orElseThrow(() -> new ResourceNotFoundException("TblWareHouseUserReg", "WareHouseUserRegId", wareHouseUserRegDto.getWareHouseUserRegId()));
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
        TblState tblState = stateRepository.findById(wareHouseUserRegDto.getStateId()).orElseThrow(() -> new ResourceNotFoundException("TblState ", "stateId ", wareHouseUserRegDto.getStateId()));
             List<TblAuctionCenter> auctionCenters=new ArrayList<>();
               for(long auctionCenterId:wareHouseUserRegDto.getAuctionCenterId()){
            TblAuctionCenter auctionCenter = auctionCenterRepository.findById(auctionCenterId).orElseThrow(() -> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId",auctionCenterId));
            auctionCenters.add(auctionCenter);
            }
                wareHouseUserReg.setWareHouseName(wareHouseUserRegDto.getWareHouseName());
                wareHouseUserReg.setWareHouseCode(wareHouseUserRegDto.getWareHouseCode());
                wareHouseUserReg.setWareHouseLicenseNo(wareHouseUserRegDto.getWareHouseLicenseNo());
                wareHouseUserReg.setShortName(wareHouseUserRegDto.getShortName());
                wareHouseUserReg.setAddress(wareHouseUserRegDto.getAddress());
                wareHouseUserReg.setCity(wareHouseUserRegDto.getCity());
                wareHouseUserReg.setContactPerson(wareHouseUserRegDto.getContactPerson());
                wareHouseUserReg.setEmail(wareHouseUserRegDto.getEmail());
                wareHouseUserReg.setEntityCode(wareHouseUserRegDto.getEntityCode());
                wareHouseUserReg.setFax(wareHouseUserRegDto.getFax());
                wareHouseUserReg.setMobileNo(Long.valueOf(wareHouseUserRegDto.getMobileNo()));
                wareHouseUserReg.setPhoneNo(wareHouseUserRegDto.getPhoneNo());
                wareHouseUserReg.setIsActive(wareHouseUserRegDto.getIsActive());
                wareHouseUserReg.setPanNo(wareHouseUserRegDto.getPanNo());
                wareHouseUserReg.setGstNo(wareHouseUserRegDto.getGstNo());
                wareHouseUserReg.setTaxIdentityNo(wareHouseUserRegDto.getTaxIdentityNo());
                wareHouseUserReg.setTeaBoardRegistrationNo(wareHouseUserRegDto.getTeaBoardRegistrationNo());
                wareHouseUserReg.setAuctionCenter(auctionCenters);
                wareHouseUserReg.setState(tblState);
                wareHouseUserReg.setUpdatedOn(new Date());
                wareHouseUserReg.setUpdatedBy(tblUserLogin);
                TblWareHouseUserReg tblWareHouseUserReg = wareHouseUserRepository.save(wareHouseUserReg);
               WareHouseUserRegDto wareHouseUserRegDto1=modelMapper.map(tblWareHouseUserReg, WareHouseUserRegDto.class);
        if(wareHouseUserRegDto.getUploadDocumentContent()!=null) {

            int i = 0;
            for (String DocumentName : wareHouseUserRegDto.getUploadDocumentName()) {
                UploadDocumentConfDto documentConfDto = new UploadDocumentConfDto();
                documentConfDto.setUploadDocumentName(DocumentName);
                documentConfDto.setDocumentSize(wareHouseUserRegDto.getUploadDocumentSize());
                documentConfDto.setTableName(AppConstants.TBL_WAREHOUSEUSER);
                documentConfDto.setTableID(wareHouseUserRegDto1.getWareHouseUserRegId());
                documentConfDto.setDocumentSize(wareHouseUserRegDto.getUploadDocumentSize());
                documentConfDto.setFlag(2);
                documentConfDto.setStatus(1);
                documentConfDto.setIsActive(1);
                documentConfDto.setFolderName(AppConstants.WAREHOUSEUSER);
                documentConfDto.setRemarks(wareHouseUserRegDto.getUploadDocumentRemarks());
                documentConfDto.setUploadDocumentContent(wareHouseUserRegDto.getUploadDocumentContent()[i]);
                TblUploadDocumentConf document = uploadDocumentConfService.uploadDocument(documentConfDto);
                i++;
            }
        }
                return new ApiResponse("WareHouse user Updated successfully", 200, wareHouseUserRegDto1);

    }

    @Override
    public ApiResponse<List<WareHouseUserRegDto>> searchWareHouseUser(Long auctionCenter,String wareHouseCode) {
       Optional< List<TblWareHouseUserReg>> tblWareHouseUserRegs=wareHouseUserRepository.findByauctionCenterIdAndWareHouseCode(auctionCenter,wareHouseCode);
        List<WareHouseUserRegDto> wareHouseUserRegDtos = tblWareHouseUserRegs.get().stream().map(wareHouseUserReg -> {
            WareHouseUserRegDto wareHouseUserRegDto = modelMapper.map(wareHouseUserReg, WareHouseUserRegDto.class);
            //  wareHouseUserRegDto.setSessionUserId(wareHouseUserReg.getTblUserLogin().getUserId());
            List<Long> auctionCenterIds=new ArrayList<>();
            for(TblAuctionCenter auctionCenter1:wareHouseUserReg.getAuctionCenter()) {
                auctionCenterIds.add(auctionCenter1.getAuctionCenterId());
                wareHouseUserRegDto.setAuctionCenterId(auctionCenterIds);
            }
            wareHouseUserRegDto.setStateId(wareHouseUserReg.getState().getStateId());
            return wareHouseUserRegDto;
        }).collect(Collectors.toList());
        return new ApiResponse<List<WareHouseUserRegDto>>("getAll WareHouse users successfully", 200, wareHouseUserRegDtos);
    }

    @Override
    public ApiResponse<Boolean> validateUser(String wareHouseCode, String wareHouseLicenceNo, String taxIdentificationNo, String teaBoardRegistrationNo, String PanNo, String gstNo) {
        boolean flag = wareHouseUserRepository.existsByWareHouseCode(wareHouseCode);
        boolean flag1 = wareHouseUserRepository.existsBywareHouseLicenseNo(wareHouseLicenceNo);
        boolean flag2 = wareHouseUserRepository.existsBytaxIdentityNo(taxIdentificationNo);
        boolean flag3=false;
        if(!teaBoardRegistrationNo.isEmpty()) {
             flag3 = wareHouseUserRepository.existsByteaBoardRegistrationNo(teaBoardRegistrationNo);
        }
        boolean flag4 = wareHouseUserRepository.existsByPanNo(PanNo);
        boolean flag5 = wareHouseUserRepository.existsByGstNo(gstNo);
        boolean flag6=isValidGSTCode(gstNo);
        boolean flag7=isValidPanNO(PanNo);

        if (flag) {
            return new ApiResponse<>("Warehouse user with same ware house code is already registered", 500, flag);
        } else if (flag1) {
            return new ApiResponse<>("Warehouse user with same ware house licence no is already registered", 500, flag1);

        } else if (flag2) {
            return new ApiResponse<>("Warehouse user with tax identification no is already registered", 500, flag2);

        } else if (flag3) {
            return new ApiResponse<>("Warehouse user with same tea board registration number is already registered", 500, flag3);
        } else if (flag4) {
            return new ApiResponse<>("Warehouse user with same pan no is already registered", 500, flag4);

        } else if (flag5) {
            return new ApiResponse<>("Warehouse user with same gst no is already registered", 500, flag5);
        } else if (flag6) {
            return new ApiResponse<>("please enter a valid gst No", 500, flag6);
        }else if(flag7) {
            return new ApiResponse<>("please enter a valid Pan No", 500, flag6);
        }else{
            return new ApiResponse<>("",200,false);
        }
    }

    @Override
    public ApiResponse<?> getAllUploadDocument() {
        Optional<List<TblUploadDocumentConf>> tblUploadDocumentConf= uploadDocumentConfRepository.findAllUploadDocument(AppConstants.TBL_WAREHOUSEUSER);

        List<DownloadDto> downloadDtos = tblUploadDocumentConf.get().stream().map(
                tblUploadDocument ->{
                    DownloadDto downloadDto = new DownloadDto();
                    downloadDto.setUploadDocumentConfId(tblUploadDocument.getUploadDocumentConfId());
                    downloadDto.setUploadDocumentRemarks(tblUploadDocument.getRemarks());
                    downloadDto.setDocumentUploadTime(tblUploadDocument.getCreatedOn());
                    return downloadDto;
                }).collect(Collectors.toList());
        return  new ApiResponse<List<DownloadDto>>("success" ,200,downloadDtos);
    }

    @Override
    public ApiResponse<?> getUploadDocumentById(long id) throws IOException {
        DownloadDto download = uploadDocumentConfService.downloadDocument(id);
        DownloadDto downloadDto = new DownloadDto();
        downloadDto.setDocumentName(download.getDocumentName());
        downloadDto.setDocumentContent(download.getDocumentContent());
        return  new ApiResponse<DownloadDto>("success" ,200,downloadDto);
    }


    public static boolean isValidGSTCode(String gstCode) {
        // Check if the input GST code is null or empty
        if (gstCode == null || gstCode.isEmpty()) {
            return false;
        }
        // Remove any spaces from the GST code
        gstCode = gstCode.replaceAll("\\s", "");

        // GSTIN must be exactly 15 characters long
        if (gstCode.length() != 15) {
            return true;
        }

        // Check if the first two characters are state codes (numeric)
        String stateCode = gstCode.substring(0, 2);
        if (!isNumeric(stateCode)) {
            return true;
        }

        // Check if the PAN is valid (alphanumeric with specific length)
        String pan = gstCode.substring(2, 12);
        if (!isValidPAN(pan)) {
            return true;
        }

        // The 13th character must be 'Z'
        if (gstCode.charAt(12) != 'Z') {
            return true;
        }

        // Checksum validation
        char checksumDigit = calculateChecksumDigit(gstCode);
        char actualChecksumDigit = gstCode.charAt(14);

        return checksumDigit == actualChecksumDigit;
    }

    private static boolean isNumeric(String str) {
        return str.matches("\\d+");
    }

    private static boolean isValidPAN(String pan) {
        return pan.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}");
    }

    private static char calculateChecksumDigit(String gstCode) {
        String pan = gstCode.substring(2, 12);
        int[] weights = { 1, 2, 4, 8, 5, 10, 9, 7, 3, 6 };
        int sum = 0;

        for (int i = 0; i < pan.length(); i++) {
            char ch = pan.charAt(i);
            int digit = Character.isDigit(ch) ? ch - '0' : ch - 'A' + 10;
            sum += digit * weights[i % 10];
        }

        int checksumValue = (36 - (sum % 36)) % 36;
        return (char) (checksumValue < 10 ? checksumValue + '0' : checksumValue - 10 + 'A');
    }

    public static boolean isValidPanNO(String pan) {
        // Check if the PAN is null or empty
        if (pan == null || pan.isEmpty()) {
            return true;
        }

        // PAN must be exactly 10 characters long
        if (pan.length() != 10) {
            return true;
        }

        // Check if the first five characters are uppercase letters
        String firstFiveChars = pan.substring(0, 5);
        if (!firstFiveChars.matches("[A-Z]{5}")) {
            return true;
        }

        // Check if the next four characters are digits
        String nextFourChars = pan.substring(5, 9);
        if (!nextFourChars.matches("\\d{4}")) {
            return true;
        }

        // Check if the last character is an uppercase letter
        char lastChar = pan.charAt(9);
        if (!Character.isUpperCase(lastChar)) {
            return true;
        }

        return false;
    }






}