package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DownloadDto {

    private long uploadDocumentConfId;
    private String documentContent;
    private String documentName;
    private String documentSize;
    private String uploadDocumentRemarks;
    private Date documentUploadTime;
}
