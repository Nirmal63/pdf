package com.etl.eproc.admin.serviceImpl;

import com.etl.eproc.admin.dto.*;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.*;
import com.etl.eproc.admin.repository.*;
import com.etl.eproc.admin.serviceI.ChargeMasterService;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ChargeMasterServiceImpl implements ChargeMasterService {
    @Autowired
    private ModelMapper mapper;
    @Autowired
    private ChargeMasterRepository chargeMasterRepository;

    @Autowired
    private UserLoginRepository userLoginRepository;
    @Autowired
    private ChargeCodeRepository chargeCodeRepository;
    @Autowired
    private AuctionCenterRepository auctionCenterRepository;
    @Autowired
    private EntityManager entityManager;

    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;

    @Autowired
    private UploadDocumentConfRepository uploadDocumentConfRepository;

    @Override
    public ApiResponse<?> createChargeMaster(ChargeMasterDto chargeMasterDto) {
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
        TblChargeCode tblChargeCode = chargeCodeRepository.findById(chargeMasterDto.getChargeCodeId()).orElseThrow(() -> new ResourceNotFoundException("TblChargeCode", "chargeCodeId", chargeMasterDto.getChargeCodeId()));
        TblAuctionCenter auctionCenter = auctionCenterRepository.findById(chargeMasterDto.getAuctionCenterId()).orElseThrow(() -> new ResourceNotFoundException("TblAuctionCenter", "auctionCenterId", chargeMasterDto.getAuctionCenterId()));
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
        TblChargeMaster tblChargeMaster = mapper.map(chargeMasterDto, TblChargeMaster.class);
        tblChargeMaster.setTblChargeCode(tblChargeCode);
        tblChargeMaster.setChargesName(tblChargeCode.getChargeCodeName());
        tblChargeMaster.setChargeType(chargeMasterDto.getChargeType());
        tblChargeMaster.setTblAuctionCenter(auctionCenter);
        tblChargeMaster.setEffectiveFromDate(chargeMasterDto.getEffectiveFromDate());
        tblChargeMaster.setEffectiveEndDate(chargeMasterDto.getEffectiveEndDate());
        tblChargeMaster.setIsActive(1);
        tblChargeMaster.setCreatedBy(tblUserLogin);
        tblChargeMaster.setCreatedOn(new Date());
        chargeMasterRepository.save(tblChargeMaster);
        ChargeMasterDto chargeMasterDtonew = mapper.map(tblChargeMaster, ChargeMasterDto.class);
        if (!chargeMasterDto.getDownloadDto()[0].getDocumentContent().isEmpty()) {
            int i = 0;
            for(int j=0;j<=chargeMasterDto.getDownloadDto().length-1;j++) {
                UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                uploadDocumentConfDto.setRemarks(chargeMasterDto.getUploadDocumentRemarks());
                uploadDocumentConfDto.setTableID(tblChargeMaster.getChargeMasterId());
                
                uploadDocumentConfDto.setFlag(1);
                uploadDocumentConfDto.setStatus(1);
                uploadDocumentConfDto.setIsActive(1);
                uploadDocumentConfDto.setDocumentSize(String.valueOf(chargeMasterDto.getDownloadDto()[i].getDocumentSize()));
                uploadDocumentConfDto.setTableName("tbl_ChargeMaster");
                uploadDocumentConfDto.setFolderName("tbl_ChargeMaster");
                uploadDocumentConfDto.setUploadDocumentName(String.valueOf(chargeMasterDto.getDownloadDto()[i].getDocumentName()));
                uploadDocumentConfDto.setUploadDocumentContent(String.valueOf(chargeMasterDto.getDownloadDto()[i].getDocumentContent()));
                TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                i++;
            }
        }
        return new ApiResponse<ChargeMasterDto>("Charge Master created successfully", 201, chargeMasterDtonew);
    }


    @Override
    public ApiResponse<?> updateChargeMaster(ChargeMasterDto chargeMasterDto) {
            TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
            TblChargeCode tblChargeCode = chargeCodeRepository.findById(chargeMasterDto.getChargeCodeId()).orElseThrow(() -> new ResourceNotFoundException("TblChargeCode", "chargeCodeId", chargeMasterDto.getChargeCodeId()));
            TblChargeMaster tblChargeMaster1 = chargeMasterRepository.findById(chargeMasterDto.getChargeMasterId()).orElseThrow(() -> new ResourceNotFoundException("TblChargeMaster", "chargeMasterId", chargeMasterDto.getChargeMasterId()));
            tblChargeMaster1.setTblChargeCode(tblChargeCode);
            tblChargeMaster1.setChargesName(tblChargeCode.getChargeCodeName());
            tblChargeMaster1.setChargeType(chargeMasterDto.getChargeType());
            tblChargeMaster1.setChargesValue(chargeMasterDto.getChargesValue());
            tblChargeMaster1.setEffectiveFromDate(chargeMasterDto.getEffectiveFromDate());
            tblChargeMaster1.setEffectiveEndDate(chargeMasterDto.getEffectiveEndDate());
            tblChargeMaster1.setIsActive(chargeMasterDto.getIsActive());
            tblChargeMaster1.setUpdatedBy(tblUserLogin);
            tblChargeMaster1.setUpdatedOn(new Date());
            chargeMasterRepository.save(tblChargeMaster1);
        ChargeMasterDto chargeMasterDtonew = mapper.map(tblChargeMaster1, ChargeMasterDto.class);
        if (!chargeMasterDto.getDownloadDto()[0].getDocumentContent().isEmpty()) {
            int i = 0;
            for(int j=0;j<=chargeMasterDto.getDownloadDto().length-1;j++) {
                UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                uploadDocumentConfDto.setRemarks(chargeMasterDto.getUploadDocumentRemarks());
                uploadDocumentConfDto.setTableID(tblChargeMaster1.getChargeMasterId());
                
                uploadDocumentConfDto.setFlag(2);
                uploadDocumentConfDto.setStatus(1);
                uploadDocumentConfDto.setIsActive(1);
                uploadDocumentConfDto.setDocumentSize(String.valueOf(chargeMasterDto.getDownloadDto()[i].getDocumentSize()));
                uploadDocumentConfDto.setTableName("tbl_FactoryType");
                uploadDocumentConfDto.setFolderName("FactoryType");
                uploadDocumentConfDto.setUploadDocumentName(String.valueOf(chargeMasterDto.getDownloadDto()[i].getDocumentName()));
                uploadDocumentConfDto.setUploadDocumentContent(String.valueOf(chargeMasterDto.getDownloadDto()[i].getDocumentContent()));
                TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                i++;
            }
        }
            return new ApiResponse<ChargeMasterDto>("Charge Master Updated successfully", 200, chargeMasterDtonew);
        }

    @Override
    public ApiResponse<ChargeMasterDto> getChargeMasterById(long chargeMasterId) {
        TblChargeMaster tblChargeMaster = chargeMasterRepository.findById(chargeMasterId).orElseThrow(() -> new ResourceNotFoundException("TblChargeMaster", "gradeId", chargeMasterId));
        ChargeMasterDto chargeMasterByid = mapper.map(tblChargeMaster, ChargeMasterDto.class);
        //chargeMasterByid.setSessionUserId(tblChargeMaster.getCreatedBy().getUserId());
        chargeMasterByid.setAuctionCenterId(tblChargeMaster.getTblAuctionCenter().getAuctionCenterId());
        chargeMasterByid.setChargeCodeId(tblChargeMaster.getTblChargeCode().getChargeCodeId());
        return new ApiResponse<ChargeMasterDto>("Charge Master get by Id successfully", 200, chargeMasterByid);
    }

    public ApiResponse<List<ChargeMasterDto>> getAllChargeMaster(){
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE).setAmbiguityIgnored(true);
        List<ChargeMasterDto> getAllChargeMasterList=chargeMasterRepository.findAll().stream().map(
                tblChargeMaster -> {
                       ChargeMasterDto chargeMasterDto = mapper.map(tblChargeMaster, ChargeMasterDto.class);
                       //chargeMasterDto.setSessionUserId(tblChargeMaster.getCreatedBy().getUserId());
                       chargeMasterDto.setAuctionCenterId(tblChargeMaster.getTblAuctionCenter().getAuctionCenterId());
                       chargeMasterDto.setChargeCodeId(tblChargeMaster.getTblChargeCode().getChargeCodeId());
                       return chargeMasterDto;
                } ).collect(Collectors.toList());
        return new ApiResponse<List<ChargeMasterDto>>("get All Charge Master Successfully" ,200,getAllChargeMasterList);
    }

    @Override
    public ApiResponse<?> getAllChargeMasterPageable(int isActive, int offset, int page) {
        Pageable pageable= PageRequest.of(page,offset);
        Optional<List<TblChargeMaster>> list =chargeMasterRepository.findAllByIsActive(isActive,pageable);
        if(!list.isEmpty() && list.isPresent()){
            List<ChargeMasterDto> dtos=list.get().stream().map(
                    tblChargeMaster -> {
                        ChargeMasterDto dto= new ChargeMasterDto();
                       dto.setChargesName(tblChargeMaster.getChargesName());
                       dto.setChargeCodeId(tblChargeMaster.getTblChargeCode().getChargeCodeId());
                       dto.setChargeType(tblChargeMaster.getChargeType());
                       dto.setChargesValue(tblChargeMaster.getChargesValue());
                       dto.setAuctionCenterId(tblChargeMaster.getTblAuctionCenter().getAuctionCenterId());
                       return dto;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse("success",200,dtos);
        }

        return new ApiResponse("No Record Found",404,null);
    }

    public ApiResponse<?> searchChargeMaster(ChargeMasterSearchDto chargeMasterSearchDto) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appmaster.Get_tbl_ChargeMaster_Search")
                .registerStoredProcedureParameter("@V_chargeMasterName", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_chargeMasterCode", String.class,ParameterMode.IN)
                .registerStoredProcedureParameter("@V_isactive", Integer.class,ParameterMode.IN)
                .setParameter("@V_chargeMasterName",chargeMasterSearchDto.getChargesName())
                .setParameter("@V_chargeMasterCode",chargeMasterSearchDto.getChargeCodeId())
                .setParameter("@V_isactive",chargeMasterSearchDto.getIsActive());
        List<Object[]> executeChargeMaster = storedProcedureQuery.getResultList();
        if(!executeChargeMaster.isEmpty()) {
            List<ChargeMasterSearchDto> chargeMasterDtos = executeChargeMaster.stream().map(
                    objects -> {
                        ChargeMasterSearchDto chargeMasterSearchDto1 = new ChargeMasterSearchDto();
                        chargeMasterSearchDto1.setChargeMasterId(Long.valueOf(objects[0].toString()));
                        ;
                        chargeMasterSearchDto1.setChargesName((String) objects[1]);
                        chargeMasterSearchDto1.setChargeCodeId((String) objects[2]);
                        chargeMasterSearchDto1.setIsActive((Boolean) objects[3] == true ? 1 : 0);
                        return chargeMasterSearchDto1;

                    }
            ).collect(Collectors.toList());
            return new ApiResponse<>("getBySearch Success", 200, chargeMasterDtos);
        }
        return new ApiResponse<>(("No Record Found"),404,null);
    }

    @Override
    public ApiResponse<?> getAllUploadedDocument() {
        Optional<List<TblUploadDocumentConf>> tblUploadDocumentConf= uploadDocumentConfRepository.findAllUploadDocument("tbl_chargeMaster");

        List<DownloadDto> downloadDtos = tblUploadDocumentConf.get().stream().map(
                tblUploadDocument ->{
                    DownloadDto downloadDto = new DownloadDto();
                    downloadDto.setUploadDocumentConfId(tblUploadDocument.getUploadDocumentConfId());
                    downloadDto.setUploadDocumentRemarks(tblUploadDocument.getRemarks());
                    downloadDto.setDocumentUploadTime(tblUploadDocument.getCreatedOn());
                    return downloadDto;
                }).collect(Collectors.toList());
        return  new ApiResponse<List<DownloadDto>>("success" ,200,downloadDtos);
    }

    @Override
    public ApiResponse<?> getUploadedDocumentById(long id) throws IOException {
        DownloadDto download = uploadDocumentConfService.downloadDocument(id);
        DownloadDto downloadDto = new DownloadDto();
        downloadDto.setDocumentName(download.getDocumentName());
        downloadDto.setDocumentContent(download.getDocumentContent());
        return  new ApiResponse<DownloadDto>("success" ,200,downloadDto);
    }

}



