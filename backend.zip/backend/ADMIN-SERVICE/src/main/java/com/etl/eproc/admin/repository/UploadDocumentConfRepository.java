package com.etl.eproc.admin.repository;

import com.etl.eproc.admin.model.TblUploadDocumentConf;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UploadDocumentConfRepository extends JpaRepository<TblUploadDocumentConf,Long> {

    @Query(value = "select top 1 * from appmaster.tbl_UploadDocumentConf order by 1 desc",nativeQuery = true)
    TblUploadDocumentConf findbyPath(long id,String tableName);

    @Query(value = "select top 1 * from [appmaster].[tbl_UploadDocumentConf] where tableID=:id and tableName=:tableName order by 1 desc",nativeQuery = true)
    TblUploadDocumentConf updateIsActive(long id,String tableName);

    @Query(value = "select * from appmaster.tbl_UploadDocumentConf where tableName=:tableName order by 1 desc",nativeQuery = true)
    Optional<List<TblUploadDocumentConf>> findAllUploadDocument(String tableName);
}
