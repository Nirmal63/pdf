package com.etl.eproc.admin.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;


@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbl_Factory" , schema = "appuser")
public class TblFactory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long factoryId;
    private String factoryName;
    private String tbRegistrationNo;
    @ManyToOne
    @JoinColumn(name = "userId")
    private TblUserLogin tblUserLogin;
    @ManyToOne
    @JoinColumn(name = "factoryTypeId")
    private TblFactoryType tblFactoryType;
    @ManyToOne
    @JoinColumn(name = "revenueId")
    private TblRevenue tblRevenue;
    private int isActive;
    private String address;
    private String city;
    private String contactPerson;
    private String email;
    private String fax;
    private String gstNo;
    private String panNo;
    private String mobileNo;

    private String phoneNo;
    private String  taxIdentityNo;
    private String fssaiNo;

    /*@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY,mappedBy = "factory")
    private List<TblMark> marks;
*/
    @ManyToOne
    @JoinColumn(name = "createdBy")
    private TblUserLogin createdBy;

    @Column(name = "createdOn")
    private Date createdOn;

    @ManyToOne
    @JoinColumn(name = "updatedBy")
    private TblUserLogin updatedBy;

    @Column(name = "updatedOn")
    private Date updatedOn;
}
