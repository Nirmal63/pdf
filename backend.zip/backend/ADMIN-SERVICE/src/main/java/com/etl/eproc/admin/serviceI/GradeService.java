package com.etl.eproc.admin.serviceI;

import com.etl.eproc.admin.dto.GradeDto;
import com.etl.eproc.admin.util.ApiResponse;

import java.io.IOException;
import java.util.List;

public interface GradeService {
    ApiResponse<?> createGrade(GradeDto gradeDto) ;

    ApiResponse<?>  updateGrade(GradeDto gradeDto);

    ApiResponse<GradeDto>  getGradeById(long gradeId);

    ApiResponse<List<GradeDto>> getAllGrade();

   ApiResponse<?> getAllGradePageable(int cStatus, int offset, int page);

   ApiResponse<?> searchGrade(GradeDto gradeDto);

    ApiResponse<?> getAllUploadedDocument();

    ApiResponse<?> getUploadedDocumentById(long id) throws IOException;
}
