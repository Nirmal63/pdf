package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.MarkDto;
import com.etl.eproc.admin.dto.MarkSearchDto;
import com.etl.eproc.admin.dto.StateDto;
import com.etl.eproc.admin.model.TblMark;
import com.etl.eproc.admin.serviceI.MarkService;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/admin/mark")
public class MarkController {

    @Autowired
    private MarkService markService;

    @PostMapping(value = "/create")
    public ApiResponse<MarkDto >  createMark(@Valid @RequestBody MarkDto markDto){
        try {
            return markService.createMark(markDto );
        } catch (Exception e){
            return new  ApiResponse<>(e.getMessage(),500,null);
        }
    }

    @GetMapping("/get/{markId}")
    public ApiResponse<MarkDto> createMark(@PathVariable("markId") Long markId){
        try {
            return markService. getMarkById(markId);
        } catch (Exception e){
            return new  ApiResponse<>(e.getMessage(),500,null);
        }
    }

   /* @GetMapping("/getAll")
    public ApiResponse<List<MarkDto>> getMarkById(){
        try {
            return markService.getAllMark();
        } catch (Exception e){
            return new  ApiResponse<>(e.getMessage(),500,null);
        }
    }*/

    @PostMapping(value = "/update")
    public ApiResponse<MarkDto>  updateMark( @Valid @RequestBody MarkDto markDto){
        try {
            return markService.updateMark(markDto);
        } catch (Exception e){
            return new ApiResponse<>(e.getMessage(),500,null);
        }
    }

   /* @GetMapping("/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> searchMarkPageable(@PathVariable("isActive") int isActive,@PathVariable("offset") int offset,@PathVariable("page") int page) {
        try {
            return markService.searchMarkPageable(isActive,offset,page);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }*/

    @PostMapping("/search")
    public ApiResponse<?> searchMark(@RequestBody MarkSearchDto markSearchDto) {
        try {
            return markService.searchMarks(markSearchDto);
        } catch (Exception e) {
            return new ApiResponse<TblMark>(e.getMessage(), 500, null);
        }
    }
}
