package com.etl.eproc.admin.serviceImpl;


import com.etl.eproc.admin.dto.CategoryDto;
import com.etl.eproc.admin.dto.DownloadDto;
import com.etl.eproc.admin.dto.TestDTO;
import com.etl.eproc.admin.dto.UploadDocumentConfDto;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.TblCategory;
import com.etl.eproc.admin.model.TblUploadDocumentConf;
import com.etl.eproc.admin.model.TblUserLogin;
import com.etl.eproc.admin.repository.CategoryRepository;
import com.etl.eproc.admin.repository.UploadDocumentConfRepository;
import com.etl.eproc.admin.repository.UserLoginRepository;
import com.etl.eproc.admin.serviceI.CategoryService;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import com.etl.eproc.admin.util.SearchResponce;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    private ModelMapper mapper;
    @Autowired
    private CategoryRepository categoryRepository;
    @Autowired
    private UserLoginRepository userLoginRepository;
    @Autowired
    private EntityManager entityManager;
    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;
    @Autowired
    private UploadDocumentConfRepository uploadDocumentConfRepository;
    @Override
    public ApiResponse<?> createCategory(CategoryDto categoryDto) {
    try {
    TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
    boolean CategoryCodeISexists = categoryRepository.existsByCategoryCode(categoryDto.getCategoryCode());
    boolean CategoryNameISexists =categoryRepository.existsByCategoryName(categoryDto.getCategoryName());
    if (!CategoryCodeISexists) {
        if (!CategoryNameISexists){
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setAmbiguityIgnored(true);
        TblCategory tblCategory = mapper.map(categoryDto, TblCategory.class);
        tblCategory.setCreatedOn(new Date());
        tblCategory.setCreatedBy(tblUserLogin);
        tblCategory.setIsActive(1);
        TblCategory tblCategorynew = categoryRepository.save(tblCategory);
        CategoryDto categoryDtonew = mapper.map(tblCategory, CategoryDto.class);
//            if (!categoryDto.getDownloadDto()[0].getDocumentContent().isEmpty()) {
                int i = 0;
                for(int j=0;j<=categoryDto.getDownloadDto().length-1;j++) {
                    UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                    uploadDocumentConfDto.setRemarks(categoryDto.getUploadDocumentRemarks());
                    uploadDocumentConfDto.setTableID(tblCategory.getCategoryId());
                    uploadDocumentConfDto.setDocumentSize(String.valueOf(categoryDto.getDownloadDto()[i].getDocumentSize()));
                    uploadDocumentConfDto.setTableName("tbl_Category");
                    uploadDocumentConfDto.setFolderName("Category");
//                    uploadDocumentConfDto.setUploadDocumentName(String.valueOf(categoryDto.getDownloadDto()[i].getDocumentName()));
//                    uploadDocumentConfDto.setUploadDocumentContent(String.valueOf(categoryDto.getDownloadDto()[i].getDocumentContent()));
                    TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                    i++;
                }
//            }

                 return new ApiResponse<>("Category created successfully", 201, null);
        } else {
            return new ApiResponse<>("Category name must be unique. The entered value already exists.", 400, null);
        }
         } else {
                return new ApiResponse<>("Category code must be unique. The entered value already exists.", 400, null);
        }
        }catch (Exception e){
                 return new ApiResponse<>(e.getMessage(),500, null);
        }
        }

    @Override
    public ApiResponse<?> updateCategory(CategoryDto categoryDto) {
        try {

            TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));
            boolean tblCategory1 = categoryRepository.existsByCategoryCode(categoryDto.getCategoryCode());

            if (!tblCategory1) {
                TblCategory tblCategory = categoryRepository.findById(categoryDto.getCategoryId()).orElseThrow(() -> new ResourceNotFoundException("TblCategory", "CategoryId", categoryDto.getCategoryId()));
                tblCategory.setCategoryName(categoryDto.getCategoryName());
                tblCategory.setCategoryCode(categoryDto.getCategoryCode());
                tblCategory.setIsActive(categoryDto.getIsActive());
                tblCategory.setUpdatedBy(tblUserLogin);
                tblCategory.setUpdatedOn(new Date());
                TblCategory tblCategoryNew = categoryRepository.save(tblCategory);
                CategoryDto categoryDtoNew = mapper.map(tblCategoryNew, CategoryDto.class);
//                if (!categoryDto.getDownloadDto()[0].getDocumentContent().isEmpty()) {
                    int i = 0;
                   TestDTO[] categoryDtoNew1= new TestDTO[]{categoryDto.getDownloadDto()[i]};
                    UploadDocumentConfDto dto =mapper.map(categoryDto.getDownloadDto()[i],UploadDocumentConfDto.class);

                    for(int j=0;j<=categoryDto.getDownloadDto().length-1;j++) {
//                        UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                        UploadDocumentConfDto uploadDocumentConfDto=mapper.map(categoryDtoNew1,UploadDocumentConfDto.class);
//                        uploadDocumentConfDto.setRemarks(categoryDto.getUploadDocumentRemarks());
//                        uploadDocumentConfDto.setTableID(tblCategory.getCategoryId());
//                        uploadDocumentConfDto.setDocumentSize(String.valueOf(categoryDto.getDownloadDto()[i].getDocumentSize()));
                        uploadDocumentConfDto.setTableName("tbl_Category");
                        uploadDocumentConfDto.setFolderName("Category");
//                        uploadDocumentConfDto.setUploadDocumentName(String.valueOf(categoryDto.getDownloadDto()[i].getDocumentName()));
//                        uploadDocumentConfDto.setUploadDocumentContent(String.valueOf(categoryDto.getDownloadDto()[i].getDocumentContent()));
                        TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                        i++;
                    }
//                }

                return new ApiResponse<>("Category Updated successfully", 201, categoryDtoNew);
            } else {
                return new ApiResponse<>("Category already exists", 400, null);
            }
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 400, null);
        }

    }

    @Override
     public SearchResponce getAllCategory(CategoryDto categoryDto) {

//        Pageable pageable = PageRequest.of(pageNo, pageSize);
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appmaster.Get_tbl_Category_Search")
                .registerStoredProcedureParameter("@V_CategoryName", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_CategoryCode", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_isactive", Integer.class,ParameterMode.IN)

//                .registerStoredProcedureParameter("@V_StartPage", Integer.class, ParameterMode.IN)
//                .registerStoredProcedureParameter("@V_EndPage", Integer.class, ParameterMode.IN)
                .setParameter("@V_CategoryName", categoryDto.getCategoryName())
                .setParameter("@V_CategoryCode", categoryDto.getCategoryCode())
                .setParameter("@V_isactive",categoryDto.getIsActive());;
//                .setParameter("@V_StartPage", 0)
//                .setParameter("@V_EndPage", 10);
        List<Object[]> execute = storedProcedureQuery.getResultList();
        List<CategoryDto> CategoryDtos = execute.stream().map(
                objects ->{
                    CategoryDto CategoryDto1 = new CategoryDto();
                    CategoryDto1.setCategoryId(Long.valueOf(objects[0].toString()));
                    CategoryDto1.setCategoryName((String) objects[1]);
                    CategoryDto1.setCategoryCode((String) objects[2]);
                    CategoryDto1.setIsActive((Boolean)objects[3]==true?1:0);
                    return CategoryDto1;
                }
        ).collect(Collectors.toList());

//        Page<TblCategory> tblCategories =categoryRepository.findAll(pageable);
        SearchResponce searchResponce = new SearchResponce();
        searchResponce.setContent(CategoryDtos);

//        searchResponce.setPageNo(tblCategories.getNumber());
//        searchResponce.setPageSize(tblCategories.getSize());
//        searchResponce.setTotalElements(tblCategories.getTotalElements());
//        searchResponce.setTotalPages(tblCategories.getTotalPages());

         return searchResponce;

    }
    @Override
    public ApiResponse<List<CategoryDto>> getAllCategorys(int isActive) {
//        Pageable pageable= PageRequest.of(page,offset);

        Optional<List<TblCategory>> tblCategories=categoryRepository.findAllByIsActive(isActive);
        if(!tblCategories.isEmpty() && tblCategories.isPresent()) {
            List<CategoryDto> categoryDtos = tblCategories.get().stream().map(
                    tblCategory ->{
                        CategoryDto categoryDto = new CategoryDto();
                        categoryDto.setCategoryId(tblCategory.getCategoryId());
                        categoryDto.setCategoryName(tblCategory.getCategoryName());
                        categoryDto.setIsActive(tblCategory.getIsActive());
                        categoryDto.setCategoryCode(tblCategory.getCategoryCode());
                        return categoryDto;
                    }).collect(Collectors.toList());
            return new ApiResponse("success",200,categoryDtos);
        }
        return new ApiResponse("failed",500,null);
    }

    @Override
    public ApiResponse<?> getCategoryId(long categoryId) {
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE).setAmbiguityIgnored(true);
        TblCategory category = categoryRepository.findById(categoryId).orElseThrow(()->new ResourceNotFoundException("TblAuctionCenter","auctionCenterId",categoryId));
        CategoryDto  categoryDto = mapper.map(category,CategoryDto.class);
        return  new ApiResponse<CategoryDto>("Category get by Id successfully" ,200,categoryDto);
    }

    @Override
    public ApiResponse<?> getAllUploadDocument() {
        Optional<List<TblUploadDocumentConf>> tblUploadDocumentConf= uploadDocumentConfRepository.findAllUploadDocument("tbl_Category");

        List<DownloadDto> downloadDtos = tblUploadDocumentConf.get().stream().map(
                tblUploadDocument ->{
                    DownloadDto downloadDto = new DownloadDto();
                    downloadDto.setUploadDocumentConfId(tblUploadDocument.getUploadDocumentConfId());
                    downloadDto.setUploadDocumentRemarks(tblUploadDocument.getRemarks());
                    downloadDto.setDocumentUploadTime(tblUploadDocument.getCreatedOn());
                    return downloadDto;
                }).collect(Collectors.toList());
        return  new ApiResponse<List<DownloadDto>>("success" ,200,downloadDtos);
    }

    @Override
    public ApiResponse<?> getUploadDocumentById(long id) throws IOException {
        DownloadDto download = uploadDocumentConfService.downloadDocument(id);
         DownloadDto downloadDto = new DownloadDto();
         downloadDto.setDocumentName(download.getDocumentName());
         downloadDto.setDocumentContent(download.getDocumentContent());
        return  new ApiResponse<DownloadDto>("success" ,200,downloadDto);
    }

}



