package com.etl.eproc.admin.serviceImpl;

import com.etl.eproc.admin.dto.SubTeaTypeDto;
import com.etl.eproc.admin.dto.UploadDocumentConfDto;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.TblSubTeaType;
import com.etl.eproc.admin.model.TblTeaType;
import com.etl.eproc.admin.model.TblUploadDocumentConf;
import com.etl.eproc.admin.model.TblUserLogin;
import com.etl.eproc.admin.repository.SubTeaTypeRepository;
import com.etl.eproc.admin.repository.TeaTypeRepository;
import com.etl.eproc.admin.repository.UserLoginRepository;
import com.etl.eproc.admin.serviceI.SubTeaTypeService;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class SubTeaTypeServiceImpl implements SubTeaTypeService {

    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;
    @Autowired
    private SubTeaTypeRepository subTeaTypeRepository;

    @Autowired
    private UserLoginRepository userLoginRepository;
    @Autowired
    private ModelMapper mapper;

    @Autowired
    private EntityManager entityManager;
    @Autowired
    private TeaTypeRepository teaTypeRepository;
    @Override
    public ApiResponse<?> createSubTeaType(SubTeaTypeDto subTeaTypeDto) {
        boolean subTeaTypeduplicatename = subTeaTypeRepository.existsBySubTeaTypeName(subTeaTypeDto.getSubTeaTypeName());
        boolean subTeaTypeduplicatecode = subTeaTypeRepository.existsBySubTeaTypeCode(subTeaTypeDto.getSubTeaTypeCode());
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin","userId",1));
        if(!subTeaTypeduplicatename && !subTeaTypeduplicatecode) {
            TblSubTeaType subTeaType = new TblSubTeaType();
            TblTeaType teaType = teaTypeRepository.findById(subTeaTypeDto.getTeaTypeId()).orElseThrow(
                    () -> new ResourceNotFoundException("TeaType", "teaTypeId", subTeaTypeDto.getTeaTypeId())
            );
            subTeaType.setTeaType(teaType);
            subTeaType.setSubTeaTypeName(subTeaTypeDto.getSubTeaTypeName());
            subTeaType.setSubTeaTypeCode(subTeaTypeDto.getSubTeaTypeCode());
            subTeaType.setIsActive(1);
            subTeaType.setCreatedBy(tblUserLogin);
            subTeaType.setCreatedOn(subTeaTypeRepository.getServerDateTime());

            TblSubTeaType save = subTeaTypeRepository.save(subTeaType);
            SubTeaTypeDto subTeaTypeDto1 = mapToDto(save);


            if (subTeaTypeDto.getUploadDocumentContent() != null) {
                int i = 0;
                for (String DocumenName:subTeaTypeDto.getUploadDocumentName()) {
                    UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                    uploadDocumentConfDto.setRemarks(subTeaTypeDto.getUploadDocumentRemarks());
                    uploadDocumentConfDto.setTableID(subTeaType.getSubTeaTypeId());
                    uploadDocumentConfDto.setFlag(1);
                    uploadDocumentConfDto.setStatus(1);
                    uploadDocumentConfDto.setIsActive(1);
                    uploadDocumentConfDto.setDocumentSize(subTeaTypeDto.getUploadDocumentSize());
                    uploadDocumentConfDto.setTableName("tbl_SubTeaType");
                    uploadDocumentConfDto.setFolderName("SubTeaType");
                    uploadDocumentConfDto.setUploadDocumentName(DocumenName);
                    uploadDocumentConfDto.setUploadDocumentContent(subTeaTypeDto.getUploadDocumentContent()[i]);
                    TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                    i++;
                }
            }
            return new ApiResponse<>("Sub Tea Type created Successfully ", 200, subTeaTypeDto1);
        }else if (subTeaTypeduplicatename) {
            return new ApiResponse<>("Sub tea type name must be unique. The entered value already exists.", 400, null);
        } else  {
            return new ApiResponse<>("Sub tea type code must be unique. The entered value already exists.", 400, null);
        }
        
    }

    @Override
    public  ApiResponse<?> getAllSubTeaType() {

        List<TblSubTeaType> page = subTeaTypeRepository.findAll();
        List<SubTeaTypeDto> collect = page.stream().map(t -> mapToDto(t)).collect(Collectors.toList());
        return  new ApiResponse<>("get SubTeaType By Id " ,200,collect) ;
    }

    @Override
    public  ApiResponse<?> updateSubTeaType(SubTeaTypeDto subTeaTypeDto) {
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin","userId",1));
        TblSubTeaType subTeaType = subTeaTypeRepository.findById(subTeaTypeDto.getSubTeaTypeId()).orElseThrow(
                () -> new ResourceNotFoundException("SubTeaType", "SubTeaTypeId", subTeaTypeDto.getSubTeaTypeId())
        );
        TblTeaType tblTeaType = teaTypeRepository.findById(subTeaTypeDto.getTeaTypeId()).orElseThrow(
                () -> new ResourceNotFoundException("TeaType", "teaTypeId", subTeaTypeDto.getTeaTypeId())
        );
        subTeaType.setTeaType(tblTeaType);

        subTeaType.setSubTeaTypeName(subTeaTypeDto.getSubTeaTypeName());
        subTeaType.setSubTeaTypeCode(subTeaTypeDto.getSubTeaTypeCode());
        subTeaType.setIsActive(1);

        subTeaType.setUpdatedBy(tblUserLogin);
        subTeaType.setUpdatedOn(subTeaTypeRepository.getServerDateTime());
        TblSubTeaType subTeaType1 = subTeaTypeRepository.save(subTeaType);
        SubTeaTypeDto subTeaTypeDto1 = mapToDto(subTeaType1);
        if (subTeaTypeDto.getUploadDocumentContent() != null) {
            int i = 0;
            for (String DocumenName:subTeaTypeDto.getUploadDocumentName()) {
                UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                uploadDocumentConfDto.setRemarks(subTeaTypeDto.getUploadDocumentRemarks());
                uploadDocumentConfDto.setTableID(subTeaType.getSubTeaTypeId());
                uploadDocumentConfDto.setFlag(1);
                uploadDocumentConfDto.setStatus(1);
                uploadDocumentConfDto.setIsActive(1);
                uploadDocumentConfDto.setDocumentSize(subTeaTypeDto.getUploadDocumentSize());
                uploadDocumentConfDto.setTableName("tbl_SubTeaType");
                uploadDocumentConfDto.setFolderName("SubTeaType");
                uploadDocumentConfDto.setUploadDocumentName(DocumenName);
                uploadDocumentConfDto.setUploadDocumentContent(subTeaTypeDto.getUploadDocumentContent()[i]);
                TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                i++;
            }
        }
        return  new ApiResponse<>("SubTeaType Updated Successfully " ,200,subTeaTypeDto1) ;
    }

    @Override
    public  ApiResponse<?> findSubTeaTypeById(int subTeaTypeId) {
        TblSubTeaType subTeaType = subTeaTypeRepository.findById(subTeaTypeId).orElseThrow(
                () -> new ResourceNotFoundException("SubTeaTypeDto", "SubTeaTypeId", subTeaTypeId)
        );
        SubTeaTypeDto subTeaTypeDto = mapToDto(subTeaType);
        return  new ApiResponse<>("get SubTeaType By Id " ,200,subTeaTypeDto) ;
    }

    @Override
    public ApiResponse<?> searchSubTeaTypePageable(int isActive, int offset, int page) {
        Pageable pageable= PageRequest.of(page,offset);
        Optional<List<TblSubTeaType>> list =subTeaTypeRepository.findAllByIsActive(isActive,pageable);

        if(!list.isEmpty() && list.isPresent()){
            List<SubTeaTypeDto> dtos=list.get().stream().map(
                    tblSubTeaType -> {
                        SubTeaTypeDto dto= new SubTeaTypeDto();
                        dto.setSubTeaTypeId(tblSubTeaType.getSubTeaTypeId());
                        dto.setSubTeaTypeName(tblSubTeaType.getSubTeaTypeName());
                        dto.setSubTeaTypeCode(tblSubTeaType.getSubTeaTypeCode());
                        TblTeaType teaType = tblSubTeaType.getTeaType();
                        dto.setTeaTypeName(teaType.getTeaTypeName());
                        dto.setIsActive(tblSubTeaType.getIsActive());
                        return dto;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse("success",200,dtos);
        }

        return new ApiResponse("success",200,null);
    }

    @Override
    public ApiResponse<?> searchSubTeaType(SubTeaTypeDto subTeaTypeDto) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appmaster.Get_tbl_SubTeaType_Search")
                .registerStoredProcedureParameter("@V_subTeaTypeName",String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_subTeaTypeCode",String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_teaTypeName",String.class, ParameterMode.IN)

                .setParameter("@V_subTeaTypeName",subTeaTypeDto.getSubTeaTypeName())
                .setParameter("@V_subTeaTypeCode",subTeaTypeDto.getSubTeaTypeCode())
                .setParameter("@V_teaTypeName",subTeaTypeDto.getTeaTypeName());

        List<Object[]> execute = storedProcedureQuery.getResultList();
        List<SubTeaTypeDto> subTeaTypeDtos = execute.stream().map(
                objects ->{
                    SubTeaTypeDto subTeaTypeDto1 = new SubTeaTypeDto();
                    subTeaTypeDto1.setSubTeaTypeId(Integer.parseInt(objects[0].toString()));
                    subTeaTypeDto1.setSubTeaTypeName((String) objects[1]);
                    subTeaTypeDto1.setSubTeaTypeCode((String) objects[2]);
                    subTeaTypeDto1.setTeaTypeName((String) objects[3]);
                    subTeaTypeDto1.setIsActive((Boolean)objects[4]==true?1:0);
                    return subTeaTypeDto1;
                }
        ).collect(Collectors.toList());

        return new ApiResponse<List<SubTeaTypeDto>>("getAll Success",200 ,subTeaTypeDtos);
    }


    private SubTeaTypeDto mapToDto(TblSubTeaType subTeaType) {
      return mapper.map(subTeaType,SubTeaTypeDto.class);
    }

    private TblSubTeaType maptoEntity(SubTeaTypeDto subTeaTypeDto) {
        return mapper.map(subTeaTypeDto, TblSubTeaType.class);
    }


}
