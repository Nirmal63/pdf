package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.AuctioneerDto;
import com.etl.eproc.admin.serviceI.AuctioneerService;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.IOException;

@RestController
@RequestMapping("/admin/auctioneer")
public class AuctioneerController {
    @Autowired
    private AuctioneerService auctioneerService;

    @PostMapping(value = "/create")
    public ApiResponse<?> createAuctioneer(@Valid @RequestBody AuctioneerDto auctioneerDto) {
        try {

            return auctioneerService.createAuctioneer(auctioneerDto);
        } catch (Exception e) {
            return new ApiResponse<>(e.getMessage(), 500, null);
        }

    }

    @PostMapping(value = "/update")
    public ApiResponse<?> updateAuctioneer( @Valid @RequestBody  AuctioneerDto auctioneerDto) {
        try {
            return auctioneerService.updateAuctioneer(auctioneerDto);
        } catch (Exception e) {
            return new ApiResponse<>(e.getMessage(), 500, null);
        }
    }

    @GetMapping("/getAllAuctioneer/{userType}")
    public ApiResponse<?> getAllAuctioneerByType(@PathVariable long userType) {
        try {
            return auctioneerService.getAllAuctioneer(userType);
        } catch (Exception e) {
            return new ApiResponse<>(e.getMessage(), 500, null);
        }
    }

    @GetMapping("/getAuctioneerById/{userId}")
    public ApiResponse<?> getAuctioneerById(@PathVariable long userId) {
        try {
            return auctioneerService.getAuctioneerById(userId);
        } catch (Exception e) {
            return new ApiResponse<>(e.getMessage(), 500, null);
        }
    }

   /* @GetMapping(value = "/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> getAllAuctioneerPageable(@PathVariable("isActive") int isActive, @PathVariable("offset") int offset, @PathVariable("page") int page) {

        try {
            return auctioneerService.getAllAuctioneerPageable(isActive, offset, page);
        } catch (Exception e) {
            return new ApiResponse<>(e.getMessage(), 500, null);
        }
    }*/

    @PostMapping(value = "/validateUser")
    public ApiResponse<?> validateUser(@RequestParam(name = "email",required = false) String email,
                                       @RequestParam(name = "userCode",required = false)String userCode,
                                       @RequestParam(name = "teaBoardRegistrationNo",required = false)String teaBoardRegistrationNo,
                                       @RequestParam(name = "taxIdentityNo",required = false) String taxIdentityNo,
                                       @RequestParam(name = "panNo",required = false)String panNo,
                                       @RequestParam(name = "gstNo",required = false)String gstNo,
                                       @RequestParam(name = "fssaiNo",required = false) String fssaiNo,
                                       @RequestParam(name = "cinNo",required = false)String cinNo) {
        try {
            return auctioneerService.validateUser(email,userCode,teaBoardRegistrationNo,taxIdentityNo,panNo,gstNo,fssaiNo,cinNo);
        } catch (Exception e) {
            return new ApiResponse<>(e.getMessage(), 500, null);
        }
    }
    @GetMapping("/getalluploadeddocument")
    public ApiResponse<?> getAllDocument(){
        return new ApiResponse<>("success",200,auctioneerService.getAllUploadedDocument());
    }

    @GetMapping("/getdocument/{uploadeddocumentId}")
    public ApiResponse<?> getuploadDocument(@PathVariable("uploadeddocumentId") long id) throws IOException {
        return new ApiResponse<>("success",200,auctioneerService.getUploadedDocumentById(id));

    }
}


