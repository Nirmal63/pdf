package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SPUMasterDto {


    private int spuMasterId;
    private int auctionCenterId;
    private int teaTypeId;
    private long gradeId;
    @NotEmpty(message = "Please select period")
    private String manufacturingPeriod;
    @NotNull(message = "Please enter Lot Size")
    private String spuQuantity;
    @NotNull(message = "Please enter the SPU Quantity")
    private String minLotSize;
    @NotNull(message = "Please enter capacity")
    private String factoryAnnualCapacity;
    private int isActive;
    private String uploadDocumentRemarks;
    private String[] uploadDocumentContent;
    private String[] uploadDocumentName;
    private String uploadDocumentSize;

}
