package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.WareHouseUserRegDto;
import com.etl.eproc.admin.serviceI.WareHouseUserRegService;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/admin/WareHouseUserReg")
public class WareHouseUserRegController {

    @Autowired
    private WareHouseUserRegService wareHouseUserRegService;

    @PostMapping(value = "/create")
    public ApiResponse<?> saveWareHouseUser(@Valid @RequestBody WareHouseUserRegDto wareHouseUserRegDto) {
        try {
            return wareHouseUserRegService.createWareHouseUser(wareHouseUserRegDto);
        } catch (Exception e) {
            return new ApiResponse<>(e.getMessage(), 500,null);

        }
    }

    @GetMapping("/get/{wareHouseUserRegId}")
    public ApiResponse<WareHouseUserRegDto> getWareHouseUserById(@PathVariable(name ="wareHouseUserRegId") long wareHouseUserRegId){
        try {
            return wareHouseUserRegService.getWareHouseUserById(wareHouseUserRegId);
        }catch(Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);

        }
    }

    @GetMapping("/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> getAllWareHouseUser(@PathVariable("isActive") int isActive, @PathVariable("offset") int offset, @PathVariable("page") int page){
        try {
            ApiResponse<?> taxMaster = wareHouseUserRegService.getAllWareHouseUser(isActive, offset, page);
            return taxMaster;
        }catch(Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);

        }
    }

    @PostMapping(value = "/update")
    public ApiResponse<?> updateWareHouseUser(@Valid  @RequestBody WareHouseUserRegDto wareHouseUserRegDto){
        try {
            ApiResponse<?> wareHouseUserRegDtoApiResponse = wareHouseUserRegService.updateWareHouseUserBy(wareHouseUserRegDto);
            return wareHouseUserRegDtoApiResponse;
        }catch(Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }


    @PostMapping("/search")
    public ApiResponse<List<WareHouseUserRegDto>> searchBy(@RequestParam(name = "auctionCenter",required = false) Long auctionCenterId,
                                                           @RequestParam(name = "wareHouseCode",required = false) String wareHouseCode){
        try {
            ApiResponse<List<WareHouseUserRegDto>> searchWareHouseUser = wareHouseUserRegService.searchWareHouseUser(auctionCenterId,wareHouseCode);
            return searchWareHouseUser;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);

        }
    }

    @GetMapping("/validateUser")
    public ApiResponse<?> validateUser(@RequestParam (name = "wareHouseCode",required = false)String wareHouseCode,
                                       @RequestParam (name = "wareHouseLicenceNo",required = false)String wareHouseLicenceNo,
                                       @RequestParam (name = "taxIdentificationNo",required = false)String taxIdentificationNo,
                                       @RequestParam (name = "PanNo",required = false)String PanNo,
                                       @RequestParam (name = "gstNo",required = false)String gstNo,
                                       @RequestParam (name = "teaBoardRegistrationNo",required = false)String teaBoardRegistrationNo){
        try{
            return wareHouseUserRegService.validateUser(wareHouseCode,wareHouseLicenceNo,taxIdentificationNo,teaBoardRegistrationNo,PanNo,gstNo);
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);

        }
    }

    @GetMapping("/getAllUploaddocument")
    public ApiResponse<?> getAllDocument(){
        return new ApiResponse<>("success",200,wareHouseUserRegService.getAllUploadDocument());
    }

    @GetMapping("/getById/{uploaddocumentId}")
    public ApiResponse<?> getUploadDocument(@PathVariable("uploaddocumentId") long id) throws IOException {
        return new ApiResponse<>("success",200,wareHouseUserRegService.getUploadDocumentById(id));

    }

}
