package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PlantationDto {

    private long plantationId;

    @NotEmpty(message = "please enter plantation district name")
    @Size(min = 2,max = 50,message = "The plantation district name should be  at least 2 characters long and not exceed 50 characters")
    private String plantationDistrictName;

    @NotNull(message = "Please select State")
    private  long stateId;


    private Integer isActive;

    private String uploadDocumentRemarks;

    private String[] uploadDocumentContent;

    private String[] uploadDocumentName;

    private String uploadDocumentSize;

}
