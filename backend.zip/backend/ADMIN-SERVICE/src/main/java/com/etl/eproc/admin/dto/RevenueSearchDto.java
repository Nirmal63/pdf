package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RevenueSearchDto {

    private String revenueDistrictName;

    private Long plantationId;

    private  Long stateId;

    private Integer isActive;


}
