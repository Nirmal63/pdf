package com.etl.eproc.admin.controller;

import com.etl.eproc.admin.dto.TaxMasterDto;
import com.etl.eproc.admin.dto.TaxMasterSearchDto;
import com.etl.eproc.admin.serviceI.TaxMasterService;
import com.etl.eproc.admin.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("admin/Taxmaster")
public class TaxMasterController {

    @Autowired
    private TaxMasterService taxMasterService;

    @PostMapping(value = "/create")
    public ApiResponse<?> saveTaxData(@Valid @RequestBody TaxMasterDto taxMasterDto) {

        try {
            return taxMasterService.createtax(taxMasterDto);
        } catch (Exception e) {
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }

    @GetMapping("/get/{taxMasterId}")
    public ApiResponse<TaxMasterDto> getTaxById(@PathVariable(name ="taxMasterId") long taxMasterId){
        try {
            ApiResponse<TaxMasterDto> taxdto = taxMasterService.getTaxMasterById(taxMasterId);
            return taxdto;
        }catch(Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }

    @GetMapping("/getAll/{isActive}/{offset}/{page}")
    public ApiResponse<?> getAllTaxMaster(@PathVariable("isActive") int isAcive, @PathVariable("offset") int offset, @PathVariable("page") int page){
        try {
            ApiResponse<?> taxMaster = taxMasterService.getAllTaxMaster(isAcive, offset, page);
            return taxMaster;
        }catch(Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }

    @PostMapping(value = "/update")
    public ApiResponse<?> updateData(@Valid  @RequestBody TaxMasterDto taxMasterDto){
        try {
            ApiResponse<?> taxMaster = taxMasterService.updateTaxMasterBy(taxMasterDto);
            return taxMaster;
        }catch(Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }
    @PostMapping("/search")
    public ApiResponse<List<TaxMasterSearchDto>> searchBy(@RequestBody TaxMasterSearchDto taxMasterSearchDto){
        try {

            ApiResponse<List<TaxMasterSearchDto>> searchTaxMaster = taxMasterService.searchTaxMaster(taxMasterSearchDto);
            return searchTaxMaster;
        }catch (Exception e){
            return new ApiResponse<>(e.getMessage(), 500,null);
        }
    }

    @GetMapping("/getAllUploaddocument")
    public ApiResponse<?> getAllDocument(){
        return new ApiResponse<>("success",200,taxMasterService.getAllUploadDocument());
    }

    @GetMapping("/getById/{uploaddocumentId}")
    public ApiResponse<?> getUploadDocument(@PathVariable("uploaddocumentId") long id) throws IOException {
        return new ApiResponse<>("success",200,taxMasterService.getUploadDocumentById(id));

    }


}
