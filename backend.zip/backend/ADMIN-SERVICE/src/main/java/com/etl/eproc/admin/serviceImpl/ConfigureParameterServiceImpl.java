package com.etl.eproc.admin.serviceImpl;

import com.etl.eproc.admin.dto.*;
import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.*;
import com.etl.eproc.admin.repository.*;
import com.etl.eproc.admin.serviceI.ConfigureParameterService;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import java.text.ParseException;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ConfigureParameterServiceImpl implements ConfigureParameterService {

    @Autowired
    private ModelMapper mapper;

    @Autowired
    private ConfigureParameterRepository configureParameterRepository;
    @Autowired
    private AuctionCenterRepository auctionCenterRepository;

    @Autowired
    private UserLoginRepository userLoginRepository;
    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;
    @Autowired
    private EntityManager entityManager;
    @Override
    public ApiResponse<?> createConfigureParameter(ConfigureParameterDto configureParameterDto) throws ParseException {

        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin","userId",1));
        TblAuctionCenter tblAuctionCenter1 = auctionCenterRepository.findById((long)configureParameterDto.getAuctionCenterId()).get();
        List<TblConfigureParameter> byAuctionCenterId = configureParameterRepository.findByAuctionCenterId(configureParameterDto.getAuctionCenterId());

        if(configureParameterDto.getCatalogClosingDay() < configureParameterDto.getCatalogPublishingDay()) {

                if (byAuctionCenterId.size() == 0) {

                    TblAuctionCenter tblAuctionCenter = auctionCenterRepository.findById((long) configureParameterDto.getAuctionCenterId()).orElseThrow(
                            () -> new ResourceNotFoundException("Auction Center", "auctionCenterId", configureParameterDto.getAuctionCenterId())
                    );

                    TblConfigureParameter configureParameter = new TblConfigureParameter();
                    configureParameter.setAuctionCenter(tblAuctionCenter);
                    configureParameter.setCatalogClosingDay(configureParameterDto.getCatalogClosingDay());
                    configureParameter.setCatalogPublishingDay(configureParameterDto.getCatalogPublishingDay());
                    configureParameter.setBuyersPromptDays(configureParameterDto.getBuyersPromptDays());
                    configureParameter.setSellersPromptDay(configureParameterDto.getSellersPromptDay());
                    configureParameter.setIntervalMin(configureParameterDto.getIntervalMin());
                    configureParameter.setIsActive(configureParameterDto.getIsActive());
                    configureParameter.setCreatedBy(tblUserLogin);
                    configureParameter.setCreatedOn(configureParameterRepository.getServerDateTime());
                    TblConfigureParameter con = configureParameterRepository.save(configureParameter);
                    ConfigureParameterSearchDto configureParameterSearchDto = mapToDto(con);


                    if (configureParameterDto.getUploadDocumentContent() != null) {
                        int i = 0;
                        for (String DocumenName:configureParameterDto.getUploadDocumentName()) {
                            UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                            uploadDocumentConfDto.setRemarks(configureParameterDto.getUploadDocumentRemarks());
                            uploadDocumentConfDto.setTableID(configureParameter.getConfigParaId());
                            
                            uploadDocumentConfDto.setFlag(1);
                            uploadDocumentConfDto.setStatus(1);
                            uploadDocumentConfDto.setIsActive(1);
                            uploadDocumentConfDto.setDocumentSize(configureParameterDto.getUploadDocumentSize());
                            uploadDocumentConfDto.setTableName("tbl_ConfigureParameter");
                            uploadDocumentConfDto.setFolderName("Configure Parameter");
                            uploadDocumentConfDto.setUploadDocumentName(DocumenName);
                            uploadDocumentConfDto.setUploadDocumentContent(configureParameterDto.getUploadDocumentContent()[i]);
                            TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                            i++;
                        }
                    }

                    return new ApiResponse<>("Configure Parameter created successfully", 201, configureParameterSearchDto);
                }
                return  new ApiResponse<>("Configure Parameter  already Exists for this Auction Center", 400, null);

        }
        return new ApiResponse<>("Catalog Closing Date < catalog publishing date", 400, null);
    }


    @Override
    public ApiResponse<?> getAllConfigureParameter() {
        List<TblConfigureParameter> configureParameters = configureParameterRepository.findAll();

        List<ConfigureParameterSearchDto> collect = configureParameters.stream().map(
                tblConfigureParameter -> {
                    ConfigureParameterSearchDto configureParameterSearchDto=new ConfigureParameterSearchDto();
                    TblAuctionCenter auctionCenter = tblConfigureParameter.getAuctionCenter();
                    configureParameterSearchDto.setConfigParaId(tblConfigureParameter.getConfigParaId());
                    configureParameterSearchDto.setAuctionCenterName(auctionCenter.getAuctionCenterName());
                    configureParameterSearchDto.setCatalogClosingDay(tblConfigureParameter.getCatalogClosingDay());
                    configureParameterSearchDto.setCatalogPublishingDay(tblConfigureParameter.getCatalogPublishingDay());
                    configureParameterSearchDto.setSellersPromptDay(tblConfigureParameter.getSellersPromptDay());
                    configureParameterSearchDto.setBuyersPromptDays(tblConfigureParameter.getBuyersPromptDays());
                    configureParameterSearchDto.setIntervalMin(tblConfigureParameter.getIntervalMin());
                    return configureParameterSearchDto;
                }
        ).collect(Collectors.toList());

        return new ApiResponse<List<ConfigureParameterSearchDto>>("getAll Configure Parameter successfully" ,200,collect);
    }


    @Override
    public ApiResponse<?> updateConfigureParameter(ConfigureParameterDto configureParameterDto) {
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin","userId",1));
        TblAuctionCenter tblAuctionCenter = auctionCenterRepository.findById((long)configureParameterDto.getAuctionCenterId()).orElseThrow(
                () -> new ResourceNotFoundException("Auction Center", "auctionCenterId",configureParameterDto.getAuctionCenterId())
        );

        if(configureParameterDto.getCatalogClosingDay() < configureParameterDto.getCatalogPublishingDay()) {

            if(configureParameterDto.getSellersPromptDay() > configureParameterDto.getBuyersPromptDays()) {
            TblConfigureParameter configureParameter = configureParameterRepository.findById(configureParameterDto.getConfigParaId()).orElseThrow(
                    () -> new ResourceNotFoundException("Configure Parameter", "configParaId", configureParameterDto.getConfigParaId())
            );
            configureParameter.setAuctionCenter(tblAuctionCenter);
            configureParameter.setCatalogClosingDay(configureParameterDto.getCatalogClosingDay());
            configureParameter.setCatalogPublishingDay(configureParameterDto.getCatalogPublishingDay());
            configureParameter.setBuyersPromptDays(configureParameterDto.getBuyersPromptDays());
            configureParameter.setSellersPromptDay(configureParameterDto.getSellersPromptDay());
            configureParameter.setIntervalMin(configureParameterDto.getIntervalMin());
            configureParameter.setIsActive(configureParameterDto.getIsActive());
            configureParameter.setUpdatedBy(tblUserLogin);
            configureParameter.setUpdatedOn(configureParameterRepository.getServerDateTime());
            TblConfigureParameter con = configureParameterRepository.save(configureParameter);
            ConfigureParameterSearchDto configureParameterSearchDto = mapToDto(con);
            configureParameterSearchDto.setAuctionCenterName(tblAuctionCenter.getAuctionCenterName());

                if (configureParameterDto.getUploadDocumentContent() != null) {
                    int i = 0;
                    for (String DocumenName:configureParameterDto.getUploadDocumentName()) {
                        UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                        uploadDocumentConfDto.setRemarks(configureParameterDto.getUploadDocumentRemarks());
                        uploadDocumentConfDto.setTableID(configureParameter.getConfigParaId());
                        
                        uploadDocumentConfDto.setFlag(1);
                        uploadDocumentConfDto.setStatus(1);
                        uploadDocumentConfDto.setIsActive(1);
                        uploadDocumentConfDto.setDocumentSize(configureParameterDto.getUploadDocumentSize());
                        uploadDocumentConfDto.setTableName("tbl_ConfigureParameter");
                        uploadDocumentConfDto.setFolderName("Configure Parameter");
                        uploadDocumentConfDto.setUploadDocumentName(DocumenName);
                        uploadDocumentConfDto.setUploadDocumentContent(configureParameterDto.getUploadDocumentContent()[i]);
                        TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                        i++;
                    }
                }
            return new ApiResponse<>("Configure Parameter Updated successfully", 201, configureParameterSearchDto);
            }
            return  new ApiResponse<>("Buyer's Prompt Date < Seller's Prompt Date", 400, null);
        }
        return new ApiResponse("success",200,null);
    }

    @Override
    public ApiResponse<?> findConfigureParameterId(int configParaId) {
        TblConfigureParameter configureParameter = configureParameterRepository.findById(configParaId).orElseThrow(
                () -> new ResourceNotFoundException("Configure Parameter", "configParaId", configParaId)
        );
        ConfigureParameterSearchDto configureParameterSearchDto = mapToDto(configureParameter);
        TblAuctionCenter auctionCenter = configureParameter.getAuctionCenter();
        configureParameterSearchDto.setAuctionCenterName(auctionCenter.getAuctionCenterName());
        return  new ApiResponse<ConfigureParameterSearchDto>("Configure Parameter get by Id successfully" ,200,configureParameterSearchDto);
    }

    @Override
    public ApiResponse<?> searchConfigureParameterPageable(int isActive, int offset, int page) {

        Pageable pageable= PageRequest.of(page,offset);
        Optional<List<TblConfigureParameter>> list = configureParameterRepository.findAllByIsActive(isActive, pageable);
        if(!list.isEmpty() && list.isPresent()){
            List<ConfigureParameterSearchDto> dtos=list.get().stream().map(
                    tblConfigureParameter -> {
                        ConfigureParameterSearchDto dto=new ConfigureParameterSearchDto();
                        TblAuctionCenter auctionCenter = tblConfigureParameter.getAuctionCenter();
                        dto.setConfigParaId(tblConfigureParameter.getConfigParaId());
                        dto.setAuctionCenterName(auctionCenter.getAuctionCenterName());
                        dto.setCatalogClosingDay(tblConfigureParameter.getCatalogClosingDay());
                        dto.setCatalogPublishingDay(tblConfigureParameter.getCatalogPublishingDay());
                        dto.setBuyersPromptDays(tblConfigureParameter.getBuyersPromptDays());
                        dto.setSellersPromptDay(tblConfigureParameter.getSellersPromptDay());
                        return dto;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse("success",200,dtos);
        }

        return new ApiResponse("success",200,null);
    }

    @Override
    public ApiResponse<?> searchConfigureParameter(ConfigureParameterSearchDto configureParameterSearchDto) {


        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appmaster.Get_tbl_ConfigureParameter_Search")
                .registerStoredProcedureParameter("@V_auctionCenterName",String.class, ParameterMode.IN)

                .setParameter("@V_auctionCenterName",configureParameterSearchDto.getAuctionCenterName());

        List<Object[]> executeAuction = storedProcedureQuery.getResultList();
        List<ConfigureParameterSearchDto> configureParameterSearchDtos = executeAuction.stream().toList().stream().map(
                objects -> {
                    ConfigureParameterSearchDto configureParameterSearchDto1 = new ConfigureParameterSearchDto();
                    configureParameterSearchDto1.setConfigParaId(Integer.parseInt(objects[0].toString()));
                    configureParameterSearchDto1.setAuctionCenterName((String) objects[1]);
                    configureParameterSearchDto1.setCatalogClosingDay(Integer.parseInt(objects[2].toString()));
                    configureParameterSearchDto1.setCatalogPublishingDay(Integer.parseInt(objects[3].toString()));
                    configureParameterSearchDto1.setBuyersPromptDays(Integer.parseInt(objects[4].toString()));
                    configureParameterSearchDto1.setSellersPromptDay(Integer.parseInt(objects[5].toString()));

                    configureParameterSearchDto1.setIsActive((Boolean) objects[6] == true ? 1 : 0);
                    return configureParameterSearchDto1;
                }
        ).collect(Collectors.toList());
        return new ApiResponse<List<ConfigureParameterSearchDto>>("getAll Success Auction",200 ,configureParameterSearchDtos);
    }

    private ConfigureParameterSearchDto mapToDto(TblConfigureParameter configureParameter) {
        return mapper.map(configureParameter,ConfigureParameterSearchDto.class);
    }

    private TblConfigureParameter mapToEntity(ConfigureParameterDto configureParameterDto) {
        return mapper.map(configureParameterDto,TblConfigureParameter.class);
    }
}