package com.etl.eproc.admin.repository;

import com.etl.eproc.admin.model.TblBankAccountDetail;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface BankAccountDetailRepository extends JpaRepository<TblBankAccountDetail,Long> {

    public boolean existsByBankAccountNumber(Long bankAccountNumber);

    public boolean existsByEmail(String email);

    public boolean existsByContactNumber(Long contactNumber);

    public boolean existsByAuctionCenterId(int auctionCenterId);

    Optional<List<TblBankAccountDetail>> findAllByIsActive(int isActive, Pageable pageable);
}
