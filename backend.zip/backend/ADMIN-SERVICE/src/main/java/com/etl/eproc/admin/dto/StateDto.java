package com.etl.eproc.admin.dto;

import lombok.*;

import javax.validation.constraints.NotEmpty;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StateDto {

    private Long stateId;
    @NotEmpty(message = "please enter State name")
    private String stateName;
    @NotEmpty(message = "please enter State code")
    private String stateCode;
    @NotEmpty(message = "please enter stateInitial")
    private String stateInitial;
    private int isActive;
    private String uploadDocumentRemarks;
    private String[] uploadDocumentContent;
    private String[] uploadDocumentName;
    private String uploadDocumentSize;
}
