package com.etl.eproc.admin.serviceImpl;

import com.etl.eproc.admin.dto.*;

import com.etl.eproc.admin.exception.ResourceNotFoundException;
import com.etl.eproc.admin.model.*;
import com.etl.eproc.admin.repository.*;
import com.etl.eproc.admin.serviceI.SPUMasterService;
import com.etl.eproc.admin.serviceI.UploadDocumentConfService;
import com.etl.eproc.admin.util.ApiResponse;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class SPUMasterServiceImpl implements SPUMasterService {
    @Autowired
    private EntityManager entityManager;

    @Autowired
    private UploadDocumentConfService uploadDocumentConfService;

    @Autowired
    private AuctionCenterRepository auctionCenterRepository;
    @Autowired
    private GradeRepository gradeRepository;
    @Autowired
    private TeaTypeRepository teaTypeRepository;
    @Autowired
    private ModelMapper mapper;
    @Autowired
    private SPUMasterRepository spuMasterRepository;

    @Autowired
    private UserLoginRepository userLoginRepository;



    @Override
    public ApiResponse<?> createSPUMaster(SPUMasterDto spuMasterDto) {
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));

        List<TblSPUMaster> bySPUQuantity = spuMasterRepository.findBySPUQuantity(spuMasterDto.getSpuQuantity());

        if (bySPUQuantity.size()==0) {

            TblSPUMaster tblSPUMaster1 = new TblSPUMaster();
            TblAuctionCenter tblAuctionCenter = auctionCenterRepository.findById((long)spuMasterDto.getAuctionCenterId()).orElseThrow(
                    () -> new ResourceNotFoundException("AuctionCenter", "auctionCenterId", spuMasterDto.getAuctionCenterId())
            );
            TblGrade tblGrade = gradeRepository.findById((long)spuMasterDto.getGradeId()).orElseThrow(
                    () -> new ResourceNotFoundException("Grade", "gradeId", spuMasterDto.getGradeId())
            );
            TblTeaType teaType = teaTypeRepository.findById(spuMasterDto.getTeaTypeId()).orElseThrow(
                    () -> new ResourceNotFoundException("TeaType", "teaTypeId", spuMasterDto.getTeaTypeId())
            );

            tblSPUMaster1.setAuctionCenter(tblAuctionCenter);
            tblSPUMaster1.setTblGrade(tblGrade);
            tblSPUMaster1.setTblTeaType(teaType);
            tblSPUMaster1.setSpuQuantity(spuMasterDto.getSpuQuantity());
            tblSPUMaster1.setManufacturingPeriod(spuMasterDto.getManufacturingPeriod());
            tblSPUMaster1.setMinLotSize(spuMasterDto.getMinLotSize());
            tblSPUMaster1.setFactoryAnnualCapacity(spuMasterDto.getFactoryAnnualCapacity());
            tblSPUMaster1.setIsActive(1);
            tblSPUMaster1.setCreatedBy(tblUserLogin);
            tblSPUMaster1.setCreatedOn(spuMasterRepository.getServerDateTime());
            TblSPUMaster tblSPUMaster = spuMasterRepository.save(tblSPUMaster1);
            SPUMasterSearchDto spuMasterSearchDto = mapToDto1(tblSPUMaster);
            spuMasterSearchDto.setAuctionCenterName(tblAuctionCenter.getAuctionCenterName());
            spuMasterSearchDto.setTeaTypeName(teaType.getTeaTypeName());
            spuMasterSearchDto.setGradeName(tblGrade.getGradeName());
            if (spuMasterDto.getUploadDocumentContent() != null) {
                int i = 0;
                for (String DocumenName:spuMasterDto.getUploadDocumentName()) {
                    UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                    uploadDocumentConfDto.setRemarks(spuMasterDto.getUploadDocumentRemarks());
                    uploadDocumentConfDto.setTableID(tblSPUMaster1.getSpuMasterId());
                    uploadDocumentConfDto.setFlag(1);
                    uploadDocumentConfDto.setStatus(1);
                    uploadDocumentConfDto.setIsActive(1);
                    uploadDocumentConfDto.setDocumentSize(spuMasterDto.getUploadDocumentSize());
                    uploadDocumentConfDto.setTableName("tbl_SPUMaster");
                    uploadDocumentConfDto.setFolderName("SPUMaster");
                    uploadDocumentConfDto.setUploadDocumentName(DocumenName);
                    uploadDocumentConfDto.setUploadDocumentContent(spuMasterDto.getUploadDocumentContent()[i]);
                    TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                    i++;
                }
            }

            return new ApiResponse<SPUMasterSearchDto>("SPU created successfully", 200, spuMasterSearchDto);
        } else  {
            return new ApiResponse<AuctionCenterDto>("SPU already exists", 400, null);
        }

    }


    @Override
    public ApiResponse<?> getAllSPUMaster() {
        try {
            List<TblSPUMaster> tblSPUMaster1 = spuMasterRepository.findAll();
            List<SPUMasterSearchDto> collect = tblSPUMaster1.stream().map(
                    tblSPUMaster -> {
                        SPUMasterSearchDto dto= new   SPUMasterSearchDto();
                        dto.setSpuMasterId(tblSPUMaster.getSpuMasterId());
                        dto.setSPUQuantity(tblSPUMaster.getSpuQuantity());
                        dto.setFactoryAnnualCapacity(tblSPUMaster.getFactoryAnnualCapacity());
                        dto.setManufacturingPeriod(tblSPUMaster.getManufacturingPeriod());
                        dto.setMinLotSize(tblSPUMaster.getMinLotSize());
                        TblAuctionCenter auctionCenter = tblSPUMaster.getAuctionCenter();
                        dto.setAuctionCenterName(auctionCenter.getAuctionCenterName());
                        TblTeaType tblTeaType = tblSPUMaster.getTblTeaType();
                        dto.setTeaTypeName(tblTeaType.getTeaTypeName());
                        TblGrade tblGrade = tblSPUMaster.getTblGrade();
                        dto.setGradeName(tblGrade.getGradeName());
                        return dto;
                    }
            ).collect(Collectors.toList());

            return  new ApiResponse<>("get All SPUMaster " ,200,collect) ;
        }catch (Exception e){
            return  new ApiResponse<>(e.getMessage(),500,null) ;
        }

    }

    @Override
    public ApiResponse<?> updateSPUMaster(SPUMasterDto spuMasterDto) {
        TblUserLogin tblUserLogin = userLoginRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException("TblUserLogin", "userId", 1));

            TblAuctionCenter tblAuctionCenter = auctionCenterRepository.findById((long)spuMasterDto.getAuctionCenterId()).orElseThrow(
                    () -> new ResourceNotFoundException("AuctionCenter", "auctionCenterId", spuMasterDto.getAuctionCenterId())
            );
            TblGrade tblGrade = gradeRepository.findById((long)spuMasterDto.getGradeId()).orElseThrow(
                    () -> new ResourceNotFoundException("Grade", "gradeId", spuMasterDto.getGradeId())
            );
            TblTeaType teaType = teaTypeRepository.findById(spuMasterDto.getTeaTypeId()).orElseThrow(
                    () -> new ResourceNotFoundException("TeaType", "teaTypeId", spuMasterDto.getTeaTypeId())
            );
            TblSPUMaster tblSPUMaster2 = spuMasterRepository.findById(spuMasterDto.getSpuMasterId()).orElseThrow(
                    () -> new ResourceNotFoundException("SPUMaster", "spuMasterId", spuMasterDto.getSpuMasterId())
            );

            tblSPUMaster2.setAuctionCenter(tblAuctionCenter);
            tblSPUMaster2.setTblGrade(tblGrade);
            tblSPUMaster2.setTblTeaType(teaType);
            tblSPUMaster2.setSpuQuantity(spuMasterDto.getSpuQuantity());
            tblSPUMaster2.setManufacturingPeriod(spuMasterDto.getManufacturingPeriod());
            tblSPUMaster2.setMinLotSize(spuMasterDto.getMinLotSize());
            tblSPUMaster2.setFactoryAnnualCapacity(spuMasterDto.getFactoryAnnualCapacity());
            tblSPUMaster2.setIsActive(1);
            tblSPUMaster2.setUpdatedBy(tblUserLogin);
            tblSPUMaster2.setUpdatedOn(spuMasterRepository.getServerDateTime());
            TblSPUMaster tblSPUMaster = spuMasterRepository.save(tblSPUMaster2);
            SPUMasterSearchDto spuMasterSearchDto = mapToDto1(tblSPUMaster);
            spuMasterSearchDto.setAuctionCenterName(tblAuctionCenter.getAuctionCenterName());
            spuMasterSearchDto.setTeaTypeName(teaType.getTeaTypeName());
            spuMasterSearchDto.setGradeName(tblGrade.getGradeName());


        if (spuMasterDto.getUploadDocumentContent() != null) {
            int i = 0;
            for (String DocumenName:spuMasterDto.getUploadDocumentName()) {
                UploadDocumentConfDto uploadDocumentConfDto = new UploadDocumentConfDto();
                uploadDocumentConfDto.setRemarks(spuMasterDto.getUploadDocumentRemarks());
                uploadDocumentConfDto.setTableID(tblSPUMaster2.getSpuMasterId());
                uploadDocumentConfDto.setFlag(1);
                uploadDocumentConfDto.setStatus(1);
                uploadDocumentConfDto.setIsActive(1);
                uploadDocumentConfDto.setDocumentSize(spuMasterDto.getUploadDocumentSize());
                uploadDocumentConfDto.setTableName("tbl_SPUMaster");
                uploadDocumentConfDto.setFolderName("SPUMaster");
                uploadDocumentConfDto.setUploadDocumentName(DocumenName);
                uploadDocumentConfDto.setUploadDocumentContent(spuMasterDto.getUploadDocumentContent()[i]);
                TblUploadDocumentConf tblUploadDocumentConf = uploadDocumentConfService.uploadDocument(uploadDocumentConfDto);
                i++;
            }
        }
            return new ApiResponse<SPUMasterSearchDto>("SPU updated successfully", 200, spuMasterSearchDto);

    }

    @Override
    public ApiResponse<?> findSPUMasterById(int spuMasterId) {
        TblSPUMaster tblSPUMaster = spuMasterRepository.findById(spuMasterId).orElseThrow(
                () -> new ResourceNotFoundException("SPUMaster", "spuMasterId", spuMasterId)
        );
        SPUMasterSearchDto spuMasterSearchDto = mapToDto1(tblSPUMaster);
        TblAuctionCenter auctionCenter = tblSPUMaster.getAuctionCenter();
        spuMasterSearchDto.setAuctionCenterName(auctionCenter.getAuctionCenterName());
        TblTeaType tblTeaType = tblSPUMaster.getTblTeaType();
        spuMasterSearchDto.setTeaTypeName(tblTeaType.getTeaTypeName());
        TblGrade tblGrade = tblSPUMaster.getTblGrade();
        spuMasterSearchDto.setGradeName(tblGrade.getGradeName());
        return  new ApiResponse<>("get By  SPUMaster" ,200,spuMasterSearchDto) ;
    }

    @Override
    public ApiResponse<?> searchSPUMasterPageable(int isActive, int offset, int page) {

        Pageable pageable= PageRequest.of(page,offset);
        Optional<List<TblSPUMaster>> list =spuMasterRepository.findAllByIsActive(isActive,pageable);
        if(!list.isEmpty() && list.isPresent()){
            List<SPUMasterSearchDto> dtos=list.get().stream().map(
                    tblSPUMaster -> {
                        SPUMasterSearchDto dto= new SPUMasterSearchDto();
                        dto.setSpuMasterId(tblSPUMaster.getSpuMasterId());
                       dto.setSPUQuantity(tblSPUMaster.getSpuQuantity());
                       dto.setFactoryAnnualCapacity(tblSPUMaster.getFactoryAnnualCapacity());
                       dto.setManufacturingPeriod(tblSPUMaster.getManufacturingPeriod());
                       dto.setMinLotSize(tblSPUMaster.getMinLotSize());
                        TblAuctionCenter auctionCenter = tblSPUMaster.getAuctionCenter();
                        dto.setAuctionCenterName(auctionCenter.getAuctionCenterName());
                        TblTeaType tblTeaType = tblSPUMaster.getTblTeaType();
                        dto.setTeaTypeName(tblTeaType.getTeaTypeName());
                        TblGrade tblGrade = tblSPUMaster.getTblGrade();
                        dto.setGradeName(tblGrade.getGradeName());
                        return dto;
                    }
            ).collect(Collectors.toList());
            return new ApiResponse("success",200,dtos);
        }

        return new ApiResponse("success",200,null);
    }

    @Override
    public ApiResponse<?> searchSPUMaster(SPUMasterSearchDto spuMasterDto) {

        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("appmaster.Get_tbl_SPUMaster_Search")
                .registerStoredProcedureParameter("@V_auctionCenterName",String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_teaTypeName",String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("@V_gradeName",String.class, ParameterMode.IN)
                .setParameter("@V_auctionCenterName",spuMasterDto.getAuctionCenterName())
                .setParameter("@V_teaTypeName",spuMasterDto.getTeaTypeName())
                .setParameter("@V_gradeName",spuMasterDto.getGradeName());

        List<Object[]> execute = storedProcedureQuery.getResultList();
        List<SPUMasterSearchDto> spuMasterDto1 = execute.stream().map(
                objects ->{
                    SPUMasterSearchDto spuMasterDto2 = new SPUMasterSearchDto();
                    spuMasterDto2.setSpuMasterId(Integer.parseInt( objects[0].toString()));
                    spuMasterDto2.setAuctionCenterName((String) objects[1]);
                    spuMasterDto2.setTeaTypeName((String) objects[2]);
                    spuMasterDto2.setGradeName((String) objects[3]);
                    spuMasterDto2.setManufacturingPeriod((String) objects[4]);
                    spuMasterDto2.setMinLotSize((String) objects[5]);
                    spuMasterDto2.setFactoryAnnualCapacity((String) objects[6]);
                    spuMasterDto2.setSPUQuantity((String) objects[7]);
                    spuMasterDto2.setIsActive((Boolean)objects[8]==true?1:0);
                    return spuMasterDto2;
                }
        ).collect(Collectors.toList());
        return new ApiResponse<List<SPUMasterSearchDto>>("getAll Success",200 ,spuMasterDto1);
    }


    private TblSPUMaster mapToEntity(SPUMasterDto spuMasterDto) {
        return  mapper.map(spuMasterDto,TblSPUMaster.class);
    }


    private SPUMasterSearchDto mapToDto1(TblSPUMaster tblSPUMaster) {

        return mapper.map(tblSPUMaster, SPUMasterSearchDto.class);
    }
    private SPUMasterDto mapToDto(TblSPUMaster tblSPUMaster) {

        return mapper.map(tblSPUMaster, SPUMasterDto.class);
    }
}
