package com.etl.eproc.admin.repository;



import com.etl.eproc.admin.model.TblSubTeaType;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface SubTeaTypeRepository extends JpaRepository<TblSubTeaType,Integer> {


    Optional<List<TblSubTeaType>> findAllByIsActive(int isActive, Pageable pageable);

    boolean existsBySubTeaTypeName(String subTeaTypeName);



    @Query(value = "select teaTypeId from appmaster.tbl_TeaType where teaTypeName=:teaTypeName",nativeQuery = true)
    Integer  findByTeaTypeName(@Param("teaTypeName") String teaTypeName);
    boolean existsBySubTeaTypeCode(String subTeaTypeCode);
    @Query(value = "select GETUTCDATE()",nativeQuery = true)
    Date getServerDateTime();
}
