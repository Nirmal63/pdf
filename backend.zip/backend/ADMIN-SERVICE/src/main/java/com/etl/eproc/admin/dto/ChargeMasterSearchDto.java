package com.etl.eproc.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ChargeMasterSearchDto {
    @Column(name = "@V_chargeMasterName")
    private long chargeMasterId;
    private String chargesName;
    private String chargeCodeId;
    private Integer isActive;

}
