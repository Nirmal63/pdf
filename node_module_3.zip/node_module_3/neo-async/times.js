'use strict';

module.exports = require('./async').times;
