module.exports = {
  css: require('./css'),
}
